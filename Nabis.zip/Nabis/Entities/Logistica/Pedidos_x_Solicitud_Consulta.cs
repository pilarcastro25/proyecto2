﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
    public class Pedidos_x_Solicitud_Consulta
    {


        public string IdEb { get; set; }
        public int? RepLegalIdentidad { get; set; }
        public string RepresentanteLegal { get; set; }
        public int? RepLegalFijo { get; set; }
        public long? RepLegalCelular { get; set; }
        public string DireccionPrincipal { get; set; }
        public string CiudadPrincipal { get; set; }
        public string BarrioPrincipal { get; set; }
        public string CodBarrioPrincipal { get; set; }
        public decimal IdPedido { get; set; }
        public string DireccionEntrega { get; set; }
        public string Coddane { get; set; }
        public string Contacto1numident { get; set; }
        public string Contacto1nombre { get; set; }
        public int? Contacto1fijoind { get; set; }
        public long? Contacto1celular { get; set; }
        public string Contacto2numident { get; set; }
        public string Contacto2nombre { get; set; }
        public int? Contacto2fijoind { get; set; }
        public long? Contacto2celular { get; set; }
        public string Contacto3numident { get; set; }
        public string Contacto3nombre { get; set; }
        public int? Contacto3fijoind { get; set; }
        public long? Contacto3celular { get; set; }
        public string Notas { get; set; }
        public string Estado { get; set; }
        public decimal IdEstado { get; set; }


        public Pedidos_x_Solicitud_Consulta()
        {

        }
        public Pedidos_x_Solicitud_Consulta(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor del registro no puede ser nullo o vacio.");
            }
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.RepLegalIdentidad = rowInfo.Field<int?>("REP_LEGAL_IDENTIDAD");
            this.RepresentanteLegal = rowInfo.Field<string>("REPRESENTANTE_LEGAL");
            this.RepLegalFijo = rowInfo.Field<int?>("REP_LEGAL_FIJO");
            this.RepLegalCelular = rowInfo.Field<long?>("REP_LEGAL_CELULAR");
            this.DireccionPrincipal = rowInfo.Field<string>("DIRECCION_PRINCIPAL");
            this.CiudadPrincipal = rowInfo.Field<string>("CIUDAD_PRINCIPAL");
            this.BarrioPrincipal = rowInfo.Field<string>("BARRIO_PRINCIPAL");
            this.CodBarrioPrincipal = rowInfo.Field<string>("COD_BARRIO_PRINCIPAL");
            this.IdPedido = rowInfo.Field<decimal>("ID_PEDIDO");
            this.DireccionEntrega = rowInfo.Field<string>("DIRECCION_ENTREGA");
            this.Coddane = rowInfo.Field<string>("Coddane");
            this.Contacto1numident = rowInfo.Field<string>("contacto1NumIdent");
            this.Contacto1nombre = rowInfo.Field<string>("contacto1Nombre");
            this.Contacto1fijoind = rowInfo.Field<int?>("contacto1FijoInd");
            this.Contacto1celular = rowInfo.Field<long?>("contacto1Celular");
            this.Contacto2numident = rowInfo.Field<string>("contacto2NumIdent");
            this.Contacto2nombre = rowInfo.Field<string>("contacto2Nombre");
            this.Contacto2fijoind = rowInfo.Field<int?>("contacto2FijoInd");
            this.Contacto2celular = rowInfo.Field<long?>("contacto2Celular");
            this.Contacto3numident = rowInfo.Field<string>("contacto3NumIdent");
            this.Contacto3nombre = rowInfo.Field<string>("contacto3Nombre");
            this.Contacto3fijoind = rowInfo.Field<int?>("contacto3FijoInd");
            this.Contacto3celular = rowInfo.Field<long?>("contacto3Celular");
            this.Notas = rowInfo.Field<string>("NOTAS");
            this.Estado = rowInfo.Field<string>("ESTADO");
            this.IdEstado = rowInfo.Field<decimal>("ID_ESTADO");
        }


    }
}
