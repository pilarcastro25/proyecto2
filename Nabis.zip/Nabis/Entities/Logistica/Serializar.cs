﻿namespace Nabis_ET.Logistica
{
	public class Serializar
	{
		public int? IdArticulo { get; set; }
		public int? IdArticuloSim { get; set; }
		public string IdEb { get; set; }
		public int? IdLinea { get; set; }
		public int? IdPedido { get; set; }
		public int? IdPedidoDetalle { get; set; }
		public string ImeiEquipo { get; set; }
		public string ImeiSim { get; set; }
		public string TipoArticulo { get; set; }
		public string TipoPedido { get; set; }
		public string User { get; set; }
	}
}