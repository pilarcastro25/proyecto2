﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
    public class PendientesAsignarL
    {
        public string IdEb { get; set; }
        public int IdPedido { get; set; }
        public int CantidadSolicitudes { get; set; }
        public string TipoNegocio { get; set; }
        public string CanalVendedor { get; set; }
        public int IdGrupo { get; set; }
        public string Convenio { get; set; }
        public DateTime FechaAdicion { get; set; }
        public DateTime FechaSerializado { get; set; }
    }
}
