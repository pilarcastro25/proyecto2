﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
    public class ArticulosCantidad
    {
        public string IdEb { get; set; }
        public decimal IdPedido { get; set; }
        public decimal? IdArticulo { get; set; }
        public string Articulo { get; set; }
        public int CantidadEquipos { get; set; }
    }
}
