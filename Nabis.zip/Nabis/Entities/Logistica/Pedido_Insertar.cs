﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
   public class Pedido_Insertar
    {
        public string UsrIdAdicion { get; set; }
        public string IdEb { get; set; }
        public int CantLineasNegocio { get; set; }
        public int CantArticulos { get; set; }
        public string CodigoDane { get; set; }
        public string DireccionEntrega { get; set; }
        public string NumIdentContactoAut { get; set; }
        public string NomContactoAut { get; set; }
        public int ? NumFijoContactoAut { get; set; }
        public long CelularContactoAut { get; set; }
        public string NumIdentContactoAut2 { get; set; }
        public string NomContactoAut2 { get; set; }
        public int? NumFijoContactoAut2 { get; set; }
        public long? CelularContactoAut2 { get; set; }
        public string NumIdentContactoAut3 { get; set; }
        public string NomContactoAut3 { get; set; }
        public int? NumFijoContactoAut3 { get; set; }
        public long? CelularContactoAut3 { get; set; } 
    }
}
