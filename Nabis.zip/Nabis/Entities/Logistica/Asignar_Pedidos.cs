﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
    public class Asignar_Pedidos
    {
        public string IdEb { get; set; }
        public int? RepLegalIdentidad { get; set; }
        public string RepresentanteLegal { get; set; }
        public int? RepLegalFijo { get; set; }
        public long? RepLegalCelular { get; set; }
        public string DireccionPrincipal { get; set; }
        public string CiudadPrincipal { get; set; }
        public string BarrioPrincipal { get; set; }
        public string CodBarrioPrincipal { get; set; }
        public decimal IdPedido { get; set; }
        public string DireccionEntrega { get; set; }
        public string DepartamentoMunicipio { get; set; }
        public string Contacto1numident { get; set; }
        public string Contacto1nombre { get; set; }
        public int? Contacto1fijoind { get; set; }
        public long? Contacto1celular { get; set; }
        public string Contacto2numident { get; set; }
        public string Contacto2nombre { get; set; }
        public int? Contacto2fijoind { get; set; }
        public long? Contacto2celular { get; set; }
        public string Contacto3numident { get; set; }
        public string Contacto3nombre { get; set; }
        public int? Contacto3fijoind { get; set; }
        public long? Contacto3celular { get; set; }
        public string Notas { get; set; }
        public string Descripcion { get; set; }
    }
}
