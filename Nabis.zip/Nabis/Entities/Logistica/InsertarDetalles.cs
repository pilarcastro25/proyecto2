﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Nabis_ET.Logistica
{
   public class PedidoLinea
    {
        public int IdPedido { get; set; }
        public char TipoPedido { get; set; }
        public decimal? IdArticulo { get; set; }
        public string NumImei { get; set; }
        public string Procedencia { get; set; }
        public decimal? IdArticuloSim { get; set; }
        public string NumSim { get; set; }
        public int IdLinea { get; set; }
        public long Celular { get; set; }
    }
}
