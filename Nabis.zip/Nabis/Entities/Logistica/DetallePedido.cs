﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Nabis_ET.Logistica
{
    public class DetallePedido
    {
        public string IdEb { get; set; }
        public decimal IdPedido { get; set; }
        public decimal IdPedidoDetalle { get; set; }
        public string TipoPedido { get; set; }
        public long? Celular { get; set; }
        public int? IdLinea { get; set; }
        public decimal? IdArticulo { get; set; }
        public string ArticuloEquipo { get; set; }
        public string NumImei { get; set; }
        public string Procedencia { get; set; }
        public decimal? IdArticuloSim { get; set; }
        public string ArticuloSim { get; set; }
        public string NumSim { get; set; }
        public int IdEstado { get; set; }
        public string Estado { get; set; }
        public string IdEStadoEb { get; set; }

    }
}
