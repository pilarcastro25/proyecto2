﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Logistica
{
    public class Despachar
    {

        public string NumGuiaDespacho { get; set; }
        public string User { get; set; }
        public string IdEb { get; set; }
        public int? IdPedido { get; set; }

    }
}
