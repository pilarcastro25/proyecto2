﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class AlertaCondiciones
    {
        public int       IdCondicion { get; set; }
        public string    Tabla { get; set; }
        public string    Campo { get; set; }
        public string    Operador { get; set; }
        public string    Valor { get; set; }
        public DateTime? Fecha { get; set; }
        public int       IdAlerta { get; set; }
        public bool       Estado { get; set; }
        public string    Usuario { get; set; }

        public string  NombreEstado { get; set; }
        public string  MsgAlerta { get; set; }

    }
}
