﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class CiudadesDane
    {
        public string DepartamentoMunicipio { get; set; }
        public string CodDane { get; set; }
        public string CodDepto { get; set; }
        public string CodMunicipio { get; set; }
        public string CodLocalidad { get; set; }
        public string Departamento { get; set; }
        public string Municipio { get; set; }
        public string TipoCiudad { get; set; }

    }
}
