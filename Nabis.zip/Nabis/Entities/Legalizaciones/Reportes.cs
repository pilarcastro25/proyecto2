﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Reportes
    {
        public string Usuario { get; set; }
        public int Year { get; set; }
        public DateTime FecInicial { get; set; }
        public DateTime fecFinal { get; set; }
        public string NomArchivo { get; set; }
        public int trans { get; set; }

    }
}
