﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Legalizar
    {
        public int      idProducto { get; set; }    // saber si es fija, opc, corpos.
        public string   numGuia { get; set; }       // Número de la guía.
        public int      codAbonado { get; set; }    // código de abonado.
        public int      saldo{ get; set; }          // Saldo pendiente.
        public int      muestra { get; set; }       // Indica si se toma como muestra.
        public int      novedad { get; set; }       // 1= si hay novedad  0=no hay novedad.
        public string   observacion { get; set; }   // observacion de la novedad.
        public string   novedades { get; set; }     // string con los id_causales de novedad concatenados.
    }
}
