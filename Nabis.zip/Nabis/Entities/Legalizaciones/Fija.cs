﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Fija
    {
        public long NumPeticion  { get; set; }
        public DateTime? FecRegistro  { get; set; }
        public DateTime? FecAlta  { get; set; }
        public string Operacion  { get; set; }
        public string ClaseOperacion  { get; set; }
        public string SegmentoCuenta  { get; set; }
        public string Direccion  { get; set; }
        public string Barrio  { get; set; }
        public string Municipio  { get; set; }
        public string Localidad  { get; set; }
        public string Departamento  { get; set; }
        public string NombreCliente  { get; set; }
        public string TipoIdentCliente  { get; set; }
        public string NumIdentCliente  { get; set; }
        public string NumContacto  { get; set; }
        public int? CodVendedor  { get; set; }
        public decimal? NumIdentVendedor  { get; set; }
        public string NomVendedor  { get; set; }
        public string Comercializador  { get; set; }
        public string NombreGrupo  { get; set; }
        public string Multiproducto  { get; set; }
        public int? DifDias  { get; set; }
        public string Rango  { get; set; }
        public int Calidad  { get; set; }
        public DateTime? FecIngreso  { get; set; }
        public string UserIngreso  { get; set; }
        public int? Dia  { get; set; }
        public int? Mes  { get; set; }
        public int? Año  { get; set; }
        public int? NumCaja  { get; set; }
        public string NumGuia  { get; set; }
        public DateTime? FecAsignado  { get; set; }
        public string UserAsignado  { get; set; }
        public bool? Novedad  { get; set; }
        public bool? Muestra  { get; set; }
        public DateTime? FecNovedad  { get; set; }
        public DateTime? FecSolucion  { get; set; }
        public string UsuarioSolucion  { get; set; }
        public string Notas  { get; set; }
        public DateTime? FecLeg  { get; set; }
        public string UserLeg  { get; set; }
        public DateTime? FecEnvio  { get; set; }
        public string UserEnvio  { get; set; }
        public int IdEstado  { get; set; }
        public int IdBolsa  { get; set; }
        public string TipoVenta { get; set; } 
        //---   ---//
        public string NombreInterlocutor { get; set; }
        public string NumIdentInterlocutor { get; set; }
        public string Productos { get; set; }
        public string Estado { get; set; }
        public string User { get; set; }
    }
}
