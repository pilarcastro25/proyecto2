﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class CajasContenidos
    {
        public int IdContenido  { get; set; }
        public string Contenido  { get; set; }
        public int CantMax  { get; set; }
        public string Usuario { get; set; }
    }
}
