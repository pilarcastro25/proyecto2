﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Caja
    {
        public int       NumCaja  { get; set; }
        public int       IdContenido  { get; set; }
        public DateTime? FecIngreso  { get; set; }
        public string    UserIngreso  { get; set; }
        public DateTime? FecCierre  { get; set; }
        public string    UserCierre  { get; set; }
        public int?      Cantidad  { get; set; }
        public int?      MaxCantidad  { get; set; }
        public bool?     Novedad  { get; set; }
        public string    Leibol  { get; set; }
        public int?      Estado  { get; set; }

        //--- Propiedades fuera de la tabla --//

        public int Trans { get; set; }
        public string Vista { get; set; }
        public string Contenido { get; set; }
        public string Usuario { get; set; }
        public string NombreEstado{ get; set; }
    }
}
