﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Alertas
    {
       
        public int      IdAlerta { get; set; }
        public int      IdProducto { get; set; }
        public string   MsgAlerta { get; set; }
        public bool     Estado { get; set; }
        public int      TotalCondiciones { get; set; }
        public DateTime FecCreacion { get; set; }
        public string   Usuario { get; set; }

        public string NombreProducto { get; set; }
        public string NombreEstado { get; set; }
    }
}
