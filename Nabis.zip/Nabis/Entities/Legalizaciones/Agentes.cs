﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Agentes
    {
        public int? CodAgente  { get; set; }
        public string Agente  { get; set; }
        public string Nit  { get; set; }
        public int? IdCanal  { get; set; }
        public bool? IsMovil  { get; set; }
        public bool? IsFija  { get; set; }
        public bool? Activo  { get; set; }

    }
}
