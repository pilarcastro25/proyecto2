﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Ventas_Scl_Ind
    {

        public string    Producto  { get; set; }
        public string    CodMasterD  { get; set; }
        public string    NombreMasterD  { get; set; }
        public DateTime? Fecventa  { get; set; }
        public int?      CodVenta  { get; set; }
        public string    EstadoVenta  { get; set; }
        public string    UsuarioVenta  { get; set; }
        public string    TipoContrato  { get; set; }
        public string    CodCliente  { get; set; }
        public long      CodAbonado  { get; set; }
        public string    TipoIdentCliente  { get; set; }
        public string    DesTippersonaH2  { get; set; }
        public string    NumIdentCliente  { get; set; }
        public string    NumIdentH2  { get; set; }
        public string    NombreCliente  { get; set; }
        public long      Celular  { get; set; }
        public string    CodigoPlan  { get; set; }
        public string    NombrePlan  { get; set; }
        public int?      CargoBasico  { get; set; }
        public string    SituacionAbonado  { get; set; }
        public string    SerialImei  { get; set; }
        public string    Procedencia  { get; set; }
        public string    CodEquipo  { get; set; }
        public string    BodegaEquipo  { get; set; }
        public string    NombreArticulo  { get; set; }
        public string    Gama  { get; set; }
        public string    NumeroIcc  { get; set; }
        public string    Telefono  { get; set; }
        public string    TipCalle  { get; set; }
        public string    NombreCalle  { get; set; }
        public string    DireccionCliente  { get; set; }
        public string    Observacion  { get; set; }
        public string    Zona  { get; set; }
        public string    Depto  { get; set; }
        public string    Distrito  { get; set; }
        public string    TipoComisionista  { get; set; }
        public string    CodigoDealer  { get; set; }
        public string    NombreDealer  { get; set; }
        public int?      CodVendedor  { get; set; }
        public string    NomVendedor  { get; set; }
        public string    Canal  { get; set; }
        public string    NombreGrupo  { get; set; }
        public string    DistritoCliente  { get; set; }
        public string    RegionalCliente  { get; set; }
        public int?      ValorEquipo  { get; set; }
        public int?      SaldoFactura  { get; set; }
        public string    CodPlanServicio  { get; set; }
        public string    PlanServicio  { get; set; }
        public int?      DifDias  { get; set; }
        public string    Rango  { get; set; }
        public string    TipoCliente  { get; set; }
        public DateTime? FecIngreso  { get; set; }
        public string    UserIngreso  { get; set; }
        public int?      Dia  { get; set; }
        public int?      Mes  { get; set; }
        public int?      Año  { get; set; }
        public DateTime? FecAsignado  { get; set; }
        public int?      NumCaja  { get; set; }
        public string    NumGuia  { get; set; }
        public string    UserAsignado  { get; set; }
        public bool?     Novedad  { get; set; }
        public bool?     Muestra  { get; set; }
        public int?      IdBolsa  { get; set; }
        public string    Causales  { get; set; }
        public DateTime? FecLeg  { get; set; }
        public DateTime? FecEnvio  { get; set; }
        public string    UserEnvio  { get; set; }
        public DateTime? FecNovedad  { get; set; }
        public DateTime? FecSolucion  { get; set; }
        public string    Notas  { get; set; }
        public DateTime? FecLegScl  { get; set; }
        public string    UserLegScl  { get; set; }
        public int?      IdEstado  { get; set; }
        public int?      TiempoConsulta  { get; set; }
        public string    Indportabilidad  { get; set; }
        public string    TipoVenta  { get; set; }

        //--- Propiedades fuera de la entidad ---//
        public string    Estado { get; set; }
        public string    Usuario { get; set; }
        public string    ObsNovedad { get; set; }
        public string    Tabla { get; set; }
        public string    VentaCuota { get; set; }
        public string    NumCuotas { get; set; }
        public string    VlrCuota { get; set; }
        public string    VlrFacturaCuota { get; set; }

    }
}
