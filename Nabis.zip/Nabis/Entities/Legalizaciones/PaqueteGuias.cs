﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class PaqueteGuias
    {
        public int IdPaquete { get; set; }
        public int NumPaquete { get; set; }
        public DateTime? FechaIngreso { get; set; }
        public string UserIngreso { get; set; }
        public string Estado { get; set; }
        public string UserAsignado { get; set; }
        public int CantidadGuias { get; set; }
        public DateTime? FechaAsignado { get; set; }
    }
}
