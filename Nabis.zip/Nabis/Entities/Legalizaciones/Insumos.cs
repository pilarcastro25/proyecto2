﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Insumos
    {
        public long Id { get; set; }
        public string NombreInsumo { get; set; }
        public string Detalle { get; set; }
        public DateTime FecCarga { get; set; }
        public string Usuario { get; set; }
    }
}
