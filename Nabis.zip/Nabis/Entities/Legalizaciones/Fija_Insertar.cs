﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Fija_Insertar
    {
        public string Canal { get; set; }
        public string User { get; set; }
        public string Guia { get; set; }
        public long    NumPeticion { get; set; }
        public int    Estado { get; set; } // estado venta al que pasa 2 o 5 novedad
        public int    Calidad { get; set; }
        public string Notas { get; set; }
        public string NumIdentCliente { get; set; }
        public string NombreCliente { get; set; }
        public string DirCliente { get; set; }
        public string NumIdentVendedor { get; set; }
        public bool   Novedad { get; set; }
        public string Causales { get; set; }
        public int    Salida { get; set; } // respuesta del servidor 
    }
}
