﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Ventas_Scl_Ind_Gestion
    {
        public string   Guia { get; set; }      //NÚMERO DE LA GUÍA
        public int      CodAbonado { get; set; }//CÓDIGO DEL ABONADO
        public int      SaldoScl { get; set; } //SALDO PENDIENTE
        public bool      Muestra { get; set; }   //INDICA SI ESTA VENTA FORMA PARTE DE LAS MUESTRAS.
        public bool     Novedad { get; set; }   //BIT DE NOVEDAD 1=NOVEDAD 0=SIN NOVEDAD
        public string   Notas { get; set; }     //OBSERVACION DE LA NOVEDAD
        public string   Causales { get; set; }  //ID DE CAUSALES DE NOVEDAD: LLEGA EN STRING: 1,2,3,4,5
        public string   User { get; set; }
        public int?     ValorSalida{ get; set; }
    }
}
