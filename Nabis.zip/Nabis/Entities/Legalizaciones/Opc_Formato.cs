﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Opc_Formato
    {
        public long IdFormato { get; set; }
        public long NumFormato  { get; set; }
        public string Nit  { get; set; }
        public int? CodVendedor  { get; set; }
        public string NomVendedor  { get; set; }
        public string Canal  { get; set; }
        public string NombreGrupo  { get; set; }
        public string CodComisionista  { get; set; }
        public string TipoComisionista  { get; set; }
        public string CodMaster  { get; set; }
        public string NomMaster  { get; set; }
        public int CantTotal  { get; set; }
        public int PendTotal  { get; set; }
        public DateTime? FecIngreso  { get; set; }
        public string UserIngreso  { get; set; }
        public int? Dia  { get; set; }
        public int? Mes  { get; set; }
        public int? Año  { get; set; }
        public int NumCaja  { get; set; }
        public string NumGuia  { get; set; }
        public DateTime? FecAsignado  { get; set; }
        public string UserAsignado  { get; set; }
        public DateTime? FecCierre  { get; set; }
        public bool Novedad  { get; set; }
        public int? IdBolsa  { get; set; }
        public int  IdEstado  { get; set; }
        public DateTime? FecGestion  { get; set; }
        public DateTime? FecLegalizacion  { get; set; }
        public bool? Penalizado  { get; set; }

        //----    ----//
        public string NombreEstado { get; set; }
        public string Notas { get; set; }
        public int? InRr { get; set; }
        public int? InCp { get; set; }
        public int? InSd { get; set; }
        public int? InLcc { get; set; }
        public int? InCs { get; set; }
        public int? InTotal { get; set; }
        public string Causales { get; set; }

        public string User { get; set; }

    }
}
