﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
     public class Guia
    {
        public int       trans { get; set; }
        public int       idGuia { get; set; }
        public string    guias { get; set; }
        public string    origen{ get; set; }
        public DateTime? entrega { get; set; }
        public DateTime? asignado { get; set; }
        public DateTime? desembalaje { get; set; }
        public string    canal { get; set; }   // userGrupo=canal
        public string    novedad { get; set; }
        public DateTime? cierre { get; set; }
        public string    devolucion { get; set; }
        public int       idPaquete { get; set; }
        public string    user { get; set; }
        public string    userAsignado{ get; set; }
        
    }
}
