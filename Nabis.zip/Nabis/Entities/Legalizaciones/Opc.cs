﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class Opc
    {

        public long         Id  { get; set; }
        public long         NumFormato  { get; set; }
        public long?        Ooss  { get; set; }
        public long?        Celular  { get; set; }
        public long         CodAbonado  { get; set; }
        public int          MesAlta  { get; set; }
        public DateTime?    FechaAltaServicio  { get; set; }
        public string       CodSs  { get; set; }
        public string       DesSs  { get; set; }
        public string       UsuarioActivacionSs  { get; set; }
        public string       CodUsuario  { get; set; }
        public int?         CodVendedor  { get; set; }
        public string       NomVendedor  { get; set; }
        public string       CodComisionista  { get; set; }
        public string       TipoComisionista  { get; set; }
        public string       CodPlanServicio  { get; set; }
        public string       DescripcionServicio  { get; set; }
        public string       Costo  { get; set; }
        public string       TipoIdent  { get; set; }
        public string       NumIdent  { get; set; }
        public string       NomCliente  { get; set; }
        public string       CodPlan  { get; set; }
        public string       NombrePlan  { get; set; }
        public int?         CargoBasico  { get; set; }
        public string       Equipo  { get; set; }
        public string       SerieImei  { get; set; }
        public string       Producto  { get; set; }
        public string       Zona  { get; set; }
        public string       CodMaster  { get; set; }
        public string       NomMaster  { get; set; }
        public string       Canal  { get; set; }
        public string       NombreGrupo  { get; set; }
        public string       GrupoSs  { get; set; }
        public int?         NumFolio  { get; set; }
        public int?         SaldoFactura  { get; set; }
        public string       TipoCliente  { get; set; }
        public string       TablaOrigen  { get; set; }
        public string       TipoOpc  { get; set; }
        public int?         DifDias  { get; set; }
        public string       Rango  { get; set; }
        public DateTime?    FecIngreso  { get; set; }
        public string       UserIngreso  { get; set; }
        public int?         Dia  { get; set; }
        public int?         Mes  { get; set; }
        public int?         Año  { get; set; }
        public DateTime?    FecEnvio  { get; set; }
        public string       UserEnvio  { get; set; }
        public int          IdEstado  { get; set; }
        //---   ---//
        public bool         Ingresado { get; set; }
        public string       User { get; set; }
        public string       IdOpcTmp { get; set; }
        
    }
}
