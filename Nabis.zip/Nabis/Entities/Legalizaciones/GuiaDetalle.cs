﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Legalizaciones
{
    public class GuiaDetalle
    {
        public long         IdPaquete { get; set; }
        public long         idGuia { get; set; }
        public String       guia { get; set; }
        public DateTime?    fecha { get; set; }
        public string       codigoAgente { get; set; }
        public int          idCiudadOrigen { get; set; }
        public string       nota { get; set; }
        public string       novedades { get; set; }
        public int          canal { get; set; } // idcanal = userGrupo
        public int          corp { get; set; }
        public int          ind { get; set; }
        public int          opc { get; set; }
        public int          fija { get; set; }
        public int          muestra { get; set; }
        public int          total { get; set; }
        public string       estado { get; set; }
        public string       usuario { get; set; }
    }
}
