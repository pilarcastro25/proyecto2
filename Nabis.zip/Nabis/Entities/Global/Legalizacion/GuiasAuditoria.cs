﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Legalizacion
{
    public class GuiasAuditoria
    {
        public string user { get; set; }
        public string nombre { get; set; }
        public int? guias { get; set; }
        public int?corp { get; set; }
        public int? ind { get; set; }
        public int? opc { get; set; }
        public int? fija { get; set; }
        public int? muestra { get; set; }
    }
}
