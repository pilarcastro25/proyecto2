﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Legalizacion
{
    public class GuiasCambioVentas
    {
        public int          trans { get; set; }
        public int          id { get; set; }
        public int          numGuia { get; set; }
        public string       producto { get; set; }
        public string       operacion { get; set; }
        public int          cantidad { get; set; }
        public string       usuario { get; set; }
        public DateTime?    fecSolicitud { get; set; }
        public string       estado { get; set; }
        public string       solucion { get; set; }
        public DateTime?    fecSolucion { get; set; }
        public string       user_aprobo { get; set; }
        public string       observacion { get; set; }
    }
}
