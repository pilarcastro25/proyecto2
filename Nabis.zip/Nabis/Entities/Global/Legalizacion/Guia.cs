﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Legalizacion
{
     public class Guia
    {
        public int numGuia { get; set; }
        public int idPaquete { get; set; }
        public string user { get; set; }

        public string guias { get; set; }
    }
}
