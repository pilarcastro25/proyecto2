﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Global
{
    public class CausalET
    {
        public int IdCausal { get; set; }
        public string DescripcionCausal { get; set; }
    }
}
