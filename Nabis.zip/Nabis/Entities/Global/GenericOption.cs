﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Global
{
    public class GenericOption
    {
        public string Id { get; set; }
        public string Value { get; set; }
        public string ValueOfGroup { get; set; }
    }
}
