﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Global
{
    /// <summary>
    /// Representa un usuario de la aplicación
    /// </summary>
    public class User
    {
        public string IdUser { get; set; }
        public int? Cc { get; set; }
        public int? CodVendedor { get; set; }
        public int? CodAgente { get; set; }
        public string NombreAgente { get; set; }
        public string UserLogin { get; set; }
        public string Pass { get; set; }
        public string Nombre { get; set; }
        public string Mail { get; set; }
        public long? Celular { get; set; }
        public int? Extension { get; set; }
        public string HostEquipo { get; set; }
        public string IpEquipo { get; set; }
        public int? HoraIngreso { get; set; }
        public int? HoraSalida { get; set; }
        public string Notas { get; set; }
        public int? NumIntentos { get; set; }
        public DateTime? FecIngreso { get; set; }
        public DateTime? FecMod { get; set; }
        public DateTime? FecRetiro { get; set; }
        public DateTime? FecBloqueo { get; set; }
        public int? IdCanal { get; set; }
        public int? IdTipo { get; set; }
        public int? IdPerfil { get; set; }
        public int? IdRegional { get; set; }
        public int? IdArea { get; set; }
        public int? IdGrupo { get; set; }
        public int? IdEstado { get; set; }
    }
}