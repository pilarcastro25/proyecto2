﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Global
{
    /// <summary>
    /// Clase para almacenar la información del contexto de origen de la petición
    /// </summary>
    public class ExceptionContext
    {
        #region propiedades

        /// <summary>
        /// Usuario autenticado en la app
        /// </summary>
        public string CurrentUser { get; set; }

        /// <summary>
        /// Usuario autenticado en la app
        /// </summary>
        public string CurrentUserIP { get; set; }

        /// <summary>
        /// Usuario autenticado en la app
        /// </summary>
        public string CurrentUserHost { get; set; }

        /// <summary>
        /// Host desde donde se origino la petición. Valores posibles: thor.movistar.com | Backoffice1;
        /// </summary>
        public string CurrentHost { get; set; }

        /// <summary>
        /// Host desde donde se origino la petición. Valores posibles: thor.movistar.com | Backoffice1;
        /// </summary>
        public string CurrentUrl { get; set; }

        /// <summary>
        /// Nombre de Clase o archivo desde donde se origino la petición. Valores posibles: thor.movistar.com | Backoffice1;
        /// </summary>
        public string CurrentFile { get; set; }

        /// <summary>
        /// Nombre del método desde donde se inició o lanzó la petición o script de BD de la falla
        /// </summary>
        public string CurrentMethod { get; set; }

        /// <summary>
        /// Mensaje de Error de la Excepción
        /// </summary>
        public string CurrentErrorMesage { get; set; }

        /// <summary>
        /// Línea desde donde se inició la petición
        /// </summary>
        public int CurrentLine { get; set; }

        /// <summary>
        /// Código de excepción 
        /// </summary>
        public int CurrentCodException { get; set; }

        /// <summary>
        /// Propiedad para almacenar detalles de pila o información complementaria de la excepción
        /// </summary>
        public string CurrentNotas { get; set; }

        #endregion propiedades
    }
}
