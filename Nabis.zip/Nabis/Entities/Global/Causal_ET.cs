﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Global
{
    public class Causal_ET
    {
        public int Proceso_Origen { get; set; }
        public int Proceso_Destino { get; set; }
    }
}
