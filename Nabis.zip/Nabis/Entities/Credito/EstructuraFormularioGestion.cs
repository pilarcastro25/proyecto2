﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class EstructuraFormularioGestion
    {
        public decimal? ID_ETAPA { get; set; }
        public string ETAPA { get; set; }
        public decimal? ID_CATEGORIA { get; set; }
        public string CATEGORIA { get; set; }
        public decimal? ID_CONCEPTO { get; set; }
        public string CONCEPTO { get; set; }
        public decimal? ID_ESTADO_CONCEPTO { get; set; }
        public string ESTADO_CONCEPTO { get; set; }
        public string CONDICIONAL { get; set; }
        public string GENERA_DATA { get; set; }
        public decimal? ID_CAUSAL { get; set; }
        public string CAUSAL { get; set; }

        public EstructuraFormularioGestion()
        {

        }

        public EstructuraFormularioGestion(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser igual a nulo o vacio.");
            }
            this.ID_ETAPA = rowInfo.Field<decimal?>("ID_ETAPA");
            this.ETAPA = rowInfo.Field<string>("ETAPA");
            this.ID_CATEGORIA = rowInfo.Field<decimal?>("ID_CATEGORIA");
            this.CATEGORIA = rowInfo.Field<string>("CATEGORIA");
            this.ID_CONCEPTO = rowInfo.Field<decimal?>("ID_CONCEPTO");
            this.CONCEPTO = rowInfo.Field<string>("CONCEPTO");
            this.ID_ESTADO_CONCEPTO = rowInfo.Field<decimal?>("ID_ESTADO_CONCEPTO");
            this.ESTADO_CONCEPTO = rowInfo.Field<string>("ESTADO_CONCEPTO");
            this.CONDICIONAL = rowInfo.Field<string>("CONDICIONAL");
            this.GENERA_DATA = rowInfo.Field<string>("GENERA_DATA");
            this.ID_CAUSAL = rowInfo.Field<decimal?>("ID_CAUSAL");
            this.CAUSAL = rowInfo.Field<string>("CAUSAL");
        }
    }
}
