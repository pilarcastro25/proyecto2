﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class Reciclaje_ET
    {
        public string IdEb { get; set; }
        public int? CodigoAbonado { get; set; }
        public int? IdLinea { get; set; }
        public long? NumeroMovil { get; set; }
        public string Identificacion { get; set; }

        public Reciclaje_ET()
        {

        }

        public Reciclaje_ET(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser un valor nulo vacio.");
            }
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.CodigoAbonado = rowInfo.Field<int?>("CODIGO_ABONADO");
            this.IdLinea = rowInfo.Field<int?>("ID_LINEA");
            this.NumeroMovil = rowInfo.Field<long?>("NUMERO_MOVIL");
            this.Identificacion = rowInfo.Field<string>("IDENTIFICACION");
        }
    }
}
