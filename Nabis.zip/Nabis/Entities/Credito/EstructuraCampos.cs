﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    /// <summary>
    /// Resultado de la consulta del procedimiento almacenado Nab_SP_Credito_Estructura_Campos
    /// </summary>
    public class EstructuraCampos
    {
        public string SUB_CAMPOS { get; set; }
        public decimal? ID_CAMPO { get; set; }
        public string CAMPO { get; set; }
        public string TIPO_VALOR_CAMPO { get; set; }
        public string CAMPO_OBLIGATORIO { get; set; }
        public string EXPRESION_REGULAR_CAMPO { get; set; }
        public decimal? ID_SUB_CAMPO_PADRE { get; set; }
        public string SUB_CAMPO_PADRE { get; set; }
        public string TIPO_VALOR_SUBCAMPOPADRE { get; set; }
        public string SUBCAMPOPADRE_OBLIGATORIO { get; set; }
        public string EXPRESION_REGULAR_SUBCAMPOPADRE { get; set; }
        public decimal? ID_SUB_CAMPO { get; set; }
        public string SUB_CAMPO { get; set; }
        public string TIPO_VALOR_SUBCAMPO { get; set; }
        public string SUBCAMPO_OBLIGATORIO { get; set; }
        public string EXPRESION_REGULAR_SUBCAMPO { get; set; }
        public string VALOR { get; set; }
        public string ALIAS { get; set; }
        public decimal? ID_INPUT { get; set; }

        public EstructuraCampos()
        {

        }

        public EstructuraCampos(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser nulo o vacio.");
            }
            this.SUB_CAMPOS = rowInfo.Field<string>("SUB_CAMPOS");
            this.ID_CAMPO = rowInfo.Field<decimal?>("ID_CAMPO");
            this.CAMPO = rowInfo.Field<string>("CAMPO");
            this.TIPO_VALOR_CAMPO = rowInfo.Field<string>("TIPO_VALOR_CAMPO");
            this.CAMPO_OBLIGATORIO = rowInfo.Field<string>("CAMPO_OBLIGATORIO");
            this.EXPRESION_REGULAR_CAMPO = rowInfo.Field<string>("EXPRESION_REGULAR_CAMPO");
            this.ID_SUB_CAMPO_PADRE = rowInfo.Field<decimal?>("ID_SUB_CAMPO_PADRE");
            this.SUB_CAMPO_PADRE = rowInfo.Field<string>("SUB_CAMPO_PADRE");
            this.TIPO_VALOR_SUBCAMPOPADRE = rowInfo.Field<string>("TIPO_VALOR_SUBCAMPOPADRE");
            this.SUBCAMPOPADRE_OBLIGATORIO = rowInfo.Field<string>("SUBCAMPOPADRE_OBLIGATORIO");
            this.EXPRESION_REGULAR_SUBCAMPOPADRE = rowInfo.Field<string>("EXPRESION_REGULAR_SUBCAMPOPADRE");
            this.ID_SUB_CAMPO = rowInfo.Field<decimal?>("ID_SUB_CAMPO");
            this.SUB_CAMPO = rowInfo.Field<string>("SUB_CAMPO");
            this.TIPO_VALOR_SUBCAMPO = rowInfo.Field<string>("TIPO_VALOR_SUBCAMPO");
            this.SUBCAMPO_OBLIGATORIO = rowInfo.Field<string>("SUBCAMPO_OBLIGATORIO");
            this.EXPRESION_REGULAR_SUBCAMPO = rowInfo.Field<string>("EXPRESION_REGULAR_SUBCAMPO");
            this.VALOR = rowInfo.Field<string>("VALOR");
            this.ALIAS = rowInfo.Field<string>("ALIAS");
            this.ID_INPUT = rowInfo.Field<decimal?>("ID_INPUT");
        }
    }
}
