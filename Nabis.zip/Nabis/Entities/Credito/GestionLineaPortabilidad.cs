﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class GestionLineaPortabilidad
    {
        public int IdLinea { get; set; }
        public string Estado { get; set; }
        public DateTime FechaVentana { get; set; }
        public string IdWeb { get; set; }
    }
}
