﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class LineaPortabilidadEnProceso : LineasPortabilidad
    {

        public LineaPortabilidadEnProceso()
        {

        }

        public LineaPortabilidadEnProceso(DataRow rowInfo)
            :base(rowInfo)
        {

        }
    }
}
