﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;


namespace Nabis_ET.Credito
{
    public class LineasPortabilidad
    {
        public string IdEb { get; set; }
        public int? IdOperadorOrigen { get; set; }
        public string Operador { get; set; }
        public long Celular { get; set; }
        public int? IdTipoPlanOrigen { get; set; }
        public string PlanOrigen { get; set; }
        public int? IdTipoPlanDestino { get; set; }
        public string PlanDestino { get; set; }
        public bool? Traspaso { get; set; }
        public int? IdTipoIdentOrigen { get; set; }
        public string TipoIdentificacion { get; set; }
        public string NumIdentOrigen { get; set; }
        public string NombreClienteOrigen { get; set; }
        public string ApellidoClienteOrigen { get; set; }
        public string IdWeb { get; set; }
        public DateTime? FechaVentana { get; set; }
        public int? IdLinea { get; set; }


        public LineasPortabilidad()
        {

        }

        public LineasPortabilidad(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser un valor nulo vacio.");
            }
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.Celular = rowInfo.Field<long>("CELULAR");
            this.IdOperadorOrigen = rowInfo.Field<int>("ID_OPERADOR_ORIGEN");
            this.Operador = rowInfo.Field<string>("OPERADOR");
            this.IdTipoPlanOrigen = rowInfo.Field<int>("ID_TIPO_PLAN_ORIGEN");
            this.PlanOrigen = rowInfo.Field<string>("PLAN_ORIGEN");
            this.IdTipoPlanDestino = rowInfo.Field<int>("ID_TIPO_PLAN_DESTINO");
            this.PlanDestino = rowInfo.Field<string>("PLAN_DESTINO");
            this.Traspaso = rowInfo.Field<bool?>("TRASPASO");
            this.IdTipoIdentOrigen = rowInfo.Field<int?>("ID_TIPO_IDENT_ORIGEN");
            this.TipoIdentificacion = rowInfo.Field<string>("TIPO_IDENT_ORIGEN");
            this.NumIdentOrigen = rowInfo.Field<string>("NUM_IDENT_ORIGEN");
            this.NombreClienteOrigen = rowInfo.Field<string>("NOMBRE_CLIENTE_ORIGEN");
            this.ApellidoClienteOrigen = rowInfo.Field<string>("APELLIDO_CLIENTE_ORIGEN");
            this.FechaVentana = rowInfo.Field<DateTime?>("FECHA_VENTANA");
            this.IdLinea = rowInfo.Field<int?>("ID_LINEA");
        }
    }
}
