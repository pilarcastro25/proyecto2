﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class GestionLineasABD
    {
        public string UserId { get; set; }
        public string IdEb { get; set; }
        public string XmlLineas { get; set; }
        public int? Estado { get; set; }
        public DateTime? FechaVentana { get; set; }
        public string IdWeb { get; set; }
    }
}
