﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class EstructuraNotas
    {
        public string OBSERVACIONES { get; set; }

        public EstructuraNotas()
        {

        }

        public EstructuraNotas(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser un valor nulo o vacio.");
            }
            this.OBSERVACIONES = rowInfo.Field<string>("OBSERVACIONES");
        }
    }
}
