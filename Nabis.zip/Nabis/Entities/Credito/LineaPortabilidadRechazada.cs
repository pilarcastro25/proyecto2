﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class LineaPortabilidadRechazada : LineasPortabilidad
    {
        public LineaPortabilidadRechazada()
        {

        }

        public LineaPortabilidadRechazada(DataRow rowInfo)
            :base(rowInfo)
        {

        }
    }
}
