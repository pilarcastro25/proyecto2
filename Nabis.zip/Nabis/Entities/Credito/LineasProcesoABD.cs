﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class LineasProcesoABD
    {
        public long IdPortacion { get; set; }
        public int IdLinea { get; set; }
        public long Celular { get; set; }
        public string IdEb { get; set; }
        public string Identidad { get; set; }
        public DateTime FechaLanzamiento { get; set; }
        public DateTime FechaActivacion { get; set; }
        public int? IdEstado { get; set; }

        public LineasProcesoABD()
        {

        }

        public LineasProcesoABD(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor del registro no puede ser un valor nulo o vacio.");
            }
            this.IdPortacion = rowInfo.Field<long>("ID_PORTACION");
            this.IdLinea = rowInfo.Field<int>("ID_LINEA");
            this.Celular = rowInfo.Field<long>("CELULAR");
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.Identidad = rowInfo.Field<string>("IDENTIDAD");
            this.FechaLanzamiento = rowInfo.Field<DateTime>("FECHA_LANZAMIENTO");
            this.FechaActivacion = rowInfo.Field<DateTime>("FECHA_ACTIVACION");
            this.IdEstado = null;
        }
    }
}
