﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class LineaPortabilidadPendiente : LineasPortabilidad
    {
        public string IdWeb { get; set; }

        public LineaPortabilidadPendiente()
        {

        }

        public LineaPortabilidadPendiente(DataRow rowInfo)
            : base(rowInfo)
        {
            /*if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.IdWeb = rowInfo.Field<string>("ID_WEB");*/
        }
    }
}
