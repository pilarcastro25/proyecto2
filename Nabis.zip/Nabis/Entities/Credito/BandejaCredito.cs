﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Credito
{
    public class BandejaCredito
    {
        public int? IdEtapa { get; set; }
        public int? IdGestion { get; set; }
        public string IdEb { get; set; }
        public string TipoId { get; set; }
        public string Identidad { get; set; }
        public string TipoCliente { get; set; }
        public string TipoServicio { get; set; }
        public string TipoSolicitud { get; set; }
        public DateTime? FechaAsignacion { get; set; }
        public string Portado { get; set; }
        public int? IdCanal { get; set; }
        public string Canal { get; set; }
        public int? IdTipoContrato { get; set; }
        public string TipoContrato { get; set; }
        public int? IdEstadoEtapa { get; set; }
        public string EstadoEtapa { get; set; }
        public string Campos { get; set; }

        public BandejaCredito()
        {

        }

        public BandejaCredito(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor del registro no puede ser un valor nulo o vacio.");
            }
            this.IdEtapa = rowInfo.Field<int?>("ID_ETAPA");
            this.IdGestion =rowInfo.Field<int?>("ID_GESTION");
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.TipoId = rowInfo.Field<string>("TIPO_ID");
            this.Identidad = rowInfo.Field<string>("IDENTIDAD");
            this.TipoCliente = rowInfo.Field<string>("TIPO_CLIENTE");
            this.TipoServicio = rowInfo.Field<string>("TIPO_SERVICIO");
            this.TipoSolicitud = rowInfo.Field<string>("TIPO_SOLICITUD");
            this.FechaAsignacion = rowInfo.Field<DateTime?>("FECHA_ASIGNACION");
            this.Portado = rowInfo.Field<string>("PORTADO");
            this.IdCanal = rowInfo.Field<int?>("ID_CANAL");
            this.Canal = rowInfo.Field<string>("CANAL");
            this.IdTipoContrato = rowInfo.Field<int?>("ID_TIPO_CONTRATO");
            this.TipoContrato = rowInfo.Field<string>("TIPO_CONTRATO");
            this.IdEstadoEtapa = rowInfo.Field<int?>("ID_ESTADO_ETAPA");
            this.EstadoEtapa = rowInfo.Field<string>("ESTADO_ETAPA");
            this.Campos = rowInfo.Field<string>("CAMPOS");
        }
    }
}
