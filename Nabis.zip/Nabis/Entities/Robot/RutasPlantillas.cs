﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Nabis_ET.Robot
{
    [DataContract]
    public class RutasPlantillas
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Descripcion { get; set; }
        [DataMember]
        public string RutaPlantilla { get; set; }
        [DataMember]
        public string NombreArchivo { get; set; }
    }
}
