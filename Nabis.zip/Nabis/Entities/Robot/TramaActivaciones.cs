﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Robot
{
    public class TramaActivaciones
    {
        
        public string Trama0 { get; set; }
        
        public string Trama1 { get; set; }
        
        public string Trama2 { get; set; }
        
        public string Trama3 { get; set; }
        
        public string Trama4 { get; set; }
        
        public int? Id { get; set; }
        
        public string TipoPlan { get; set; }
    }
}
