﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Robot
{
    public class RestaurarEstado
    {
        public string IdEb { get; set; }
        public int IdEstructura{ get; set; }
        public int IdEstado { get; set; }

        public RestaurarEstado()
        {

        }

        public RestaurarEstado(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser un valor nulo vacio.");
            }
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.IdEstructura = rowInfo.Field<int>("Estructura");
            this.IdEstado = rowInfo.Field<int>("Estado");
        }
    }
}
