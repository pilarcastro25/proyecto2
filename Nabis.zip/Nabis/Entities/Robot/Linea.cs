﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Nabis_ET.Robot
{
    [DataContract]
    public class Linea
    {
        [DataMember]
        public int Id  { get; set; }
        [DataMember]
        public string IdEb { get; set; }
        [DataMember]
        public int IdLinea { get; set; }
        [DataMember]
        public string NumeroLinea { get; set; }
        [DataMember]
        public int? Reproceso { get; set; }
        [DataMember]
        public DateTime? FechaSolicitud { get; set; }
        [DataMember]
        public DateTime? FechaProgramacion { get; set; }
        [DataMember]
        public string UsuarioSolic { get; set; }
        [DataMember]
        public string UsuarioDescarga { get; set; }
        [DataMember]
        public DateTime? FechaDescarga { get; set; }
        [DataMember]
        public int IdEstado { get; set; }
        [DataMember]
        public string Idweb { get; set; }
        [DataMember]
        public bool? Portado { get; set; }
        [DataMember]
        public string TipoPlan { get; set; }
        [DataMember]
        public string DescEstado { get; set; }
        [DataMember]
        public string CodCuenta { get; set; }
        [DataMember]
        public string Imei { get; set; }
        [DataMember]
        public string SimCard { get; set; }
    }
}
