﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Robot
{
    public class BandejaRobot
    {
        public string IdEb { get; set; }
        public int CantidadLineas { get; set; }
        public string Portado { get; set; }

        public BandejaRobot()
        {

        }

        public BandejaRobot(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor del registro no puede ser un valor nulo o vacio.");
            }
            this.IdEb = rowInfo.Field<string>("RADICADO");
            this.CantidadLineas = rowInfo.Field<int>("LINEAS");
            this.Portado = rowInfo.Field<string>("PORTADO");
        }
    }
}
