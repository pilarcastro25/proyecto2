﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class Beneficio
    {
        public string CODIGO { get; set; }
        public string DESCRIPCION { get; set; }
        public int LATENCIA { get; set; }
        public string CONCEPTO { get; set; }
    }
}
