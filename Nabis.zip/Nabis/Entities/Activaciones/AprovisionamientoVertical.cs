﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Activaciones
{
    public class AprovisionamientoVertical
    {
        public string IdNegocio { get; set; }
        public int? CantidadLineas { get; set; }
        public string Observacioenes { get; set; }
        public string Usuario { get; set; }
        public DateTime? FechaRegistro { get; set; }
        public DateTime? FechaAsignacion { get; set; }
        public string Estado { get; set; }
    }
}
