﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Activaciones
{
    public class AprovisionamientoAtlantida
    {
        public string IdEb { get; set; }
        public long Celular { get; set; }
        public string UsuarioAtlantida { get; set; }
        public DateTime? FechaAprovisionamiento { get; set; }
        public int? IdPerfil { get; set; }
        public string CodTarea { get; set; }
        public int? IdIngresoAtlantida { get; set; }
        public int IdEstado { get; set; }
        public DateTime FechaAsignacion { get; set; }
    }
}
