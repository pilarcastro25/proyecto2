﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class EstrVenActi
    {
        #region Informacion General Estructura de Venta
        public DateTime FechaProgramacion { get; set; }
        public int IdLinea { get; set; }
        public string Ejecucion { get; set; }
        public string CodigoNegocio { get; set; }
        public int IdEstructuraVenta { get; set; }
        public int CodCliente { get; set; }
        public string ContratoVenta { get; set; }
        public Int64 NumeroLinea { get; set; }
        public string ModalidadVenta { get; set; }
        public string Cuotas { get; set; }
        public string Producto { get; set; }
        public int Lineas { get; set; }
        public int Abono { get; set; }
        #endregion

        #region Informacion de Simcard
        public string NumeroSIMCARD { get; set; }
        public string DescripcionSIM { get; set; }
        public string Imei { get; set; }
        public string PrecioDescuentoSIM { get; set; }
        #endregion

        #region Informacion del Equipo
        public string Procedencia { get; set; }
        public string TipoEquipo { get; set; }
        public string DescripcionEquipo { get; set; }
        public string AbonoEquipo { get; set; }
        public string PrecioDctoEquipo { get; set; }
        public string DescuentoImei { get; set; }
        #endregion

        #region Informacion del Plan
        public string CodigoPlan { get; set; }
        public string DctoPlan { get; set; }
        public string PrecioDctoPlan { get; set; }
        #endregion

        #region Informacion de los Servicios
        public string CodigoServicio { get; set; }
        public string DctoServicio { get; set; }
        public string PrecioDctoServicio { get; set; }
        #endregion

        #region Informacion de Licencia de Correo
        public string CodigoLic { get; set; }
        public string DctoLic { get; set; }
        public string PrecioDctoLic { get; set; }
        #endregion

        #region Informacion de Planes Adicionales
        public string CodPlanAdic { get; set; }
        public string DctoPlanAdic { get; set; }
        public string PrecioDctoPlanAdic { get; set; }
        #endregion
    }
}

