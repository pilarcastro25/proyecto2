﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Activaciones
{
    public class TipoPerfil
    {
        public int IdTipoPerfil { get; set; }
        public string TipoPerfiles { get; set; }
    }
}
