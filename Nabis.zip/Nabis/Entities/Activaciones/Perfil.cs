﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ML.Activaciones
{
    public class Perfil
    {
        public int IdPerfil { get; set; }
        public string Perfiles { get; set; }
        public int IdTipoPerfil { get; set; }
        public int IdTipoPlan { get; set; }
    }
}
