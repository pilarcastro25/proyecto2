﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class ExcelBeneficios
    {
        public string IdEb { get; set; }
        public string Identificacion { get; set; }
        public long Celular { get; set; }
        public string CodBeneficio { get; set; }
        public long Latencia { get; set; }
    }
}
