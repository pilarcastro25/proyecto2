﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class InformacionNegocio
    {
        #region INFORMACION DEL NEGOCIO
        
        public string CodigoNegocio { get; set; }
        public string TipoIdentificacion { get; set; }
        public string NumIdentCliente { get; set; }
        public int CodigoCliente { get; set; }
        public string NombreCliente { get; set; }
        public string Portado { get; set; }
        public DateTime? FechaVentana { get; set; }
        public int LineasSolicitadas { get; set; }
        public int LineasAprobadas { get; set; }
        public DateTime FechaAsignacion { get; set; }
        public int IdReciclaje { get; set; }
        public int NumLineasReciclaje { get; set; }
        public string LineasReciclaje { get; set; }
        public Int64? TelefonoCliente { get; set; }
        public string CiudadCliente { get; set; }
        public string DireccionCliente { get; set; }
        public string Carterizado { get; set; }
        public string ContratoMarco { get; set; }
        public string ObservacionesComercial { get; set; }
        public string Pedido { get; set; }
        public string SolicitudEspecial { get; set; }
        public string Reventa { get; set; }
        public string AutorizacionMercadeo { get; set; }
        public string Permanencia { get; set; }
        public string PagoAnticipado { get; set; }
        public string TipoCliente { get; set; }
        

	    #endregion

        #region INFORMACION DEL VENDEDOR

        public string GrupoVendedor { get; set; }
        public int CodigoVendedor { get; set; }
        public string NombreVendedor { get; set; }
        public string IdentificacionVendedor { get; set; }
        public string CanalVendedor { get; set; }

        #endregion

        #region INFORMACION DE CREDITO

        public string ObservacionesCredito { get; set; }

        #endregion

        #region INFORMACION ADICIONAL
        
        public string CodPlan { get; set; }
        public int LineasPendientes { get; set; }
        public int LineasActivas { get; set; }
        public int LineasAprobaParcial { get; set; }
        //public int CodigoCliente { get; set; }
        public int ImpresionFactura { get; set; }
        public int LineasAtlantida { get; set; }
        public int LineasVerticales { get; set; }
        public int LineasBeneficios { get; set; }
        public string EstadoAtlantida { get; set; }
        public string EstadoVerticales { get; set; }
        public string EstadoBeneficios { get; set; }
        public string EstadoActivacion { get; set; }
        public DateTime FechaActivacion { get; set; }
        public string PFraude { get; set; }

        #endregion
               
    }
}
