﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class ConceptoBeneficios
    {
        public int ID_RELACION { get; set; }
        public string RELACION { get; set; }
    }
}
