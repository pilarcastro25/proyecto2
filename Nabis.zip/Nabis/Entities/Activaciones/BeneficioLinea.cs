﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class BeneficioLinea
    {
        public int ID_BENEFICIOS { get; set; }
        public string ID_EB { get; set; }
        public long CELULAR { get; set; }
        public string COD_BENEFICIO_BASICO { get; set; }
        public string COD_BENEFICIO_DATOS { get; set; }
        public string COD_BENEFICIO_OTROS { get; set; }
        public string COD_BENEFICIO_DATOS_ADICIONAL { get; set; }
        public string COD_BENEFICIO_VOZ_ADICIONAL { get; set; }
        public string ID_KORAL { get; set; }
        public string ID_KORAL_CARGO { get; set; }
        public DateTime FECHA_ASIGNACION { get; set; }
        public string USUARIO_BENEFICIOS { get; set; }
        public DateTime? FECHA_REGISTRO { get; set; }
        public DateTime? FECHA_REGISTRO_MASIVO { get; set; }
        public string USUARIO_CARGUE_MASIVO { get; set; }
        public string SD { get; set; }
        public int ID_ESTADO_BENEFICIOS { get; set; }
    }
}
