﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//namespace ML.Activaciones
namespace Nabis_ET.Activaciones
{
    /// <summary>
    /// Entidad que representa la informacion asociada a Activaciones.
    /// </summary>
    public class BandejaActivaciones
    {
        
        public string CodigoNegocio { get; set; }
        public string TipoIdentificacion { get; set; }
        public string NombreCliente { get; set; }
        public string TipoCliente { get; set; }
        public int LineasSolicitadas { get; set; }
        public string Categoria { get; set; }
        public string PFraude { get; set; }
        public DateTime FechaRegistro { get; set; }
        public string Portado { get; set; }
        public DateTime? FechaVentana { get; set; }
        public string Actividad { get; set; }
        public string Clase { get; set; }

        //public string CodPlan { get; set; }
        //public int LineasAprobadas { get; set; }
        //public int LineasPendientes { get; set; }
        //public int LineasActivas { get; set; }
        //public int LineasAprobaParcial { get; set; }
        //public int CodigoCliente { get; set; }
        //public int ImpresionFactura { get; set; }
        //public int LineasAtlantida { get; set; }
        //public int LineasVerticales { get; set; }
        //public int LineasBeneficios { get; set; }
        //public string EstadoAtlantida { get; set; }
        //public string EstadoVerticales { get; set; }
        //public string EstadoBeneficios { get; set; }
        //public string EstadoActivacion { get; set; }
        //public DateTime FechaActivacion { get; set; }        
    }
}
