﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Activaciones
{
    public class BandejaBeneficios
    {
        public string ID_EB { get; set; }
        public string TIPO_DOCUMENTO { get; set; }
        public string DOCUMENTO { get; set; }
        public string TIPO_CLIENTE { get; set; }
        public int LINEAS_BENEFICIOS { get; set; }
        public string PORTABILIDAD { get; set; }
        public string PARCIAL { get; set; }
        public string ESTADO { get; set; }
    }
}
