﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class DatosNegocio
    {
        public string UserConsulta { get; set; }
        public DateTime FecIngreso { get; set; }
        public string idEb { get; set; }
        public int cantLineas { get; set; }
        public int CodVendedor { get; set; }
        public int IdGrupo { get; set; }
        public string CanalVendedor { get; set; }
        public string canalVenta { get; set; }
        public int IdTipoIdentidad { get; set; }
        public string TipoIdentidad { get; set; }
        public string numIdent { get; set; }
        public string razonSocial { get; set; }
        public int CodDistrito { get; set; }
        public string CodTipoCalle { get; set; }
        public string Direccion { get; set; }
        public string Complemento { get; set; }
        public int Departamento { get; set; }
        public string TelefonoCliente { get; set; }
        public string EmailCliente { get; set; }
        public byte RepLegalTipoID { get; set; }
        public int RepLegalIdentidad { get; set; }
        public string RepLegalNombre { get; set; }
        public string RepLegalApellido1 { get; set; }
        public string RepLegalApellido2 { get; set; }
        public int? RepLegalFijo { get; set; }
        public long? RepLegalCelular { get; set; }
        public DateTime? RepLegalFecnacimiento { get; set; }
        public string tipoVenta { get; set; }
        public string tipSolicitud { get; set; }
        public string tipContrato { get; set; }
        public string convenio { get; set; }
        public string numContrato { get; set; }
        public string TipoCambioPlan { get; set; }
        public int PendLineas { get; set; }
        public string portado { get; set; }
        public string pedido { get; set; }
        public string Estado { get; set; }
        public string IdEstado { get; set; }
        public DateTime? FecVentana { get; set; }
        public long? MovilVendedor { get; set; }
        public string IdentificacionVendedor { get; set; }
        public string Carterizado { get; set; }
        public string LimiteConsumo { get; set; }
        public int LineasIngresadas { get; set; }
        public bool EsPyme { get; set; }
        public string Observaciones { get; set; }
        public string Operador { get; set; }
        public string Regional { get; set; }
    }
}
