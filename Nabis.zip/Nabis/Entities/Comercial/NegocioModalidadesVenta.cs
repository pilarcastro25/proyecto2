﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioModalidadesVenta
    {
        public string ModalidadVenta { get; set; }
        public string DescripcionCuota { get; set; }
        public string Producto { get; set; }
        public int CantidadLineas { get; set; }
        public double? CuotaInicial { get; set; }
        public int? NumeroCuotas { get; set; }
        public double? CuotaMensual { get; set; }
        public double? ValorTotalEquipo { get; set; }
        public double? ValorTotalEquipos { get; set; }
        public bool? IsVentaCuotas { get; set; }
    }
}