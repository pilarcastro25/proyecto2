﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class CodigoNegocio
    {
        public string IdEb { get; set; }
    }
}
