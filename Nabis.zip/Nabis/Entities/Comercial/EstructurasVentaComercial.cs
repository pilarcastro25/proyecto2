﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class EstructurasVentaComercial
    {
        public int? IdEstructuraVenta { get; set; }
        public string IdEb { get; set; }
        public int IdModalidadVenta { get; set; }
        public string DescripcionModalidadVenta { get; set; }
        public int IdCuota { get; set; }
        public string DescripcionCuota { get; set; }
        public int CantidadLineas { get; set; }
        public float? CuotaInicial { get; set; }
        public int IdProducto { get; set; }
        public string Producto { get; set; }
        public int IdContrato { get; set; }
        public string Contrato { get; set; }
        public string Traido { get; set; }
        public int? CodigoTipoUso { get; set; }
        public string TipoUso { get; set; }
        public string IdPlan { get; set; }
        public string NombrePlan { get; set; }
        public string DescuentoValorPlan { get; set; }
        public string FormaPago { get; set; }
        public int? TipoPlanCliente { get; set; }
        public string TipoCliente { get; set; }
        public bool? Roaming { get; set; }
        public string CodBeneficioCargoBasico { get; set; }
        public string BeneficioCondicionesCargoBasico { get; set; }
        public double? ValorSimCard { get; set; }
        public double? ValorEquipo { get; set; }
        public double? ValorEquipoKoral { get; set; }
        public double? ValorEquipoBeneficio { get; set; }
        public double? ValorEquipoDiferido { get; set; }
    }
}
