﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioInformacionCuentas
    {
        public int IdCuenta { get; set; }
        public string IdEb { get; set; }
        public string CodigoCliente { get; set; }
        public string NombreCuenta { get; set; }
        public string Apellido1Cuenta { get; set; }
        public string Apellido2Cuenta { get; set; }
        public string Telefono { get; set; }
        public string CodTipoCalle { get; set; }
        public string Direccion { get; set; }
        public string Barrio { get; set; }
        public string Complemento { get; set; }
        public int? Regional { get; set; }
        public int? Departamento { get; set; }
        public int? Ciudad { get; set; }
        public int? Localidad { get; set; }
        public int? IdCiclo { get; set; }
        public string TipoCliente { get; set; }
        public string Nuevo { get; set; }
        public string NombreSubcuenta { get; set; }
        public string ApellidosSubcuenta { get; set; }
        public string Correo { get; set; }
        public int? Estrato { get; set; }
        public int? IdPerfilAutorizado { get; set; }
        public string TipoVivienda { get; set; }
        public string NombreDepartamento { get; set; }
        public string NombreCiudad { get; set; }
        public string TelefonoMovil { get; set; }

        public NegocioInformacionCuentas()
        {

        }

        /// <summary>
        /// Informacion de registro
        /// </summary>
        /// <param name="rowInfo"></param>
        public NegocioInformacionCuentas(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser nulo o vacio.");
            }
            this.IdCuenta = rowInfo.Field<int>("ID_CUENTA");
            this.IdEb = rowInfo.Field<string>("ID_EB");
            this.CodigoCliente = rowInfo.Field<string>("CODIGO_CLIENTE");
            this.NombreCuenta = rowInfo.Field<string>("NOMBRE_CUENTA");
            this.Apellido1Cuenta = rowInfo.Field<string>("APELLIDO1_CUENTA");
            this.Apellido2Cuenta = rowInfo.Field<string>("APELLIDO2_CUENTA");
            this.Telefono = rowInfo.Field<string>("TELEFONO");
            this.CodTipoCalle = rowInfo.Field<string>("COD_TIPO_CALLE");
            this.Direccion = rowInfo.Field<string>("DIRECCION");
            this.Barrio = rowInfo.Field<string>("BARRIO");
            this.Complemento = rowInfo.Field<string>("COMPLEMENTO");
            this.Regional = rowInfo.Field<int?>("REGIONAL");
            this.Departamento = rowInfo.Field<int?>("DEPARTAMENTO");
            this.Ciudad = rowInfo.Field<int?>("CIUDAD");
            this.Localidad = rowInfo.Field<int?>("LOCALIDAD");
            this.IdCiclo = rowInfo.Field<int?>("ID_CICLO");
            this.TipoCliente = rowInfo.Field<string>("TIPO_CLIENTE");
            this.Nuevo = rowInfo.Field<string>("NUEVO");
            this.NombreSubcuenta = rowInfo.Field<string>("NOMBRE_SUBCUENTA");
            this.ApellidosSubcuenta = rowInfo.Field<string>("APELLIDOS_SUBCUENTA");
            this.Correo = rowInfo.Field<string>("CORREO");
            this.Estrato = rowInfo.Field<int?>("ESTRATO");
            this.IdPerfilAutorizado = rowInfo.Field<int?>("ID_PERFIL_AUTORIZADO");
            this.TipoVivienda = rowInfo.Field<string>("TIPO_VIVIENDA");
            this.NombreDepartamento = rowInfo.Field<string>("NOMBRE_DEPARTAMENTO");
            this.NombreCiudad = rowInfo.Field<string>("NOMBRE_CIUDAD");
            this.TelefonoMovil = rowInfo.Field<string>("TELEFONO_MOVIL");
        }
    }
}
