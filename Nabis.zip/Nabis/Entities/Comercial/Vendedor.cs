﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class Vendedor
    {
        public bool IsExist { get; set; }
        public string NumIdent { get; set; }
        public int IdCanal { get; set; }
        public int CodVendedor { get; set; }
        public string NombreVendedor { get; set; }
        public long? NumCelular { get; set; }
        public string Regional { get; set; }
        public string Ciudad { get; set; }
        public string Departamento { get; set; }
        public string NombreResponsable { get; set; }
        public int? CodAgente { get; set; }
        public string NombreAgente { get; set; }
        public string CodTipoComisionista { get; set; }
        public string TipoComisionista { get; set; }
        public string CanalComercial { get; set; }
        public string CodPunto { get; set; }
        public string NombrePunto { get; set; }
        public string EstadoPunto { get; set; }
        public string EstadoAsesor { get; set; }
        public DateTime? FecContrato { get; set; }
        public DateTime? FecFinContrato { get; set; }
        public int? IdGrupo { get; set; }
        public int? IdRegional { get; set; }
    }
}
