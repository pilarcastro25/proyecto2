﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    /// <summary>
    /// Representa un documento o anexo de un negocio
    /// </summary>
    public class Documento
    {
        /// <summary>
        /// Id asociado al documento
        /// </summary>
        public int IdDocumento { get; set; }
        /// <summary>
        /// Nombre del documento.
        /// </summary>
        public string NombreDocumento { get; set; }
        /// <summary>
        /// El documento es obligatorio
        /// </summary>
        public bool Requisito { get; set; }
        /// <summary>
        /// Id de tipo de contrato
        /// </summary>
        public int IdTipoContrato { get; set; }
        /// <summary>
        /// Nombre de tipo de contrato.
        /// </summary>
        public string NombreTipoContrato { get; set; }
        /// <summary>
        /// Alias del documentos
        /// </summary>
        public string Alias { get; set; }
    }
}
