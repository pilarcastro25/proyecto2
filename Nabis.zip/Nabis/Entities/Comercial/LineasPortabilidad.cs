﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class LineasPortabilidad
    {
        public string IdEb  { get; set; }
        public int? IdOperadorOrigen  { get; set; }
        public long Celular  { get; set; }
        public int? IdTipoPlanOrigen  { get; set; }
        public int? IdTipoPlanDestino  { get; set; }
        public bool? Traspaso  { get; set; }
        public int? IdTipoIdentOrigen  { get; set; }
        public string NumIdentOrigen  { get; set; }
        public string NombreClienteOrigen  { get; set; }
        public string ApellidoClienteOrigen  { get; set; }
        public DateTime? FecIngreso  { get; set; }
        public string IdWeb  { get; set; }
        public DateTime FechaVentana  { get; set; }
        public int? IdLinea  { get; set; }
    }
}
