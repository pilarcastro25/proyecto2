﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioTraspaso
    {
        public int IdTraspaso { get; set; }
        public string IdEb { get; set; }
        public int? IdEstructuraVenta { get; set; }
        public bool? ClausulasACargoOrigen { get; set; }
        public bool? SaldosACargoOrigen { get; set; }
        public string Adjunto1 { get; set; }
        public string Adjunto2 { get; set; }
        public string Adjunto3 { get; set; }
        public string Adjunto4 { get; set; }
        public Byte? IdTipoIdentOrigen { get; set; }
        public string NumIdentOrigen { get; set; }
        public string NombreClienteOrigen { get; set; }
        public long? CelularOrigen { get; set; }
        public long? LineaCelular { get; set; }
        public string LineaCodPlan { get; set; }
        public string LineaRefEquipo { get; set; }
    }
}
