﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class Negocio
    {
        public string IdEb  { get; set; }
        public DateTime FecIngreso  { get; set; }
        public int CodVendedor  { get; set; }
        public string CanalVendedor  { get; set; }
        public int IdRegionalNegocio  { get; set; }
        public string UserIngreso  { get; set; }
        public int CantLineas  { get; set; }
        public int PendLineas  { get; set; }
        public int Portado  { get; set; }
        public int Pedido  { get; set; }
        public int? Robot  { get; set; }
        public DateTime? FecPedido  { get; set; }
        public string UserPedido  { get; set; }
        public DateTime? FecCierrePedido  { get; set; }
        public string UserCierrePedido  { get; set; }
        public DateTime? FecEstrVenta  { get; set; }
        public string UserEstrVenta  { get; set; }
        public DateTime? FecCierreEstrVenta  { get; set; }
        public string UserCierreEstrVenta  { get; set; }
        public string EstructuraVenta  { get; set; }
        public DateTime? FecDctos  { get; set; }
        public string UserDctos  { get; set; }
        public DateTime? FecCierreDctos  { get; set; }
        public string UserCierreDctos  { get; set; }
        public DateTime? FecCierre  { get; set; }
        public string UserCierre  { get; set; }
        public DateTime? FecCancelacion  { get; set; }
        public string UserCancelacion  { get; set; }
        public DateTime? FecUltMod  { get; set; }
        public string UserUltMod  { get; set; }
        public string IdEstado  { get; set; }
        public int? IdGrupo  { get; set; }
        public decimal? IdTipoContrato  { get; set; }
        public int? IdIdentidad  { get; set; }
        public string Identidad  { get; set; }
        public string NombreCliente  { get; set; }
        public int? IdTipoCliente  { get; set; }
        public int? IdTipoServicio  { get; set; }
        public int? IdTipoSolicitud  { get; set; }
        public DateTime? FechaCierreCredito  { get; set; }
        public int? IdConvenio  { get; set; }
        public int? IdIdentidadRepLegal  { get; set; }
        public int? RepLegalIdentidad  { get; set; }
        public string RepLegalNombre  { get; set; }
        public string RepLegalApellido1  { get; set; }
        public string RepLegalApellido2  { get; set; }
        public string RepLegalEmail  { get; set; }
        public int? RepLegalFijo  { get; set; }
        public long? RepLegalCelular  { get; set; }
        public DateTime? RepLegalFecnacimiento  { get; set; }
        public long? RepLegalSupIdentidad  { get; set; }
        public string RepLegalSupNombre  { get; set; }
        public string RepLegalSupApellido1  { get; set; }
        public string RepLegalSupApellido2  { get; set; }
        public int? RepLegalSupFijo  { get; set; }
        public long? RepLegalSupCelular  { get; set; }
        public DateTime? RepLegalSupFecnacimiento  { get; set; }
        public int? CodDistrito  { get; set; }
        public int? CodBarrio  { get; set; }
        public string CodTipoCalle  { get; set; }
        public string Direccion  { get; set; }
        public string Complemento  { get; set; }
        public string CodDane  { get; set; }
        public long? IdContratoMarco  { get; set; }
        public DateTime? FecVentana  { get; set; }
        public int? IdTipoCambioPlan  { get; set; }
        public int EsPymes  { get; set; }
        public string TelefonoCliente  { get; set; }
        public string Observaciones  { get; set; }
        public string EmailCliente  { get; set; }
        public char? TipoNegocioAtado  { get; set; }
        public string NegocioReferencia  { get; set; }
        public int? CategoriaTributaria  { get; set; }
        public int? IdOperador  { get; set; }
        public int EsAtado { get; set; }
    }
}
