﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioInformacionAdicional
    {
        public int IdInformacionAdicional { get; set; }
        public string IdKoral { get; set; }
        public string IdPricing { get; set; }
        public bool? EnvioCorreoElectronico { get; set; }
        public string CorreoElectronico { get; set; }
        public string NombreClienteSocio1 { get; set; }
        public string CodigoClienteSocio1 { get; set; }
        public string NitClienteSocio1 { get; set; }
        public string IdCodigoNegocio { get; set; }
        public int? DuracionServicios { get; set; }
        public string RenovacionReposicion { get; set; }
        public string Beneficios { get; set; }
        public string NombreReferencia1 { get; set; }
        public string TelcontactoReferencia1 { get; set; }
        public string InstitucionReferencia1 { get; set; }
        public string NombreReferencia2 { get; set; }
        public string TelcontactoReferencia2 { get; set; }
        public string InstitucionReferencia2 { get; set; }
        public string NombreClienteSocio2 { get; set; }
        public string CodigoClienteSocio2 { get; set; }
        public string NitClienteSocio2 { get; set; }
        public string NombreClienteSocio3 { get; set; }
        public string CodigoClienteSocio3 { get; set; }
        public string NitClienteSocio3 { get; set; }
        public string Profesionalcia { get; set; }
        public string Jefezona { get; set; }
        public string Gerenteregional { get; set; }
        public bool? Perfilsaliente { get; set; }
        public int? CiudadOpcional { get; set; }
        public string DireccionOpcional { get; set; }
        public string Observaciones { get; set; }
        public string MovilContactoReferencia1 { get; set; }
        public string MovilContactoReferencia2 { get; set; }
        public bool? AutorizacionEnvioEmail { get; set; }
        public bool? AutorizacionNumeroCelular { get; set; }
    }
}
