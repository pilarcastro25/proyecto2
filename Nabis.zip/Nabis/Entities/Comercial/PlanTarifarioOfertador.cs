﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class PlanTarifarioOfertador
    {
        public decimal IDT { get; set; }
        public string BUSCAR_POR { get; set; }
        public string COD_PLAN { get; set; }
        public string PROD_SEGMENTO { get; set; }
        public string TIPO_SEGMENTO { get; set; }
        public string CLASE_SEGMENTO { get; set; }
        public string SEGMENTO_MK { get; set; }
        public string ESTADO { get; set; }
        public string NOMBRE_PLAN_ACTUAL { get; set; }
        public decimal? CB_ACTUAL_SIN_IVA { get; set; }
        public string CB_INTEGRADO { get; set; }
        public decimal? CB_ACTUAL { get; set; }
        public decimal? MIN_INCLUIDOS_TD { get; set; }
        public decimal? MIN_INCLUIDOS_MOVISTAR_FIJOS { get; set; }
        public decimal? MIN_INCLUIDOS_OTROS { get; set; }
        public decimal? SMS_INCLUIDOS_MOVISTAR { get; set; }
        public decimal? SMS_INCLUIDOS_TD { get; set; }
        public string UNIDADES_INCLUIDAS { get; set; }
        public string DATOS_INCLUIDOS { get; set; }
        public string KB_ADIC { get; set; }
        public decimal? MAX_MIN_MOVISTAR_FIJOS { get; set; }
        public decimal? MAX_MIN_OTROS { get; set; }
        public decimal? VLR_MIN_MOVISTAR_ACTUAL { get; set; }
        public decimal? VLR_MIN_FIJOS_ACTUAL { get; set; }
        public decimal? VLR_MIN_OTROS_ACTUAL { get; set; }
        public decimal? VLR_MIN_GRUPO_ACTUAL { get; set; }
        public decimal? VLR_TRIBU_ACTUAL { get; set; }
        public decimal? VLR_MIN_CONEXEMPRESARIAL { get; set; }
        public double? VLR_MIN_ADIC_MOVISTAR_ACTUAL { get; set; }
        public double? VLR_MIN_ADIC_FIJOS_ACTUAL { get; set; }
        public double? VLR_MIN_ADIC_OTROS_ACTUAL { get; set; }
        public decimal? VLR_MIN_ADIC_GRUPO_ACTUAL { get; set; }
        public decimal? VLR_TRIBU_ADIC_ACTUAL { get; set; }
        public decimal? VLR_MIN_ADIC_CONEXEMPRESARIAL { get; set; }
        public string VLR_SMS_INCL_MOVISTAR { get; set; }
        public string VLR_SMS_INCL_OTROS_ACTUAL { get; set; }
        public decimal? VLR_SMS_ADIC_MOVISTAR { get; set; }
        public decimal? VLR_SMS_ADIC_OTROS { get; set; }
        public decimal? VLR_9PREFERIDOS_ACT { get; set; }
        public decimal? VLR_PREFERIDO_INTERNAL { get; set; }
        public string SUPER_PREFERIDO { get; set; }
        public string LDI { get; set; }
        public string EXTRATIEMPO_EXTRAS { get; set; }
        public string SERVICIO_OBLIG_DATOS { get; set; }
        public string PLAN_ADIC_DATOS { get; set; }
        public string LICENCIA { get; set; }
        public string FUNCIONAL_CAPACIDAD { get; set; }
        public string OBSERVACIONES { get; set; }
        public decimal? VLR_RECARGA_MOVISTAR { get; set; }
        public double? VLR_RECARGA_OTROS { get; set; }
        public decimal? RECARGA_EMPRESA_MOVISTAR_ACTUAL { get; set; }
        public decimal? RECARGA_EMPRESA_FIJOS_ACTUAL { get; set; }
        public decimal? RECARGA_EMPRESA_OTROS_ACTUAL { get; set; }
        public decimal? RECARGA_EMPRESA_GRUPO_ACTUAL { get; set; }
        public decimal? RECARGA_EMPRESA_TRIBU_ACTUAL { get; set; }
        public decimal? RECARGA_EMPRESA_AMIGA_ACTUAL { get; set; }
        public string BONOS { get; set; }
        public string Q_LINEAS { get; set; }
        public decimal? COD_CONTROL { get; set; }
        public string COD_ILIMITADO { get; set; }
        public decimal? VLR_CONTROL_ACTUAL { get; set; }
        public decimal? VLR_ILIMITADO_ACTUAL { get; set; }
        public string NOMBRE_PLAN_ANT { get; set; }
        public decimal? CB_ACTUAL_SIN_IVA_ANT { get; set; }
        public string CB_INTEGRADO_ANT { get; set; }
        public decimal? CB_ANT { get; set; }
        public decimal? VLR_MIN_MOVISTAR_ANT { get; set; }
        public decimal? VLR_MIN_FIJOS_ANT { get; set; }
        public decimal? VLR_MIN_OTROS_ANT { get; set; }
        public decimal? VLR_MIN_GRUPO_ANT { get; set; }
        public decimal? VLR_TRIBU_ANT { get; set; }
        public decimal? VLR_MIN_CONEXEMPRESARIAL_ANT { get; set; }
        public decimal? VLR_MIN_ADIC_MOVISTAR_ANT { get; set; }
        public decimal? VLR_MIN_ADIC_FIJOS_ANT { get; set; }
        public decimal? VLR_MIN_ADIC_OTROS_ANT { get; set; }
        public decimal? VLR_MIN_ADIC_GRUPO_ANT { get; set; }
        public decimal? VLR_TRIBU_ADIC_ANT { get; set; }
        public decimal? VLR_MIN_ADIC_CONEXEMPRESARIAL_ANT { get; set; }
        public string VLR_SMS_INCL_MOVISTAR_ANT { get; set; }
        public string VLR_SMS_INCL_OTROS_ANT { get; set; }
        public decimal? VLR_9PREFERIDOS_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_MOVISTAR_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_FIJOS_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_OTROS_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_GRUPO_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_TRIBU_ANT { get; set; }
        public decimal? RECARGA_EMPRESA_AMIGA_ANT { get; set; }
        public decimal? VLR_CONTROL_ANT { get; set; }
        public decimal? VLR_ILIMITADO_ANT { get; set; }
        public decimal? CLICS { get; set; }
        public string DOWN { get; set; }
        public string APLICA_PADRE_FA { get; set; }
        public string APLICA_BENEFICIARIO_FA { get; set; }
        public string PLAN_ADIC_DATOS_2015 { get; set; }
    }
}
