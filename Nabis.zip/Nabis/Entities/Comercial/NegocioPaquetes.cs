﻿namespace Nabis_ET.Comercial
{
	using System;

	public class NegocioPaquetes
	{
		public string user { get; set; }
		public int? paquete { get; set; }
		public int? idlinea { get; set; }
		public string simcard { get; set; }
		public string imei { get; set; }
		public string referencia { get; set; }
		public string plan_ { get; set; }
		public int? ciclo_corte { get; set; }
		public DateTime? fecprogr { get; set; }
	}
}