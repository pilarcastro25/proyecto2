﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class ContactoAutorizadoET
    {
        #region Property

        public string IdContactoAutorizado { get; set; }
        public string NombreCompleto { get; set; }
        public string MovilContacto { get; set; }
        public string EmailContacto { get; set; }
        public string CedulaContacto { get; set; }
        public string IdPerfilAutorizado { get; set; }
        public string PerfilAutorizado { get; set; }
        public string CodigoNegocio { get; set; }
        public string Ivr { get; set; }

        #endregion

        #region Constructor

        public ContactoAutorizadoET(string NombreCompleto, string MovilContacto, string EmailContacto, string CedulaContacto, string IdPerfilAutorizado,string CodigoNegocio, string Ivr)
        {
            this.NombreCompleto = NombreCompleto;
            this.MovilContacto = MovilContacto;
            this.EmailContacto = EmailContacto;
            this.CedulaContacto = CedulaContacto;
            this.IdPerfilAutorizado = IdPerfilAutorizado;
            this.CodigoNegocio = CodigoNegocio;
            this.Ivr = Ivr;
        }

        public ContactoAutorizadoET()
        {
            
        }


        #endregion
    }
}
