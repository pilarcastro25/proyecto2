﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class Cuentas_Subcuentas
    {
        public string IdEb { get; set; }
        public int TipId { get; set; }
        public string CodigoCliente { get; set; }
        public string NombreCuenta { get; set; }
        public string Apellido1Cuenta { get; set; }
        public string Apellido2Cuenta { get; set; }
        public string Telefono { get; set; }
        public string CodTipoCalle { get; set; }
        public string Direccion { get; set; }
        public string Barrio { get; set; }
        public string Complemento { get; set; }
        public int? Departamento { get; set; }
        public int? Ciudad { get; set; }
        public int? Localidad { get; set; }
        public int? IdCiclo { get; set; }
        public string Email { get; set; }
        public int? Estrato { get; set; }
        public int? IdPerfilAutorizado { get; set; }
        public string NombreUsuarioCuenta { get; set; }
        public string ApellidoUsuarioCuenta { get; set; }
        public string TelefonoMovil { get; set; }
    }
}
