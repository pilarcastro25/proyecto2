﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioDocumento
    {
        public long IdDoc { get; set; }
        public DateTime FecIngreso { get; set; }
        public string UserIngreso { get; set; }
        public string IdEb { get; set; }
        public string Alias { get; set; }
        public Byte[] Documento { get; set; }
        public string ContentType { get; set; }
        public string Extension { get; set; }
        public decimal? Peso { get; set; }
        public string PathFile { get; set; }
        public bool? InFilePath { get; set; }
        public bool? IsLoad { get; set; }
        public DateTime? FecLoad { get; set; }
        public string UserLoad { get; set; }
    }
}
