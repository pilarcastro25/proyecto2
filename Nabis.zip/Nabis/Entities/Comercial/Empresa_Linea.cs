﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class Empresa_Linea
    {
        public long IdEmpresaLinea { get; set; }
        public string IdEb { get; set; }
        public int? CantLicencias { get; set; }
        public long? ValorMensual { get; set; }
        public string CiudadFirma { get; set; }
        public string EMail { get; set; }
    }
}
