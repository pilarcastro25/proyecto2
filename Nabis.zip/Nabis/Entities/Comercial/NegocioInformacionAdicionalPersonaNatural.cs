﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioInformacionAdicionalPersonaNatural
    {
        public int IdInformacionAdicionalCondicionesUniformes { get; set; }
        public string GeneroPersonaNatural { get; set; }
        public string TipoTrabajo { get; set; }
        public string TipoContrato { get; set; }
        public string EmpresaDondeLabora { get; set; }
        public string AsignacionSalarial { get; set; }
        public string TarjetaCredito { get; set; }
        public string TarjetaCreditoOtro { get; set; }
        public string TarjertaCreditoNumero { get; set; }
        public DateTime? TarjetaCreditoFechaVencimiento { get; set; }
        public string NombreUsuarioAutorizado { get; set; }
        public string TipoDocumentoUsuarioAutorizado { get; set; }
        public string NumeroIdentificacionUsuarioAutorizado { get; set; }
        public string ReferenciaPersonalNombre1 { get; set; }
        public string ReferenciaPersonalTelefono1 { get; set; }
        public string ReferenciaPersonalNombre2 { get; set; }
        public string ReferenciaPersonalEmpresa2 { get; set; }
        public string ReferenciaPersonalTelefono2 { get; set; }
        public string CodNegocio { get; set; }

        public NegocioInformacionAdicionalPersonaNatural()
        {

        }

        public NegocioInformacionAdicionalPersonaNatural(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "el valor de registro no puede ser un valor nulo o vacio.");
            }
            this.IdInformacionAdicionalCondicionesUniformes = rowInfo.Field<int>("ID_INFORMACION_ADICIONAL_CONDICIONES_UNIFORMES");
            this.GeneroPersonaNatural = rowInfo.Field<string>("GENERO_PERSONA_NATURAL");
            this.TipoTrabajo = rowInfo.Field<string>("TIPO_TRABAJO");
            this.TipoContrato = rowInfo.Field<string>("TIPO_CONTRATO");
            this.EmpresaDondeLabora = rowInfo.Field<string>("EMPRESA_DONDE_LABORA");
            this.AsignacionSalarial = rowInfo.Field<string>("ASIGNACION_SALARIAL");
            this.TarjetaCredito = rowInfo.Field<string>("TARJETA_CREDITO");
            this.TarjetaCreditoOtro = rowInfo.Field<string>("TARJETA_CREDITO_OTRO");
            this.TarjertaCreditoNumero = rowInfo.Field<string>("TARJERTA_CREDITO_NUMERO");
            this.TarjetaCreditoFechaVencimiento = rowInfo.Field<DateTime?>("TARJETA_CREDITO_FECHA_VENCIMIENTO");
            this.NombreUsuarioAutorizado = rowInfo.Field<string>("NOMBRE_USUARIO_AUTORIZADO");
            this.TipoDocumentoUsuarioAutorizado = rowInfo.Field<string>("TIPO_DOCUMENTO_USUARIO_AUTORIZADO");
            this.NumeroIdentificacionUsuarioAutorizado = rowInfo.Field<string>("NUMERO_IDENTIFICACION_USUARIO_AUTORIZADO");
            this.ReferenciaPersonalNombre1 = rowInfo.Field<string>("REFERENCIA_PERSONAL_NOMBRE_1");
            this.ReferenciaPersonalTelefono1 = rowInfo.Field<string>("REFERENCIA_PERSONAL_TELEFONO_1");
            this.ReferenciaPersonalNombre2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_NOMBRE_2");
            this.ReferenciaPersonalEmpresa2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_EMPRESA_2");
            this.ReferenciaPersonalTelefono2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_TELEFONO_2");
            this.CodNegocio = rowInfo.Field<string>("COD_NEGOCIO");
        }
    }
}
