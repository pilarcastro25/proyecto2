﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public  class LineasNegocio
    {
        public int IdLinea { get; set; }
        public string IdEb { get; set; }
        public int? IdEstructuraVenta { get; set; }
        public string Central { get; set; }
        public string NumeroMovil { get; set; }
        public int? CodSclSimcard { get; set; }
        public string Simcard { get; set; }
        public string DescuentoValorSimcard { get; set; }
        public int? CodSclImei { get; set; }
        public string Imei { get; set; }
        public string DescuentoValorImei { get; set; }
        public int? CambioUso { get; set; }
        public int? LimiteConsumo { get; set; }
        public string Correo { get; set; }
        public DateTime? FechaSolicitud { get; set; }
        public string UserId { get; set; }
        public int? IdEstado { get; set; }
        public string Estado { get; set; }
        public DateTime? FechaActivacion { get; set; }
        public long? CodigoAbonado { get; set; }
        public long? CodigoVenta { get; set; }
        public int? Paquete { get; set; }
        public int? TipoStock { get; set; }
        public string TipoPedido { get; set; }
    }
}
