﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioPlanesAdquiridos
    {
        public int IdDescripcionPlan { get; set; }
        public string IdPlanTarifario { get; set; }
        public int CantidadLineas { get; set; }
        public string ValorMovistarVoz { get; set; }
        public string ValorFijoVoz { get; set; }
        public string ValorOtrosVoz { get; set; }
        public string ValorMovistarAdicionalVoz { get; set; }
        public string ValorFijoAdicionalVoz { get; set; }
        public string ValorOtrosAdicionalVoz { get; set; }
        public string ServicioObs1 { get; set; }
        public string ServicioObs2 { get; set; }
        public string ServicioObs3 { get; set; }
        public string ServicioObs4 { get; set; }
        public string IdPlanServicioAdicional1 { get; set; }
        public string DescuentoValorServ1 { get; set; }
        public string ServicioAdicional1ValorMovistarVoz { get; set; }
        public string RentaMesPlanDatosServicioAdicional1 { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional1 { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional1 { get; set; }
        public string IdPlanServicioAdicional2 { get; set; }
        public string DescuentoValorServ2 { get; set; }
        public string ServicioAdicional2ValorMovistarVoz { get; set; }
        public string RentaMesPlanDatosServicioAdicional2 { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional2 { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional2 { get; set; }
        public string IdPlanServicioAdicional3 { get; set; }
        public string DescuentoValorServ3 { get; set; }
        public string ServicioAdicional3ValorMovistarVoz { get; set; }
        public string RentaMesPlanDatosServicioAdicional3 { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional3 { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional3 { get; set; }
        public string PlanAdicionalObs1 { get; set; }
        public string PlanAdicionalObs2 { get; set; }
        public string PlanAdicionalObs3 { get; set; }
        public string IdPlanPlanAdicional1 { get; set; }
        public string DescuentoValorPlanAdic1 { get; set; }
        public string PlanAdicional1ValorMovistarVoz { get; set; }
        public string RentaMesPlanDatosPlanAdicional1 { get; set; }
        public string KbIncluidoPlanDatosPlanAdicional1 { get; set; }
        public string KbAdicionalPlanDatosPlanAdicional1 { get; set; }
        public string IdPlanPlanAdicional2 { get; set; }
        public string DescuentoValorPlanAdic2 { get; set; }
        public string PlanAdicional2ValorMovistarVoz { get; set; }
        public string RentaMesPlanDatosPlanAdicional2 { get; set; }
        public string KbIncluidoPlanDatosPlanAdicional2 { get; set; }
        public string KbAdicionalPlanDatosPlanAdicional2 { get; set; }
        public string PlanDatosRentaMes { get; set; }
        public string PlanDatosKbIncluido { get; set; }
        public string PlanDatosKbAdicional { get; set; }
        public string IdCodigoNegocio { get; set; }
        public string CargoBasico { get; set; }
        public string MinutosIncluidos { get; set; }
        public string ValorOtrosG { get; set; }
        public string ValorGAdicionalVoz { get; set; }
        public int? IdEstructuraVenta { get; set; }
        public string Producto { get; set; }
    }
}
