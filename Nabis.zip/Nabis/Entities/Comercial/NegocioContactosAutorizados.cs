﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioContactosAutorizados
    {
        public int IdUsuarioAutorizado { get; set; }
        public string Contacto1Nombre { get; set; }
        public string Contacto1Movil { get; set; }
        public string Contacto1Email { get; set; }
        public string Contacto1PerfilAutorizado { get; set; }
        public string Contacto1Cedula { get; set; }
        public string Contacto2Nombre { get; set; }
        public string Contacto2Movil { get; set; }
        public string Contacto2Email { get; set; }
        public string Contacto2PerfilAutorizado { get; set; }
        public string Contacto2Cedula { get; set; }
        public string Contacto3Nombre { get; set; }
        public string Contacto3Movil { get; set; }
        public string Contacto3Email { get; set; }
        public string Contacto3PerfilAutorizado { get; set; }
        public string Contacto3Cedula { get; set; }
        public string Contacto4Nombre { get; set; }
        public string Contacto4Movil { get; set; }
        public string Contacto4Email { get; set; }
        public string Contacto4PerfilAutorizado { get; set; }
        public string Contacto4Cedula { get; set; }
        public string IdCodigoNegocio { get; set; }
    }
}
