﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class NegocioCobroRevertidoMepe
    {
        public int IdCobroRevertidoMepe { get; set; }
        public string IdEb { get; set; }
        public string ActividadEconomica { get; set; }
        public string CodPlan { get; set; }
        public string NombrePlan { get; set; }
        public int? IdTipoPlan { get; set; }
        public string TipoPlan { get; set; }
        public int? ApartadoCliente { get; set; }
        public string CategoriaImpositiva { get; set; }
        public string Cobertura { get; set; }
        public int? CodCliente { get; set; }
        public int? ContactoAutTipoIdent { get; set; }
        public long? ContactoAutNumIdent { get; set; }
        public string ContactoAutNombre { get; set; }
        public string ContactoAutApellido1 { get; set; }
        public string ContactoAutApellido2 { get; set; }
        public string ContactoAutMail { get; set; }
        public long? ContactoAutNumFijo { get; set; }
        public long? ContactoAutNumCelular { get; set; }
        public string ContactoAutDireccion { get; set; }
        public string ContactoAutIdCiudad { get; set; }
        public string ContactoAutCiudad { get; set; }
        public string ContactoAutIdDepartamento { get; set; }
        public string ContactoAutDepartamento { get; set; }
        public long? CobroLineaEspecial { get; set; }
        public long? CobroNumEnrutamiento { get; set; }
        public bool? CobroIsLinea018000 { get; set; }
        public bool? CobroIsNumeralAbreviado { get; set; }
        public bool? CobroIsLinea1xy { get; set; }
        public double? CobroValorMinuto { get; set; }
        public double? MepeValorMensaje { get; set; }
        public int? MepeCodActivacion { get; set; }
        public int? MepeCantidadMensajes { get; set; }
    }
}
