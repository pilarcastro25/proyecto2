﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.Comercial
{
    public class Estructura_Venta_Completa
    {
        public string User { get; set; }
        public string IdEb  { get; set; }
        //Estrcutura de venta
        public int? SubCatImpos { get; set; }
        public int IdCuota  { get; set; }
        public int CantidadLineas  { get; set; }
        public int IdProducto  { get; set; }
        public char? Traido  { get; set; }
        public string IdPlan  { get; set; }
        public string DescuentoValorPlan  { get; set; }
        public string FormaPago  { get; set; }
        public int? Roaming  { get; set; }
        public string CodBeneficioCargoBasico { get; set; }
        public string BeneficioCondicionesCargoBasico { get; set; }
        public float? ValorSimCard { get; set; }
        public float? ValorEquipo { get; set; }
        public float? ValorEquipoKoral { get; set; }
        public float? ValorEquipoBeneficio { get; set; }
        public float? ValorEquipoDiferido { get; set; }
        public float? CuotaInicial { get; set; }
        //Plan Adquirido
        public string ValorMovistarVoz  { get; set; }
        public string ValorFijoVoz  { get; set; }
        public string ValorOtrosVoz  { get; set; }
        public string ValorMovistarAdicionalVoz  { get; set; }
        public string ValorFijoAdicionalVoz  { get; set; }
        public string ValorOtrosAdicionalVoz  { get; set; }
        public string IdPlanServicioAdicional1  { get; set; }
        public string DescuentoValorServ1  { get; set; }
        public string ServicioAdicional1ValorMovistarVoz  { get; set; }
        public string RentaMesPlanDatosServicioAdicional1  { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional1  { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional1  { get; set; }
        public string IdPlanServicioAdicional2  { get; set; }
        public string DescuentoValorServ2  { get; set; }
        public string ServicioAdicional2ValorMovistarVoz  { get; set; }
        public string RentaMesPlanDatosServicioAdicional2  { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional2  { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional2  { get; set; }
        public string IdPlanServicioAdicional3  { get; set; }
        public string DescuentoValorServ3  { get; set; }
        public string ServicioAdicional3ValorMovistarVoz  { get; set; }
        public string RentaMesPlanDatosServicioAdicional3  { get; set; }
        public string KbIncluidoPlanDatosServicioAdicional3  { get; set; }
        public string KbAdicionalPlanDatosServicioAdicional3  { get; set; }
        public string IdPlanPlanAdicional1  { get; set; }
        public string DescuentoValorPlanAdic1  { get; set; }
        public string PlanAdicional1ValorMovistarVoz  { get; set; }
        public string RentaMesPlanDatosPlanAdicional1  { get; set; }
        public string KbIncluidoPlanDatosPlanAdicional1  { get; set; }
        public string KbAdicionalPlanDatosPlanAdicional1  { get; set; }
        public string IdPlanPlanAdicional2  { get; set; }
        public string DescuentoValorPlanAdic2  { get; set; }
        public string PlanAdicional2ValorMovistarVoz  { get; set; }
        public string RentaMesPlanDatosPlanAdicional2  { get; set; }
        public string KbIncluidoPlanDatosPlanAdicional2  { get; set; }
        public string KbAdicionalPlanDatosPlanAdicional2  { get; set; }
        public string PlanDatosRentaMes  { get; set; }
        public string PlanDatosKbIncluido  { get; set; }
        public string PlanDatosKbAdicional  { get; set; }
        public string CargoBasico  { get; set; }
        public string MinutosIncluidos  { get; set; }
        public string ValorOtrosG  { get; set; }
        public string ValorGAdicionalVoz  { get; set; }
        //Nuevos Plan Adquirido
        public string CodBeneficioRecurrente { get; set; }
        public string BeneficioCondiciones { get; set; }
        public bool? ControlVoz { get; set; }
        public bool? ControlDatos { get; set; }
        public bool? ControlSms { get; set; }
        public bool? ControlLdi { get; set; }
        public bool? ControlPremium { get; set; }
        //Líneas
        public string NumeroMovil  { get; set; }
        public int TipId { get; set; }
        public string Carterizado { get; set; }
        public int? CodSclSimcard  { get; set; }
        public string Simcard  { get; set; }
        public string DescuentoValorSimcard  { get; set; }
        public int? CodSclImei  { get; set; }
        public string Imei  { get; set; }
        public string DescuentoValorImei  { get; set; }
        public string Correo  { get; set; }      
        public DateTime? FechaActivacion  { get; set; }
        public bool PedidoSimcard { get; set; }
        public bool PedidoEquipos { get; set; }
        public string PortabilidadXml { get; set; }
        //Traspaso
        public bool IsTraspaso { get; set; }
        public long? NumIdentOrigen { get; set; }
        public string TraspasoXml { get; set; }
        //CobroRevertidoMepe
        public bool IsCobroMepe { get; set; }
        public string CobroMepeXml { get; set; }
        // Informacion adicional de condiciones uniformes (persona natural)
        public bool IsCondicionesUniformes { get; set; }
        public string CondicionesUniformesXml { get; set; }
        // Informacion adicional de condiciones uniformes
        public string ValorMensajeTextoIncluido_M { get; set; }
        public string ValorMensajeTextoIncluido_G { get; set; }
        public string ValorMensajeTextoIncluido_O { get; set; }
        public string ValorMensajeTextoAdicional_M { get; set; }
        public string ValorMensajeTextoAdicional_G { get; set; }
        public string ValorMensajeTextoAdicional_O { get; set; }
        public string BandaEquipo_aws { get; set; }
        public string BandaEquipo_aws_2500mhz { get; set; }
        public string BandaEquipo_otra { get; set; }
    }
}
