﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class BeneficiosAplicados
    {
        public string ID_REGISTRO { get; set; }
        public long ABONADO { get; set; }
        public long CELULAR { get; set; }
        public int CODIGO_CICLO { get; set; }
        public string FECHA_ALTA { get; set; }
        public DateTime FECHA_HORA_ALTA { get; set; }
        public string TIPO_IDENTIFICACION { get; set; }
        public string IDENTIFICACION { get; set; }
        public string NOMBRE_CLIENTE { get; set; }
        public string CODIGO_PLAN { get; set; }
        public string DESCRIPCION_PLAN { get; set; }
        public string CODIGO_BENEFICIO { get; set; }
        public string DESCRIPCION_BENEFICIO { get; set; }
        public string PERIODOS { get; set; }
        public string FECHA_BENEFICIO { get; set; }
        public DateTime FECHA_HORA_BENEFICIO { get; set; }
        public string CODIGO_USUARIO { get; set; }
        public string NOMBRE_USUARIO { get; set; }
        public int CODIGO_ESTADO { get; set; }
    }
}
