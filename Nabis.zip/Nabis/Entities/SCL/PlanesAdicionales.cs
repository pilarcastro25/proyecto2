﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class PlanesAdicionales
    {
        public string CodigoPlan { get; set; }
        public string CodigoPlanAdicional { get; set; }
        public string CodigoProductoAdicional { get; set; }
        public string ProductoAdicional { get; set; }
        public string Relacion { get; set; }
        public int CodigoFacturacion { get; set; }
        public string ConceptoFacturacion { get; set; }
        public int? Tarifa { get; set; }
    }
}
