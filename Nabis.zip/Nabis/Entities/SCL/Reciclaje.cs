﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class Reciclaje
    {
        public int CodigoCliente { get; set; }
        public int CodigoAbonado { get; set; }
        public string CodigoCausalBaja { get; set; }
        public string CodigoPlan { get; set; }
        public string CodigoSituacion { get; set; }
        public DateTime FechaBaja { get; set; }
        public string Identificacion { get; set; }
        public string TipoUso { get; set; }
        public DateTime FechaAlta { get; set; }
        public long NumeroMovil { get; set; }
        public string CodigoTecnologia { get; set; }
        public int CodigoCiclo { get; set; }
        public int EsPortado { get; set; }
    }
}
