﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class SeriesBodegas
    {
        public string NumeroSerie { get; set; }
        public int CodigoBodega { get; set; }
        public string Bodega { get; set; }
        public string DescripcionTipoBodega { get; set; }
        public int CodigoArticulo { get; set; }
        public string DescripcionArticulo { get; set; }
        public int TipoStock { get; set; }
        public string Estado { get; set; }
        public int IdTipoUso { get; set; }
        public string Central { get; set; }
        public int? CodigoCentral { get; set; }
        public string Codigohlr { get; set; }
        public string Descripcionhlr { get; set; }
        public long? NumeroMovil { get; set; }
    }
}
