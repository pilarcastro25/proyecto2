﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class LineasAAA
    {
        public long NUM_CELULAR { get; set; }
        public long NUM_ABONADO { get; set; }
        public long COD_CLIENTE { get; set; }
        public long COD_CUENTA { get; set; }
        public long NUM_VENTA { get; set; }
        public long NUM_IMEI { get; set; }
        public long NUM_SERIE { get; set; }
        public string COD_SITUACION { get; set; }
    }
}
