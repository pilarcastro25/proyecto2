﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class PlanesServicios
    {
        public string CodigoPlan { get; set; }
        public string CodigoServicio { get; set; }
        public string DescripcionServicio { get; set; }
        public string EsCorreo { get; set; }
        public string Relacion { get; set; }
        public int CodigoFacturacion { get; set; }
        public string ConceptoFacturacion { get; set; }
        public int? Tarifa { get; set; } 
    }
}
