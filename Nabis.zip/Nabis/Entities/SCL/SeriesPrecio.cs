﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class SeriesPrecio
    {
        public int CodigoModalidadVenta { get; set; }
        public int Meses { get; set; }
        public int CodigoTipoUso { get; set; }
        public int TipoProducto { get; set; }
        public string CodigoCategoria { get; set; }
        public int CodigoArticulo { get; set; }
        public int TipoStock { get; set; }
        public int CodigoFacturacion { get; set; }
        public string ConceptoFacturacion { get; set; }
        public string ConceptoVenta { get; set; }
        public int? Tarifa { get; set; }
        public string DescuentoContrato { get; set; }
        public decimal? DescuentoCarpeta { get; set; }
    }
}
