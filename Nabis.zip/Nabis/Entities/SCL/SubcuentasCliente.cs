﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class SubcuentasCliente
    {
        public int CodigoCuenta { get; set; }
        public string CodigoSubcuenta { get; set; }
        public string NombreSubcuenta { get; set; }
    }
}
