﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class PlanesTarifarios
    {
        public int? CodigoTipoUso { get; set; }
        public string TipoUso { get; set; }
        public string CodigoPlan { get; set; }
        public string DescripcionPlan { get; set; }
        public string LimiteConsumo { get; set; }
        public string CodigoTipoPlan { get; set; }
        public string CodigoCategoria { get; set; }
        public string DescripcionCategoria { get; set; }
        public string ConceptoFacturacion { get; set; }
        public string DescripcionFacturacion { get; set; }
        public int? Tarifa { get; set; }
    }
}
