﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class Articulos
    {
        public int CodigoArticulo { get; set; }
        public string DescripcionArticulo { get; set; }
        public int CodigoFabricante { get; set; }
        public string DescripcionFabricante { get; set; }
        public string ReferenciaFabricante { get; set; }
        public string DescripcionTerminal { get; set; }
        public int UsoPortabilidad { get; set; }
    }
}
