﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class ResultadosPortabilidad
    {
        public string NumeroPortable { get; set; }
        public string CodigoSolicitud { get; set; }
        public string Estado { get; set; }
        public string DescripcionEstado { get; set; }
        public string CodigoSituacion { get; set; }
        public string Codigospn { get; set; }
        public string Identificacion { get; set; }
        public string IdCorto { get; set; }
        public DateTime FechaVentana { get; set; }
    }
}
