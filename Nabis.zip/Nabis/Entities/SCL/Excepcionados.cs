﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class Excepcionados
    {
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public DateTime FechaDesde { get; set; }
        public DateTime FechaHasta { get; set; }
        public string NombreUsuario { get; set; }
        public DateTime FechaUltimaModificacion { get; set; }
        public int CodigoRestriccion { get; set; }
    }
}
