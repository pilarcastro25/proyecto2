﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class CuentasCliente
    {
        public int CodigoCuenta { get; set; }
        public string TipoIdentificacion { get; set; }
        public string Identificacion { get; set; }
        public DateTime FechaNacimiento { get; set; }
    }
}
