﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_ET.SCL
{
    public class UsuariosAreas
    {
        public string NombreUsuario { get; set; }
        public string NombreOperador { get; set; }
        public int CodigoVendedor { get; set; }
        public string Area { get; set; }
    }
}
