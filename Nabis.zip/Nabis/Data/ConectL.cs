﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;

namespace DL
{
    public class ConectL
    {
        #region Campos
        private SqlConnection conexion = new SqlConnection(Properties.Resources.ResourceManager.GetString("NABIS"));
        private Dictionary<string, object> parameters = new Dictionary<string, object>();
        private Dictionary<string, SqlParameter> parametersOutput = new Dictionary<string, SqlParameter>();
        public Double timeQuery;
        public int numRows = 0;
        public int numColumns = 0;
        public SqlDataReader data;
        public string[] dataColumns;
        public List<object[]> dataRows = new List<object[]>();
        public bool error = false;
        #endregion
        #region Propiedades
        public string CommandQuery { get; set; }
        #endregion
        public ConectL()
        {

        }

        public void AddParameters(string key, object value)
        {
            if (value == null)
            {
                value = DBNull.Value;
            }
            else if (value.GetType().ToString() == "System.String")
            {
                value = (value == null) ? (DBNull.Value) : (value);
            }
            parameters.Add(key, value);
        }
        public void AddParametersOutPut(string key, object value, SqlDbType type)
        {
            SqlParameter param = new SqlParameter(key, value);
            param.SqlDbType = type;
            param.Direction = ParameterDirection.Output;
            parametersOutput.Add(key, param);
        }
        public void ExecQuery(Boolean execStoreProcedure)
        {
            try
            {
                SqlCommand command = new SqlCommand(CommandQuery, conexion);
                //verifica si es procedimiento almacenado
                if (execStoreProcedure)
                {
                    command.CommandType = CommandType.StoredProcedure;
                    //Asigna parametros de consulta o de procedimiento
                    if (parameters != null)
                    {
                        foreach (KeyValuePair<string, object> parameter in parameters)
                        {
                            if (parameter.Value.GetType().ToString() == "System.String")
                            {
                                SqlParameter param = new SqlParameter("@" + parameter.Key, SqlDbType.VarChar);
                                param.Value = parameter.Value;
                                command.Parameters.Add(param);
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@" + parameter.Key, parameter.Value);
                            }
                            //command.Parameters.Add(paramsKeys[i], paramsTypes[i]).Value = paramsValues[i]; --> desactivado por estar obsoleto > fuente: http://msdn.microsoft.com/es-es/library/vstudio/9dd8zze1%28v=vs.80%29.aspx, http://msdn.microsoft.com/es-es/library/9dd8zze1%28v=vs.80%29.aspx
                            //System.Web.HttpContext.Current.Response.Write(paramsKeys(index) & ":" & paramsValues(index) & "(" & paramsTypes(index) & ")")
                        }
                    }
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter row in parametersOutput.Values)
                        {
                            command.Parameters.Add(row);
                        }
                    }
                }
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                data = command.ExecuteReader();
                //Verifica si hubo resultados (filas)
                if (data.HasRows)
                {
                    //Obtiene estructura de Columnas del dataReader
                    DataTable dataTable = data.GetSchemaTable();
                    //Define la dimensión de dataColumns con base en el total de columnas 
                    dataColumns = new string[dataTable.Rows.Count];
                    //Recorre las filas que contienen la información de las columnas
                    foreach (DataRow item in dataTable.Rows)
                    {
                        //Almacena en indice actual el nombre de la columna actual
                        dataColumns[numColumns] = item[0].ToString();
                        numColumns++;
                    }
                    dataTable.Clear();
                    int i = 0;
                    while (data.Read())
                    {
                        object[] row = new object[data.FieldCount];
                        data.GetValues(row);
                        dataRows.Add(row);
                        i++;
                    }
                    numRows = i;
                    data.Close();
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter item in parametersOutput.Values)
                        {
                            item.Value = command.Parameters[item.ParameterName].Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                error = true;
                conexion.Close();
                if (CommandQuery != "Nab_Log_Excepciones_Registro")
                {
                    this.Reset();
                }
            }
            finally
            {
                data = null;
                conexion.Close();
                conexion.Dispose();
            }
        }
        public void Reset()
        {
            if (parameters.Count > 0) { this.parameters.Clear(); }
            if (this.parametersOutput != null) { this.parametersOutput.Clear(); }
            this.dataColumns = null;
            this.dataRows.Clear();
            this.numRows = 0;
            this.numColumns = 0;
            this.timeQuery = 0;
            this.parametersOutput = null;
        }

        public string GetColumnValue(string columnName)
        {
            int indexColumn = Array.IndexOf(dataColumns, columnName);
            if (indexColumn != -1)
            {
                string value = dataRows[0][indexColumn].ToString();
                return value;
            }
            else
            {
                return indexColumn.ToString();
            }
        }
        public DataTable GetDataTable(Boolean execStoreProcedure)
        {
            DataTable dataTable = new DataTable();
            SqlCommand command = new SqlCommand(CommandQuery, conexion);
            //verifica si es procedimiento almacenado
            if (execStoreProcedure)
            {
                command.CommandType = CommandType.StoredProcedure;
                //Asigna parametros de consulta o de procedimiento
                if (parameters != null)
                {
                    foreach (KeyValuePair<string, object> parameter in parameters)
                    {
                        if (parameter.Value.GetType().ToString() == "System.String")
                        {
                            SqlParameter param = new SqlParameter("@" + parameter.Key, SqlDbType.VarChar);
                            param.Value = parameter.Value;
                            command.Parameters.Add(param);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("@" + parameter.Key, parameter.Value);
                        }
                        //command.Parameters.Add(paramsKeys[i], paramsTypes[i]).Value = paramsValues[i]; --> desactivado por estar obsoleto > fuente: http://msdn.microsoft.com/es-es/library/vstudio/9dd8zze1%28v=vs.80%29.aspx, http://msdn.microsoft.com/es-es/library/9dd8zze1%28v=vs.80%29.aspx
                        //System.Web.HttpContext.Current.Response.Write(paramsKeys(index) & ":" & paramsValues(index) & "(" & paramsTypes(index) & ")")
                    }
                }
                if (parametersOutput != null)
                {
                    foreach (SqlParameter parameter in parametersOutput.Values)
                    {
                        command.Parameters.Add(parameter);
                    }
                }
            }
            //Time out de conexión a 0
            command.CommandTimeout = 0;
            //Abre conexión
            conexion.Open();
            //Ejecuta sentencia
            SqlDataAdapter adapterData = new SqlDataAdapter();
            adapterData.SelectCommand = command;
            dataTable.Locale = CultureInfo.InvariantCulture;
            adapterData.Fill(dataTable);
            return dataTable;
        }

    }
}
