/****** Object:  StoredProcedure [dbo].[Nab_Global_Reportes]    Script Date: 10/03/2016 11:20:47 ******/
IF  OBJECT_ID(N'[dbo].[Nab_Global_Reportes]') is not null
DROP PROCEDURE [dbo].[Nab_Global_Reportes]
GO

/****** Object:  StoredProcedure [dbo].[Nab_Global_Reportes]    Script Date: 10/03/2016 11:20:47 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,Nelson Fabian Rios,Name>
-- Create date: <Create Date,08 DE JULIO 2016,>
-- Description:	<Description,Reportes nabis,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_Global_Reportes]
	@fec_inicial varchar(10),
	@fec_final varchar(10),
	@nit varchar(30)=null,
	@canal varchar(20)=null,
	@grupo varchar(100)=null,
	@regional varchar(100)=null,
	@estado varchar(100) = null
AS
BEGIN
print 'MENS'
--	DECLARE @wk_no NVARCHAR(500);
--	DECLARE @MD NVARCHAR(500);
--	DECLARE @V_RUTA NVARCHAR(500);
--	DECLARE @V_NOM_ARCHIVO_FULL NVARCHAR(500);
--	DECLARE @V_ANHOMES NVARCHAR(6);
	DECLARE @V_CADENA nvarchar(4000);
--	DECLARE @V_TABLA_FULL NVARCHAR(500);
--	DECLARE @paramsBCP varchar(100);
		
--	SET NOCOUNT ON;
	
--	SET @V_ANHOMES= REPLACE(CONVERT(NVARCHAR(10),GETDATE(),120),'-','');
--    SET @wk_no = '\\archivos\Gsoporte\Insumos\Reportes\';
--	SET @MD = ' mkdir ' + @wk_no;
--	EXEC xp_cmdshell @MD, no_output;	
	
--	SET @V_RUTA = '\\archivos\Gsoporte\Insumos\Reportes\';
--	SET @V_NOM_ARCHIVO_FULL= 'ReporteNabis_'+@V_ANHOMES+'.csv';
--	SET @V_TABLA_FULL = 'dbo.Nab_EB_VW_ComercialConsulta_Negocio';
--	SET @paramsBCP = '-C ACP -w -r \n -U "Nablink" -P "Transac" -S "BDSQL\USUARIOS"';
	
	set @V_CADENA= N'SELECT idEb,
					tipoIdent,
					numIdent,
					empresa,
					fecIngreso,
					cantLineas,
					canal,
					grupo,
					codAsesor,
					regional,
					codAgente,
					tipSolicitud,
					TramiteMesa,
					LinApro,
					TramiteCredito,
					ActiLinActi,
					ActiLinPen,
					TramiteActivacion
					FROM dbo.Nab_EB_VW_ComercialConsulta_Negocio 
					WHERE (fecIngreso between ''' + replace(@fec_inicial,'/','-') + ''' and ''' + replace(@fec_final, '/', '-') + ''')'
					print @V_CADENA;					
					if(@nit is not null and @nit<>'')
					begin
					set @V_CADENA = @V_CADENA + ' and numident = '''+@nit+'''';
					print @V_CADENA
					end
					if(@canal is not null and @canal<>'')
					begin
					set @V_CADENA = @V_CADENA + ' and canal = '''+@canal+'''';
					print @V_CADENA
					end
					if(@grupo is not null and @grupo<>'')
					begin
					set @V_CADENA = @V_CADENA + ' and grupo = '''+@grupo+'''';
					print @V_CADENA
					end
					if(@regional is not null and @regional<>'')
					begin
					set @V_CADENA = @V_CADENA + ' and regional = '''+@regional+''''
					print @V_CADENA
					end
					if(@estado is not null and @estado<>'')
					begin
					set @V_CADENA = @V_CADENA + 'and estado = '''+@estado + '''';
					print @V_CADENA
					end
	
execute(@V_CADENA)
--declare @cant int
--declare @V_CADENA2 nvarchar(4000)
--set @V_CADENA2 = 'select @cnt = count(*) from (' + @V_CADENA + ')'
--print @V_CADENA2
--execute sp_executesql @V_CADENA2, N'@cnt int output', @cnt = @cant output
	--IF (@cant) > 0
	--BEGIN
	--	SET @V_CADENA = 'bcp "SELECT * FROM dbo.Nab_EB_VW_ComercialConsulta_Negocio" queryout ' + @V_RUTA + ' ' + @V_NOM_ARCHIVO_FULL +' ' + @paramsBCP
	--	print @V_CADENA
	--END
	--ELSE
	--BEGIN
	--	SET @V_CADENA = 'BCP " SELECT ''No hay registros disponibles para el reporte " queryOUT "' + @V_RUTA +' '+ @V_NOM_ARCHIVO_FULL +' '+ @paramsBCP
	--	print @V_CADENA
	--END
	--EXEC master..XP_CMDSHELL @V_CADENA;
	
	--SET @V_CADENA = 'SELECT ''Reporte '+@V_NOM_ARCHIVO_FULL+' descargado en '+@V_RUTA+ ''' as descargar_lb'
	--print @V_CADENA
	--EXEC master..XP_CMDSHELL @V_CADENA;
	
END

/*
exec dbo.Nab_Global_Reportes 
'07-01-2013', '07-01-2015', '','','','Bogota','',''
@nit=null, 
@canal=null, 
@grupo=null, 
@regional=null,  
@proceso=null, 
@estado=null;
SELECT GETDATE()
*/
GO

