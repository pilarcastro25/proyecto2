/****** Object:  StoredProcedure [dbo].[Nab_GuardarAnexosNegocio]    Script Date: 10/03/2016 10:03:54 ******/
IF  OBJECT_ID(N'[dbo].[Nab_GuardarAnexosNegocio]') is not null
DROP PROCEDURE [dbo].[Nab_GuardarAnexosNegocio]
GO

/****** Object:  StoredProcedure [dbo].[Nab_GuardarAnexosNegocio]    Script Date: 10/03/2016 10:03:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_GuardarAnexosNegocio] 
	-- Add the parameters for the stored procedure here
	@CodigoNegocio_FK varchar(50),
	@Numero varchar(20),
	@CodigoDePlan varchar(20),
	@CodServSuplementario varchar(10),
	@RentaBasica varchar(20),
	@RentaBasicaServSuplementario varchar(20),
	@CapacidadDeDatosServSupl varchar(20),
	@ImeiEquipo varchar(20),
	@EsVoz int,
	@EsDatos int,
	@EsSMS int,
	@EsLDI int,
	@EsPremium int,
	@EsPortabilidad int,
	@OperadorDonante varchar(10),
	@NoNIP varchar(10),
	@EquipoTraidoVendido varchar(20),
	@NoSerial varchar(50),
	@Imei varchar(20),
	@MarcaRefEquipo varchar(50),
	@ValorEquipo float,
	@ValorEquipoKoralOPricing float,
	@EquipoACuotas int,
	@CuotaInicial float,
	@ValorADiferir float,
	@NumeroDeCuotas int,
	@SerialSimCard varchar(20),
	@ValorDeLaSimCard float,
	@ValorBeneficio float,
	@CondicionesBeneficio varchar(200),
	@CodigoBeneficioRecurrente varchar(10),
	@CondicionesBeneficioBasico varchar(200),
	@CodigoBeneficioBasico varchar(10),
	@Observaciones varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   INSERT INTO [dbo].NAB_ANEXOS_NEGOCIO VALUES(
      
    @CodigoNegocio_FK,
	@Numero,
	@CodigoDePlan,
	@CodServSuplementario,
	@RentaBasica,
	@RentaBasicaServSuplementario,
	@CapacidadDeDatosServSupl,
	@ImeiEquipo,
	@EsVoz,
	@EsDatos,
	@EsSMS,
	@EsLDI,
	@EsPremium,
	@EsPortabilidad,
	@OperadorDonante,
	@NoNIP,
	@EquipoTraidoVendido,
	@NoSerial,
	@Imei,
	@MarcaRefEquipo,
	@ValorEquipo,
	@ValorEquipoKoralOPricing,
	@EquipoACuotas,
	@CuotaInicial,
	@ValorADiferir,
	@NumeroDeCuotas,
	@SerialSimCard,
	@ValorDeLaSimCard,
	@ValorBeneficio,
	@CondicionesBeneficio,
	@CodigoBeneficioRecurrente,
	@CondicionesBeneficioBasico,
	@CodigoBeneficioBasico,
	@Observaciones
   )
END
GO

