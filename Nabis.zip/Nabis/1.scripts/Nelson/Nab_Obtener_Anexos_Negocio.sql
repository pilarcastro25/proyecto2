/****** Object:  StoredProcedure [dbo].[Nab_Obtener_Anexos_Negocio]    Script Date: 10/03/2016 10:02:29 ******/
IF  OBJECT_ID(N'[dbo].[Nab_Obtener_Anexos_Negocio]') is not null
DROP PROCEDURE [dbo].[Nab_Obtener_Anexos_Negocio]
GO

/****** Object:  StoredProcedure [dbo].[Nab_Obtener_Anexos_Negocio]    Script Date: 10/03/2016 10:02:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_Obtener_Anexos_Negocio]  
	@CodigoNegocio varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from NABIS.dbo.NAB_ANEXOS_NEGOCIO
	where CodigoNegocio_FK = @CodigoNegocio
END

GO

