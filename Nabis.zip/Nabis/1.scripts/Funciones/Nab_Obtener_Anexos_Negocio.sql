USE [NABIS]
GO

/****** Object:  StoredProcedure [dbo].[Nab_Obtener_Anexos_Negocio]    Script Date: 09/30/2016 20:09:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_Obtener_Anexos_Negocio]  
	@CodigoNegocio varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT * from NABIS.dbo.NAB_ANEXOS_NEGOCIO
	where CodigoNegocio_FK = @CodigoNegocio
END

GO

