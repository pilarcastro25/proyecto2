IF OBJECT_ID (N'dbo.fnAppendLine') IS NOT NULL
   DROP FUNCTION dbo.fnAppendLine
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres
-- Fecha Creación     : 2014-03-14
-- Descripción        : Permite agregar una nueva línea de texto a una cadena.
--
-- Parámetros         : @inputString    - Cadena original.
--                      @attachedString - Texto de la línea a añadir.
--
-- Retorno            : @outputString   - Cadena concatenada.
-- ========================================================================================
CREATE FUNCTION dbo.fnAppendLine
(
	@inputString VARCHAR(MAX),
	@attachedString VARCHAR(MAX)
)
RETURNS VARCHAR(MAX) AS
BEGIN
	DECLARE @outputString VARCHAR(MAX);
	SET @outputString = '';
	IF @inputString IS NOT NULL
	BEGIN		
		IF @attachedString IS NOT NULL
		BEGIN		
			SET @outputString = dbo.fnConcatWith(@inputString, @attachedString, CHAR(13));
		END
	END
	RETURN @outputString;
END 

