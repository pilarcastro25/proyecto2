USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_ANEXOS_NEGOCIO]    Script Date: 09/30/2016 20:08:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_ANEXOS_NEGOCIO](
	[CodigoNegocio_FK] [varchar](50) NULL,
	[Numero] [varchar](20) NULL,
	[CodigoDePlan] [varchar](20) NULL,
	[CodServSuplementario] [varchar](10) NULL,
	[RentaBasica] [varchar](20) NULL,
	[RentaBasicaServSuplementario] [varchar](20) NULL,
	[CapacidadDeDatosServSupl] [varchar](20) NULL,
	[ImeiEquipo] [varchar](20) NULL,
	[EsVoz] [int] NULL,
	[EsDatos] [int] NULL,
	[EsSMS] [int] NULL,
	[EsLDI] [int] NULL,
	[EsPremium] [int] NULL,
	[EsPortabilidad] [int] NULL,
	[OperadorDonante] [varchar](10) NULL,
	[NoNIP] [varchar](10) NULL,
	[EquipoTraidoVendido] [varchar](20) NULL,
	[NoSerial] [varchar](50) NULL,
	[Imei] [varchar](20) NULL,
	[MarcaRefEquipo] [varchar](50) NULL,
	[ValorEquipo] [float] NULL,
	[ValorEquipoKoralOPricing] [float] NULL,
	[EquipoACuotas] [int] NULL,
	[CuotaInicial] [float] NULL,
	[ValorADiferir] [float] NULL,
	[NumeroDeCuotas] [int] NULL,
	[SerialSimCard] [varchar](20) NULL,
	[ValorDeLaSimCard] [float] NULL,
	[ValorBeneficio] [float] NULL,
	[CondicionesBeneficio] [varchar](200) NULL,
	[CodigoBeneficioRecurrente] [varchar](10) NULL,
	[CondicionesBeneficioBasico] [varchar](200) NULL,
	[CodigoBeneficioBasico] [varchar](10) NULL,
	[Observaciones] [varchar](max) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[NAB_ANEXOS_NEGOCIO]  WITH CHECK ADD  CONSTRAINT [FK__ANEXOS_NE__Codig__7D4E87B5] FOREIGN KEY([CodigoNegocio_FK])
REFERENCES [dbo].[NAB_EB_NEGOCIOS] ([ID_EB])
GO

ALTER TABLE [dbo].[NAB_ANEXOS_NEGOCIO] CHECK CONSTRAINT [FK__ANEXOS_NE__Codig__7D4E87B5]
GO

