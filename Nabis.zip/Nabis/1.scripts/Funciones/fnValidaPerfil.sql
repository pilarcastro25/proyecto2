USE [NABIS]
GO

IF OBJECT_ID (N'dbo.fnValidaPerfil') IS NOT NULL
   DROP FUNCTION dbo.fnValidaPerfil
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez
-- Fecha Creación     : 2016-08-23
-- Descripción        : Permite agregar una nueva línea de texto a una cadena.
--
-- Parámetros         : @idPerfil    - Id del Perfil a evaluar
--
-- Retorno            : Entero con idperfil  
-- ========================================================================================
CREATE FUNCTION dbo.fnValidaPerfil
(
	@idPerfil INT
)
RETURNS INT
BEGIN
	IF NOT(@idPerfil BETWEEN 1 AND 5)
	BEGIN
	SET @idPerfil = 6
	END
	return @idperfil
END

