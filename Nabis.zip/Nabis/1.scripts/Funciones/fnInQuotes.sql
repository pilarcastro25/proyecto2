IF OBJECT_ID (N'dbo.fnInQuotes') IS NOT NULL
   DROP FUNCTION dbo.fnInQuotes
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres
-- Fecha Creación     : 2014-03-14
-- Descripción        : Devuelve una cadena de texto encerrada entre comillas sencillas.
--
-- Parámetros         : @inputString    - Cadena original.
--
-- Retorno            : @outputString   - Cadena de texto encerrada entre comillas.
-- ========================================================================================
CREATE FUNCTION dbo.fnInQuotes
(
	@inputString VARCHAR(MAX)	
)
RETURNS VARCHAR(MAX) AS
BEGIN
	DECLARE @outputString VARCHAR(MAX);
	SET @outputString = ''
	IF @inputString IS NOT NULL
	BEGIN				
		SET @outputString = CHAR(39) + @inputString + CHAR(39);
	END
	RETURN @outputString;
END 

