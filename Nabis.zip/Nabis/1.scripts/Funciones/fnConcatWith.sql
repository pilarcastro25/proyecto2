IF OBJECT_ID (N'dbo.fnConcatWith') IS NOT NULL
   DROP FUNCTION dbo.fnConcatWith
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres
-- Fecha Creación     : 2014-03-14
-- Descripción        : Permite concatenar dos cadenas de texto con un contenido de relleno.
--
-- Parámetros         : @inputString    - Cadena original.
--                      @attachedString - Texto a concatenar.
--                      @paddingText    - Texto de relleno (blanco por defecto).
--
-- Retorno            : @outputString   - Cadena concatenada.
-- ========================================================================================
CREATE FUNCTION dbo.fnConcatWith
(
	@inputString VARCHAR(MAX),
	@attachedString VARCHAR(MAX),
	@paddingText VARCHAR(20) = ''
)
RETURNS VARCHAR(MAX) AS
BEGIN
	DECLARE @outputString VARCHAR(MAX);
	SET @outputString = '';
	IF @inputString IS NOT NULL
	BEGIN
		SET @outputString = @inputString + @paddingText;
		IF @attachedString IS NOT NULL
		BEGIN		
			SET @outputString = @outputString + @attachedString;
		END
	END
	RETURN @outputString;
END 

