USE [NABIS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'NAB_ESTADOLOGIN') IS NOT NULL
	DROP TABLE NAB_ESTADOLOGIN
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-10
-- Descripci�n        : Tabla estado login.
-- ========================================================================================
CREATE TABLE NAB_ESTADOLOGIN(
	IdEstadoLogin INT IDENTITY(1,1) PRIMARY KEY,
	Descripcion VARCHAR(50) NOT NULL
);
GO

INSERT INTO NAB_ESTADOLOGIN VALUES('BLOQUEADO')
INSERT INTO NAB_ESTADOLOGIN VALUES('DESBLOQUEADO')
GO
