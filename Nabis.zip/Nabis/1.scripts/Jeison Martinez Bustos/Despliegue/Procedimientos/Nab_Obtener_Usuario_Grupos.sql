SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Usuario_Grupos ') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Usuario_Grupos 
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Extraer los grupos de usuarios
-- =============================================
CREATE PROCEDURE Nab_Obtener_Usuario_Grupos

AS
BEGIN
	SELECT * FROM USERS_GRUPOS
END
GO
