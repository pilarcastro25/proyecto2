USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Obtener_Procesos_Usuario') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Obtener_Procesos_Usuario
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 22-09-2016
-- Descripción        : Permite obtener los procesos de NABIS para los usuarios
-- Debug			  : EXEC Nab_Obtener_Procesos_Usuario
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Procesos_Usuario]
AS
BEGIN
 SELECT * FROM USERS_PROCESOS
 
END