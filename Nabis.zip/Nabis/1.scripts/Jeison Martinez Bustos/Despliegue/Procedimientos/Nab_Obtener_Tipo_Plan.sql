SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Tipo_Plan') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Tipo_Plan
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Extraer los tipos de planes que exsiten
-- =============================================
CREATE PROCEDURE Nab_Obtener_Tipo_Plan
	
AS
BEGIN
	SELECT IdTipoPlan,TipoPlan FROM NAB_TIPO_PLAN
END
GO
