USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Actualizar_Modulo') IS NOT NULL
	DROP PROCEDURE Nab_Actualizar_Modulo
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 20-09-2016
-- Description:	Actualizar m�dulo del que hace parte el contrato
-- =============================================
CREATE PROCEDURE Nab_Actualizar_Modulo 
	@IdEb VARCHAR(50),
	@IdModulo INT,
	@UsuarioOrigen VARCHAR(50)=NULL,
	@UsuarioFin VARCHAR(50)=NULL,
	@Reasignador VARCHAR(50)	
AS
BEGIN
	
	UPDATE NAB_GLOBAL_ESTADO_NEGOCIO_MODULO SET
	IdModulo=@IdModulo,UsuarioOrigen=@UsuarioOrigen,
	Reasignador=@Reasignador,FechaReasignacion=GETDATE()
	WHERE IdEb=@IdEb
	

END
GO
