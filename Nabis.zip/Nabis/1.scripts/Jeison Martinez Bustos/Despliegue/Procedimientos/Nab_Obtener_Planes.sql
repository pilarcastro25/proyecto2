USE NABIS
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Planes') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Planes
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Extraer los tipos de planes que exsiten
-- Debug Exec Nab_Obtener_Planes
-- =============================================
CREATE PROCEDURE Nab_Obtener_Planes
	
AS
BEGIN
	SELECT * FROM NAB_PLANES
END
GO
