USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Obtener_Planes_Tipos]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Obtener_Planes_Tipos]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-22
-- Descripción        : Obtener planes y tipos.
-- Parámetros		  : @cod
--Modicación			: Se cambia consulta de Id de plan a Código
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Planes_Tipos](
@cod VARCHAR(50) = null,
@idPlan VARCHAR(50) =null
)
AS
BEGIN	


	SELECT IdPlan,CodigoPlan,Planes,TipoPlan
	FROM NAB_PLANES P
	INNER JOIN NAB_TIPO_PLAN TP ON TP.IDTIPOPLAN = P.IDTIPOPLAN
	WHERE( (@idPlan IS NULL OR IdPlan = @idPlan )
	and (@cod IS NULL OR CodigoPlan = @cod ) )
END

--exec [Nab_Obtener_Planes_Tipos] @cod='Asesor2'