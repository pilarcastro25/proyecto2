USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Eb_Obtener_Negocio]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Eb_Obtener_Negocio]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-08
-- Descripción        : Obtener negocio
-- Parámetros		  : @eb id del negocio
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_Obtener_Negocio](
@eb VARCHAR(50)
)
AS
BEGIN
	SELECT * FROM [dbo].[NAB_EB_NEGOCIOS] N
	WHERE N.ID_EB=@eb
END