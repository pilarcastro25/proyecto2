USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Obtener_Rol]    Script Date: 08/30/2016 15:00:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Obtener_Modulo]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Obtener_Modulo]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-08-30
-- Descripción        : Obtener modulo del usuario.
-- Parámetros		  : @nh   Nh del usuario.
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Modulo](
@nh varchar(50)
)
AS
BEGIN
	SELECT M.MODULO AS MODULO
	FROM USERS U
	INNER JOIN NAB_GLOBAL_USER_PROCESOS_MODULOS P ON U.ID_PROCESO = P.ID_PROCESO
	INNER JOIN NAB_MODULOS M ON P.ID_MODULO  = M.IDMODULO
	WHERE U.USR_ID = @nh
	
	
END