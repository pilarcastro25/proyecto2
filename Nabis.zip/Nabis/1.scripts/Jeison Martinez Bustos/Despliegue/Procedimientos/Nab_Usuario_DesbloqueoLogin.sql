USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_DesbloqueoLogin]    Script Date: 08/31/2016 08:29:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Usuario_DesbloqueoLogin') IS NOT NULL
	DROP PROCEDURE Nab_Usuario_DesbloqueoLogin
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion   : N/A
-- Descripción        : Permite consultar usuarios en Nabis.
--
-- Parámetros       : @nh   -NH del usuario.
-- Fecha Modificacion : 2016-08-23
-- Autor              : Gabriel Martinez.
-- Descripción        : Se realiza el desbloqueo del Usuario 
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Usuario_DesbloqueoLogin](
@nh varchar(50),
@pass varchar(50) = NULL
)
AS
BEGIN
	IF (@pass IS NULL )
		BEGIN
		UPDATE USERS SET ID_ESTADOLOGIN = 2,CONTLOGINERROR=0,
		FECHABLOQUEO =NULL,USR_PASSW=@pass
		WHERE USR_ID=@nh;
		END
	ELSE 
		BEGIN
		UPDATE USERS SET ID_ESTADOLOGIN = 2,CONTLOGINERROR=0,
		FECHABLOQUEO =NULL
		WHERE USR_ID=@nh;
		END
		
END