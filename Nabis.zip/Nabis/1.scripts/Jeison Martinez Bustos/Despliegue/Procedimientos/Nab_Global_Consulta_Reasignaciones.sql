USE [NABIS]
GO

/****** Object:  StoredProcedure [dbo].[Nab_Global_Consulta_Reasignaciones]    Script Date: 09/19/2016 10:02:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[dbo].[Nab_Global_Consulta_Reasignaciones]') IS NOT NULL
	DROP PROCEDURE [dbo].[Nab_Global_Consulta_Reasignaciones]
GO

-- =============================================
-- Author:		<Author,ANA MARIA GOMEZ,Name>
-- Create date: <Create Date,08 DE JULIO 2016,>
-- Description:	<Description,CONSULTA Reasignaciones,>


-- Fecha Modificacion : 2016-09-20  
-- Autor              : Gabriel Martinez.  
-- Descripci�n        : Se se corrige la sentencia del SELECT del SP, ya que estaba truncando
--						el id del contrato.
-- ========================================================================================  
CREATE PROCEDURE [dbo].[Nab_Global_Consulta_Reasignaciones]
	@identificacion varchar(20)
AS
BEGIN
	DECLARE @v_cadena NVARCHAR(1000);
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    IF EXISTS(SELECT * FROM NAB_GLOBAL_CONTRATO_MARCO WHERE NUM_IDENTIFICACION=@identificacion) 
    BEGIN
	 SET @v_cadena= 'select '''+ @identificacion+ ''' as Consecutivo , ''Documental'' as modulo, ''JEISSON IVAN GOMEZ VARGAS'' as Usuario_Fin , ''RODRIGO ALBERTO SIERRA BALLEN'' as Reasignador, ''6-4-2016 7:35 pm'' as Feca_Reasignacion '

	 EXEC SP_EXECUTESQL @v_cadena;
    END
    ELSE
    BEGIN
	 SET @v_cadena='SELECT ''No existen regitros asociados a los datos de entrada'' as Consulta_Sin_Resultados';
	 PRINT @v_cadena
	 EXEC SP_EXECUTESQL @v_cadena
    END
END

GO
--EXEC [Nab_Global_Consulta_Reasignaciones] '1094269875-1'

