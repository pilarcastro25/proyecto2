USE NABIS
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Correo_Desbloqueo') IS NOT NULL
	DROP PROCEDURE Nab_Correo_Desbloqueo
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Obtener correo encargado del desbloqueo
-- =============================================
CREATE PROCEDURE Nab_Correo_Desbloqueo 
	
AS
BEGIN
	SELECT TOP 1 * FROM  NAB_GLOBAL_CORREO_DESBLOQUEO
END
GO
