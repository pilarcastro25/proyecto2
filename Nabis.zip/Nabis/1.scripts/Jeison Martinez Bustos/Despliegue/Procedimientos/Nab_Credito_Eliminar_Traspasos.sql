USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/31/2016 16:12:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Credito_Eliminar_Traspasos]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Credito_Eliminar_Traspasos]
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripción        : Eliminar traspasos del negocio
-- Parámetros	      :	@idNegocio
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Credito_Eliminar_Traspasos] (
@IdNegocio VARCHAR(50)
)
 AS
BEGIN
	--DECLARE @msg varchar(1000)
	--BEGIN TRAN TRSC
	--	BEGIN TRY
	--		SET @msg =''
			DELETE FROM [dbo].[NAB_CREDITO_TRASPASO] 
			WHERE @IdNegocio = IdEb
		
		--COMMIT TRAN TRSC
		--END TRY
		--BEGIN CATCH
		--	SET @msg ='Ha ocurrido un error al procesar la solicitud: ' + ERROR_MESSAGE()+ 'en la linea' ++ CONVERT(VARCHAR(255), ERROR_LINE() ) + '.'
		--	ROLLBACK TRAN TRSC
		--END CATCH
		--SELECT @msg 
END