USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Modificar_Plan]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Modificar_Plan]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-05
-- Descripción        : Modificar planes.
-- Parámetros		  : 
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Modificar_Plan](
@id INT,
@cod VARCHAR(50),
@descripcion VARCHAR(50),
@tipo VARCHAR(50) 
)
AS
BEGIN

	UPDATE NAB_PLANES SET CodigoPlan = @cod,Planes=@descripcion,IdTipoPlan=@tipo
	WHERE IdPlan=@id
END