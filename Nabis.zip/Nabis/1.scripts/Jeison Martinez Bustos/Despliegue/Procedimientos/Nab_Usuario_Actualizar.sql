USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Usuario_UpdateEmail') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Usuario_UpdateEmail
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion   : N/A
-- Descripción        : Permite activar/desactivar usuarios en Nabis.
--
-- Parámetros		  : @estado   -estado del usuario.
-- Fecha Modificacion : 2016-08-25
-- Autor              : Gabriel Martinez.
-- Descripción        : Se realiza la activación/desactivación del Usuario 
-- ========================================================================================

CREATE PROCEDURE [dbo].Nab_Usuario_UpdateEmail(
@nh varchar(50),
@mail varchar(50),
@perfil int
)
AS
BEGIN
 UPDATE USERS SET USR_MAIL = @mail,ID_PERFIL=@perfil
 WHERE USR_ID=@nh
END