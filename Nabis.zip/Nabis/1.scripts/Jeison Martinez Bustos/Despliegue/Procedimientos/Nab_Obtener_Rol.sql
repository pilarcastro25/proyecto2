USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.Nab_Obtener_Rol') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Obtener_Rol
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-08-30
-- Descripción        : Obtener rol del usuario.
-- Parámetros		  : @nh   Nh del usuario.
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Rol](
@nh varchar(50)
)
AS
BEGIN
	SELECT (P.PROCESO+ ',' ) AS ROLES
	FROM USERS M
	INNER JOIN USERS_PROCESOS P ON M.ID_PROCESO = P.ID_PROCESO
	WHERE M.USR_ID = @nh;
	
END