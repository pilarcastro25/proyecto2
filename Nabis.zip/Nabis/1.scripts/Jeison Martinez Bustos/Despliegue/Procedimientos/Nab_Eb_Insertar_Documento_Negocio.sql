USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Eb_Insertar_Documento_Negocio') IS NOT NULL
	DROP PROCEDURE Nab_Eb_Insertar_Documento_Negocio
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-12
-- Descripción        : Insertar documento y negocio.
-- Parámetros		  : @IdEb ID del negocio
--						@Documento 
--DEBUG					EXEC Nab_Eb_Insertar_Documento_Negocio 'bo',2
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_Insertar_Documento_Negocio](
@IdEb VARCHAR(50),
@IdDocumento INT
)
AS
BEGIN
	INSERT INTO NAB_NEGOCIO_DOCUMENTOS VALUES (@IdEb,@IdDocumento)
	END