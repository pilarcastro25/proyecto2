USE 
NABIS

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Credito_Obtener_Traspaso') IS NOT NULL
	DROP PROCEDURE Nab_Credito_Obtener_Traspaso
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Obtener traspaso de un negocio
-- =============================================
CREATE PROCEDURE Nab_Credito_Obtener_Traspaso
@eb VARCHAR(50)
AS
BEGIN
	SELECT * FROM NAB_CREDITO_TRASPASO T
	WHERE T.IdEb=@eb
END
GO