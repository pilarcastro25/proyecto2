USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Obtener_Traspaso_Imei_Celular]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Obtener_Traspaso_Imei_Celular]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-05
-- Descripción        : Obtener traspasos por Imei y/o celular.
-- Parámetros		  : 
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Traspaso_Imei_Celular](
@imei VARCHAR(50)=NULL,
@celular VARCHAR(50)=NULL
)
AS
BEGIN

	SELECT IdTraspaso,IdEb,IdPlan FROM NAB_CREDITO_TRASPASO
	WHERE( (@imei IS NULL OR Imei = @imei )
	and (@celular IS NULL OR Celular = @celular ) )
END

--exec [Nab_Obtener_Traspaso_Imei_Celular] @imei='12297005118581'