USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Bloquear]    Script Date: 08/31/2016 11:44:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[Nab_Usuario_Bloquear]') IS NOT NULL
	DROP PROCEDURE [Nab_Usuario_Bloquear]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion	  : 2016-08-25
-- Descripción        : Permite activar/desactivar usuarios en Nabis.
--
-- Parámetros		  : @estado   -estado del usuario.
-- Fecha Modificacion : 2016-08-25
-- Autor              : Gabriel Martinez.
-- Descripción        : Se realiza ajuste en el SELECT del contador
-- Debug			  : EXEC Nab_Usuario_Bloquear 'JCORTES'
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Usuario_Bloquear](
@user varchar(50)
)
AS
BEGIN
	DECLARE @bloqueos  int;
	DECLARE @numeroIntentos int;
	SET @numeroIntentos=3;
	
	SELECT @bloqueos= CONTLOGINERROR FROM USERS
	WHERE USR_LOGIN=@user;
	
	SET @bloqueos = @bloqueos+1;
	
	IF (@bloqueos >=@numeroIntentos)
 	BEGIN
 		UPDATE USERS SET USERS.ID_ESTADOLOGIN=1,FECHABLOQUEO=GETDATE(),CONTLOGINERROR=@bloqueos
 		WHERE USR_LOGIN=@user;
 	END
 	ELSE
 	BEGIN
 	
 		UPDATE USERS SET CONTLOGINERROR=@bloqueos
		WHERE USR_LOGIN=@user;
 		
 	END
	
	
	SELECT @bloqueos AS CONTADOR;
END



