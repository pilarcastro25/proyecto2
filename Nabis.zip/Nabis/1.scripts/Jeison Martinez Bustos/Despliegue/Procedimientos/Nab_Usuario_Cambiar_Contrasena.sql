USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripción        : Permite cambiar contraseñas de los usuarios.
--
-- Parámetros	      :	@nh			-NH del usuario.
--						@pass       -Contraseña antigua del usuario
--						@passnew	-Contraseña nueva del usuario
--						@outmessage	-mensaje de salida de la operación
-- ========================================================================================
IF OBJECT_ID (N'dbo.[Nab_Usuario_Cambiar_Contrasena]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Cambiar_Contrasena]
GO

CREATE PROCEDURE [dbo].[Nab_Usuario_Cambiar_Contrasena](
@nh VARCHAR(50),
@pass VARCHAR(MAX),
@passnew VARCHAR(MAX)
)
AS 
BEGIN
	DECLARE @consulta VARCHAR(50);
	SELECT @consulta = USR_PASS FROM USERS
	WHERE @nh=USR_ID;
	
	IF @consulta IS NULL
	BEGIN
		SET @consulta=''
	END
	IF @pass IS NULL
	BEGIN
		SET @pass=''
	END
	
	IF(@consulta=@pass)
		BEGIN
		SELECT '1' AS MSG;
		UPDATE USERS SET USR_PASS=@passnew
		WHERE @nh=USR_ID;
		END
	ELSE
		BEGIN
		SELECT '0' AS MSG;
		END
END 