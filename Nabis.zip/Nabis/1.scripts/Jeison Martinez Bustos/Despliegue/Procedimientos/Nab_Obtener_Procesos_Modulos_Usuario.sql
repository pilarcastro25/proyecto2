USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Obtener_Procesos_Modulos_Usuario') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Obtener_Procesos_Modulos_Usuario
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 22-09-2016
-- Descripción        : Permite obtener los procesos de NABIS para los usuarios con 
--						los módulos
-- Debug			  : EXEC Nab_Obtener_Procesos_Usuario
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Obtener_Procesos_Modulos_Usuario](
@modulo	VARCHAR(50)
)
AS
BEGIN
 SELECT * FROM NAB_GLOBAL_USER_PROCESOS_MODULOS
 WHERE ID_MODULO=@modulo
END