SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Usuarios_Tipos ') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Usuarios_Tipos 
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 21-09-2016
-- Description:	Extraer los tipos de usuarios
-- =============================================
CREATE PROCEDURE Nab_Obtener_Usuarios_Tipos 

AS
BEGIN
	SELECT * FROM USERS_TIPOS
END
GO
