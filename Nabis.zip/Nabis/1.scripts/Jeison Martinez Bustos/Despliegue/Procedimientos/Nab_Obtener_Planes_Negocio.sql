USE 
NABIS

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Planes_Negocio') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Planes_Negocio
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 22-09-2016
-- Description:	Obtener planes de un negocio
-- =============================================
CREATE PROCEDURE Nab_Obtener_Planes_Negocio
@eb VARCHAR(50)
AS
BEGIN
	SELECT ID_PLAN_TARIFARIO,CANTIDAD_LINEAS FROM NAB_VENTAS_PLAN_ADQUIRIDO P
	WHERE P.ID_CODIGO_NEGOCIO=@eb
END
GO
--sp_helptext 'Nab_Obtener_Planes_Tipos'