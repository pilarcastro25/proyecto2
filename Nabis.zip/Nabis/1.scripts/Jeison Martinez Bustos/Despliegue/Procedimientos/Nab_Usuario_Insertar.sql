USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/31/2016 16:12:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Usuario_Insertar]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Insertar]
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripción        : Permite insertar usuarios nuevos a Nabis.
--
-- Parámetros	      :	@nh			-NH del usuario.
--						@cc			-Cédula del usuario
--						@login		-Login  
--						@nombre		-Nombre de usuario.
--						@pass 		-Contraseña que el usuario asigna
--						@mail		-E-mail
--						@reg		-Región 
--						@area		-Area
--						@grupo		-Grupo	
--						@proceso	-Proceso
--						@tipo		-Tipo
--						@equipo		-Equipo
--						@ip			-IP del equipo
--						@cel		-Número de celular 
--						@ext		-Extensión telefónica
--						@perfil		-Perfil del usuario
--						@cod		-Código vendedor
	-- Fecha Modificacion : 2016-08-23
	-- Autor              : Gabriel Martinez.
	-- Descripción        : Se cambia la columna a la cual se le raliza el INSERT, pasa de ser
	--						PASSW a PASS	
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Usuario_Insertar] (
@nh varchar(10),
@cc numeric,
@login varchar(50),
@nombre varchar(150),
@pass varchar(MAX),
@mail varchar(150),
@reg int,
@area int,
@grupo int,
@proceso int,
@tipo int,
@equipo varchar(50),
@ip varchar(15),
@cel varchar(10)= null,
@ext varchar(10) = null,
@perfil int,
@cod decimal,
@canal int,
@agente int=null
)
 AS
BEGIN
	IF @cel = ''
	BEGIN
		SET @cel = '0'
	END
	
	IF @ext = ''
	BEGIN
		SET @ext = '0'
	END
	
	INSERT INTO USERS(USR_ID, CC, USR_LOGIN, USR_PASS, USR_NOMBRE, USR_MAIL, ID_REGIONAL, ID_AREA,
	ID_GRUPO, ID_PROCESO, USR_CELULAR, USR_EXT, USR_EQUIPO, USR_IP, FEC_INGRESO, ID_TIPO, NOTAS, ID_ESTADO,ID_PERFIL,ID_ESTADOLOGIN,COD_VEND,CONTLOGINERROR,ID_CANAL,COD_AGENTE)
	VALUES
	(@nh, @cc, @login, @pass, @nombre, @mail, @reg, @area, @grupo, @proceso, @cel, @ext, @equipo, @ip, GETDATE(), @tipo,'REGISTRADO POR NABIS',1,@perfil,2,@cod,0,@canal,@agente)
END