USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Insertar_Negocio_Modulo') IS NOT NULL
	DROP PROCEDURE Nab_Insertar_Negocio_Modulo
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 20-09-2016
-- Description:	Actualizar m�dulo del que hace parte el contrato
-- =============================================
CREATE PROCEDURE Nab_Insertar_Negocio_Modulo 
	@IdEb VARCHAR(50),
	@IdModulo INT,
	@UsuarioOrigen VARCHAR(50)=NULL,
	@UsuarioFin VARCHAR(50)=NULL,
	@Reasignador VARCHAR(50)	
AS
BEGIN
	
	INSERT INTO NAB_GLOBAL_ESTADO_NEGOCIO_MODULO VALUES(@IdEb, @IdModulo,
	@UsuarioOrigen,@UsuarioFin, @Reasignador, GETDATE())		

END
GO
--EXEC Nab_Insertar_Negocio_Modulo @IdEb='COS92016-131',@IdModulo=1,@Reasignador='JEISON GABRIEL MARTINEZ BUSTOS'
--SELECT * FROM NAB_GLOBAL_ESTADO_NEGOCIO_MODULO