USE [NABIS]
GO

IF OBJECT_ID (N'dbo.fnValidaPerfil') IS NOT NULL
   DROP FUNCTION dbo.fnValidaPerfil
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez
-- Fecha Creaci�n     : 2016-10-03
-- Descripci�n        : Eliminar funci�n.
--
-- Par�metros         : @idPerfil    - Id del Perfil a evaluar
--
-- Retorno            : Entero con idperfil  
-- ========================================================================================