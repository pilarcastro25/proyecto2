USE [NABIS]
GO

IF OBJECT_ID(N'NAB_ESTADOLOGIN') IS NOT NULL
	DROP TABLE NAB_ESTADOLOGIN
GO

-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-10
-- Descripci�n        : Eliminar tabla EstadoLogin.
-- ========================================================================================
