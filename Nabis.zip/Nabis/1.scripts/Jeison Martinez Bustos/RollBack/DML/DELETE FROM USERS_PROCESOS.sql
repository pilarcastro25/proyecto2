USE [NABIS]
GO

-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 03-10-2016
-- Descripci�n        : Delete de la tabla USERS_PROCESOS.
-- ========================================================================================
DELETE FROM USERS_PROCESOS 
WHERE PROCESO IN(
				'ADMINISTRADOR LIDER',
				'COORDINADOR COMERCIAL',
				'COORDINADOR CREDITO',
				'COORDINADOR LOGISTICA',
				'COORDINADOR ACTIVACIONES',
				'PYMES',
				'ASESOR COMERCIAL'
				)