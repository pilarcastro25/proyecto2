USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[NAB_PLANES]') IS NOT NULL
   DROP TABLE dbo.[NAB_PLANES]
GO
IF OBJECT_ID (N'dbo.[NAB_TIPO_PLAN]') IS NOT NULL
	DROP TABLE dbo.[NAB_TIPO_PLAN]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 03-10-2016
-- Descripci�n        : Eliminaci�n de tablas de planes y de tipo panel.
-- ========================================================================================