USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.NAB_GLOBAL_CORREO_DESBLOQUEO') IS NOT NULL
   DROP TABLE dbo.NAB_GLOBAL_CORREO_DESBLOQUEO
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creaci�n     : 2016-10-03
-- Descripci�n        : Eliminaci�n table de correo de desbloqueo

-- ======================================================================================== 