USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID (N'dbo.[NAB_GLOBAL_ESTADO_NEGOCIO_MODULO]') IS NOT NULL
	DROP TABLE [dbo].[NAB_GLOBAL_ESTADO_NEGOCIO_MODULO]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 20-09-2016
-- Descripci�n        : Eliminarci�n de tabla de etapa de negocio por m�dulo
-- ========================================================================================