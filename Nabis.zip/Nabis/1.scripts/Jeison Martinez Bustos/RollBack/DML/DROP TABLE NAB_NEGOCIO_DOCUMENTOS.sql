USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.NAB_NEGOCIO_DOCUMENTOS') IS NOT NULL
   DROP TABLE dbo.NAB_NEGOCIO_DOCUMENTOS
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creaci�n     : 2016-09-30
-- Descripci�n        : Eliminaci�n tabla de rompimiento de negocios y documentos

-- ======================================================================================== 