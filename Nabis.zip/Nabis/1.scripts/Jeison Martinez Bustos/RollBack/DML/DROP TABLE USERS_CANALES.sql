USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.USERS_CANALES') IS NOT NULL
   DROP TABLE dbo.USERS_CANALES
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creaci�n     : 2016-10-03
-- Descripci�n        : Eliminaci�n tabla de Tipos de Canal

-- ======================================================================================== 