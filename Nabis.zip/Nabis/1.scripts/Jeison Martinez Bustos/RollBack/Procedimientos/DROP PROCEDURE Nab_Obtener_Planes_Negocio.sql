USE NABIS

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Planes_Negocio') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Planes_Negocio
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 03-10-2016
-- Description:	SP eliminado, Obtener planes de un negocio
-- =============================================