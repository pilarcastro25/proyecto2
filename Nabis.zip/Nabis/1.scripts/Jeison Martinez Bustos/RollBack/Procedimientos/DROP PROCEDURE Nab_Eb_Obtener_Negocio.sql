USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Eb_Obtener_Negocio]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Eb_Obtener_Negocio]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-02
-- Descripci�n        : Sp eliminado, Obtener negocio
-- Par�metros		  : @eb id del negocio
-- ========================================================================================