USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Usuario_Cambiar_Contrasena]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Cambiar_Contrasena]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  :  2016-10-03
-- Descripci�n        :  SP eliminado, permite cambiar contrase�as de los usuarios.
-- ========================================================================================