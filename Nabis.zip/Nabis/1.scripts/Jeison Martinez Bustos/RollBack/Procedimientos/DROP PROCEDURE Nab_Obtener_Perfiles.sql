USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[Nab_Obtener_Perfiles]') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Perfiles 
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 03-10-2016
-- Description:	Se elimina SP, Extraer los perfiles que existan
-- =============================================