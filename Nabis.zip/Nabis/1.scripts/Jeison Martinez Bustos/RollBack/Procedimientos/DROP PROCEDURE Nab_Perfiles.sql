USE [NABIS]
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO
IF OBJECT_ID(N'Nab_Perfiles')
	DROP PROCEDURE Nab_Perfiles
GO
-- =============================================
-- Author:        <Jeison Gabriel Martinez Bustos NABIS>
-- Create date: <2016-10-03>
-- Description:    SP eliminado
	-- =============================================