USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Insertar_Plan]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Insertar_Plan]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-02
-- Descripci�n        : Se elimina SP, Insertar Planes	