USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Eb_Insertar_Documento_Negocio') IS NOT NULL
	DROP PROCEDURE Nab_Eb_Insertar_Documento_Negocio
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-03
-- Descripci�n        : Sp eliminado, Insertar Traspasos.
-- Par�metros		  : @IdEb ID del negocio
--						@Documento 
--DEBUG					EXEC Nab_Eb_Insertar_Documento_Negocio 'bo',2
-- ========================================================================================