USE [NABIS]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[dbo].[Nab_Global_Consulta_Reasignaciones]') IS NOT NULL
	DROP PROCEDURE [dbo].[Nab_Global_Consulta_Reasignaciones]
GO

-- Fecha Modificacion : 2016-10-03  
-- Autor              : Gabriel Martinez.  
-- Descripci�n        : Elimina SP.
-- ========================================================================================  