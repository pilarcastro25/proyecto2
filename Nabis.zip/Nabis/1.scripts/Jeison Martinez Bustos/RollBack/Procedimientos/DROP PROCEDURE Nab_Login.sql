USE [NABIS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Login') IS NOT NULL
	DROP PROCEDURE Nab_Login
GO
-- =============================================
-- Author:		<Gabriel Martinez Bustos>
-- Create date: <2016-10-03>
-- Description:	Sp eliminado, <Login de usuario en NABIS>
-- =============================================