SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Usuario_Grupos ') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Usuario_Grupos 
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 03-10-2016
-- Description:	Sp eliminado, extraer los grupos de usuarios
-- =============================================