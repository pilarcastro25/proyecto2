USE [NABIS]
GO
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

IF OBJECT_ID (N'[dbo].[Nab_Global_Contrato_Marco_Crud]') IS NOT NULL
	DROP PROCEDURE [dbo].[Nab_Global_Contrato_Marco_Crud]
GO

-- Fecha Modificacion : 2016-10-03  
-- Autor              : Gabriel Martinez.  
-- Descripci�n        : Se elimina SP.
-- ========================================================================================  
