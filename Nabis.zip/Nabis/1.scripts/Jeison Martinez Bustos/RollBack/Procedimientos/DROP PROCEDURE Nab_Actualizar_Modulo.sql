USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID(N'Nab_Actualizar_Modulo') IS NOT NULL
	DROP PROCEDURE Nab_Actualizar_Modulo
GO
-- =============================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 20-09-2016
-- Description:	Eliminar SP, m�dulo del que hace parte el contrato
-- =============================================