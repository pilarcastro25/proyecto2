USE NABIS
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripci�n        : Eliminar sp, cambiar contrase�as de los usuarios.
--
-- Par�metros	      :	@nh			-NH del usuario.
--						@pass       -Contrase�a antigua del usuario
--						@passnew	-Contrase�a nueva del usuario
--						@outmessage	-mensaje de salida de la operaci�n
-- ========================================================================================
IF OBJECT_ID (N'dbo.[Nab_Cambiar_Contrasena]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Cambiar_Contrasena]
GO