USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Consulta]    Script Date: 09/13/2016 14:21:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Usuario_Consulta]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Consulta]
GO
-- ========================================================================================  
-- Autor              : Gabriel Martinez.  
-- Fecha Creacion     : 2016-10-03 
-- Descripci�n        : Sp eliminado, se agrega nueva columna a la consulta con el estado de la clave  
-- ========================================================================================  