USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Obtener_Traspaso_Imei_Celular]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Obtener_Traspaso_Imei_Celular]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-03
-- Descripci�n        : Sp eliminado , obtener traspasos por Imei y/o celular.
-- ========================================================================================