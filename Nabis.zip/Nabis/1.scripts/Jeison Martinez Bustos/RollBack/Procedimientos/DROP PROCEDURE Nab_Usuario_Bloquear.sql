USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Bloquear]    Script Date: 08/31/2016 11:44:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'[Nab_Usuario_Bloquear]') IS NOT NULL
	DROP PROCEDURE [Nab_Usuario_Bloquear]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion	  : 2016-08-25
-- Descripci�n        : Sp eliminado, permite activar/desactivar usuarios en Nabis.
-- ========================================================================================