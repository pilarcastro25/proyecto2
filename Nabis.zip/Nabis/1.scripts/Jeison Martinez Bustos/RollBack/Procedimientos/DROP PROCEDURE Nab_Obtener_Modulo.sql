USE [NABIS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID (N'dbo.[Nab_Obtener_Modulo]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Obtener_Modulo]
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-03
-- Descripci�n        : Obtener modulo del usuario.
-- Par�metros		  : Se elimina SP, @nh   Nh del usuario.
-- ========================================================================================