USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Usuario_UpdateEmail') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Usuario_UpdateEmail
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripci�n        : SP eliminado, Permite activar/desactivar usuarios en Nabis.
-- ========================================================================================
