USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_Insertar_Traspaso]    Script Date: 09/15/2016 10:40:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Eb_Insertar_Traspaso') IS NOT NULL
	DROP PROCEDURE Nab_Eb_Insertar_Traspaso
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-10-03
-- Descripci�n        : Eliminar SP,Insertar Traspasos.
-- Par�metros		  : 
-- ========================================================================================