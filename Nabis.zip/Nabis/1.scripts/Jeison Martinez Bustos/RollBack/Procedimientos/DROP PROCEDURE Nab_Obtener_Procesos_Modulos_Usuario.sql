USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Obtener_Procesos_Modulos_Usuario') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Obtener_Procesos_Modulos_Usuario
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 03-10-2016
-- Descripci�n        : Se elimina SP, Permite obtener los procesos de NABIS para los usuarios con 
--						los m�dulos
-- ========================================================================================