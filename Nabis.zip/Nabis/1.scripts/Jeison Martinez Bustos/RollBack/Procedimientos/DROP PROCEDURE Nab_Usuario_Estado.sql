USE [NABIS]
GO

IF OBJECT_ID (N'dbo.Nab_Usuario_Estado') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Usuario_Estado
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion   : 2016-10-03
-- Descripci�n        : SP eliminado, permite activar/desactivar usuarios en Nabis.
-- ========================================================================================