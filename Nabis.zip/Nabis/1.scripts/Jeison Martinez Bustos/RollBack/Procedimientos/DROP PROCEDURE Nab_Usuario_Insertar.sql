USE [NABIS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Usuario_Insertar]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Insertar]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez.
-- Fecha Creacion	  : 2016-10-03
-- Descripci�n        : Se elimina SP, Permite insertar usuarios nuevos a Nabis.
-- ========================================================================================