USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/31/2016 16:12:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Credito_Eliminar_Traspasos]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Credito_Eliminar_Traspasos]
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion	  : N/A
-- Descripci�n        : SP eliminado,Eliminar traspasos del negocio
-- Par�metros	      :	@idNegocio
-- ========================================================================================