USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_DesbloqueoLogin]    Script Date: 08/31/2016 08:29:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Usuario_DesbloqueoLogin') IS NOT NULL
	DROP PROCEDURE Nab_Usuario_DesbloqueoLogin
GO
-- ========================================================================================
-- Autor              : N/A.
-- Fecha Creacion   : 2016-10-03
-- Descripci�n        : SP eliminado, permite consultar usuarios en Nabis.
-- ========================================================================================