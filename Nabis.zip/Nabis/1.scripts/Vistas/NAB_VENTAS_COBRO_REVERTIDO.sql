USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_PORTABILIDAD]    Script Date: 09/06/2016 17:18:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_VENTAS_PORTABILIDAD](
	[Id_portabilidad] int IDENTITY (1, 1) NOT NULL,
	[Cod_negocio] [varchar](50) NOT NULL,
	[NitCliente] [varchar](50) NOT NULL,
	[RazonSocial] [varchar](50) NOT NULL,
	[Fecha_solicitud] [datetime] NOT NULL,
	[Fecha_ventana] [datetime] NOT NULL,
	[Iden_RL] [numeric](18, 0) NOT NULL,
	[Nombre_RL] [varchar](50) NOT NULL,
	[Tipo_ident] [varchar](50) NOT NULL,
	
	PRIMARY KEY(Id_portabilidad),
	FOREIGN KEY(Cod_negocio)REFERENCES NAB_EB_NEGOCIOS(ID_EB)

) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/*
Drop table NAB_VENTAS_PORTABILIDAD
*/
