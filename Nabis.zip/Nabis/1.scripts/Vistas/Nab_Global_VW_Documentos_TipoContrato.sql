USE [NABIS]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* ========================================================================================
 Autor              : Harold Caicedo
 Fecha Modificaci�n : 2016-08-30
 Descripci�n        : Lista los documentos asociados a un tipo de contrato.

 Autor              : Jeison Martinez
 Fecha Modificaci�n : 16-11-2016
 Descripci�n        : Se agrega ALIAS a los documentos
 ========================================================================================*/
CREATE VIEW [dbo].[Nab_Global_VW_Documentos_TipoContrato]
AS
SELECT     D.ID_DOCUMENTO, D.NOMBRE AS NOMBRE_DOCUMENTO, DTC.REQUISITO, DTC.ID_TIPO_CONTRATO, CTC.TIPO_CONTRATO AS NOMBRE_TIPO_CONTRATO, D.ALIAS
FROM         dbo.NAB_GLOBAL_DOCUMENTO_TIPO_CONTRATO AS DTC INNER JOIN
                      dbo.NAB_GLOBAL_DOCUMENTOS AS D ON DTC.ID_DOCUMENTO = D.ID_DOCUMENTO INNER JOIN
                      dbo.NAB_CREDITO_P_TIPO_CONTRATOS AS CTC ON DTC.ID_TIPO_CONTRATO = CTC.ID_TIPO_CONTRATO

GO

