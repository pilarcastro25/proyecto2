USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_COBRO_REVERTIDO]    Script Date: 09/06/2016 17:18:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_VENTAS_PAGARE](
	[Id_pagare] int  NOT NULL,
	[Cod_negocio] [varchar](50) NOT NULL,
	[Nit_empresa] [varchar](50)  NOT NULL,
	[Nombre_empresa] [varchar](50)  NOT NULL,
	[Fecha_solicitud] [datetime] NOT NULL,
	[Identificacion_RL] [numeric](18, 0) NOT NULL,
	[Nombre_RL] [varchar](50) NOT NULL,
	[Valor] [numeric](18, 0) NOT NULL,
	
	PRIMARY KEY(Id_pagare),
	FOREIGN KEY(Cod_negocio)REFERENCES NAB_EB_NEGOCIOS(ID_EB)

) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/*
Drop table NAB_VENTAS_PAGARE
*/
