USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]    Script Date: 09/26/2016 10:19:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD](
	[Id_LineasPortabilidad] [int] IDENTITY(1,1) NOT NULL,
	[Cod_negocio] [varchar](50) NOT NULL,
	[NumeroMovil] [numeric](18, 0) NOT NULL,
	[ContratoActual] [int] NOT NULL,
	[ContratoNuevo] [int] NOT NULL,
	[Fecha_solicitud] [datetime] NOT NULL,
	[Fecha_ventana] [datetime] NOT NULL,
	[Nip] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_LineasPortabilidad] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

SET ANSI_PADDING OFF
GO
ALTER TABLE [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]  WITH CHECK ADD FOREIGN KEY([Cod_negocio])
REFERENCES [dbo].[NAB_EB_NEGOCIOS] ([ID_EB])
GO
/*
drop table NAB_VENTAS_LINEAS_PORTABILIDAD
select * from NAB_VENTAS_LINEAS_PORTABILIDAD
*/
