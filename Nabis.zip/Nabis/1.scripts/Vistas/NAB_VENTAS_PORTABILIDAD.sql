USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_PORTABILIDAD]    Script Date: 09/22/2016 10:21:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_VENTAS_PORTABILIDAD](
	[Id_portabilidad] [int] IDENTITY(1,1) NOT NULL,
	[Cod_negocio] [varchar](50) NOT NULL,
	[Operador] [varchar](50) NOT NULL,
	[TipoSolicitud] [varchar](50) NULL,
	[NitCliente] [varchar](50) NULL,
	[RazonSocial] [varchar](50) NULL,
	[Fecha_solicitud] [datetime] NOT NULL,
	[Fecha_ventana] [datetime] NOT NULL,
	[Iden_RL] [numeric](18, 0) NULL,
	[Nombre_RL] [varchar](50) NULL,
	[Tipo_ident] [varchar](50) NULL,
	[CantidadLineas] [int] NULL,
	[NombresPersonaNatural] [varchar](50) NULL,
	[ApellidosPersonaNatural] [varchar](50) NULL,
	[Tipo_Ident_PN] [varchar](15) NULL,
	[Identificacion_PN] [int] NULL,
 CONSTRAINT [PK__NAB_VENTAS_PORTA__2AE0483B] PRIMARY KEY CLUSTERED 
(
	[Id_portabilidad] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[NAB_VENTAS_PORTABILIDAD]  WITH CHECK ADD  CONSTRAINT [FK__NAB_VENTA__Cod_n__2BD46C74] FOREIGN KEY([Cod_negocio])
REFERENCES [dbo].[NAB_EB_NEGOCIOS] ([ID_EB])
GO

ALTER TABLE [dbo].[NAB_VENTAS_PORTABILIDAD] CHECK CONSTRAINT [FK__NAB_VENTA__Cod_n__2BD46C74]
GO

/*
select * from NAB_VENTAS_PORTABILIDAD

drop table NAB_VENTAS_PORTABILIDAD
*/
