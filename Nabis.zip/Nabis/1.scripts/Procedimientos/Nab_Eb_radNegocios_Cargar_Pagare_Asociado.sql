USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_radNegocios_Cargar_Pagare_Asociado]    Script Date: 09/15/2016 11:27:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Eder Camilo Ramirez>
-- Create date: <2016-09-19>
-- Description:	<Carga los datos de Pagar� asociados al negocio>
-- =============================================
ALTER PROCEDURE [dbo].[Nab_Eb_radNegocios_Cargar_Pagare_Asociado]
      
	@Cod_negocio	varchar(50)
	
AS
BEGIN

	--SET NOCOUNT ON;	
	BEGIN TRAN TADD
	BEGIN TRY
		DECLARE @msg varchar(1000)
		set @msg ='SE CARGARON LOS DATOS CORRECTAMENTE'
		
				
				SELECT *,@msg AS MENSAJE,convert(varchar,Fecha_solicitud,103) As Fecha
				FROM NAB_VENTAS_PAGARE 
				WHERE COD_NEGOCIO=CONVERT(VARCHAR(50),@Cod_negocio)
			
			
	COMMIT TRAN TADD
	
	END TRY
	BEGIN CATCH
		SET @msg = 'Ocurrri� un error: ' + ERROR_MESSAGE() + ' En la l�nea ' + CONVERT(VARCHAR(255), ERROR_LINE() ) + '.'
		select @msg AS mensaje
		ROLLBACK TRAN TADD
	END CATCH
END

/*


EXEC Nab_Eb_radNegocios_Cargar_Pagare_Asociado
'COS92016-46'


*/