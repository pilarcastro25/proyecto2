USE NABIS

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Ventas_Condiciones_Uniformes_Informacion_Adicional_Anexo') IS NOT NULL
	DROP PROCEDURE Nab_Ventas_Condiciones_Uniformes_Informacion_Adicional_Anexo
GO
-- =========================================================================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 04-11-2016
-- Description:	SP para realizar el INSERT del anexo en el contrato de condiciones uniformes
-- =========================================================================================
CREATE PROCEDURE Nab_Ventas_Condiciones_Uniformes_Informacion_Adicional_Anexo 
	@ID_NEGOCIO VARCHAR(50),
	@RENOVACION BIT
AS
BEGIN
	IF NOT EXISTS(SELECT * FROM NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL_ANEXO 
	WHERE ID_NEGOCIO=@ID_NEGOCIO)
		BEGIN
			INSERT INTO NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL_ANEXO VALUES(
			@ID_NEGOCIO,
			@RENOVACION
			)
			SELECT 1;
		END
	ELSE 
		BEGIN 
			UPDATE NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL_ANEXO SET
			RENOVACION = @RENOVACION
			WHERE  ID_NEGOCIO = @ID_NEGOCIO;
			SELECT 1;
		END
END
GO
