IF OBJECT_ID (N'dbo.Nab_Consulta_Vendedor') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Consulta_Vendedor
GO
-- ========================================================================================
-- Autor              : Jeffrey
-- Fecha Creacion	  : 2016-08-30
-- Descripción        : Consulta de vendedores.
--
-- Parámetros	      :	@cod_vend 		- Codigo vendedor.
--						@canal 			- Canal asociado al vendedor.
--						@usrLogin 		- Usuario autenticado.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Consulta_Vendedor 'BOG22015-14'
-- ========================================================================================

CREATE  PROCEDURE [dbo].[Nab_Consulta_Vendedor]
(
	@cod_vend int,
	@canal varchar(30),
	@usrLogin varchar(20)
)
AS
BEGIN
	DECLARE @codAgente varchar(30), @idGrupo int
	SELECT @codAgente = COD_AGENTE, @idGrupo = ID_GRUPO
	FROM USERS
	WHERE USR_LOGIN = @usrLogin;

	IF(@idGrupo = 7)
	BEGIN
		SELECT	AG_REGIÓN AS REGIONAL
				, AG_CIUDAD AS CIUDAD
				, AG_DEPARTAMENTO AS DEPARTAMENTO
				, AG_CANAL AS CANAL
				, AG_CODVENDEDEDOR AS COD_VENDEDOR
				, AG_NOMVENDEDOR AS NOMBRE_VENDEDOR
				, AG_CODAGENTE AS COD_AGENTE
				, AG_NOMAGENTE AS AGENTE
				, AG_CODTIPCOMIS AS COD_TIPOCOMISIONISTA
				, AG_DESCRITIPCOMIS AS TIPO_COMISIONISTA
				, AG_CANALCOMERCIAL AS NOMBRE_GRUPO
				, AG_CODPUNTO AS COD_PUNTO
				, AG_NOMBREPUNTO AS PUNTO
				, AG_ESTADOASESOR AS ESTADO
				, AG_FEC_CONTRATO AS FEC_CONTRATO
				, AG_FEC_FIN_CONTRATO AS FEC_RETIRO
				, AG_MOVILVENDEDOR AS MOVIL_VENDEDOR
		FROM CCC.DBO.BC_AGENTE
		WHERE	AG_CODVENDEDEDOR =  @cod_vend
				AND AG_CANAL = 'INDIRECTO'
				AND AG_CODAGENTE = @codAgente;
	END
	ELSE
	BEGIN
		SELECT	AG_REGIÓN AS REGIONAL
				, AG_CIUDAD AS CIUDAD
				, AG_DEPARTAMENTO AS DEPARTAMENTO
				, AG_CANAL AS CANAL
				, AG_CODVENDEDEDOR AS COD_VENDEDOR
				, AG_NOMVENDEDOR AS NOMBRE_VENDEDOR
				, AG_CODAGENTE AS COD_AGENTE
				, AG_NOMAGENTE AS AGENTE
				, AG_CODTIPCOMIS AS COD_TIPOCOMISIONISTA
				, AG_DESCRITIPCOMIS AS TIPO_COMISIONISTA
				, AG_CANALCOMERCIAL AS NOMBRE_GRUPO
				, AG_CODPUNTO AS COD_PUNTO
				, AG_NOMBREPUNTO AS PUNTO
				, AG_ESTADOASESOR AS ESTADO
				, AG_FEC_CONTRATO AS FEC_CONTRATO
				, AG_FEC_FIN_CONTRATO AS FEC_RETIRO
				, AG_MOVILVENDEDOR AS MOVIL_VENDEDOR
		FROM CCC.DBO.BC_AGENTE
		WHERE	AG_CODVENDEDEDOR =  @cod_vend
				AND AG_CANAL = @canal;
	END
END



