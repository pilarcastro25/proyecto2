IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_estrVenta_Insert') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_estrVenta_Insert
GO
-- =============================================
-- Author:		<Jeffrey Cortés>
-- Create date: <2015-01-14>
-- Description:	<Radicación de estructura de venta desde NABIS>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_estrVenta_Insert](
	@user varchar(20)
	,@Mesaconspref	varchar(20)
	,@Cod_Cuota		int
	,@Producto		int
	,@Lineas		int
	,@IsError		bit output
)
AS
BEGIN
	set @IsError = 0;
	DECLARE	@IdVenta INT
			,@count INT
			,@Cod_ModVenta	INT
			,@fecha DATETIME
			,@tipSolicitud varchar(30)
			,@idEstado	INT;

	SELECT @tipSolicitud = MesaTipSoli
	FROM CCC.DBO.BC_MESACONTROL 
	WHERE Mesaconspref = @Mesaconspref;

	SELECT @Cod_ModVenta = Cod_ModVenta
	FROM CCC.DBO.BC_TipVenta
	WHERE Cod_Cuota = @Cod_Cuota;

	SELECT @IdVenta = IdVenta, @count = COUNT(*)
	FROM CCC.DBO.BC_CreditoVenta
	WHERE Mesaconspref = @Mesaconspref
		AND Cod_ModVenta = @Cod_ModVenta
		AND Cod_Cuota = @Cod_Cuota
		AND Producto = @Producto
	GROUP BY IdVenta;

	SET @fecha = GETDATE();

	IF @count > 0
	BEGIN
		UPDATE CCC.DBO.BC_CreditoVenta
		SET 	Lineas = Lineas + @Lineas
		WHERE	IdVenta = @IdVenta
	END

	ELSE
	BEGIN
		INSERT INTO CCC.DBO.BC_CreditoVenta
		( Mesaconspref ,Cod_ModVenta ,Cod_Cuota ,Lineas ,Abono_ModVenta ,Producto )
		VALUES
		( @Mesaconspref, @Cod_ModVenta, @Cod_Cuota, @Lineas, 0, @Producto );
	END

	IF @@ROWCOUNT > 0 AND @@ERROR = 0
	BEGIN
		UPDATE NAB_EB_NEGOCIOS
		SET PEND_LINEAS = PEND_LINEAS - @Lineas
			, FEC_ESTR_VENTA = CASE WHEN FEC_ESTR_VENTA IS NULL THEN @fecha ELSE FEC_ESTR_VENTA END
			, USER_ESTR_VENTA = CASE WHEN FEC_ESTR_VENTA IS NULL THEN @user ELSE USER_ESTR_VENTA END
			, FEC_CIERRE_ESTR_VENTA = CASE WHEN (PEND_LINEAS - @Lineas) = 0 THEN @fecha END
			, USER_CIERRE_ESTR_VENTA = CASE WHEN (PEND_LINEAS - @Lineas) = 0 THEN @user END
			, FEC_CIERRE = CASE WHEN (PEND_LINEAS - @Lineas) = 0 AND @Cod_ModVenta >= 100 AND @tipSolicitud != 'Ventas' THEN @fecha END
			, USER_CIERRE = CASE WHEN (PEND_LINEAS - @Lineas) = 0 AND @Cod_ModVenta >= 100 AND @tipSolicitud != 'Ventas' THEN @user END
			, FEC_ULT_MOD = @fecha
			, USER_ULT_MOD = @user
			, ID_ESTADO = CASE WHEN (PEND_LINEAS - @Lineas) = 0 AND @Cod_ModVenta < 100 THEN 2 WHEN (PEND_LINEAS - @Lineas) = 0 AND @Cod_ModVenta >= 100 AND @tipSolicitud != 'Ventas' THEN 4 ELSE ID_ESTADO END
		WHERE ID_EB = @Mesaconspref
		
	END

	ELSE
	BEGIN 
		SET @IsError = 1;
	END
END