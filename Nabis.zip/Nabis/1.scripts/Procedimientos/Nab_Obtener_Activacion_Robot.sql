USE NABIS
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Activacion_Robot') IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Activacion_Robot
GO
-- =========================================================================================
-- Author:		Jeison Gabriel Martinez Bustos
-- Create date: 08-11-2016
-- Description:	Obtener informaci�n de la tabla de activaci�n robot
-- =========================================================================================
CREATE PROCEDURE Nab_Obtener_Activacion_Robot 
	@ID_NEGOCIO VARCHAR(50)
AS
BEGIN
	SELECT Contrato AS CONTRATO,
	Simcard AS SIMCARD,
	Procedenciaimei AS PROCEDENCIAIMEI,
	RefImei AS MODELO,
	Imei AS IMEI,
	FecProgr AS FECHAACTIVACION
	FROM CCC.dbo.BC_ActivacionRobot WHERE
	Mesaconspref = @ID_NEGOCIO;
END
GO
