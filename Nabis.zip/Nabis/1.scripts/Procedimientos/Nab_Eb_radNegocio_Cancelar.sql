IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_Cancelar') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_Cancelar
GO
-- ========================================================================================
-- Autor              : Jeffrey Cortés.
-- Fecha Creacion	  : 2015-07-03
-- Descripción        : Información de Ingreso de Estructura Venta.
--
-- Parámetros	      :	@user 			-- Usuario seleccionado.
--						@id_eb 			-- Id de negocio.
--
-- Fecha Modificacion : 2016-09-29
-- Autor              : Harold Caicedo
-- Descripción        : Se agregan llamados para eliminar la informacion asociada a un 
--						negocio.
-- 
-- Fecha Modificacion : 2016-11-04
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega reinicio de la parte de la informacion adicional de contrato de 
--						condiciones uniformes.
--
-- Fecha Modificacion : 2016-11-10
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega reinicio de la parte de la informacion direccion de facturacion de contrato de 
--						condiciones uniformes.
--
-- Fecha Modificacion : 2016-11-17
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega reinicio de la parte de la informacion otros si de contrato de 
--						condiciones uniformes.
--
-- DEBUG			  : EXEC Nab_Eb_radNegocio_Cancelar ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_Cancelar]  
( 
	@user VARCHAR(20),
    @id_eb VARCHAR(100)  
)  
AS  
BEGIN  
	UPDATE CCC.DBO.BC_ACTIVACIONROBOT  
	SET IDESTADO = 6  
	WHERE MESACONSPREF = @id_eb;  
	 
	DELETE A  
	FROM CCC.DBO.BC_ACTIVACIONDCTOSROBOT A  
	 INNER JOIN CCC.DBO.BC_ACTIVACIONROBOT B ON A.IDLINEA = B.IDLINEA  
	WHERE B.MESACONSPREF = @id_eb;  
	  
	UPDATE NAB_EB_NEGOCIOS  
	SET ID_ESTADO = 5  
	 , FEC_CANCELACION = GETDATE()  
	 , USER_CANCELACION = @user  
	WHERE ID_EB = @id_eb;  
	 
	 
	-- Eliminar informacion de planes adquiridos.
	EXEC Nab_Venta_Eliminar_Plan_Adquiridos @id_eb;
	-- Eliminar informacion de usuarios autorizados.
	EXEC Nab_Venta_Eliminar_Usuario_Autorizados @id_eb;
	-- Eliminar informacion adicional asociada al negocio.
	EXEC Nab_Venta_Eliminar_Informacion_Adicional @id_eb;
	--Eliminar información de Cobro Revertido asociado al negocio
	EXEC Nab_Eb_radNegocios_Eliminar_CobroRevertido_Asociado @id_eb;
	--Eliminar información de Traspasos asociado al negocio
	EXEC Nab_Credito_Eliminar_Traspasos @id_eb;
	-- Eliminar informacion de anexos de lineas.
	EXEC Nab_Venta_Eliminar_Anexos_Lineas @id_eb;
	-- Eliminar informacion de contrato a venta a cuotas.
	EXEC Nab_Venta_Eliminar_Venta_a_Cuotas @id_eb;
	-- Eliminar informacion adicional de contrato de condiciones uniformes
	EXEC Nab_Venta_Eliminar_Informacion_Adicional_Condiciones_Uniformes @id_eb;
	-- Eliminar informacion de direccion de facturacion de condiciones uniformes
	EXEC Nab_Venta_Eliminar_Informacion_Direccion_Condiciones_Uniformes @id_eb;
	-- Eliminar informacion de anexo otro si para contrato de condiciones uniformes.
	EXEC Nab_Venta_Eliminar_Anexo_Lineas_Condiciones_Uniformes @id_eb;
END