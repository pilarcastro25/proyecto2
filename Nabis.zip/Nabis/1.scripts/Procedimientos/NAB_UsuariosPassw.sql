USE [NABIS]
GO

SELECT * INTO NAB_UsuariosPassw
FROM [CCC].dbo.BC_UsuariosPassw
GO