IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_Datos_Contrato_Marco') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_Datos_Contrato_Marco
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-10-11
-- Descripción        : Obtener informacion basica de un contrato marco asociado a un cliente.
--
-- Parámetros	      :	
--						@NUMERO_IDENTIFICACION   - Identificacion del cliente
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_Datos_Contrato_Marco '1032430658-5'
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_Datos_Contrato_Marco]
(
    @NUMERO_IDENTIFICACION VARCHAR(50)
)
AS
BEGIN
	-- Obtener informacion basica de un contrato marco asociado a un cliente.
	SELECT IdContrato AS ID_CONTRATO_MARCO, NumContrato AS NUM_CONTRATO 
	FROM CCC.DBO.BC_ContratosMarco
	WHERE Mesaid = @NUMERO_IDENTIFICACION AND FecFinMarco > (GETDATE() + 1);
END			