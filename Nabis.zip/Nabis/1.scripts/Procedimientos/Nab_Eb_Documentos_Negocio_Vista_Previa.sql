USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_Documentos_Negocio_Vista_Previa]    Script Date: 09/30/2016 17:53:16 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-07
-- Descripción        : Consulta de documentos obligatorios para un negocio sin radicar.
--
-- Parámetros	      :	@id_tipo_contrato     Tipo de contrato, 
--						@id_tipo_solicitud 	  Tipo de solicitud
--						@id_convenio 		  Marcacion Especial 
--						@es_portabilidad	  Portabilidad
--
-- Fecha Modificacion : 2016-09-30
-- Autor              : Jeison Martinez Bustos
-- Descripción        : Se modifica el requisito ya que no dejaba pasar opcionales y obligatorios
-- 
-- DEBUG			  : EXEC Nab_Eb_Documentos_Negocio_Vista_Previa '', '', '', ''
-- ========================================================================================
- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_Documentos_Negocio_Vista_Previa]
(
	@id_tipo_contrato INT, 
	@id_tipo_solicitud INT, 
	@id_convenio INT, 
	@es_portabilidad BIT
)
AS
BEGIN
	SET NOCOUNT ON;
	-- Declaracio de contantes.
	DECLARE @ID_TIPO_SOLICITUD_TRASPASOS INT;
	SET @ID_TIPO_SOLICITUD_TRASPASOS = 3;
	DECLARE @ID_DOCUMENTO_ANEXO_PORTABILIDAD INT;
	SET @ID_DOCUMENTO_ANEXO_PORTABILIDAD = 4;
	DECLARE @ID_DOCUMENTO_SOLICITUD_TRASPASO INT;
	SET @ID_DOCUMENTO_SOLICITUD_TRASPASO = 5;
	DECLARE @ID_CONVENIO_COBRO_REVERTIDO INT;
	SET @ID_CONVENIO_COBRO_REVERTIDO = 10;
	DECLARE @ID_DOCUMENTO_COBRO_REVERTIDO INT;
	SET @ID_DOCUMENTO_COBRO_REVERTIDO = 15;
	
	
	-- Trae los documentos que son obligatorios
	DECLARE @sqlCmd VARCHAR(MAX);
	--SET  @sqlCmd = 'SELECT * FROM Nab_Global_VW_Documentos_TipoContrato WHERE REQUISITO = 1';
	SET  @sqlCmd = 'SELECT * FROM Nab_Global_VW_Documentos_TipoContrato';
	-- Aplicar filtro por tipo de contrato.
	--SET @sqlCmd = dbo.fnAppendLine(@sqlCmd, '  AND ID_TIPO_CONTRATO = ' + CAST(@id_tipo_contrato AS VARCHAR));
	SET @sqlCmd = dbo.fnAppendLine(@sqlCmd, '  WHERE ID_TIPO_CONTRATO = ' + CAST(@id_tipo_contrato AS VARCHAR));
	--Se debe aplicar filtro por tipo de solicitud
	IF @id_tipo_solicitud = @ID_TIPO_SOLICITUD_TRASPASOS
	BEGIN
		SET @sqlCmd = dbo.fnAppendLine(@sqlCmd, '  OR (ID_DOCUMENTO = ' + CAST(@ID_DOCUMENTO_SOLICITUD_TRASPASO AS VARCHAR) + ' AND ID_TIPO_CONTRATO = ' + CAST(@id_tipo_contrato AS VARCHAR) + ')');
	END
	-- Se debe aplicar filtro por portabilidad
	IF @es_portabilidad = 1
	BEGIN
		SET @sqlCmd = dbo.fnAppendLine(@sqlCmd, '  OR (ID_DOCUMENTO = ' + CAST(@ID_DOCUMENTO_ANEXO_PORTABILIDAD AS VARCHAR) + ' AND ID_TIPO_CONTRATO = ' + CAST(@id_tipo_contrato AS VARCHAR) + ')');
	END
	-- Se debe aplicar filtro por cobro revertido
	IF @id_convenio = @ID_CONVENIO_COBRO_REVERTIDO
	BEGIN
		SET @sqlCmd = dbo.fnAppendLine(@sqlCmd, '  OR (ID_DOCUMENTO = ' + CAST(@ID_DOCUMENTO_COBRO_REVERTIDO AS VARCHAR) + ' AND ID_TIPO_CONTRATO = ' + CAST(@id_tipo_contrato AS VARCHAR) + ')');
	END
	PRINT(@sqlCmd);
	--Ejecutar consulta.
	EXEC(@sqlCmd);
END
