USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Consulta]    Script Date: 09/13/2016 14:21:22 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[Nab_Usuario_Consulta]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Usuario_Consulta]
GO
-- ========================================================================================  
-- Autor              : N/A.  
-- Fecha Creacion     : N/A  
-- Descripción        : Permite consultar usuarios en Nabis.  
--  
-- Parámetros       : @nh   -NH del usuario.  
--      @nombre  -Nombre de usuario.  
--  @user  -Usuario Login  
--      @pass    -Contraseña que el usuario asigna  
--      @mail    -E-mail  
--      @reg     -Región   
--      @area    -Area  
--  
 -- Fecha Modificacion : 2016-08-23  
 -- Autor              : Gabriel Martinez.  
 -- Descripción        : Se agrega nueva columna a la consulta con el estado de la clave  
-- ========================================================================================  
  
CREATE PROCEDURE [dbo].[Nab_Usuario_Consulta](  
@nh varchar(50) = null,  
@user varchar(50) = null,  
@nom varchar(150) = null,  
@reg varchar(2) =null,  
@area varchar(2) = null ,
@cc VARCHAR(50) =null)
AS  
BEGIN  
 IF @nh IS NULL OR @nh =''  
 BEGIN  
  SET @nh = '%'   
 END  
 ELSE  

   
 IF @user IS NULL OR @user =''  
 BEGIN  
  SET @user = '%'  
 END  
 ELSE  

   
 IF @nom IS NULL OR @nom =''  
 BEGIN  
  SET @nom = '%'  
 END  
 ELSE  
 BEGIN  
  SET @nom  = '%' +@nom +'%'  
 END  
   
 IF @reg IS NULL OR @reg =''  
 BEGIN  
  SET @reg = '%'  
 END  
 ELSE  
 BEGIN  
  SET @reg = '%' +@reg+'%'  
 END  
   
 IF @area IS NULL OR @area =''  
 BEGIN  
  SET @area= '%'  
 END  
 ELSE  
 BEGIN  
  SET @area = '%' +@area+'%'  
 END  
  IF @cc IS NULL OR @cc =''  
 BEGIN  
  SET @cc= '%'  
 END  

 
   
 SELECT A.USR_ID,
	 A.USR_LOGIN,
	 A.USR_NOMBRE,
	 A.USR_MAIL,
	 B.REGIONAL,
	 C.AREA,
	 D.GRUPO,
	 E.PROCESO,
	 A.USR_CELULAR,
	 F.TIPO,
	 G.ESTADO,
	 EL.Descripcion AS CLAVE,
	 P.PERFIL as PERFIL,
	 A.CONTLOGINERROR as CONTADOR ,
	 A.CC
 FROM USERS AS A  
	  INNER JOIN USERS_REGIONALES AS B ON B.ID_REGIONAL = A.ID_REGIONAL  
	  INNER JOIN USERS_AREAS AS C ON C.ID_AREA = A.ID_AREA  
	  INNER JOIN USERS_GRUPOS AS D ON D.ID_GRUPO = A.ID_GRUPO  
	  INNER JOIN USERS_PROCESOS AS E ON E.ID_PROCESO = A.ID_PROCESO  
	  INNER JOIN USERS_TIPOS AS F ON F.ID_TIPO = A.ID_TIPO  
	  INNER JOIN USERS_ESTADOS AS G ON G.ID_ESTADO = A.ID_ESTADO  
	  LEFT JOIN USERS_PERFILES AS P ON dbo.fnValidaPerfil(A.ID_PERFIL) = P.ID_PERFIL  
	  LEFT JOIN NAB_ESTADOLOGIN AS EL ON A.ID_ESTADOLOGIN = EL.IdEstadoLogin  
 WHERE (A.USR_ID = @nh)    
 AND (A.USR_LOGIN = @user )   
 AND (A.USR_NOMBRE LIKE @nom)   
 AND (A.ID_REGIONAL LIKE @reg)   
 AND (A.ID_AREA LIKE @area) 
 AND (A.CC = @cc)
   
    
  ORDER BY A.USR_NOMBRE  
END  
  --EXEC  [Nab_Usuario_Consulta] @CC=1094269885
   --EXEC  [Nab_Usuario_Consulta]  @user='jgmartinezbu'
  

  
  