IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_Anexo_Otros_Si_Condiciones_Uniformes') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_Anexo_Otros_Si_Condiciones_Uniformes
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-11-17
-- Descripción        : Obtener la informacion asociado de anexo otro si de un negocio de condiciones uniformes.
--						de un negocio.
--
-- Parámetros	      :	@ID_CODIGO_NEGOCIO      - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_Anexo_Otros_Si_Condiciones_Uniformes ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_Anexo_Otros_Si_Condiciones_Uniformes]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Obtener la informacion asociada a un negocio condiciones uniformes.
	SELECT *
	FROM [NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES]
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO
END			