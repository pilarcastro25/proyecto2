IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_PlanesAdquiridos') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_PlanesAdquiridos
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-13
-- Descripción        : Obtener la informacion asociado a la informacion de planes adquiridos
--						de un negocio.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO      - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_PlanesAdquiridos ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_PlanesAdquiridos]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	SELECT *
	FROM NAB_VENTAS_PLAN_ADQUIRIDO
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO

END			