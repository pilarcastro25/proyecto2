IF OBJECT_ID (N'dbo.Nab_Ventas_Radicacion_Informacion_Adicional') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Ventas_Radicacion_Informacion_Adicional
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-13
-- Descripción        : Inserta la informacion asociado al plan adquirido de un negocio.
--
-- Parámetros	      :	
--						@ID_KORAL 			  			- Id de koral asociado al negocio,
--						@ID_PRICING 					- Id de pricing asociado al negocio,
--						@ENVIO_CORREO_ELECTRONICO 		- La factura del negocio debe ser envia via email,
--						@CORREO_ELECTRONICO  			- Correo electronico al que debe ser enviado la factura del negocio,
--						@NOMBRE_CLIENTE_SOCIO 			- Nombre del cliente socio del negocio,
--						@CODIGO_CLIENTE_SOCIO 			- Codigo del cliente socio del negocio,
--						@NIT_CLIENTE_SOCIO				- Nit del cliente socio del negocio,
--						@ID_CODIGO_NEGOCIO 				- Id de codigo del negocio,
--						@DURACION_SERVICIOS 			- Duracion de los servicios				
--
-- Fecha Modificacion : 2016-09-30
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega campo de duracion de los servicios.
-- 
-- DEBUG			  : EXEC Nab_Ventas_Radicacion_Informacion_Adicional 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Ventas_Radicacion_Informacion_Adicional]
(
	@ID_KORAL 			  		VARCHAR(150),
    @ID_PRICING 				VARCHAR(150),
    @ENVIO_CORREO_ELECTRONICO 	BIT,
    @CORREO_ELECTRONICO  		VARCHAR(150),
    @NOMBRE_CLIENTE_SOCIO 		VARCHAR(150),
    @CODIGO_CLIENTE_SOCIO 		VARCHAR(150),
    @NIT_CLIENTE_SOCIO			VARCHAR(150),
    @ID_CODIGO_NEGOCIO 			VARCHAR(50),
	@DURACION_SERVICIOS			VARCHAR(50)
)
AS
BEGIN
	-- Agregar registro de usuarios autorizados por contrato.
	IF NOT EXISTS (SELECT * FROM NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO)
	BEGIN
		INSERT INTO [dbo].[NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL]
		(
			[ID_KORAL],[ID_PRICING],[ENVIO_CORREO_ELECTRONICO],[CORREO_ELECTRONICO],[NOMBRE_CLIENTE_SOCIO],
			[CODIGO_CLIENTE_SOCIO],[NIT_CLIENTE_SOCIO],[ID_CODIGO_NEGOCIO], [DURACION_SERVICIOS]
		)
	    VALUES
		(	
			@ID_KORAL, @ID_PRICING, @ENVIO_CORREO_ELECTRONICO,@CORREO_ELECTRONICO, 
		    @NOMBRE_CLIENTE_SOCIO, @CODIGO_CLIENTE_SOCIO, @NIT_CLIENTE_SOCIO, @ID_CODIGO_NEGOCIO,
			@DURACION_SERVICIOS
		);
	END
	ELSE
	BEGIN
		UPDATE [NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL]
		   SET [ID_KORAL] = @ID_KORAL,  
			   [ID_PRICING] = @ID_PRICING,  
			   [ENVIO_CORREO_ELECTRONICO] = @ENVIO_CORREO_ELECTRONICO, 
			   [CORREO_ELECTRONICO] = @CORREO_ELECTRONICO,  
			   [NOMBRE_CLIENTE_SOCIO] = @NOMBRE_CLIENTE_SOCIO,  
			   [CODIGO_CLIENTE_SOCIO] = @CODIGO_CLIENTE_SOCIO,  
			   [NIT_CLIENTE_SOCIO] = @NIT_CLIENTE_SOCIO,
			   [DURACION_SERVICIOS] = @DURACION_SERVICIOS
		 WHERE [ID_CODIGO_NEGOCIO] = @ID_CODIGO_NEGOCIO;
	END
END			