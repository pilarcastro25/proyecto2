USE [NABIS]
GO

/****** Object:  StoredProcedure [dbo].[Nab_EB_RadNegocios_Insertar_Lineas_Portabilidad]    Script Date: 09/23/2016 15:12:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Nab_EB_RadNegocios_Insertar_Lineas_Portabilidad]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Nab_EB_RadNegocios_Insertar_Lineas_Portabilidad]
GO

USE [NABIS]
GO

/****** Object:  StoredProcedure [dbo].[Nab_EB_RadNegocios_Insertar_Lineas_Portabilidad]    Script Date: 09/23/2016 15:12:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Nelson Fabian Rios Deantonio>
-- Create date: <Create Date,22/09/2016,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_EB_RadNegocios_Insertar_Lineas_Portabilidad] 
	-- Add the parameters for the stored procedure here	   	
	@NumeroMovil numeric(18, 0),
	@ContratoActual int,
	@ContratoNuevo int,
	@Fecha_solicitud datetime,
	@Fecha_ventana datetime,
	@Nip varchar(50)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		
		insert into dbo.NAB_VENTAS_LINEAS_PORTABILIDAD
	values (				
	@NumeroMovil,
	@ContratoActual,
	@ContratoNuevo,
	@Fecha_solicitud,
	@Fecha_ventana,
	@Nip
	);
END
GO

