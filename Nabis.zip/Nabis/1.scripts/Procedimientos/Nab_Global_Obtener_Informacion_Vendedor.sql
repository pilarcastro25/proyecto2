IF OBJECT_ID (N'dbo.Nab_Global_Obtener_Informacion_Vendedor') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Global_Obtener_Informacion_Vendedor
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-11-11
-- Descripción        : Obtener la informacion registrada de un vendedor
--
-- Parámetros	      :	
--						@COD_VENDEDOR      - Codigo del vendedor.
--
-- Fecha Modificacion : 2016-11-15
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega union para traer informacion de base de datos de nabis o 
--						e - bussines
-- 
-- DEBUG			  : EXEC Nab_Global_Obtener_Informacion_Vendedor '207017'
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Global_Obtener_Informacion_Vendedor]
(
    @COD_VENDEDOR VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	SELECT TOP 1 V.*
	FROM
	(
		SELECT Ag_Codvendededor AS COD_VENDEDOR, Ag_Región AS REGIONAL, Ag_Ciudad AS CIUDAD, Ag_Departamento AS DEPARTAMENTO, 
			   Ag_Canal AS CANAL, Ag_Nomresponsable AS RESPONSABLE,Ag_CodAgente AS COD_AGENTE, Ag_Nomagente AS NOMBRE_AGENTE, 
			   Ag_Nomvendedor AS VENDEDOR, Ag_Codtipcomis AS COD_TIP_COMISIONISTA, Ag_Descritipcomis AS TIPO_COMISIONISTA,
			   Ag_CanalComercial AS CANAL_COMERCIAL, Ag_codpunto AS COD_PUNTO, Ag_NombrePunto AS NOMBRE_PUNTO, Ag_EstadoPunto AS ESTADO_PUNTO,
			   Ag_Fec_Contrato AS FECHA_INICIO_CONTRATO, Ag_Fec_Fin_Contrato AS FECHA_FIN_CONTRATO, Ag_Identvendedor AS NUM_IDEN_VENDEDOR,
			   Ag_MovilVendedor AS MOVIL_VENDEDOR   
		FROM ccc.dbo.BC_Agente
		WHERE Ag_Codvendededor = @COD_VENDEDOR 
		UNION
		SELECT COD_VENDEDOR, REGIONAL, CIUDAD, DEPARTAMENTO, CANAL, RESPONSABLE, COD_AGENTE, NOMBRE_AGENTE, VENDEDOR, COD_TIP_COMISIONISTA, 
			   TIPO_COMISIONISTA, CANAL_COMERCIAL, COD_PUNTO, NOMBRE_PUNTO, ESTADO_PUNTO, FECHA_INICIO_CONTRATO, FECHA_FIN_CONTRATO, NUM_IDEN_VENDEDOR,
			   MOVIL_VENDEDOR 	 
		FROM NAB_GLOBAL_VENDEDORES V where COD_VENDEDOR = @COD_VENDEDOR
	)V
END			