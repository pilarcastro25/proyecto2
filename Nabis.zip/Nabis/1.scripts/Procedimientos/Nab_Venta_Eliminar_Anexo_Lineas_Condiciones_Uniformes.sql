IF OBJECT_ID (N'dbo.Nab_Venta_Eliminar_Anexo_Lineas_Condiciones_Uniformes') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Eliminar_Anexo_Lineas_Condiciones_Uniformes
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-11-17
-- Descripción        : Eliminar la informacion asociado a las lineas anexas.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO    - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Eliminar_Anexo_Lineas_Condiciones_Uniformes ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Eliminar_Anexo_Lineas_Condiciones_Uniformes]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion de anexo otros a un negocio de condiciones uniformes.
	DELETE NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO
END			