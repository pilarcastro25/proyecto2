USE [NABIS]
GO

/****** Object:  StoredProcedure [dbo].[Nab_GuardarAnexosNegocio]    Script Date: 09/22/2016 14:45:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_GuardarAnexosNegocio] 
	-- Add the parameters for the stored procedure here
	@CodigoNegocio_FK varchar(50),
	@ImeiEquipo varchar(20),
	@ValorEquipo float,
	@ValorEquipoKoral float,
	@EquipoACuotas bit,
	@CuotaInicial float,
	@ValorADiferir float,
	@NumeroDeCuotas int,
	@SerialSimCard varchar(20),
	@ValorDeLaSimCard float,
	@ValorBeneficio float,
	@CondicionesBeneficio varchar(200),
	@CodigoBeneficioRecurrente varchar(6),
	@CondicionesBeneficioBasico varchar(200),
	@CodigoBeneficioBasico varchar(6)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   INSERT INTO [NABIS].[dbo].NAB_ANEXOS_NEGOCIO VALUES(
           @CodigoNegocio_FK,
		   @ImeiEquipo,
		   @ValorEquipo,
		   @ValorEquipoKoral,
		   @EquipoACuotas,
		   @CuotaInicial,
		   @ValorADiferir,
		   @NumeroDeCuotas,
		   @SerialSimCard,
		   @ValorDeLaSimCard,
		   @ValorBeneficio,
		   @CondicionesBeneficio,
		   @CodigoBeneficioRecurrente,
		   @CondicionesBeneficioBasico,
		   @CodigoBeneficioBasico
		   )	
END


GO

