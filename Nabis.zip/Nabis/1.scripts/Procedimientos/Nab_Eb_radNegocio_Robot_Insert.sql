IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_Robot_Insert') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_Robot_Insert
GO
-- ========================================================================================
-- Autor              : Jeffrey Cortés.
-- Fecha Creacion	  : 2015-07-03
-- Descripción        : Ingreso de líneas a robot desde NABIS.
--
-- Parámetros	      :	
--
-- Fecha Modificacion : 2016-09-09
-- Autor              : Harold Caicedo
-- Descripción        : Se variable de numero de lineas
--
-- DEBUG			  : EXEC Nab_Eb_radNegocio_Reiniciar ''
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_Robot_Insert]
(
	@user				VARCHAR(30)
	,@Cod_Cuota			INT
	,@Producto			INT
	,@IdLinea			VARCHAR(50)
	,@Mesaconspref		VARCHAR(30)
	,@TipId				VARCHAR(30)
	,@Nit				VARCHAR(30)
	,@Cuenta			VARCHAR(100)
	,@Canal				VARCHAR(30)
	,@Cod_Vendedor		INT
	,@Cod_cliente		BIGINT
	,@Cuota				VARCHAR(30)
	,@AbonoLin			INT
	,@carterizado		VARCHAR(30)
	,@Pago				VARCHAR(30)
	,@nombrer 			VARCHAR (60)
	,@apellido1r 		VARCHAR (30)
	,@apellido2r 		VARCHAR (30)
	,@fecnac 			DATETIME
	,@nombrec 			VARCHAR (60)
	,@apellido1c 		VARCHAR (30)
	,@apellido2c 		VARCHAR (30)
	,@tel 				VARCHAR (30)
	,@tipcalle 			VARCHAR (30)
	,@calle 			VARCHAR (30)
	,@obsdireccion 		VARCHAR (60)
	,@complemento 		VARCHAR (60)
	,@depto 			VARCHAR (30)
	,@distrito 			VARCHAR (30)
	,@barrio 			VARCHAR (30)
	,@subcatimpos 		VARCHAR (30)
	,@ciclo			 	VARCHAR (30)
	,@subcuenta		 	VARCHAR (30)
	,@usuariocuenta		VARCHAR (30)
	,@nomusuariocuenta	VARCHAR (60)
	,@apeusuariocuenta	VARCHAR (60)
	,@Contrato			VARCHAR(30)
	,@Simcard			VARCHAR(30)
	,@Procedenciaimei	VARCHAR(30)
	,@RefImei			VARCHAR(50)
	,@Imei				VARCHAR(30)
	,@Plan				VARCHAR(10)
	,@Serv1				VARCHAR(10)
	,@Serv2				VARCHAR(10)
	,@Serv3				VARCHAR(10)
	,@Correo			VARCHAR(10)
	,@PlanAdic1			VARCHAR(10)
	,@PlanAdic2			VARCHAR(10)
	,@FecProgr 			DATETIME
	,@EstadoCivil		VARCHAR(30)
	,@Sexo				VARCHAR(30)
	,@Estrato			INT
	,@PerfUsrAutoriza	VARCHAR(30)
	,@Email				VARCHAR(80)
	,@IdWeb				BIGINT
	,@Celular			BIGINT
	,@ProductoLinea		VARCHAR(20)
	,@IsError			INT OUTPUT
	,@TraspasoPort		BIT = 0
	,@xmlTraspasoPort   VARCHAR(4000) = null
	,@numeroLineas      INT = 1
)
AS
BEGIN
	DECLARE		@usr_id				INT
				,@IdEstado			INT
				,@indexLinea		INT
				,@count				INT
				,@lim_comsumo		VARCHAR(5)
				,@TipCliente		VARCHAR(30)
				,@TipPlanCliente	VARCHAR(30)
				,@resultado			INT
				,@fecha				datetime
				,@region 			VARCHAR (30)
				,@Central			VARCHAR(30)
				,@TipPlan			VARCHAR(30)
				,@IdEstrVenta		INT
				,@ModVenta			VARCHAR(30)
				,@servOb1			VARCHAR(50)
				,@servOb2			VARCHAR(50)
				,@servOb3			VARCHAR(50)
				,@servOb4			VARCHAR(50)
				,@planAdicOb1			VARCHAR(50)
				,@planAdicOb2			VARCHAR(50)
				,@planAdicOb3			VARCHAR(50)
				,@planAdicOb4			VARCHAR(50);

	DECLARE @tableServ TABLE( INDX INT IDENTITY PRIMARY KEY, COD_SERV VARCHAR(10) );
	DECLARE @tablePLanes TABLE( INDX INT IDENTITY PRIMARY KEY, COD_PLANADIC VARCHAR(10) );

	SET @IdEstado = CASE WHEN @Simcard IS NULL OR @Simcard = '' THEN 4 ELSE -1 END ;

	SELECT @usr_id = usr_id
	FROM   CCC.DBO.bc_usuariospassw
	WHERE  usr_login = 'NABIS';
      
	SELECT @region = Cod_Region
	FROM CCC.DBO.BC_RobSCL_Provincias
	WHERE Cod_Provincia = @depto;
	
	SET @TipId = (SELECT TipIdScl FROM CCC.DBO.BC_TipId WHERE Id_TipId= @TipId);

	IF @Procedenciaimei = 'Interna'
	BEGIN
		SELECT @RefImei = Des_Articulo
		FROM CCC.DBO.BC_RobSCL_Series_Bodegas A
		WHERE Num_Serie = @Imei;		
	END

	IF @IdEstado = -1
	BEGIN
		SELECT @Central = HLR_Def
		FROM CCC.DBO.BC_RobSCL_Series_Bodegas
		WHERE Num_Serie = @Simcard;

		SELECT @count = COUNT(IdLinea)
		FROM   CCC.DBO.BC_ActivacionRobot
		WHERE  IdEstado != 6
				AND (Simcard = @Simcard OR Imei = @Imei);
	END
	ELSE
	BEGIN
		SET @Central = 'NA';

		SELECT @count = COUNT(IdLinea)
		FROM   CCC.DBO.BC_ActivacionRobot
		WHERE  IdEstado != 6
				AND Imei = @Imei;
	END

	SELECT @TipPlan = Des_Uso
	FROM CCC.DBO.BC_RobPlanes
	WHERE Cod_Plan = @Plan;

	SET @ModVenta = CASE WHEN @Cod_Cuota <= 0 THEN 'CONTADO' ELSE 'CREDITO' END;
	
	SELECT @IdEstrVenta = A.Id_Estructura, @Contrato = B.CONTRATO
	FROM CCC.DBO.BC_RobContratosVenta A
		INNER JOIN CCC.DBO.BC_ROBCONTRATOS B ON A.COD_CONTRATO = B.COD_CONTRATO
	WHERE	A.Cod_Cuota = @Cod_Cuota
			AND A.Producto = @Producto
			AND A.ESTADO = 1;
	
	SELECT @indexLinea = (COUNT(*) + 1)
	FROM   CCC.DBO.BC_ActivacionRobot
	WHERE MESACONSPREF = @Mesaconspref
			AND ID_ESTRUCTURA = @IdEstrVenta;

	SET @IdLinea = CAST(@IdEstrVenta AS VARCHAR) + '_' + CAST(@indexLinea AS VARCHAR) + @IdLinea;
	
	SET @fecha = GETDATE();     
	SET @TipPlanCliente = 'Individual';



	IF @Tipid='CC' OR @Tipid='CE' OR @Tipid='PS' OR @Tipid='TARJETA DE IDENTIDAD'
	BEGIN
		SELECT @TipCliente = 'Particular', @lim_comsumo = '';
	END

	ELSE
	BEGIN
		SET @TipCliente = 'Empresa';

		IF @carterizado = 'S' 
		BEGIN
			SELECT @lim_comsumo = Lim_Consumo_Carterizado
			FROM CCC.DBO.BC_RobPlanes
			WHERE Cod_Plan = @Plan;
		END

		ELSE
		BEGIN
			SELECT @lim_comsumo = '';
		END
	END

		IF @count = 0
		BEGIN

			INSERT INTO @tableServ (COD_SERV)
			SELECT COD_SERV
			FROM CCC.DBO.BC_ROBPLAN_SERV
			WHERE COD_PLAN = @Plan
				AND RELACION = 'OBL'
				AND TARIFA > 0
			ORDER BY COD_SERV;

			INSERT INTO @tablePLanes (COD_PLANADIC)
			SELECT COD_PLANADIC
			FROM CCC.DBO.BC_ROBPLAN_PLANADIC
			WHERE COD_PLAN = @Plan
				AND RELACION = 'OBL'
				AND TARIFA > 0
			ORDER BY COD_PLANADIC;


			SET @servOb1 = (SELECT COD_SERV FROM @tableServ WHERE INDX = 1);
			SET @servOb2 = (SELECT COD_SERV FROM @tableServ WHERE INDX = 2);
			SET @servOb3 = (SELECT COD_SERV FROM @tableServ WHERE INDX = 3);
			SET @servOb4 = (SELECT COD_SERV FROM @tableServ WHERE INDX = 4);
			SET @planAdicOb1 = (SELECT COD_PLANADIC FROM @tablePLanes WHERE INDX = 1);
			SET @planAdicOb2 = (SELECT COD_PLANADIC FROM @tablePLanes WHERE INDX = 2);
			SET @planAdicOb3 = (SELECT COD_PLANADIC FROM @tablePLanes WHERE INDX = 3);

		
			INSERT INTO CCC.DBO.BC_ActivacionRobot
						(Id_Estructura
						,Paquete
						,IdLinea
						,Mesaconspref
						,TipId
						,Nit
						,Cuenta
						,Canal
						,Cod_Vendedor
						,Cod_cliente
						,Des_ModVenta
						,Des_Cuota
						,AbonoLin_ModVenta
						,TipPlanCliente
						,Pago
						,Nombrer 
						,Apellido1r 
						,Apellido2r 
						,Fecnac 
						,Nombrec 
						,Apellido1c 
						,Apellido2c 
						,Tel 
						,Tipcalle 
						,Calle 
						,Obsdireccion 
						,Complemento 
						,Region 
						,Depto 
						,Distrito 
						,Barrio 
						,Subcatimpos 
						,Ciclo
						,TipCliente
						,Subcuenta
						,Usuariocuenta
						,Nomusuariocuenta
						,Apeusuariocuenta
						,Contrato
						,Central
						,Simcard
						,Procedenciaimei
						,RefImei
						,Imei
						,TipPlan
						,Plan_
						,Lim_Consumo
						,ServOb1
						,ServOb2
						,ServOb3
						,ServOb4
						,Serv1
						,Serv2
						,Serv3
						,Correo
						,PlanAdicOb1
						,PlanAdicOb2
						,PlanAdicOb3
						,PlanAdic1
						,PlanAdic2
						,FecSolic
						,UsrSolic
						,IdEstado
						,FecProgr
						,Port_EstadoCivil
						,Port_Sexo
						,Port_Correo
						,Port_Estrato
						,Port_PerfUsrAutoriza
						,Port_IdWeb
						,Port_Celular
						,Producto)
			VALUES      (@IdEstrVenta
						,1
						,@IdLinea
						,@Mesaconspref
						,UPPER(@TipId)
						,@Nit
						,@Cuenta
						,@Canal
						,@Cod_Vendedor
						,@Cod_cliente
						,@ModVenta
						,@Cuota
						,@AbonoLin
						,@TipPlanCliente
						,@Pago
						,@nombrer 
						,@apellido1r 
						,@apellido2r 
						,@Fecnac 
						,@nombrec 
						,@apellido1c 
						,@apellido2c 
						,@Tel 
						,@Tipcalle 
						,@Calle 
						,@Obsdireccion 
						,@Complemento 
						,@Region 
						,@Depto 
						,@Distrito 
						,@Barrio 
						,@Subcatimpos 
						,@Ciclo
						,@TipCliente
						,@Subcuenta
						,@Usuariocuenta
						,@nomusuariocuenta
						,@apeusuariocuenta
						,@Contrato
						,ISNULL(@Central, 'N/A')
						,@Simcard
						,@Procedenciaimei
						,@RefImei
						,@Imei
						,@TipPlan
						,@Plan
						,@lim_comsumo
						,@servOb1
						,@servOb2
						,@servOb3
						,@servOb4
						,@Serv1
						,@Serv2
						,@Serv3
						,@Correo
						,@PlanAdicOb1
						,@PlanAdicOb2
						,@PlanAdicOb3
						,@PlanAdic1
						,@PlanAdic2
						,@fecha
						,@usr_id
						,@IdEstado
						,@FecProgr
						,@EstadoCivil
						,@Sexo
						,@Email
						,@Estrato
						,@PerfUsrAutoriza
						,@IdWeb
						,@Celular
						,@ProductoLinea)

			IF @@ROWCOUNT > 0
			BEGIN
				DECLARE @IsError_EstrVenta bit;
				EXEC dbo.Nab_Eb_radNegocio_estrVenta_Insert @user, @Mesaconspref, @Cod_Cuota, @Producto, @numeroLineas, @IsError = @IsError_EstrVenta OUTPUT;

				IF @TraspasoPort = 1
				BEGIN
					EXEC Nab_Eb_radNegocio_Robot_Trapasos_Port_Insert @Mesaconspref, @IdLinea,@xmlTraspasoPort;
				END
			END
	END

	ELSE
	BEGIN
		SET @IsError = 1;
	END
END




