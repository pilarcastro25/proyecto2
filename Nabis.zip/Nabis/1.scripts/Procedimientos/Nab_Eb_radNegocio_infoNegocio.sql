IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_infoNegocio') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_infoNegocio
GO
-- ========================================================================================
-- Autor              : Jeffrey Cortés.
-- Fecha Creacion	  : 2015-01-11
-- Descripción        : Radicación de negocio desde NABIS.
--
-- Parámetros	      :	
--						@user        - Usuario.
--						@id_eb       - Codigo de negocio
--						@id_estado   - Id de estado del negocio.
--
-- Fecha Modificacion : 2016-09-15
-- Autor              : Harold Caicedo
-- Descripción        : Se agrega campo de si el negocio fue creado por pymes o asesor.
-- 
-- DEBUG			  : EXEC Nab_Eb_radNegocio_infoNegocio ''
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_infoNegocio]
(
	 @user 				VARCHAR(20),
	 @id_eb 			VARCHAR(100),	
	 @id_estado 		INT
)
AS
BEGIN
	--Envío de mensajes al cliente
	SET NOCOUNT OFF;
	
	SELECT	@user AS USER_CONSULTA , C.ID_EB AS idEb, C.CANT_LINEAS AS cantLineas, C.COD_VENDEDOR AS CodVendedor, C.CANAL_VENDEDOR AS canalVendedor
			, GRP.GRUPO AS canalVenta
			--CLIENTE
			, TPDNI.TIPO_DOC AS tipoIdent, C.IDENTIDAD AS numIdent, C.NOMBRE_CLIENTE AS razonSocial, C.COD_DISTRITO AS MesaDistrito
			, C.COD_TIPO_CALLE AS MesaTipCalle, C.DIRECCION AS MesaCalle, C.COMPLEMENTO AS MesaObsDireccion, E.CODIGO_PROVINCIA AS MesaDepartamento
			--REP LEGAL
			, C.REP_LEGAL_IDENTIDAD AS RepLegalNumIdent, C.REP_LEGAL_NOMBRE  AS NomRepLegal, C.REP_LEGAL_APELLIDO1  AS RepLegalAp1
			, C.REP_LEGAL_APELLIDO2  AS RepLegalAp2, C.REP_LEGAL_FIJO  AS RepLegalNumFijo, C.REP_LEGAL_CELULAR AS RepLegalCelular
			, C.REP_LEGAL_FECNACIMIENTO AS RepLegalFecNac
			--INFO SOLICITUD
			, TPCLT.TIPO_CLIENTE AS tipoVenta, TPSOL.TIPO_SOLICITUD AS tipSolicitud, TPCTR.TIPO_CONTRATO AS tipContrato, CONV.CONVENIO AS convenio
			, B.NumContrato AS numContrato
			--Variables de alerta o informativas
			, TPCP.TIPO_CAMBIO_PLAN AS cambioPlan, C.PEND_LINEAS AS pendLineas
			, CASE C.PORTADO WHEN 1 THEN 'S' ELSE 'N' END AS portado
			, CASE C.PEDIDO WHEN 1 THEN 'S' ELSE 'N' END AS pedido
			, D.DESCRIPCION AS ESTADO, C.ID_ESTADO, C.FEC_VENTANA AS fecVentana, I.AG_MOVILVENDEDOR AS movilVendedor, I.AG_IDENTVENDEDOR AS vendedor_numIdent
			, CASE	WHEN F.Cod_Cuenta = NULL AND (GRP.GRUPO = 'Empresas' OR GRP.GRUPO = 'Corporaciones' OR GRP.GRUPO = 'Mayoristas') THEN 'S'
					WHEN G.Nit <> NULL THEN 'S' ELSE 'N' End AS carterizado
			, CASE WHEN TPDNI.TIPO_DOC IN ('C.C','H2') THEN 'N' ELSE 'S' END AS MesaLimiteConsumo
			, CASE WHEN SUM(H.Lineas) IS NULL THEN 0 ELSE SUM(H.Lineas) END AS lineasIngresadas
			--,COUNT(I.Mesaconspref) AS lineasRobot
			, C.ES_PYMES
	FROM NAB_EB_NEGOCIOS C
			INNER JOIN NAB_GLOBAL_P_BARRIOS E ON E.CODIGO_CIUDAD = C.COD_DISTRITO
			INNER JOIN NAB_GLOBAL_P_ESTADOS D ON D.ID_ESTADO = CASE C.ID_ESTADO WHEN 0 THEN 1 ELSE C.ID_ESTADO END
			INNER JOIN USERS_GRUPOS GRP ON GRP.ID_GRUPO = C.ID_GRUPO
			INNER JOIN NAB_CREDITO_P_TIPO_CONTRATOS TPCTR ON TPCTR.ID_TIPO_CONTRATO = C.ID_TIPO_CONTRATO
			INNER JOIN NAB_GLOBAL_P_TIPOS_IDENTIDAD TPDNI ON TPDNI.ID_IDENTIDAD = C.ID_IDENTIDAD
			INNER JOIN NAB_EB_NEGOCIOS_P_TIPO_CLIENTE TPCLT ON TPCLT.ID_TIPO_CLIENTE = C.ID_TIPO_CLIENTE
			--INNER JOIN NAB_GLOBAL_P_TIPO_SERVICIO TPSRV ON TPSRV.ID_TIPO_SERVICIO = C.ID_TIPO_SERVICIO
			INNER JOIN NAB_EB_NEGOCIOS_P_TIPOS_SOLICITUD TPSOL ON TPSOL.ID_TIPO_SOLICITUD = C.ID_TIPO_SOLICITUD
			INNER JOIN NAB_EB_NEGOCIOS_P_CONVENIOS CONV ON CONV.ID_CONVENIO = C.ID_CONVENIO
			LEFT JOIN NAB_EB_NEGOCIOS_P_TIPOS_CAMBIO_PLAN TPCP ON TPCP.ID_TIPO_CAMBIO_PLAN = C.ID_TIPO_CAMBIO_PLAN
			LEFT JOIN CCC.DBO.BC_ContratosMarco B ON B.IdContrato = C.ID_CONTRATO_MARCO
			LEFT JOIN CCC.DBO.BC_RobSCL_Cuentas F ON f.Num_Ident= C.IDENTIDAD
			LEFT JOIN CCC.DBO.BC_NitCarterizados G ON G.Nit = C.IDENTIDAD
			LEFT JOIN CCC.DBO.BC_CreditoVenta H ON H.MesaConsPref = C.ID_EB
			LEFT JOIN CCC.DBO.BC_AGENTE I ON I.AG_CODVENDEDEDOR = C.COD_VENDEDOR AND I.AG_CANAL = C.CANAL_VENDEDOR
			--LEFT JOIN CCC.DBO.BC_ActivacionRobot I ON I.MesaConsPref = A.MesaConsPref
	WHERE	C.ID_EB = @id_eb
			AND C.ID_ESTADO = @id_estado
	GROUP BY C.ID_EB, C.CANT_LINEAS, C.COD_VENDEDOR, C.CANAL_VENDEDOR, GRP.GRUPO
			--CLIENTE
			, TPDNI.TIPO_DOC, C.IDENTIDAD, C.NOMBRE_CLIENTE, C.COD_DISTRITO, C.COD_TIPO_CALLE, C.DIRECCION, C.COMPLEMENTO, E.CODIGO_PROVINCIA
			--REP LEGAL
			, C.REP_LEGAL_IDENTIDAD, C.REP_LEGAL_NOMBRE, C.REP_LEGAL_APELLIDO1, C.REP_LEGAL_APELLIDO2, C.REP_LEGAL_FIJO, C.REP_LEGAL_CELULAR
			, C.REP_LEGAL_FECNACIMIENTO
			--INFO SOLICITUD
			, TPCLT.TIPO_CLIENTE, TPSOL.TIPO_SOLICITUD, TPCTR.TIPO_CONTRATO, CONV.CONVENIO, B.NumContrato
			--Variables de alerta o informativas
			, TPCP.TIPO_CAMBIO_PLAN, C.PEND_LINEAS
			, CASE C.PORTADO WHEN 1 THEN 'S' ELSE 'N' END
			, CASE C.PEDIDO WHEN 1 THEN 'S' ELSE 'N' END
			, D.DESCRIPCION, C.ID_ESTADO, C.FEC_VENTANA, I.AG_MOVILVENDEDOR, I.AG_IDENTVENDEDOR
			, CASE	WHEN F.Cod_Cuenta = NULL AND (GRP.GRUPO = 'Empresas' OR GRP.GRUPO = 'Corporaciones' OR GRP.GRUPO = 'Mayoristas') THEN 'S'
					WHEN G.Nit <> NULL THEN 'S' ELSE 'N' End
			, CASE WHEN TPDNI.TIPO_DOC IN ('C.C','H2') THEN 'N' ELSE 'S' END
			, C.ES_PYMES
END

