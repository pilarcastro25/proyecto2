IF OBJECT_ID (N'dbo.Nab_Venta_Eliminar_Anexos_Lineas') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Eliminar_Anexos_Lineas
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-09
-- Descripción        : Eliminar la informacion asociado a las lineas anexas.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Eliminar_Anexos_Lineas ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Eliminar_Anexos_Lineas]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	DELETE NAB_ANEXOS_NEGOCIO
	WHERE CodigoNegocio_FK = @ID_CODIGO_NEGOCIO

END			