USE [NABIS]
GO
IF OBJECT_ID(N'Nab_Venta_Eliminar_Anexo_Condiciones_Uniformes') IS NOT NULL
	DROP PROCEDURE Nab_Venta_Eliminar_Anexo_Condiciones_Uniformes
GO
-- ========================================================================================
-- Autor              : Jeison Martinez
-- Fecha Creacion	  : 2016-11-29
-- Descripci�n        : Informaci�n de planes estructura de venta.
--
-- Par�metros	      :	@ID_CODIGO_NEGOCIO Codigo del negocio al cual se le asocia el plan 
--						adquirido.
-- ========================================================================================
CREATE PROCEDURE [dbo].Nab_Venta_Eliminar_Anexo_Condiciones_Uniformes
(
	@id_eb VARCHAR(100)
)
AS
BEGIN
	DELETE FROM NAB_VENTAS_NEGOCIO_INFORMACION_ADICIONAL_ANEXO
	WHERE ID_NEGOCIO = @id_eb
END
GO

