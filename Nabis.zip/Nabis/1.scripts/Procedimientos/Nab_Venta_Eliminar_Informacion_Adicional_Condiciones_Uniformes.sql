IF OBJECT_ID (N'dbo.Nab_Venta_Eliminar_Informacion_Adicional_Condiciones_Uniformes') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Eliminar_Informacion_Adicional_Condiciones_Uniformes
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-10-05
-- Descripción        : Eliminar la informacion asociado al contrato venta a cuotas.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO Codigo del negocio al cual se le asocia los contratos venta a cuotas.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Eliminar_Informacion_Adicional_Condiciones_Uniformes ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Eliminar_Informacion_Adicional_Condiciones_Uniformes]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	DELETE NAB_VENTAS_CONDICIONES_UNIFORMES_ADICIONAL
	WHERE COD_NEGOCIO = @ID_CODIGO_NEGOCIO

END			