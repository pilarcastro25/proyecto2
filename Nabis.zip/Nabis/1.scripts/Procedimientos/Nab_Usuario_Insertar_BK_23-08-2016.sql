USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/22/2016 11:33:23 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO




ALTER PROCEDURE [dbo].[Nab_Usuario_Insertar](
@nh varchar(10),
@cc numeric,
@login varchar(50),
@nombre varchar(150),
@pass varchar(34),
@mail varchar(150),
@reg int,
@area int,
@grupo int,
@proceso int,
@tipo int,
@equipo varchar(50),
@ip varchar(15),
@cel varchar(10)= null,
@ext varchar(10) = null)
 AS
BEGIN
	IF @cel = ''
	BEGIN
		SET @cel = '0'
	END
	
	IF @ext = ''
	BEGIN
		SET @ext = '0'
	END
	
	INSERT INTO USERS(USR_ID, CC, USR_LOGIN, USR_PASSW, USR_NOMBRE, USR_MAIL, ID_REGIONAL, ID_AREA,
	ID_GRUPO, ID_PROCESO, USR_CELULAR, USR_EXT, USR_EQUIPO, USR_IP, FEC_INGRESO, ID_TIPO, NOTAS, ID_ESTADO)
	VALUES
	(@nh, @cc, @login, @pass, @nombre, @mail, @reg, @area, @grupo, @proceso, @cel, @ext, @equipo, @ip, GETDATE(), @tipo,'REGISTRADO POR NABIS',1)
END







