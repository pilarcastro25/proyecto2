IF OBJECT_ID (N'dbo.Nab_Eb_ComercialConsulta_Negocios') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_ComercialConsulta_Negocios
GO
-- ========================================================================================
-- Autor              : Jeffrey Cortés.
-- Fecha Creacion	  : 2015-02-27
-- Descripción        : Consulta de negocios corporativos
--
-- Parámetros	      :	@alertLogId   - Id de log de alerta.
--						@userName     - Nombre de usuario.
--						@comment 	  - Comentario asociado al log de alerta
--						@closeAlert	  - La alerta sera cerrada por el sistama.
--
-- Fecha Modificacion : 2016-08-26
-- Autor              : Harold Caicedo.
-- Descripción        : Se hace correccion en la seccion de consultas por casteo de datos.
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_ComercialConsulta_Negocios]
(
	@user varchar(20),
	@id_eb varchar(20),
	@numIdent varchar(20),
	@vista varchar(20)
)
AS
BEGIN
	DECLARE @canalVendedor VARCHAR(10), @cod_agente int, @area VARCHAR(50), @userNabis	VARCHAR(20);

	SELECT @canalVendedor = CASE WHEN A.COD_AGENTE IS NOT NULL THEN 'INDIRECTO' ELSE 'DIRECTO' END
			,@area = B.AREA, @cod_agente = A.COD_AGENTE, @userNabis = A.USR_NOMBRE
	FROM USERS A
		INNER JOIN USERS_AREAS B ON B.ID_AREA = A.ID_AREA
	WHERE A.USR_ID = @user;

	IF @vista = 'Recientes'
	BEGIN
		SELECT TOP 10 ID_EB AS RADICADO
					, FEC_INGRESO AS [FECHA INGRESO]
					, CAST(COD_VENDEDOR AS VARCHAR(50)) AS [COD. VENDEDOR]
					, IDENTIDAD AS [NIT]
					, CANAL_VENDEDOR AS [CANAL]
					, CANT_LINEAS AS LINEAS
					, CAST(PEND_LINEAS AS VARCHAR(50)) AS PENDIENTES
					, CASE PORTADO WHEN 1 THEN 'S' ELSE 'N' END AS PORTADO
					, CASE PEDIDO WHEN 1 THEN 'S' ELSE 'N' END AS PEDIDO
					, FEC_ULT_MOD AS [FECHA ULT. MODIFICACION]
		FROM NAB_EB_NEGOCIOS
		WHERE USER_INGRESO = @user
		ORDER BY FEC_INGRESO DESC;
	END

	ELSE IF @vista = 'Consulta'
	BEGIN
		SET @id_eb = '%' + @id_eb + '%';
		SET @numIdent = '%' + @numIdent + '%';
		IF @canalVendedor = 'INDIRECTO'
		BEGIN
			  SELECT A.mesaconspref  AS RADICADO
			  		,A.mesafechasis AS [FECHA INGRESO]
					,A.MESACODASESOR AS [COD. VENDEDOR]
					,A.mesaid AS [NIT]
					,A.MESACANAL AS [CANAL]
					,A.MESALINEAS AS LINEAS
					,'-' AS PENDIENTES
					,CASE A.PORTABLE WHEN 'Si' THEN 'S' ELSE 'N' END AS PORTADO
					,CASE B.rutaseriales WHEN 'Si' THEN 'S' ELSE 'N' END AS PEDIDO
					,FEC_ULT_MOD AS [FECHA ULT. MODIFICACION]
				  FROM   CCC.DBO.BC_MESACONTROL A
					LEFT JOIN CCC.DBO.BC_HOJARUTAMESA B ON B.MESACONSPREF = A.MESACONSPREF
					LEFT JOIN NAB_EB_NEGOCIOS C ON C.ID_EB = A.MESACONSPREF
				  WHERE A.MESACODAGENTE = @cod_agente
						AND A.mesaconspref LIKE @id_eb
						AND A.mesaid LIKE @numIdent
				  ORDER  BY A.mesafechasis DESC;
		END

		ELSE
		BEGIN
			  SELECT A.mesaconspref  AS RADICADO
			  		,A.mesafechasis AS [FECHA INGRESO]
					,A.MESACODASESOR AS [COD. VENDEDOR]
					,A.MESAID AS [NIT]
					,A.MESACANAL AS [CANAL]
					,A.MESALINEAS AS LINEAS
					,'-' AS PENDIENTES
					,CASE A.PORTABLE WHEN 'Si' THEN 'S' ELSE 'N' END AS PORTADO
					,CASE B.rutaseriales WHEN 'Si' THEN 'S' ELSE 'N' END AS PEDIDO
					,FEC_ULT_MOD AS [FECHA ULT. MODIFICACION]
				  FROM   CCC.DBO.BC_MESACONTROL A
					LEFT JOIN CCC.DBO.BC_HOJARUTAMESA B ON B.MESACONSPREF = A.MESACONSPREF
					LEFT JOIN NAB_EB_NEGOCIOS C ON C.ID_EB = A.MESACONSPREF
				  WHERE A.MESACONSPREF LIKE @id_eb
						AND A.MESAID LIKE @numIdent
				  ORDER  BY A.MESAFECHASIS DESC;
		END
	END

	ELSE IF @vista = 'Detalles'
	BEGIN
		IF @canalVendedor = 'INDIRECTO'
		BEGIN
			  SELECT @userNabis AS userIngreso
					, *
					,	CASE	WHEN (TramiteMesa='Devolucion Cliente' OR CSubEst='Devolución' OR (TramiteActivacion<>'reasignado' AND ASubEst='devolucion')) THEN 'Devolución'
								WHEN CSubEst='Rechazado' THEN 'Rechazada'
								WHEN CSubEst='Fraude' THEN 'Fraude'
								WHEN (ASubEst='Activo' OR (ASubEst='Aprobado' AND ACausal='Activado') OR (ASubEst='Aprobado' AND ActiLinPen=0)) THEN 'Activado'
								WHEN ((CSubEst='pendiente' AND ASubEst='') OR (CSubEst='Aprobado - Pendiente ABD' AND ASubEst='') OR TramiteActivacion='Pendiente' OR ASubEst='Pendiente') THEN 'Pdte. Novedad'
								WHEN ((TramiteMesa='solucionado' AND CSubEst='Aprobado' AND TramiteActivacion='tramite') OR (TramiteMesa='solucionado' AND CSubEst='Aprobado -  Aprobado ABD' AND TramiteActivacion='tramite') OR (TramiteMesa='solucionado' AND TramiteCredito='tramite')) THEN  'Pdte. Tramite'
								WHEN ASubEst='Activo - pdte. líneas' THEN 'Activado Parcial'
								WHEN TramiteActivacion='reasignado' THEN 'Pdte. Novedad'
						ELSE 'Inconcluso' END AS estadoNegocio
			  FROM   Nab_EB_VW_ComercialConsulta_Negocio
			  WHERE		IDEB = @id_eb
						AND codAgente = @cod_agente;
		END

		ELSE
		BEGIN
			  SELECT @userNabis AS userIngreso
					, *
					,	CASE	WHEN (TramiteMesa='Devolucion Cliente' OR CSubEst='Devolución' OR (TramiteActivacion<>'reasignado' AND ASubEst='devolucion')) THEN 'Devolución'
								WHEN CSubEst='Rechazado' THEN 'Rechazada'
								WHEN CSubEst='Fraude' THEN 'Fraude'
								WHEN (ASubEst='Activo' OR (ASubEst='Aprobado' AND ACausal='Activado') OR (ASubEst='Aprobado' AND ActiLinPen=0)) THEN 'Activado'
								WHEN ((CSubEst='pendiente' AND ASubEst='') OR (CSubEst='Aprobado - Pendiente ABD' AND ASubEst='') OR TramiteActivacion='Pendiente' OR ASubEst='Pendiente') THEN 'Pdte. Novedad'
								WHEN ((TramiteMesa='solucionado' AND CSubEst='Aprobado' AND TramiteActivacion='tramite') OR (TramiteMesa='solucionado' AND CSubEst='Aprobado -  Aprobado ABD' AND TramiteActivacion='tramite') OR (TramiteMesa='solucionado' AND TramiteCredito='tramite')) THEN  'Pdte. Tramite'
								WHEN ASubEst='Activo - pdte. líneas' THEN 'Activado Parcial'
								WHEN TramiteActivacion='reasignado' THEN 'Pdte. Novedad'
						ELSE 'Pdte Gestión' END AS estadoNegocio
			  FROM   Nab_EB_VW_ComercialConsulta_Negocio
			  WHERE		IDEB = @id_eb;
		END
	END
END
