IF OBJECT_ID (N'dbo.Nab_Global_Parametros_Sistema') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Global_Parametros_Sistema
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-02
-- Descripción        : Consulta los parametros del sistema.
--
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Global_Parametros_Sistema 
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Global_Parametros_Sistema]

AS
BEGIN
	SET NOCOUNT ON;
	-- Obtener el valor asociado a los parametros del sistema.
	SELECT ID_CONFIGURACION, NOMBRE, ALIAS, VALOR, DESCRIPCION
	FROM NAB_GLOBAL_P_CONFIGURACION_SISTEMA
END
