IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_Condiciones_Uniformes_Info_Adicional') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_Condiciones_Uniformes_Info_Adicional
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-13
-- Descripción        : Obtener la informacion asociado a la informacion de adicional de un 
--						negocio de condiciones uniformes.
--						de un negocio.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO      - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_Condiciones_Uniformes_Info_Adicional ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_Condiciones_Uniformes_Info_Adicional]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	SELECT *
	FROM [NAB_VENTAS_CONDICIONES_UNIFORMES_ADICIONAL]
	WHERE COD_NEGOCIO = @ID_CODIGO_NEGOCIO
END			