USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Consulta]    Script Date: 08/23/2016 09:05:52 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO




ALTER PROCEDURE [dbo].[Nab_Usuario_Consulta](
@nh varchar(50) = null,
@user varchar(50) = null,
@nom varchar(150) = null,
@reg varchar(2) =null,
@area varchar(2) = null)
AS
BEGIN
	IF @nh IS NULL OR @nh =''
	BEGIN
		SET @nh = '%' 
	END
	ELSE
	BEGIN
		SET @nh = '%' +@nh+'%'
	END
	
	IF @user IS NULL OR @user =''
	BEGIN
		SET @user = '%'
	END
	ELSE
	BEGIN
		SET @user = '%' +@user+'%'
	END
	
	IF @nom IS NULL OR @nom =''
	BEGIN
		SET @nom = '%'
	END
	ELSE
	BEGIN
		SET @nom  = '%' +@nom +'%'
	END
	
	IF @reg IS NULL OR @reg =''
	BEGIN
		SET @reg = '%'
	END
	ELSE
	BEGIN
		SET @reg = '%' +@reg+'%'
	END
	
	IF @area IS NULL OR @area =''
	BEGIN
		SET @area= '%'
	END
	ELSE
	BEGIN
		SET @area = '%' +@area+'%'
	END
	
	SELECT A.USR_ID,A.USR_LOGIN,A.USR_NOMBRE,A.USR_MAIL,B.REGIONAL,C.AREA,D.GRUPO,E.PROCESO,A.USR_CELULAR,F.TIPO,G.ESTADO
	FROM USERS AS A
		INNER JOIN USERS_REGIONALES AS B ON B.ID_REGIONAL = A.ID_REGIONAL
		INNER JOIN USERS_AREAS AS C ON C.ID_AREA = A.ID_AREA
		INNER JOIN USERS_GRUPOS AS D ON D.ID_GRUPO = A.ID_GRUPO
		INNER JOIN USERS_PROCESOS AS E ON E.ID_PROCESO = A.ID_PROCESO
		INNER JOIN USERS_TIPOS AS F ON F.ID_TIPO = A.ID_TIPO
		INNER JOIN USERS_ESTADOS AS G ON G.ID_ESTADO = A.ID_ESTADO
	WHERE (A.USR_ID LIKE @nh)  
		AND (A.USR_LOGIN LIKE @user ) 
		AND (A.USR_NOMBRE LIKE @nom) 
		AND (A.ID_REGIONAL LIKE @reg) 
		AND (A.ID_AREA LIKE @area)
END






