IF OBJECT_ID (N'dbo.SP_AsignarCredito') IS NOT NULL
   DROP PROCEDURE dbo.SP_AsignarCredito
GO
-- =============================================
-- Author:			<Oscar Torres Prieto CCC>
-- ALTER  date:		<2009-03-10>
-- Description:		<Update Mesa>
-- =============================================
CREATE PROCEDURE [dbo].[SP_AsignarCredito] 
	 @MesaTipId        VARCHAR(10)
	,@MesaId           VARCHAR(20)
	,@MesaEmpresa      VARCHAR(150)
	,@MesaFechaReci    VARCHAR(30)
	,@MesaLineas       INT
	,@MesaCodAsesor    INT
	,@nombre_vendedor  VARCHAR(150)
	,@acod_agente      INT
	,@MesaCanal        VARCHAR(100)
	,@MesaGrupo        VARCHAR(100)
	,@MesaTipSoli      VARCHAR(100)
	,@MesaCliente      VARCHAR(15)
	,@MesaRegional     VARCHAR(20)
	,@MesaObservacion  VARCHAR(250)
	,@MesaBypass       VARCHAR(30)
	,@usr_id           INT
	,@Asignar          INT
	,@RutaOtroSi       VARCHAR(10)
	,@RutaOtroSiOb     VARCHAR(30)
	,@RutaAnexo        VARCHAR(10)
	,@RutaAnexoOb      VARCHAR(30)
	,@RutaSolicitud    VARCHAR(10)
	,@RutaSolicitudO   VARCHAR(30)
	,@RutaCedRep       VARCHAR(10)
	,@RutaCedRepOb     VARCHAR(30)
	,@RutaCaComercio   VARCHAR(10)
	,@RutaCaComercioOb VARCHAR(30)
	,@bfmvisita        VARCHAR(10)
	,@bfmvisitaobs     VARCHAR(30)
	,@bfminscr         VARCHAR(10)
	,@bfminscriobs     VARCHAR(30)
	,@bseriales        VARCHAR(50)
	,@bserialesobs     VARCHAR(150)
	,@bscan            VARCHAR(10)
	,@bscanobs         VARCHAR(30)
	,@bftpdti          VARCHAR(10)
	,@bftpdtiobs       VARCHAR(30)
	,@bautorizacon     VARCHAR(10)
	,@bautorizaconobs  VARCHAR(30)	
	,@cupocero         VARCHAR(10)
	,@cuporefe         INT
	,@MesaOfeAnt       VARCHAR(20)
	,@MesaCamPlan      VARCHAR(50)
	,@MesaLinCamPlan   INT
	,@MesaVenFirme     VARCHAR(50)
	,@MesaVenSolici    INT
	,@convenio		   VARCHAR(80)
	,@categoria		   VARCHAR(20)
	,@clasecliente     VARCHAR(40)
	,@pdti			   INT
	,@offideliza       VARCHAR(20)
	,@portable		   VARCHAR(2)
	,@operador		   VARCHAR(15)
	,@fec_ventana		VARCHAR(20)
	,@distrito			VARCHAR(30)
	,@barrio			VARCHAR(30)
	,@tipcalle			VARCHAR(30)
	,@calle				VARCHAR(30)
	,@obsdireccion		VARCHAR(60)
	,@cod_dane			VARCHAR(30)
	,@IdMesaContrato    BIGINT
	,@NomRepLegal		VARCHAR(30)
	,@Ap1RepLegal		VARCHAR(30)
	,@Ap2RepLegal		VARCHAR(30)
	,@CCRepLegal		BIGINT
	
AS
  BEGIN
      DECLARE @variable      INT
              ,@regional     INT
              ,@Menor        INT
              ,@MesaConsPref VARCHAR(20)
              ,@mes          INT
              ,@maximo       INT
              ,@mesmaximo    INT
              ,@mesactual    INT
              ,@Añoactual    INT
              ,@telecom      INT
              ,@radicador    VARCHAR(30)

      SELECT @regional = id_regional
      FROM   bc_regional
      WHERE  regional = @MesaRegional

      SELECT @variable = usr_id
      FROM   bc_activacion

	  --Normaliza barrio para ingresos desde NABIS
		IF @usr_id = 1961
		BEGIN
				SELECT @barrio = COD_BARRIO
				FROM BC_RobSCL_Barrios
				WHERE COD_CIUDAD = @distrito;
		END

      ------Seleccion del Usuario para asignar el negocio

      CREATE TABLE #temporaltop1
        (
           valor INT
        )
        
         ----Selección de Usuarios para Productos de Op. Movil No Portabilidad          
      IF @categoria <> 'Fija' AND @portable = 'No' --AND @Movil <> null
		BEGIN
			INSERT INTO #temporaltop1
                      (valor)
			SELECT TOP 1 usr_id
			FROM (
					  SELECT USR.usr_id,
							 CASE WHEN A.carpetas IS NULL THEN 0 ELSE A.carpetas END 'Carpetas'
					  FROM   (	SELECT usr.usr_id
								FROM bc_usuariospassw usr
								JOIN Bc_UsuariosGrupos ugr ON (ugr.usr_id=usr.usr_id)
								JOIN Bc_Grupo grp ON (grp.id=ugr.id_grupo)
								WHERE opcion = @MesaGrupo 
									AND usr.usr_bc_mesa = 2
									AND usr.usr_estado = 1
									AND usr.usr_perfil = 8
									AND usr.usr_movil = 1) USR
					  LEFT OUTER JOIN (SELECT mes.usr_credito, COUNT(mes.mesaconspref) AS 'carpetas' 
								FROM bc_mesacontrol mes 
								WHERE CONVERT(VARCHAR(20), mes.mesafechasis,103) = CONVERT(VARCHAR(20), Getdate(), 103)
								GROUP BY mes.usr_credito) A 
					  ON (A.usr_credito = USR.usr_id)
			) Z
			ORDER BY Carpetas
		END


	----Selección de Usuarios para Productos de Op. Movil Portabilidad
	
      IF @categoria <> 'Fija' AND @portable = 'Si' --AND @portabilidad <> null
        BEGIN
			INSERT INTO #temporaltop1
                      (valor)
			SELECT TOP 1 usr_id
			FROM (
					  SELECT USR.usr_id,
							 CASE WHEN A.carpetas IS NULL THEN 0 ELSE A.carpetas END 'Carpetas'
					  FROM   (	SELECT usr.usr_id
								FROM bc_usuariospassw usr
								JOIN Bc_UsuariosGrupos ugr ON (ugr.usr_id=usr.usr_id)
								JOIN Bc_Grupo grp ON (grp.id=ugr.id_grupo)
								WHERE 	opcion = @MesaGrupo 
									AND usr.usr_bc_mesa = 2
									AND usr.usr_estado = 1
									AND usr.usr_perfil = 8
									AND usr.usr_portabilidad = 1) USR
					  LEFT OUTER JOIN (SELECT mes.usr_credito, COUNT(mes.mesaconspref) AS 'carpetas' 
								FROM bc_mesacontrol mes 
								WHERE CONVERT(VARCHAR(20), mes.mesafechasis,103) = CONVERT(VARCHAR(20), Getdate(), 103)
								GROUP BY mes.usr_credito) A 
					  ON (A.usr_credito = USR.usr_id)
			) Z
			ORDER BY Carpetas
        END 

     ----Selección de Usuarios para Productos de Op. Fija
      IF @categoria = 'Fija' --AND @fija <> null
        BEGIN
			INSERT INTO #temporaltop1
                      (valor)
			SELECT TOP 1 usr_id
			FROM (
					  SELECT USR.usr_id,
							 CASE WHEN A.carpetas IS NULL THEN 0 ELSE A.carpetas END 'Carpetas'
					  FROM   (	SELECT usr.usr_id
								FROM bc_usuariospassw usr
								JOIN Bc_UsuariosGrupos ugr ON (ugr.usr_id=usr.usr_id)
								JOIN Bc_Grupo grp ON (grp.id=ugr.id_grupo)
								WHERE 	opcion = @MesaGrupo 
									AND usr.usr_bc_mesa = 2
									AND usr.usr_estado = 1
									AND usr.usr_perfil = 8
									AND usr.usr_fija = 1) USR
					  LEFT OUTER JOIN (SELECT mes.usr_credito, COUNT(mes.mesaconspref) AS 'carpetas' 
								FROM bc_mesacontrol mes 
								WHERE CONVERT(VARCHAR(20), mes.mesafechasis,103) = CONVERT(VARCHAR(20), Getdate(), 103)
								GROUP BY mes.usr_credito) A 
					  ON (A.usr_credito = USR.usr_id)
			) Z
			ORDER BY Carpetas
        END
          

      ---------------------------------------------------------------------------------------------
      --Insertamos en la tabla  BC_MesaControl
      SELECT @radicador = case when @usr_id = 1961 then 'NABIS_MESA' else '' end
      
      --SELECT @mesmaximo = mes
      --FROM   bc_mesacontrol
      --WHERE  mesacons = @maximo

      SELECT @mesactual = CAST(MONTH(Getdate()) AS VARCHAR)

      SELECT @Añoactual = CAST(YEAR(Getdate()) AS VARCHAR)

      SELECT @maximo = MAX(mesacons)
      FROM   bc_mesacontrol
      GROUP  BY mes,año
      HAVING mes = MONTH(Getdate())
         AND año = YEAR(Getdate())
    
    --PRINT 'RADICADO MAXIMO->' + CAST(@maximo AS VARCHAR);
      
    IF (@maximo IS NOT NULL)
	BEGIN
		SET @maximo = @maximo + 1
	END
      ELSE
        BEGIN
            SET @maximo = 1
        END

      SELECT @MesaConsPref = (regional_pre + CAST(MONTH(Getdate()) AS VARCHAR) + CAST(YEAR(Getdate()) AS VARCHAR) + '-' + CAST(@maximo AS VARCHAR) )
      FROM   bc_regional_bd
      WHERE  regional_bd = @MesaRegional

      IF ( @Asignar = 1 )
        BEGIN
            SELECT @Menor = valor
            FROM   #temporaltop1
        END
      ELSE
        BEGIN
            SET @Menor = '0'
        END
	
	IF (@fec_ventana < GETDATE())
		BEGIN
			SET @fec_ventana = NULL
		END
	
	BEGIN
		  INSERT INTO bc_mesacontrol
					  (mesacons
					   ,mes
					   ,año
					   ,mesaconspref
					   ,mesatipid
					   ,mesaid
					   ,mesaempresa
					   ,mesafechareci
					   ,mesafechasis
					   ,mesalineas
					   ,mesacodasesor
					   ,mesanomasesor
					   ,mesacodagente
					   ,mesacanal
					   ,mesagrupo
					   ,mesatipsoli
					   ,mesacliente
					   ,mesacupocero
					   ,mesacuporef
					   ,mesavenfirme
					   ,mesavensolici
					   ,mesaofeant
					   ,mesacamplan
					   ,mesalincamplan
					   ,mesaregional
					   ,mesaobservacion
					   ,mesabypass
					   ,usr_inicial
					   ,usr_credito
					   ,creditoestado
					   ,mesaconvenio
					   ,categoria
					   ,FijaClaseCliente
					   ,FijaPdti
					   ,FijaOffideliza
					   ,portable
					   ,operador
					   ,fec_ventana
					   ,mesadistrito
					   ,mesabarrio
					   ,mesatipcalle
					   ,mesacalle
					   ,mesaobsdireccion
					   ,cod_dane
					   ,idmesacontrato
					   ,mesanomreplegal
					   ,mesaap1replegal
					   ,mesaap2replegal
					   ,mesaccreplegal)
		  VALUES      ( @maximo
						,@mesactual
						,@Añoactual
						,@MesaConsPref
						,UPPER(@MesaTipId)
						,replace (@MesaId, ' ','')
						,@MesaEmpresa
						,CAST(@MesaFechaReci AS DATETIME)
						,Getdate()
						,@MesaLineas
						,@MesaCodAsesor
						,@nombre_vendedor
						,@acod_agente
						,@MesaCanal
						,@MesaGrupo
						,@MesaTipSoli
						,@MesaCliente
						,@cupocero
						,@cuporefe
						,@MesaVenFirme
						,@MesaVenSolici
						,@MesaOfeAnt
						,@MesaCamPlan
						,@MesaLinCamPlan
						,@MesaRegional
						,@MesaObservacion
						,@MesaBypass
						,@usr_id
						,case when @radicador = 'NABIS_MESA' THEN null ELSE @Menor END
						,case when @radicador = 'NABIS_MESA' THEN null ELSE 0 END
						,@convenio
						,@categoria
						,@clasecliente
						,@pdti
						,@offideliza
						,@portable
						,case when @portable = 'Si' then @operador else '' end
						,case when @portable = 'Si' then cast(@fec_ventana as datetime) else null end
						,@distrito
						,@barrio
						,@tipcalle
						,@calle
						,@obsdireccion
						,@cod_dane
						,@IdMesaContrato
						,@NomRepLegal
						,@Ap1RepLegal
						,@Ap2RepLegal
						,@CCRepLegal)
				
		  INSERT INTO bc_hojarutamesa
					  (mesaconspref
					   ,rutaotrosi
					   ,rutaotrosiob
					   ,rutaanexo
					   ,rutaanexoob
					   ,rutasolicitud
					   ,rutasolicitudob
					   ,rutacedrep
					   ,rutacedrepob
					   ,rutacacomercio
					   ,rutacacomercioob
					   ,rutafmvisita
					   ,rutafmvisitaobs
					   ,rutafmincri
					   ,rutafmincriobs
					   ,rutaseriales
					   ,rutaserialesobs
					   ,rutascan
					   ,rutascanobs
					   ,rutaftpdti
					   ,rutaftpdtiobs
					   ,rutaAutoriza
					   ,rutaAutorizaObs)
		  VALUES      ( @MesaConsPref
					   ,@RutaOtroSi
					   ,@RutaOtroSiOb
					   ,@RutaAnexo
					   ,@RutaAnexoOb
					   ,@RutaSolicitud
					   ,@RutaSolicitudO
					   ,@RutaCedRep
					   ,@RutaCedRepOb
					   ,@RutaCaComercio
					   ,@RutaCaComercioOb
					   ,@bfmvisita
					   ,@bfmvisitaobs
					   ,@bfminscr
					   ,@bfminscriobs
					   ,@bseriales
					   ,@bserialesobs
					   ,@bscan
					   ,@bscanobs
					   ,@bftpdti
					   ,@bftpdtiobs
					   ,@bautorizacon
					   ,@bautorizaconobs)

		  SELECT @MesaConsPref AS consecutivo
		END
      IF @Menor = 0
        BEGIN
            UPDATE bc_mesacontrol
            SET    mesaesatdo = 4
                   ,creditoestado = 1
            WHERE  ( mesaconspref = @MesaConsPref )
        END
  END

--[SP_AsignarCredito] 'NIT'	, '1234567-1'	, 'nabis'	, '2016-09-30'	, '2'	, '207017'	, 'JEFFREY CORTES'	, '1'	, 'DIRECTO'	, 'AGENTES'	, 'Ventas'	, 'NUEVO'	, 'Bogota'	, ''	,0	, '1961'	, '1'	, 'Si'	, 'Registro ingresado desde NABIS. Usuario'	, 'Si'	, ''	, 'Si'	, ''	, 'Si'	, ''	, 'Si'	, ''	, ''	, ''	, ''	, ''	, 'No'	, ''	, 'Si'	, 'Registro ingresado desde NABIS. Usuario'	, ''	, ''	, ''	, ''	, ''	, '0'	, 'No'	, 'Seleccione'	, '2'	, ''	, '0'	, 'NO APLICA'	, 'Movil'	, ''	, '0'	, ''	, 'No'	, ''	, ''	, '2'	, '2'	, 'AA'	, 'cll 114'	, 'MORATO'	, ''	, '15'	, 'JEFF'	, 'POL'	, 'LOP'	, '1234657'