IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_updateEstado') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_updateEstado
GO
-- =============================================
-- Author:		<Jeffrey Cortés>
-- Create date: <2015-02-10>
-- Description:	<Normaliza estado de negocio ingresado desde NABIS>
-- =============================================
CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_updateEstado]
(
	@user varchar(20)
	,@id_eb	varchar(20)
	,@id_estado int
)
AS
BEGIN
	
	DECLARE @fecha datetime;
	DECLARE @Id_Canal numeric(18), @id_tipo_contrato numeric(18), @Portabilidad CHAR(1);

	SET @fecha = GETDATE();

	IF @id_estado = 0
	BEGIN
		UPDATE NAB_EB_NEGOCIOS
		SET FEC_CIERRE_PEDIDO = @fecha
			, USER_CIERRE_PEDIDO = @user
			, FEC_ULT_MOD = @fecha
			, USER_ULT_MOD = @user
			, ID_ESTADO = CASE PEND_LINEAS WHEN 0 THEN 2 ELSE 1 END
		WHERE ID_EB = @id_eb;
	END

	ELSE IF @id_estado = 1
	BEGIN
		UPDATE NAB_EB_NEGOCIOS
		SET PEND_LINEAS = 0
			, FEC_CIERRE_ESTR_VENTA = @fecha
			, USER_CIERRE_ESTR_VENTA = @user
			, FEC_ULT_MOD = @fecha
			, USER_ULT_MOD = @user
			, ID_ESTADO = 2
		WHERE ID_EB = @id_eb;
	END

	ELSE IF @id_estado = 2
	BEGIN

		UPDATE CCC.DBO.BC_ACTIVACIONROBOT
		SET REPROCESO = 0
		WHERE MESACONSPREF = @id_eb;

		UPDATE NAB_EB_NEGOCIOS
		SET ESTRUCTURA_VENTA = dbo.Nab_dateFormat(@fecha, 103) + ': Cierra Paquetes'
			, FEC_ULT_MOD = @fecha
			, USER_ULT_MOD = @user
			, ID_ESTADO = 3
		WHERE ID_EB = @id_eb;
	END

	ELSE IF @id_estado = 3
	BEGIN
		UPDATE NAB_EB_NEGOCIOS
		SET FEC_CIERRE_DCTOS = @fecha
			, USER_CIERRE_DCTOS = @user
			, FEC_ULT_MOD = @fecha
			, USER_ULT_MOD = @user
			, FEC_CIERRE = @fecha
			, USER_CIERRE = @user
			, ID_ESTADO = 4
		WHERE ID_EB = @id_eb;

		--Asignación a crédito en NABIS
		SELECT @Id_Canal = ID_GRUPO, @ID_TIPO_CONTRATO = ID_TIPO_CONTRATO, @Portabilidad = PORTADO
		FROM NAB_EB_NEGOCIOS
		WHERE ID_EB = @id_eb;
		
		Exec Nab_Credito_Balanceador_Asignacion @id_eb, @Id_Canal, @id_tipo_contrato, @Portabilidad;
	END
	ELSE IF @id_estado = 4
	BEGIN
		--Asignación a crédito en NABIS
		SELECT @Id_Canal = ID_GRUPO, @ID_TIPO_CONTRATO = ID_TIPO_CONTRATO, @Portabilidad = PORTADO
		FROM NAB_EB_NEGOCIOS
		WHERE ID_EB = @id_eb;
		
		Exec Nab_Credito_Balanceador_Asignacion @id_eb, @Id_Canal, @id_tipo_contrato, @Portabilidad;
	END
END




