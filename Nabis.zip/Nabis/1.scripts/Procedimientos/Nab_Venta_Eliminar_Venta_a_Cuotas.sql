IF OBJECT_ID (N'dbo.Nab_Venta_Eliminar_Venta_a_Cuotas') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Eliminar_Venta_a_Cuotas
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-10-05
-- Descripción        : Eliminar la informacion asociado al contrato venta a cuotas.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO Codigo del negocio al cual se le asocia los contratos venta a cuotas.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Eliminar_Venta_a_Cuotas ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Eliminar_Venta_a_Cuotas]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	DELETE NAB_VENTAS_VENTA_A_CUOTAS
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO

END			