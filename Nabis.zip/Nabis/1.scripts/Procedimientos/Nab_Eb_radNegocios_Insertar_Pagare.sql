USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_radNegocios_Insertar_Portabilidad]    Script Date: 09/15/2016 11:25:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Eder Camilo Ramirez>
-- Create date: <2016-09-15>
-- Description:	<Inserta registros en Portabilidad>
-- =============================================
ALTER PROCEDURE [dbo].[Nab_Eb_radNegocios_Insertar_Portabilidad]

	@Cod_negocio	varchar(50),
	@Nit_cliente	varchar(15),             
	@RazonSocial varchar(100),             
	@Fecha_solicitud	datetime,        
	@Fecha_ventana	datetime,        
	@Identificacion_RL	int,
	@Nombre_RL varchar(100),             
	@Tipo_RL varchar(15)
	
AS
BEGIN

	SET NOCOUNT ON;	
	BEGIN TRAN TADD
	BEGIN TRY
		DECLARE @msg varchar(1000)
		set @msg =''
		
		IF EXISTS
		(
			SELECT *
			FROM NAB_VENTAS_PORTABILIDAD 
			WHERE COD_NEGOCIO=CONVERT(VARCHAR(50),@Cod_negocio)
		)
		BEGIN
			UPDATE NAB_VENTAS_PORTABILIDAD 
					SET Cod_negocio=@Cod_negocio,           
					NitCliente=@Nit_cliente,
					RazonSocial=@RazonSocial,
					Fecha_solicitud=@Fecha_solicitud,
					Fecha_ventana=@Fecha_ventana,
					Iden_RL=@Identificacion_RL,
					Nombre_RL=@Nombre_RL,
					Tipo_ident=@Tipo_RL
					WHERE COD_NEGOCIO=CONVERT(VARCHAR(50),@Cod_negocio)
					
					set @msg ='REGISTRO ACTUALIZADO' 
					SELECT @msg AS MENSAJE
				
		END
		
		ELSE
			BEGIN
				INSERT INTO  NAB_VENTAS_PORTABILIDAD VALUES
				(
					@Cod_negocio,           
					@Nit_cliente,
					@RazonSocial,
					@Fecha_solicitud,
					@Fecha_ventana,
					@Identificacion_RL,
					@Nombre_RL,
					@Tipo_RL
				)
				set @msg ='REGISTRO INSERTADO' 
				SELECT @msg AS MENSAJE
			END
		
	COMMIT TRAN TADD
	
	END TRY
	BEGIN CATCH
		SET @msg = 'Ocurrri� un error: ' + ERROR_MESSAGE() + ' En la l�nea ' + CONVERT(VARCHAR(255), ERROR_LINE() ) + '.'
		--select @msg AS ERROR
		ROLLBACK TRAN TADD
	END CATCH
END

/*

EXEC Nab_Eb_radNegocios_Insertar_Portabilidad
'BOG92016-3',
'5467488-3',
'COLTEJER S.A.',
'20160303',
'20160303',
44678849,
'JAIRO CASTILLO',
'CC'

SELECT * FROM NAB_VENTAS_PORTABILIDAD

*/