IF OBJECT_ID (N'dbo.Nab_Configuracion_Obtener_Cadena_Conexion_Exchange') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Configuracion_Obtener_Cadena_Conexion_Exchange
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-13
-- Descripción        : Obtener cadena de conexion para el envio de correos por exchange
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Configuracion_Obtener_Cadena_Conexion_Exchange ''
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Configuracion_Obtener_Cadena_Conexion_Exchange]

AS
BEGIN
	-- Constantes.
	DECLARE @EXCHANGE_MAIL_REMITENTE_ALIAS VARCHAR(50);
	SET @EXCHANGE_MAIL_REMITENTE_ALIAS = 'Exchange_Mail_Remitente';
	DECLARE @EXCHANGE_MAIL_USUARIO_ALIAS VARCHAR(50);
	SET @EXCHANGE_MAIL_USUARIO_ALIAS = 'Exchange_Mail_Usuario';
	DECLARE @EXCHANGE_MAIL_SERVER_EXCHANGE_ALIAS VARCHAR(50)
	SET @EXCHANGE_MAIL_SERVER_EXCHANGE_ALIAS = 'Exchange_Mail_ServerExchange';
	DECLARE @EXCHANGE_MAIL_PUERTO_ALIAS VARCHAR(50);
	SET @EXCHANGE_MAIL_PUERTO_ALIAS = 'Exchange_Mail_Puerto';
	DECLARE @EXCHANGE_MAIL_DOMINIO_ALIAS VARCHAR(50)
	SET @EXCHANGE_MAIL_DOMINIO_ALIAS = 'Exchange_Mail_Dominio'
	DECLARE @EXCHANGE_MAIL_CONTRASENIA_ALIAS VARCHAR(50);
	SET @EXCHANGE_MAIL_CONTRASENIA_ALIAS = 'Exchange_Mail_Contrasenia';

	-- Variables.
	DECLARE @exchangeMailRemitente VARCHAR(50), @exchangeMailUsuario VARCHAR(50), @exchangeMailServerExchange VARCHAR(50), 
			@exchangeMailPuerto VARCHAR(50), @exchangeMailDominio VARCHAR(50), @exchangeMailContrasenia VARCHAR(50);
	
	SET @exchangeMailRemitente  = (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_REMITENTE_ALIAS)
	SET @exchangeMailUsuario =  (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_USUARIO_ALIAS)
	SET @exchangeMailServerExchange = (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_SERVER_EXCHANGE_ALIAS)
	SET @exchangeMailPuerto = (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_PUERTO_ALIAS)
	SET @exchangeMailDominio = (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_DOMINIO_ALIAS)
	SET @exchangeMailContrasenia = (SELECT Valor FROM [NAB_GLOBAL_P_CONFIGURACION_SISTEMA] WHERE ALIAS = @EXCHANGE_MAIL_CONTRASENIA_ALIAS)
	
	-- Cadena de conexion para el envio de correos por servidor exchange.
	SELECT 'SmtpHost=' + @exchangeMailServerExchange + ';SmtpPort=' + @exchangeMailPuerto + ';FromDirection=' + @exchangeMailRemitente +
	       ';Domain=' + @exchangeMailDominio + ';AccountName=' + @exchangeMailUsuario + ';AccountPassword=' + @exchangeMailContrasenia  AS CadenaConexion
	       
	
END			
