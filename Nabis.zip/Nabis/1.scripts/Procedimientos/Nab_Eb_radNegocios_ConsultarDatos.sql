USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_radNegocios_ConsultarDatos]    Script Date: 09/12/2016 09:00:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Eder Camilo Ramirez>
-- Create date: <2016-09-06>
-- Description:	<Consulta datos>
-- =============================================
ALTER PROCEDURE [dbo].[Nab_Eb_radNegocios_ConsultarDatos]

	@Cod_Departamento varchar(50),       
	@Cod_Distrito varchar(50)      
	
	
AS
BEGIN

	SET NOCOUNT ON;	
	BEGIN TRAN TADD
	BEGIN TRY
		
				SELECT(SELECT DES_PROVINCIA  AS DEPARTAMENTO
				  FROM CCC.DBO.BC_ROBSCL_PROVINCIAS  
				  WHERE COD_PROVINCIA= @Cod_Departamento
				  ) AS DEPARTAMENTO, 
				 (SELECT CIUDAD  
				  FROM NAB_GLOBAL_P_CIUDADES  
				  WHERE CODIGO_CIUDAD = @Cod_Distrito
				  )AS CIUDAD
				  
			
	COMMIT TRAN TADD
	
	END TRY
	BEGIN CATCH
		ROLLBACK TRAN TADD
	END CATCH
END

/*
declare @msg as varchar(500)
EXEC Nab_Eb_radNegocios_ConsultarDatos 9,366
EXEC Nab_Eb_radNegocios_ConsultarDatos 'distritos',494
*/