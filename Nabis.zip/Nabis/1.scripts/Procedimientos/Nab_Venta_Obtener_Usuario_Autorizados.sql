IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_Usuario_Autorizados') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_Usuario_Autorizados
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-09
-- Descripción        : Obtener la informacion asociado a los usuarios autorizados de un negocio.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO      - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_Usuario_Autorizados ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_Usuario_Autorizados]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	SELECT *
	FROM NAB_VENTAS_USUARIO_AUTORIZADO_PERFIL
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO

END			