IF OBJECT_ID (N'dbo.Nab_Venta_Obtener_Condiciones_Uniformes_Info_Direccion') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Venta_Obtener_Condiciones_Uniformes_Info_Direccion
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-13
-- Descripción        : Obtener la informacion asociado a la informacion de direccion de facturacion de un 
--						negocio de condiciones uniformes.
--
-- Parámetros	      :	
--						@ID_CODIGO_NEGOCIO      - Codigo del negocio al cual se le asocia el plan adquirido.
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Venta_Obtener_Condiciones_Uniformes_Info_Direccion ''
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Venta_Obtener_Condiciones_Uniformes_Info_Direccion]
(
    @ID_CODIGO_NEGOCIO VARCHAR(50)
)
AS
BEGIN
	-- Eliminar la informacion asociada a un negocio.
	SELECT *
	FROM [NAB_VENTAS_CONDICIONES_UNIFORMES_DIRECCION_FACTURACION]
	WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO

END			