IF OBJECT_ID (N'dbo.Nab_Ventas_Venta_a_Cuotas_Info') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Ventas_Venta_a_Cuotas_Info
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres.
-- Fecha Creacion	  : 2016-09-09
-- Descripción        : Inserta la informacion asociado al plan adquirido de un negocio.
--
-- Parámetros	      :	
--						@CONTACTO_1_NOMBRE 			  	VARCHAR(150),
--					    @CONTACTO_1_MOVIL 				VARCHAR(50),
--					    @CONTACTO_1_EMAIL 				VARCHAR(150)
--					    @CONTACTO_1_PERFIL_AUTORIZADO  	VARCHAR(50),
--					    @CONTACTO_1_CEDULA 				VARCHAR(50),
--					    @CONTACTO_2_NOMBRE 				VARCHAR(150),
--					    @CONTACTO_2_MOVIL				VARCHAR(50),
--					    @CONTACTO_2_EMAIL				VARCHAR(150),
--					    @CONTACTO_2_PERFIL_AUTORIZADO 	VARCHAR(50),
--					    @CONTACTO_2_CEDULA 				VARCHAR(50),
--					    @CONTACTO_3_NOMBRE				VARCHAR(150)
--					    @CONTACTO_3_MOVIL 				VARCHAR(50),
--					    @CONTACTO_3_EMAIL 				VARCHAR(150),
--					    @CONTACTO_3_PERFIL_AUTORIZADO 	VARCHAR(50),
--					    @CONTACTO_3_CEDULA				VARCHAR(50),
--					    @CONTACTO_4_NOMBRE				VARCHAR(150),
--					    @CONTACTO_4_MOVIL 				VARCHAR(50),
--					    @CONTACTO_4_EMAIL 				VARCHAR(150)
--					    @CONTACTO_4_PERFIL_AUTORIZADO  	VARCHAR(50),
--					    @CONTACTO_4_CEDULA 				VARCHAR(50),
--					    @ID_CODIGO_NEGOCIO 				VARCHAR(50)
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
-- 
-- DEBUG			  : EXEC Nab_Ventas_Venta_a_Cuotas_Info 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
-- ========================================================================================
CREATE PROCEDURE [dbo].[Nab_Ventas_Usuario_Autorizados]
(

)
BEGIN

	-- Agregar registro de usuarios autorizados por contrato.
	IF NOT EXISTS (SELECT * FROM NAB_VENTAS_VENTA_A_CUOTAS WHERE ID_CODIGO_NEGOCIO = @ID_CODIGO_NEGOCIO)
	BEGIN
	   INSERT INTO [NABIS].[dbo].[NAB_VENTAS_VENTA_A_CUOTAS]
	   (
		   [ID_VENTA_CUOTAS],[FECHA_DE_CELEBRACION_DEL_CONTRATO],[NOMBRE_COMPRADOR],[IDENTIFICACION_COMPRADOR],[CORREO_ELECTRONICO_COMPRADOR],
		   [TELEFONO_COMPRADOR],[VALOR_TOTAL_EQUIPO],[CUOTA_INICIAL],[NUMERO_CUOTAS],[CUOTA_MENSUAL],[VALOR_TOTAL],
		   [ID_CODIGO_NEGOCIO]
	   )
	   VALUES
	   (
			@ID_VENTA_CUOTAS, int,>
		   ,@FECHA_DE_CELEBRACION_DEL_CONTRATO, datetime,>
		   ,@NOMBRE_COMPRADOR, varchar(150),>
		   ,@IDENTIFICACION_COMPRADOR, varchar(150),>
		   ,@CORREO_ELECTRONICO_COMPRADOR, varchar(150),>
		   ,@TELEFONO_COMPRADOR, varchar(150),>
		   ,@VALOR_TOTAL_EQUIPO, int,>
		   ,@CUOTA_INICIAL, int,>
		   ,@NUMERO_CUOTAS, int,>
		   ,@CUOTA_MENSUAL, int,>
		   ,@VALOR_TOTAL, int,>
		   ,@ID_CODIGO_NEGOCIO, varchar(50),>)
	ELSE
	BEGIN
		UPDATE [NABIS].[dbo].[NAB_VENTAS_VENTA_A_CUOTAS]
		   SET [ID_VENTA_CUOTAS] = <ID_VENTA_CUOTAS, int,>
			  ,[FECHA_DE_CELEBRACION_DEL_CONTRATO] = <FECHA_DE_CELEBRACION_DEL_CONTRATO, datetime,>
			  ,[NOMBRE_COMPRADOR] = <NOMBRE_COMPRADOR, varchar(150),>
			  ,[IDENTIFICACION_COMPRADOR] = <IDENTIFICACION_COMPRADOR, varchar(150),>
			  ,[CORREO_ELECTRONICO_COMPRADOR] = <CORREO_ELECTRONICO_COMPRADOR, varchar(150),>
			  ,[TELEFONO_COMPRADOR] = <TELEFONO_COMPRADOR, varchar(150),>
			  ,[VALOR_TOTAL_EQUIPO] = <VALOR_TOTAL_EQUIPO, int,>
			  ,[CUOTA_INICIAL] = <CUOTA_INICIAL, int,>
			  ,[NUMERO_CUOTAS] = <NUMERO_CUOTAS, int,>
			  ,[CUOTA_MENSUAL] = <CUOTA_MENSUAL, int,>
			  ,[VALOR_TOTAL] = <VALOR_TOTAL, int,>
			  ,[ID_CODIGO_NEGOCIO] = <ID_CODIGO_NEGOCIO, varchar(50),>
		 WHERE <Search Conditions,,>
	END
