IF OBJECT_ID (N'dbo.Nab_Eb_radNegocio_Pymes') IS NOT NULL
   DROP PROCEDURE dbo.Nab_Eb_radNegocio_Pymes
GO
-- ========================================================================================
-- Autor              : Harold Caicedo.
-- Fecha Creacion	  : 2016-09-28
-- Descripción        : Radicación de negocio desde NABIS Pymes
--
-- Fecha Modificacion : 
-- Autor              : 
-- Descripción        : 
--
-- ========================================================================================

CREATE PROCEDURE [dbo].[Nab_Eb_radNegocio_Pymes]
(
	@id_eb VARCHAR(100),
    @fec_ingreso			DATETIME,
    @cod_vend				INT,
    @canal_vend				VARCHAR(50),
    @nombre_grupo			VARCHAR(100),
    @user					VARCHAR(20),
    @cant_lineas			INT,
    @portado				BIT,
    @fec_ventana			DATETIME = NULL,
    @pedido					BIT,
    @tipo_solicitud			varchar(20),
    @id_identidad			INT,
    @identidad				VARCHAR(50),
    @nomCliente				VARCHAR(250),
    @cod_distrito			INT,
    @cod_tipo_calle			VARCHAR(5),
    @direccion				VARCHAR(30),
    @complemento			VARCHAR(30),
    @RepLegalIdent			INT,
    @RepLegalNom			VARCHAR(50),
    @RepLegalAp1			VARCHAR(50),
    @RepLegalAp2			VARCHAR(50) = NULL,
    @RepLegalFijo			INT,
    @RepLegalCelular		BIGINT,
    @RepLegalFecNac			DATETIME,
    @id_grupo				INT,
    @id_tipo_contrato		INT,
    @id_tipo_cliente		INT,
    @id_tipo_servicio		INT,
    @id_tipo_solicitud		INT,
    @id_convenio			INT,
    @id_contratoMarco		BIGINT,
    @id_tipo_cambio_plan	SMALLINT = NULL,
    @esPyme 				BIT = NULL,
	@telefono_cliente	    VARCHAR(50) = NULL,
	@observaciones			VARCHAR(200) = NULL
)
AS
BEGIN
	--Nab_Eb_radNegocio 'BOG122015-11', '04/12/2015 11:39:40', '207017', 'DIRECTO', 'AGENTES', 'NH004645', 5, 'False', 'False', 'Ventas', 1, '1234567', 'cred-uno', 2, 'AA', '60', 'chapinero', '123457', 'jeff', 'cor', 'cu', '19999999', '3151234567', 7, 2, 1, 2, 4, 0, -1
	DECLARE @id_estado int, @cod_barrio int;

	SET @id_estado = CASE @pedido WHEN 1 THEN 0 ELSE 1 END;
	--SET @id_estado = CASE WHEN @tipo_solicitud != 'Ventas' THEN 4 ELSE @id_estado END;

	SELECT @cod_barrio = COD_BARRIO
	FROM CCC.DBO.BC_RobSCL_Barrios
	WHERE COD_CIUDAD = @cod_distrito;
	
	INSERT INTO NAB_EB_NEGOCIOS
	(
		  ID_EB, FEC_INGRESO, COD_VENDEDOR, CANAL_VENDEDOR, NOMBRE_GRUPO, USER_INGRESO, CANT_LINEAS, PEND_LINEAS
		, PORTADO, PEDIDO, FEC_ULT_MOD, USER_ULT_MOD, ID_ESTADO
		--CLIENTE
		, ID_IDENTIDAD, IDENTIDAD, NOMBRE_CLIENTE, COD_DISTRITO, COD_BARRIO, COD_TIPO_CALLE, DIRECCION, COMPLEMENTO
		--REP LEGAL
		, REP_LEGAL_IDENTIDAD, REP_LEGAL_NOMBRE, REP_LEGAL_APELLIDO1, REP_LEGAL_APELLIDO2, REP_LEGAL_FIJO, REP_LEGAL_CELULAR
		, REP_LEGAL_FECNACIMIENTO
		--ID DE SOLICITUD DE SERV
		, ID_GRUPO, ID_TIPO_CONTRATO, ID_TIPO_CLIENTE, ID_TIPO_SERVICIO, ID_TIPO_SOLICITUD, ID_CONVENIO, ID_CONTRATO_MARCO
		, ID_TIPO_CAMBIO_PLAN, FEC_VENTANA, ES_PYMES, TELEFONO_CLIENTE, OBSERVACIONES
	)
	VALUES
	(
		 @id_eb, @fec_ingreso, @cod_vend, @canal_vend, @nombre_grupo, @user, @cant_lineas, @cant_lineas, @portado, @pedido
		, @fec_ingreso, @user, @id_estado
		--CLIENTE
		, @id_identidad, @identidad, @nomCliente, @cod_distrito, @cod_barrio, @cod_tipo_calle, @direccion, @complemento
		--REP LEGAL
		, @RepLegalIdent, @RepLegalNom, @RepLegalAp1, @RepLegalAp2, @RepLegalFijo, @RepLegalCelular, @RepLegalFecNac
		--ID DE SOLICITUD DE SERV
		, @id_grupo, @id_tipo_contrato, @id_tipo_cliente, @id_tipo_servicio, @id_tipo_solicitud, @id_convenio
		, CASE @id_contratoMarco WHEN -1 THEN NULL ELSE @id_contratoMarco END
		, CASE @id_tipo_cambio_plan WHEN -1 THEN NULL ELSE @id_tipo_cambio_plan END
		, @fec_ventana, @esPyme, @telefono_cliente, @observaciones
	);

	IF @@TOTAL_WRITE > 0 AND @tipo_solicitud != 'Pdti'-- AND @tipo_solicitud = 'Ventas'
	BEGIN
		SET NOCOUNT ON;
		UPDATE CCC.DBO.BC_MESACONTROL
		SET MesaEsatdo = -1
			,CreditoEstado = NULL
			,usr_credito = NULL
		WHERE MESACONSPREF = @id_eb;
	END;
		
	/*ELSE
	BEGIN
		EXEC Nab_Eb_radNegocio_updateEstadoCredito @id_eb
	END*/
END

