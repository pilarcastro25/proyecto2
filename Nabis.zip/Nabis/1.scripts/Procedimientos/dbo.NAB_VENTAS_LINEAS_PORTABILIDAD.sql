USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]    Script Date: 09/23/2016 15:10:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]') AND type in (N'U'))
DROP TABLE [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]
GO

USE [NABIS]
GO

/****** Object:  Table [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD]    Script Date: 09/23/2016 15:10:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[NAB_VENTAS_LINEAS_PORTABILIDAD](
	[Id_LineasPortabilidad] [int] IDENTITY(1,1) NOT NULL,
	[NumeroMovil] [numeric](18, 0) NOT NULL,
	[ContratoActual] [int] NOT NULL,
	[ContratoNuevo] [int] NOT NULL,
	[Fecha_solicitud] [datetime] NOT NULL,
	[Fecha_ventana] [datetime] NOT NULL,
	[Nip] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_LineasPortabilidad] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

