IF OBJECT_ID (N'dbo.spDescribeTable') IS NOT NULL
   DROP PROCEDURE dbo.spDescribeTable
GO
-- ========================================================================================
-- Autor              : Harold Andres Caicedo Torres
-- Fecha Creación     : 2014-02-28
-- Descripción        : Devuelve la definición de las columnas de una tabla.
--
-- Parámetros         : @tableName     - Nombre de la tabla.
-- Parámetros         : @schemaName    - Nombre del esquema de la tabla ('dbo' por defecto).
-- ========================================================================================
CREATE PROCEDURE dbo.spDescribeTable
(
	@tableName VARCHAR(80),	
	@schemaName VARCHAR(30)	= 'dbo'
)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT COLUMN_NAME AS Columna, DATA_TYPE AS [Tipo de Dato], ISNULL(CHARACTER_MAXIMUM_LENGTH, '') AS Longitud,
	       IS_NULLABLE AS Nullable, ISNULL(COLUMN_DEFAULT, '') AS [Valor Default]
	FROM INFORMATION_SCHEMA.COLUMNS
	WHERE TABLE_NAME = @tableName
	  AND TABLE_SCHEMA = @schemaName
	ORDER BY ORDINAL_POSITION;
END
