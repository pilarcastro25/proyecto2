USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[usp_EnviarCorreo]    Script Date: 08/23/2016 16:55:04 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--usp_EnviarCorreo 'ayda.lozano@telefonica.com','ayda.lozano@telefonica.com','envio desde codigo sql' ,'enviado','HTMLBody'
 
ALTER  PROCEDURE [dbo].[usp_EnviarCorreo]
(
	@De varchar(100),
	@Para varchar(100),
	@Titulo varchar(100),
	@Mensaje varchar(4000),
	@TipoMensaje varchar(50) -- 'HTMLBody' ó 'TextBody'
)
AS
 
DECLARE @ObjMensaje int,
		@RC int,
		@Fuente varchar(255),
		@Descripcion varchar(500),
		@MsjSalida varchar(1000),
		@Servidor varchar(100),
		@Puerto varchar(10),
		@Autenticar char(1),
		@Usuario varchar(100),
		@Password varchar(100)
 
	-- Aqui ahi que cambiar los valores por los reales de la cuenta a usar
	 
	SET @Autenticar = '1' -- Manda a autentificarse con una cuenta y password
	SET @Servidor = 'outlook.latam.telefonica.corp' -- Nombre de host o IP
	SET @Usuario = 'chaskis.nh.inet' -- Nombre de usuario, en los servidores POP puede ser la direccion de correo completa
	SET @Password = 'Sofia06*' -- Password de la cuenta de correo
	SET @Puerto = '110' -- Puerto de correo, normalmente es el 25, aunque esto puede cambiar dependiendo del ISP
	 
	-- Crear el objeto CDO.Message
	EXEC @RC = sp_OACreate 'CDO.Message', @ObjMensaje OUT
	 
	-- Configurar el SMTP remoto
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/sendusing").Value','2'
	-- Set: Servidor
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/smtpserver").Value', @Servidor
	-- Set: Puerto
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/smtpserverport").Value', @Puerto
	-- Set: Autenticacion
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate").Value', @Autenticar
	-- Set: Usuario
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/sendusername").Value', @Usuario
	-- Set: Password
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/sendpassword").Value', @Password
	 
	--EXEC @RC = sp_OASetProperty  @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/sendusing").Value','2'
	 
	--EXEC @RC = sp_OASetProperty  @ObjMensaje, 'Configuration.fields("http://schemas.microsoft.com/cdo/configuration/smtpserver").Value', 'chaskis.nh.inet'
	 
	-- Guardar cambios
	EXEC @RC = sp_OAMethod @ObjMensaje, 'Configuration.Fields.Update', null
	 
	-- Parametros del correo:
	 
	-- Para:
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'To', @Para
	-- De:
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'From', @De
	-- Titulo:
	EXEC @RC = sp_OASetProperty @ObjMensaje, 'Subject', @Titulo
	-- Tipo de mensaje y mensaje:
	EXEC @RC = sp_OASetProperty @ObjMensaje, @TipoMensaje, @Mensaje
	 
	-- Enviar el correo:
	EXEC @RC = sp_OAMethod @ObjMensaje, 'Send', NULL
	 
	 
	-- Obtener el mensaje de salida, tanto por éxito como por error.
	IF ( @RC <> 0 )
	BEGIN
		EXEC @RC = sp_OAGetErrorInfo NULL, @Fuente OUT, @Descripcion OUT
	IF ( @RC = 0 )
	BEGIN
		SET @MsjSalida = 'Error enviando el mensaje, Fuente:' + @Fuente + ', Descripcion: ' + @Descripcion
	END
	ELSE
	BEGIN
		SET @MsjSalida = 'Error enviando el mensaje. Error obteniendo información de la falla'
	END
	END
	ELSE
	BEGIN
		SET @MsjSalida = 'Envío realizado'
	END
	 
	-- Limpiar el objeto
	EXEC @RC = sp_OADestroy @ObjMensaje
	 
	-- Mostrar el mensaje
	SELECT @MsjSalida