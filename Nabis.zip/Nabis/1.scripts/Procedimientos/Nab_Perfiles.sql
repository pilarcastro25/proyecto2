USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Perfiles]    Script Date: 08/22/2016 09:29:32 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO

-- =============================================
-- Author:        <Jeison Gabriel Martinez Bustos NABIS>
-- Create date: <2016-08-19>
-- Description:    <Listado  Usuario>
	-- =============================================
ALTER PROCEDURE [dbo].[Nab_Perfiles] 
	@usuario VARCHAR(50)
AS
  BEGIN
      DECLARE @perfil VARCHAR(50)

      set @perfil = (SELECT b.Perfil 
      FROM   USERS as a
      join NAB_PERFIL as b
      on a.ID_PERFIL = b.ID_PERFIL
      WHERE  a.USR_LOGIN = @usuario)
    
      
		
		
		
		IF (@perfil = NULL)
			BEGIN
			
			
			set @perfil = (SELECT b.Perfil
				FROM NAB_PERFIL as b
				WHERE b.ID_PERFIL=10)
			END
		  select @perfil
			
		
		
		 
		--SELECT @PRINTS
					
      --IF @perfil = 1
      --  BEGIN
      --      SELECT id_perfil
      --             ,perfil
      --      FROM   nab_perfil
      --  END
      --IF @perfil = 0
      --  BEGIN
      --      SELECT id_perfil
      --             ,perfil
      --      FROM   nab_perfil
      --      WHERE  id_perfil > 1 OR id_perfil = 0
      --  END
  END
