IF OBJECT_ID (N'dbo.[Nab_Eb_Obtener_Negocio]') IS NOT NULL
   DROP PROCEDURE dbo.[Nab_Eb_Obtener_Negocio]
GO
-- ========================================================================================  
-- Autor              : Gabriel Martinez.  
-- Fecha Creacion     : 2016-09-08  
-- Descripción        : Obtener negocio  
-- Parámetros    	  : @eb id del negocio  

-- Fecha Modificacion : 2016-10-31
-- Autor			  : Harold Caicedo
-- Cambio			  : Se agregan campos relacionados al negocio, solo si son necesarios
--						para diligenciar el PDF.
--
-- ========================================================================================  

CREATE PROCEDURE [dbo].[Nab_Eb_Obtener_Negocio]
(  
	@eb VARCHAR(50)  
)  
AS  
BEGIN  
	SELECT N.*, TPCLT.TIPO_CLIENTE AS TIPO_VENTA, TPDNI.TIPO_DOC AS TIPO_DOCUMENTO
	FROM NAB_EB_NEGOCIOS N
		JOIN NAB_EB_NEGOCIOS_P_TIPO_CLIENTE TPCLT ON TPCLT.ID_TIPO_CLIENTE = N.ID_TIPO_CLIENTE
		JOIN NAB_GLOBAL_P_TIPOS_IDENTIDAD TPDNI ON TPDNI.ID_IDENTIDAD = N.ID_IDENTIDAD  	
	WHERE N.ID_EB = @eb  
END 