USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Eb_Insertar_Traspaso]    Script Date: 09/15/2016 10:40:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez.
-- Fecha Creacion     : 2016-09-12
-- Descripción        : Insertar Traspasos.
-- Parámetros		  : 
-- ========================================================================================

ALTER PROCEDURE [dbo].[Nab_Eb_Insertar_Traspaso](
@IdEb VARCHAR(50),
@Celular BIGINT,
@MarcaEquipo VARCHAR(50),
@Imei BIGINT,
@IdPlan VARCHAR(50),
@IdProducto INT,
@UsuarioRegistro VARCHAR(50),
@IdTipoIdentidadOrigen INT,
@CedOrigen VARCHAR(50),
@NombreOrigen VARCHAR(50),
@CelularOrigen BIGINT,
@IdTipoIdentidadDestino INT,
@CedDestino VARCHAR(50),
@NombreDestino VARCHAR(50),
@CelularDestino BIGINT,
@Nit VARCHAR(50),
@correo VARCHAR(50)=NULL,
@clausulas VARCHAR(50),
@saldosEnContra VARCHAR(50),
@Adjunto1 VARCHAR(MAX),
@Adjunto2 VARCHAR(MAX),
@Adjunto3 VARCHAR(MAX),
@Adjunto4 VARCHAR(MAX)
)
AS
BEGIN
	INSERT INTO NAB_CREDITO_TRASPASO 
	(IdEb,Celular,MarcaEquipo,Imei ,IdPlan,IdProducto ,UsuarioRegistro ,IdTipoIdentidadOrigen ,CedOrigen ,NombreOrigen ,CelularOrigen ,IdTipoIdentidadDestino ,CedDestino ,NombreDestino ,CelularDestino ,Nit,FechaTraspaso,CorreoNotificaciones,ClausulasACargoDePersonaOrigen,SaldosACargoDePersonaOrigen,Adjunto1,Adjunto2,Adjunto3,Adjunto4)
	VALUES
	(@IdEb,@Celular,@MarcaEquipo,@Imei ,@IdPlan,@IdProducto ,@UsuarioRegistro ,@IdTipoIdentidadOrigen ,@CedOrigen ,@NombreOrigen ,@CelularOrigen ,@IdTipoIdentidadDestino ,@CedDestino ,@NombreDestino ,@CelularDestino ,@Nit,GETDATE(),@correo,@clausulas,@saldosEnContra,@Adjunto1,@Adjunto2,@Adjunto3,@Adjunto4)
	END