USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Login]    Script Date: 08/31/2016 10:02:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Jeffrey Cortés>
-- Create date: <2014-12-01>
-- Description:	<Login de usuario en NABIS>
-- =============================================
ALTER PROCEDURE [dbo].[Nab_Login]
(
	@user varchar(20)
	,@password varchar(50)
)
AS
BEGIN
	SELECT	A.USR_ID
			, A.CC
			, A.USR_LOGIN
			, A.USR_PASS
			, A.USR_NOMBRE
			, A.USR_MAIL
			, A.ID_TIPO
			, A.ID_AREA
			, A.ID_GRUPO
			, A.ID_PROCESO
			, B.PROCESO AS ROL
			, A.COD_AGENTE
			, A.COD_VEND AS COD_VENDEDOR
			, CASE WHEN A.COD_AGENTE IS NULL AND A.ID_AREA != 6 THEN 1 ELSE 2 END AS ID_CANAL_VENDEDOR
			, CASE WHEN A.COD_AGENTE IS NULL AND A.ID_AREA != 6 THEN 'DIRECTO' ELSE 'INDIRECTO' END AS CANAL_VENDEDOR
			--, CASE WHEN C.AG_ESTADOASESOR IS NULL THEN '-1' ELSE C.AG_ESTADOASESOR END AS ESTADO_VENDEDOR
			,S.ESTADO AS ESTADO_VENDEDOR
			--, CASE WHEN D.UserID IS NULL THEN 'NA' ELSE CAST(D.UserID AS VARCHAR(40)) END AS USR_PEDIDOS
			,E.Descripcion AS ESTADOUSR
			,A.CONTLOGINERROR as CONTADOR
    FROM USERS A
		INNER JOIN USERS_PROCESOS B ON B.ID_PROCESO = A.ID_PROCESO
		--LEFT JOIN CCC.DBO.BC_AGENTE C ON C.Ag_Codvendededor = A.COD_VEND
		LEFT JOIN NAB_ESTADOLOGIN E ON E.IdEstadoLogin = A.ID_ESTADOLOGIN
		--LEFT JOIN [ACVLogistic].[dbo].[ACUsuario] D ON D.NH = A.USR_ID
		LEFT JOIN USERS_ESTADOS S ON A.ID_ESTADO = S.ID_ESTADO
	WHERE A.USR_LOGIN = @user
			AND A.USR_PASS = @password
			--AND A.ID_ESTADO = 1;
END
