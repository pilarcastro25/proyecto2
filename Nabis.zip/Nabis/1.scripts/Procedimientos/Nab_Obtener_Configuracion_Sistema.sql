USE NABIS

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF OBJECT_ID(N'Nab_Obtener_Configuracion_Sistema')IS NOT NULL
	DROP PROCEDURE Nab_Obtener_Configuracion_Sistema
GO

-- ==========================================================================================
-- Author:		JEISON GABRIEL MARTINEZ BUSTOS
-- Create date: 15-11-2016
-- Description:	SP para la obtenci�n de configuaracipnes de sistema por su alias
-- ==========================================================================================
CREATE PROCEDURE Nab_Obtener_Configuracion_Sistema
	@ALIAS VARCHAR(50)	
AS
BEGIN
	SELECT * FROM NAB_GLOBAL_P_CONFIGURACION_SISTEMA 
	WHERE ALIAS = @ALIAS
END
GO
