USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.NAB_GLOBAL_CORREO_DESBLOQUEO') IS NOT NULL
   DROP TABLE dbo.NAB_GLOBAL_CORREO_DESBLOQUEO
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creación     : 2016-08-30
-- Descripción        : Creación tabla de módulos

-- ======================================================================================== 
CREATE TABLE dbo.NAB_GLOBAL_CORREO_DESBLOQUEO (
IdCorreo INT IDENTITY(1,1) PRIMARY KEY,
Correo VARCHAR(50)
);
INSERT INTO NAB_GLOBAL_CORREO_DESBLOQUEO VALUES ('edwin.casallasp@telefonica.com')
GO