USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/31/2016 16:12:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID (N'dbo.[NAB_CREDITO_TRASPASO]') IS NOT NULL
	DROP TABLE [dbo].[NAB_CREDITO_TRASPASO]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 08-09-2016
-- Descripción        : Creación de tabla de traspasos
-- ========================================================================================
CREATE TABLE	[dbo].[NAB_CREDITO_TRASPASO](
	[IdTraspaso] [int] IDENTITY(1,1) NOT NULL,
	[IdEb] [varchar](50) NOT NULL,
	[Celular] [bigint] NOT NULL,
	[MarcaEquipo] [varchar](50) NOT NULL,
	[Imei] [bigint] NOT NULL,
	[IdPlan] [varchar](50) NOT NULL,
	[IdProducto] [int] NOT NULL,
	[FechaTraspaso] [datetime] NOT NULL,
	[UsuarioRegistro] [varchar](50) NOT NULL,
	[IdTipoIdentidadOrigen] [int] NOT NULL,
	[CedOrigen] [varchar](50) NOT NULL,
	[NombreOrigen] [varchar](50) NOT NULL,
	[CelularOrigen] [bigint] NOT NULL,
	[IdTipoIdentidadDestino] [int] NOT NULL,
	[CedDestino] [varchar](50) NOT NULL,
	[NombreDestino] [varchar](50) NOT NULL,
	[CelularDestino] [bigint] NOT NULL,
	[Nit] [varchar](50) NOT NULL,
	[CorreoNotificaciones] [varchar](50) NULL,
	[ClausulasACargoDePersonaOrigen] [varchar](50) NULL,
	[SaldosACargoDePersonaOrigen] [varchar](50) NULL,
	[Adjunto1] [varchar](max) NULL,
	[Adjunto2] [varchar](max) NULL,
	[Adjunto3] [varchar](max) NULL,
	[Adjunto4] [varchar](max) NULL,
);


