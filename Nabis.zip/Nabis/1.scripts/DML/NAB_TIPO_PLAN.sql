USE [NABIS]
GO
/****** Object:  StoredProcedure [dbo].[Nab_Usuario_Insertar]    Script Date: 08/31/2016 16:12:39 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF OBJECT_ID (N'dbo.[NAB_PLANES]') IS NOT NULL
   DROP TABLE dbo.[NAB_PLANES]
GO
IF OBJECT_ID (N'dbo.[NAB_TIPO_PLAN]') IS NOT NULL
	DROP TABLE dbo.[NAB_TIPO_PLAN]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 02-09-2016
-- Descripción        : Creación de tablas de planes y de tipo panel.
-- ========================================================================================
CREATE TABLE	[dbo].[NAB_TIPO_PLAN](
IdTipoPlan INT IDENTITY(1,1) PRIMARY KEY,
TipoPlan VARCHAR(50) NOT NULL
);

INSERT INTO NAB_TIPO_PLAN VALUES ('OTRO');
INSERT INTO NAB_TIPO_PLAN VALUES ('PRO');
INSERT INTO NAB_TIPO_PLAN VALUES ('ILIMITADO');


CREATE TABLE [dbo].[NAB_PLANES] (
	IdPlan INT IDENTITY(1,1),
	CodigoPlan VARCHAR(50) PRIMARY KEY,
	Planes VARCHAR(50) NOT NULL,
	IdTipoPlan INT FOREIGN KEY REFERENCES [NAB_TIPO_PLAN](IdTipoPlan) NOT NULL
)
 