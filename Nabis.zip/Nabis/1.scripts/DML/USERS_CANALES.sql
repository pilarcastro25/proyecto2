USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.USERS_CANALES') IS NOT NULL
   DROP TABLE dbo.USERS_CANALES
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creación     : 2016-08-31
-- Descripción        : Creación tabla de Tipos de Canal

-- ======================================================================================== 
CREATE TABLE dbo.USERS_CANALES (
IdCanal INT IDENTITY(1,1) PRIMARY KEY,
Canal VARCHAR(50)
);
INSERT INTO USERS_CANALES VALUES ('DIRECTO')
INSERT INTO USERS_CANALES VALUES ('INDIRECTO')
GO