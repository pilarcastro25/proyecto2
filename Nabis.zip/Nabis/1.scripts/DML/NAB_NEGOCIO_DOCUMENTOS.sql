USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.NAB_NEGOCIO_DOCUMENTOS') IS NOT NULL
   DROP TABLE dbo.NAB_NEGOCIO_DOCUMENTOS
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creación     : 2016-09-30
-- Descripción        : Creación tabla de rompimiento de negocios y documentos

-- ======================================================================================== 
CREATE TABLE dbo.NAB_NEGOCIO_DOCUMENTOS (
IdEb VARCHAR(50) ,
IdDocumento INT
);
GO