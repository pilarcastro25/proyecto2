--=================================
-- Tabla radiacion del negocio
-- NAB_EB_NEGOCIOS
--=================================
ALTER TABLE NAB_EB_NEGOCIOS ADD TELEFONO_CLIENTE VARCHAR(50) NULL

ALTER TABLE NAB_EB_NEGOCIOS ADD OBSERVACIONES VARCHAR(200) NULL