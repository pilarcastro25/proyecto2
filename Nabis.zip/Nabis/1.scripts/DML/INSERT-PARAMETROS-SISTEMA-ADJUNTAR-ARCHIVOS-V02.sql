-- Agregar parametros del envio de correos exchange(Para adjuntar archivos.)

INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange Mail Remitente', 'Exchange_Mail_Remitente', 'serviciosenlinea.moviles@telefonica.com', 'Cuenta de correo Exchange para el envio de correos por Exchange.')
         
INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange Usuario', 'Exchange_Mail_Usuario', 'serviciosenlinea', 'Nombre de usuario para el envio de correos por Exchange.')         

INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange servidor', 'Exchange_Mail_ServerExchange', 'https://mailus.telefonica.com/ews/exchange.asmx', 'Servidor para el envio de correos por Exchange.')         

INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange Puerto', 'Exchange_Mail_Puerto', '25', 'Puerto para el envio de correos por Exchange.')

INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange Dominio', 'Exchange_Mail_Dominio', 'nh', 'Dominio para el envio de correos por Exchange.')

INSERT INTO [NABIS].[dbo].[NAB_GLOBAL_P_CONFIGURACION_SISTEMA]([NOMBRE],[ALIAS],[VALOR],[DESCRIPCION])
VALUES('Exchange Dominio', 'Exchange_Mail_Contrasenia', 'Telefonica23*', 'Contraseña para el envio de correos por Exchange.')
