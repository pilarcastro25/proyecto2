USE [NABIS]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


IF OBJECT_ID (N'dbo.[NAB_GLOBAL_ESTADO_NEGOCIO_MODULO]') IS NOT NULL
	DROP TABLE [dbo].[NAB_GLOBAL_ESTADO_NEGOCIO_MODULO]
GO
-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 20-09-2016
-- Descripci�n        : Creaci�n de tabla de etapa de negocio por m�dulo
-- ========================================================================================
CREATE TABLE	[dbo].[NAB_GLOBAL_ESTADO_NEGOCIO_MODULO](
	IdEb VARCHAR(50),
	IdModulo INT,
	UsuarioOrigen VARCHAR(50),
	UsuarioFin VARCHAR(50),
	Reasignador VARCHAR(50),
	FechaReasignacion DATETIME
);


