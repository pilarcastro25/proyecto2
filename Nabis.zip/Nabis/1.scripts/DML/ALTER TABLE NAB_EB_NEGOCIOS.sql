USE NABIS
-- ========================================================================================
-- Autor              : Jeison Martinez.
-- Fecha Creacion	  : 16-11-2016
-- Descripci�n        : Se a�ade columna del email
-- ========================================================================================
ALTER TABLE NAB_EB_NEGOCIOS
ADD EMAIL_CLIENTE VARCHAR(100);