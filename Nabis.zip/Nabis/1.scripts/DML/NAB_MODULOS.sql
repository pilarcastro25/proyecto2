USE [NABIS]
--------------------------------------------------//--------------------------------------------------
IF OBJECT_ID (N'dbo.NAB_MODULOS') IS NOT NULL
   DROP TABLE dbo.NAB_MODULOS
GO
-- ========================================================================================
-- Autor              : Gabriel Martinez 
-- Fecha Creación     : 2016-08-25
-- Descripción        : Creación tabla de módulos

-- ======================================================================================== 
CREATE TABLE dbo.NAB_MODULOS(
IdModulo INT IDENTITY(1,1) PRIMARY KEY,
Modulo VARCHAR(50) NOT NULL
);
INSERT INTO NAB_MODULOS VALUES ('COMERCIAL')
INSERT INTO NAB_MODULOS VALUES ('CREDITO')
INSERT INTO NAB_MODULOS VALUES ('LOGISTICA')
INSERT INTO NAB_MODULOS VALUES ('ACTIVACIONES')
GO