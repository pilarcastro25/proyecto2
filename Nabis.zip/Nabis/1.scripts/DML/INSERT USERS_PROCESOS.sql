USE [NABIS]
GO

-- ========================================================================================
-- Autor              : Jeison Gabriel Martinez Bustos.
-- Fecha Creacion	  : 03-10-2016
-- Descripci�n        : Insert de la tabla USERS_PROCESOS.
-- ========================================================================================
INSERT INTO USERS_PROCESOS VALUES ('ADMINISTRADOR LIDER')
INSERT INTO USERS_PROCESOS VALUES ('COORDINADOR COMERCIAL')
INSERT INTO USERS_PROCESOS VALUES ('COORDINADOR CREDITO')
INSERT INTO USERS_PROCESOS VALUES ('COORDINADOR LOGISTICA')
INSERT INTO USERS_PROCESOS VALUES ('COORDINADOR ACTIVACIONES')
INSERT INTO USERS_PROCESOS VALUES ('PYMES')
INSERT INTO USERS_PROCESOS VALUES ('ASESOR COMERCIAL')
