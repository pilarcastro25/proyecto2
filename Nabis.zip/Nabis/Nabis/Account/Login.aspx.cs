﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Permissions;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using Nabis.Utilities;
using Nabis_BS.NabWSUsers;
using Nabis_BS.BUser;


namespace Nabis.Account
{
    public partial class Login : Page
    {
        private Lobibox lobibox = new Lobibox();

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        private int GetCDV()
        {
            Random r = new Random();
            int CDV = r.Next(100000, 999999);
            return CDV;
        }

        private bool AppLogin(string UserName, string Password)
        {
            lobibox.cliente = Page.ClientScript;
            string hashPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile("<|/>" + Password, "SHA1");
            int CDV = GetCDV();
            try
            {
                UserLogin user = BUsersAccounts.Login(UserName, hashPassword);
                if (user.IsLogin)
                {
                    if (user.IsLock)
                    {
                        lobibox.msg = string.Format("El usuario se encuentra Bloqueado o Inactivo!");
                        lobibox.TipoAlert = TipoAlerta.error;
                        lobibox.ImprimirAlerta();
                    }
                    else {
                        Session["usr_Id"] = user.IdUser;
                        Session["usr_Login"] = user.User;
                        Session["usr_NumIdent"] = user.Cc;
                        Session["usr_Nombre"] = user.Nombre;
                        Session["usr_Tipo"] = user.IdTipo;
                        Session["usr_Area"] = user.IdArea;
                        Session["usr_Grupo"] = user.IdGrupo;
                        Session["usr_Perfil"] = user.IdPerfil;
                        Session["usr_Mail"] = user.Mail;
                        Session["usr_CodAgente"] = user.CodAgente;
                        Session["usr_CodVendedor"] = user.CodVendedor;
                        Session["usr_IdCanalVendedor"] = user.IdCanal;
                        Session["usr_EstadoVendedor"] = user.EstadoRedVentas;
                        Session["usr_CDV"] = CDV;
                    }
                }
                else
                {
                    lobibox.msg = string.Format("Usuario o contraseña Inválidos!");
                    lobibox.TipoAlert = TipoAlerta.error;
                    lobibox.ImprimirAlerta();
                }
                return user.IsLogin;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void NabLogin_Authenticate(object sender, AuthenticateEventArgs e)
        {
            bool Authenticated = false;
            Authenticated = AppLogin(nabLogin.UserName, nabLogin.Password);
            e.Authenticated = Authenticated;
        }

        void LoginEnd(string UserName)
        {
            Response.Redirect("~/");
        }

        protected void NabLogin_LoggedIn(object sender, EventArgs e)
        {
            LoginEnd(nabLogin.UserName);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
    }
}