﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Nabis.App_GlobalCode;

namespace Nabis.Account
{
    public partial class Manage : System.Web.UI.Page
    {
        private int currentLine;

        private ListItem[] GetRegionales()
        {
            if (Cache["usersRegionales"] != null)
            {
                return (ListItem[])Cache["usersRegionales"];
            }
            else
            {
                //Tipos de calle de SCL
                currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect tipCallesList = new Conect(currentLine);
                tipCallesList.commandQuery = "SELECT * FROM USERS_REGIONALES";
                tipCallesList.execQuery(false);
                Cache.Add("usersRegionales", tipCallesList.getListItems(), null, DateTime.Now.AddHours(8), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Normal, null);
                return tipCallesList.getListItems();
            }
        }

        private ListItem[] GetAreas()
        {
            if (Cache["usersAreas"] != null)
            {
                return (ListItem[])Cache["usersAreas"];
            }
            else
            {
                //Tipos de calle de SCL
                currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect tipCallesList = new Conect(currentLine);
                tipCallesList.commandQuery = "SELECT * FROM USERS_AREAS";
                tipCallesList.execQuery(false);
                Cache.Add("usersAreas", tipCallesList.getListItems(), null, DateTime.Now.AddHours(8), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Normal, null);
                return tipCallesList.getListItems();
            }
        }

        private ListItem[] GetTipos()
        {
            if (Cache["usersTipos"] != null)
            {
                return (ListItem[])Cache["usersTipos"];
            }
            else
            {
                //Tipos de calle de SCL
                currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect tipCallesList = new Conect(currentLine);
                tipCallesList.commandQuery = "SELECT * FROM USERS_TIPOS";
                tipCallesList.execQuery(false);
                Cache.Add("usersTipos", tipCallesList.getListItems(), null, DateTime.Now.AddHours(8), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Normal, null);
                return tipCallesList.getListItems();
            }
        }

        private ListItem[] GetProcesos()
        {
            if (Cache["usersProcesos"] != null)
            {
                return (ListItem[])Cache["usersProcesos"];
            }
            else
            {
                //Tipos de calle de SCL
                currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect tipCallesList = new Conect(currentLine);
                tipCallesList.commandQuery = "SELECT * FROM USERS_PROCESOS WHERE ID_PROCESO > 0";
                tipCallesList.execQuery(false);
                Cache.Add("usersProcesos", tipCallesList.getListItems(), null, DateTime.Now.AddHours(8), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Normal, null);
                return tipCallesList.getListItems();
            }
        }

        private ListItem[] GetPerfilesScl()
        {
            if (Cache["usersPerfilesSCL"] != null)
            {
                return (ListItem[])Cache["usersPerfilesSCL"];
            }
            else
            {
                //Tipos de calle de SCL
                currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect tipCallesList = new Conect(currentLine);
                tipCallesList.commandQuery = "SELECT * FROM USERS_PERFILES";
                tipCallesList.execQuery(false);
                Cache.Add("usersPerfilesSCL", tipCallesList.getListItems(), null, DateTime.Now.AddHours(8), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Normal, null);
                return tipCallesList.getListItems();
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                userRegional.Items.AddRange(this.GetRegionales());
                userRegional.SelectedIndex = 0;

                userArea.Items.AddRange(this.GetAreas());
                userArea.SelectedIndex = 0;

                userTipo.Items.AddRange(this.GetTipos());
                userTipo.SelectedIndex = 0;

                userProceso.Items.AddRange(this.GetProcesos());
                userProceso.SelectedIndex = 0;

                userPerfil.Items.AddRange(this.GetPerfilesScl());
                userPerfil.SelectedIndex = 0;
            }
        }

        protected void userArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            userGrupo.Items.Clear();
            currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect gruposList = new Conect(currentLine);
            gruposList.commandQuery = "SELECT ID_GRUPO, GRUPO FROM USERS_GRUPOS WHERE ID_AREA = " + userArea.SelectedValue.ToString() + " ORDER BY ID_AREA";
            gruposList.execQuery(false);
            userGrupo.Items.AddRange(gruposList.getListItems());
            userArea.Focus();
        }

        protected void submit_Click(object sender, EventArgs e)
        {
            currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
            string hashPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile("<|/>" + userPass.Text, "SHA1");
            Conect user = new Conect(currentLine);
            user.commandQuery = "Nab_Manage_Users_Registro";
            user.addParameters("user", Session["usr_Id"].ToString());
            user.addParameters("usr_nh",userNh.Text.ToString());
            user.addParameters("usr_cc", userNumIdent.Text.ToString());
            user.addParameters("usr_codVend", userCodVend.Text);
            user.addParameters("usr_codAgente", userCodAgente.Text);
            user.addParameters("usr_login", userLogin.Text.ToString());
            user.addParameters("usr_pass", hashPassword);
            user.addParameters("usr_nombres", userNombre.Text.ToString());
            user.addParameters("usr_mail", userMail.Text.ToString());
            user.addParameters("usr_perfil", userPerfil.SelectedValue);
            user.addParameters("usr_regional", userRegional.SelectedValue);
            user.addParameters("usr_area", userArea.SelectedValue);
            user.addParameters("usr_grupo", userGrupo.SelectedValue);
            user.addParameters("usr_proceso", userProceso.SelectedValue);
            user.addParameters("usr_celular", userCelular.Text);
            user.addParameters("usr_ext", userExt.Text);
            user.addParameters("usr_tipo", userTipo.SelectedValue);
            user.addParametersOutPut("request", 0, System.Data.SqlDbType.Int);
            user.execTransac(true);
            switch((int)user.getValueParameterOut("request"))
            {
                case -3:
                    Conect.printScript(Page.ClientScript, "alert('Error: ¡El NH especificado ya ésta registrado!'); ", false, null);
                    break;
                case -2: 
                    Conect.printScript(Page.ClientScript, "alert('Error: ¡Código de vendedor no vigente o no existe!'); ", false, null);
                    break;
                case -1:
                    Conect.printScript(Page.ClientScript, "alert('Error: ¡La cédula del usuario no es coincidente con la cédula del código de vendedor proporcionado!'); ", false, null);
                    break;
                case 1:
                    Conect.printScript(Page.ClientScript, "alert('¡Usuario Registrado con Éxito!'); ", true, "../Default.aspx");
                    break;
                default:
                    Conect.printScript(Page.ClientScript, "alert('¡Error Inesperado de aplicación o base de datos. Por favor intente de nuevo, si persiste la falla escale el caso por el PUC!'); ", false, null);
                    break;
            }
        }
    }
}


