﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Nabis.App_GlobalCode;
using System.Web.Security;

namespace Nabis.Account
{
    public partial class Logout : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LogOut();
        }

        protected void LogOut()
        {
            string name = HttpContext.Current.User.Identity.Name;
            Session.Abandon();
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectFromLoginPage(name, false);
        }
    }
}