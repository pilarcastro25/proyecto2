﻿// ===================================================================================================
// Desarrollado Por		    :   Harold Caicedo
// Fecha de Creación		:   2016/08/29.
// Producto o sistema	    :   
// Empresa			        :   
// Proyecto			        :   
// Cliente			        :   
// ===================================================================================================
// Versión	        Descripción
// 1.0.0.0	        Entidad que representa la informacion asociada a la relacionn de documento 
//                  con el tipo de contrato seleccionado.
//             
// ===================================================================================================
// HISTORIAL DE CAMBIOS:
// ===================================================================================================
// Ver.	 Fecha		    Autor					Descripción
// ---	 -------------	----------------------	------------------------------------------------------
// XX	 yyyy/MM/dd	    [Nombre Completo]	    [Razón del cambio realizado] 
// ===================================================================================================

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    /// <summary>
    /// Entidad que representa la informacion asociada a la relacionn de documento 
    /// con el tipo de contrato seleccionado.
    /// </summary>
    public class DocumentoTipoContrato
    {
        /// <summary>
        /// Id asociado al documento
        /// </summary>
        public int ID_DOCUMENTO { get; set; }
        /// <summary>
        /// Nombre del documento.
        /// </summary>
        public string NOMBRE_DOCUMENTO { get; set; }
        /// <summary>
        /// El documento es obligatorio
        /// </summary>
        public bool REQUISITO { get; set; }
        /// <summary>
        /// Id de tipo de contrato
        /// </summary>
        public int ID_TIPO_CONTRATO { get; set; }
        /// <summary>
        /// Nombre de tipo de contrato.
        /// </summary>
        public string NOMBRE_TIPO_CONTRATO { get; set; }
        /// <summary>
        /// Alias del documentos
        /// </summary>
        public string ALIAS { get; set; }

        public DocumentoTipoContrato()
        {

        }

        public DocumentoTipoContrato(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("row", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.ID_DOCUMENTO = rowInfo.Field<int>("ID_DOCUMENTO");
            this.NOMBRE_DOCUMENTO = rowInfo.Field<string>("NOMBRE_DOCUMENTO");
            this.REQUISITO = rowInfo.Field<bool>("REQUISITO");
            //int idTipoContrato;
            //bool numero = Int32.TryParse(rowInfo.Field<int>("ID_TIPO_CONTRATO").ToString(), out idTipoContrato);
            this.ID_TIPO_CONTRATO = Convert.ToInt32(rowInfo.Field<int>("ID_TIPO_CONTRATO"));
            this.NOMBRE_TIPO_CONTRATO = rowInfo.Field<string>("NOMBRE_TIPO_CONTRATO");
            this.ALIAS = rowInfo.Field<string>("ALIAS");
        }
    }
}