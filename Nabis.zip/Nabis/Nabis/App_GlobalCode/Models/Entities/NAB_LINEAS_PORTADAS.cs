﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class NAB_LINEAS_PORTADAS
    {
        public string Negocio { get; set; }
        public string Usuario { get; set    ; }
        public string Celular { get; set; }
        public string Operador { get; set; }
        public string PlanOrigen { get; set; }
        public string PlanDestino { get; set; }
        public bool? Traspaso { get; set; }
        public string TipoIdentOrigen { get; set; }
        public string NumIdentOrigen { get; set; }
        public string NombreClienteOrigen { get; set; }
        public string ApellidoClienteOrigen { get; set; }
        public string CantLineas { get; set; }
        public string CodPlan { get; set; }
        public string RefEquipo { get; set; }
    }
}