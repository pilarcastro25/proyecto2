﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class EmpresaEnLinea
    {
        public string IdEb { get; set; }
        public long? CantidadLicencias { get; set; }
        public long? ValorMensual { get; set; }
        public string CiudadFirma { get; set; }
        public string Email { get; set; }
    }
}