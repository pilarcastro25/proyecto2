namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_PLANES
    {
        public int IdPlan { get; set; }
        public string CodigoPlan { get; set; }
        public string Planes { get; set; }
        public int IdTipoPlan { get; set; }
    
        public virtual NAB_TIPO_PLAN NAB_TIPO_PLAN { get; set; }
    }
}
