﻿using System;
using System.Data;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Entidad que representa la informacion de un vendedor.
    /// </summary>
    public class NAB_GLOBAL_VENDEDORES
    {
        public decimal? COD_VENDEDOR { get; set; }
        public string REGIONAL { get; set; }
        public string CIUDAD { get; set; }
        public string DEPARTAMENTO { get; set; }
        public string CANAL { get; set; }
        public string RESPONSABLE { get; set; }
        public decimal? COD_AGENTE { get; set; }
        public string NOMBRE_AGENTE { get; set; }
        public string VENDEDOR { get; set; }
        public string COD_TIP_COMISIONISTA { get; set; }
        public string TIPO_COMISIONISTA { get; set; }
        public string CANAL_COMERCIAL { get; set; }
        public string COD_PUNTO { get; set; }
        public string NOMBRE_PUNTO { get; set; }
        public string ESTADO_PUNTO { get; set; }
        public string ESTADO_ASESOR { get; set; }
        public string FECHA_INICIO_CONTRATO { get; set; }
        public string FECHA_FIN_CONTRATO { get; set; }
        public string NUM_IDEN_VENDEDOR { get; set; }
        public string MOVIL_VENDEDOR { get; set; }

        /// <summary>
        /// Constructor basico.
        /// </summary>
        public NAB_GLOBAL_VENDEDORES()
        {

        }

        /// <summary>
        /// Constructor que recibe por parametro el valor de un registro de un DataTable.
        /// </summary>
        /// <param name="rowInfo"></param>
        public NAB_GLOBAL_VENDEDORES(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.COD_VENDEDOR = rowInfo.Field<decimal?>("COD_VENDEDOR");
            this.REGIONAL = rowInfo.Field<string>("REGIONAL");
            this.CIUDAD = rowInfo.Field<string>("CIUDAD");
            this.DEPARTAMENTO = rowInfo.Field<string>("DEPARTAMENTO");
            this.CANAL = rowInfo.Field<string>("CANAL");
            this.RESPONSABLE = rowInfo.Field<string>("RESPONSABLE");
            this.COD_AGENTE = rowInfo.Field<decimal?>("COD_AGENTE");
            this.NOMBRE_AGENTE = rowInfo.Field<string>("NOMBRE_AGENTE");
            this.VENDEDOR = rowInfo.Field<string>("VENDEDOR");
            this.COD_TIP_COMISIONISTA = rowInfo.Field<string>("COD_TIP_COMISIONISTA");
            this.TIPO_COMISIONISTA = rowInfo.Field<string>("TIPO_COMISIONISTA");
            this.CANAL_COMERCIAL = rowInfo.Field<string>("CANAL_COMERCIAL");
            this.COD_PUNTO = rowInfo.Field<string>("COD_PUNTO");
            this.NOMBRE_PUNTO = rowInfo.Field<string>("NOMBRE_PUNTO");
            this.ESTADO_PUNTO = rowInfo.Field<string>("ESTADO_PUNTO");
            this.FECHA_INICIO_CONTRATO = rowInfo.Field<string>("FECHA_INICIO_CONTRATO");
            this.FECHA_FIN_CONTRATO = rowInfo.Field<string>("FECHA_FIN_CONTRATO");
            this.NUM_IDEN_VENDEDOR = rowInfo.Field<string>("NUM_IDEN_VENDEDOR");
            this.MOVIL_VENDEDOR = rowInfo.Field<string>("MOVIL_VENDEDOR");
        }
    }
}