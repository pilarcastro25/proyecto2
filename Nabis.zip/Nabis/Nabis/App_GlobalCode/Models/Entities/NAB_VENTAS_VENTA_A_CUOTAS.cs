﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Entidad que representa la informacion de Ventas a cuotas.
    /// </summary>
    public class NAB_VENTAS_VENTA_A_CUOTAS
    {
        public int ID_VENTA_CUOTAS { get; set; }
        public int NUMERO_LINEAS { get; set; }
        public DateTime? FECHA_DE_CELEBRACION_DEL_CONTRATO { get; set; }
        public string LUGAR_DE_CELEBRACION_DEL_CONTRATO { get; set; }
        public string NOMBRE_COMPRADOR { get; set; }
        public string IDENTIFICACION_COMPRADOR { get; set; }
        public string CORREO_ELECTRONICO_COMPRADOR { get; set; }
        public string TELEFONO_COMPRADOR { get; set; }
        public string CIUDAD_COMPRADOR { get; set; }
        public string DIRECCION_COMPRADOR { get; set; }
        public string NOMBRE_REPRESENTANTE_LEGAL { get; set; }
        public string IDENTIFICACION_REPRESENTANTE_LEGAL { get; set; }
        public string FORMA_DE_PAGO { get; set; }
        public int? VALOR_TOTAL_EQUIPO { get; set; }
        public int? CUOTA_INICIAL { get; set; }
        public int? NUMERO_CUOTAS { get; set; }
        public int? CUOTA_MENSUAL { get; set; }
        public int? VALOR_TOTAL { get; set; }
        public string ID_CODIGO_NEGOCIO { get; set; }

        public NAB_VENTAS_VENTA_A_CUOTAS()
        {

        }

        public NAB_VENTAS_VENTA_A_CUOTAS(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.ID_VENTA_CUOTAS = rowInfo.Field<int>("ID_VENTA_CUOTAS");
            this.NUMERO_LINEAS = rowInfo.Field<int>("NUMERO_LINEAS");
            this.FECHA_DE_CELEBRACION_DEL_CONTRATO = rowInfo.Field<DateTime?>("FECHA_DE_CELEBRACION_DEL_CONTRATO");
            this.LUGAR_DE_CELEBRACION_DEL_CONTRATO = rowInfo.Field<string>("LUGAR_DE_CELEBRACION_DEL_CONTRATO");
            this.NOMBRE_COMPRADOR = rowInfo.Field<string>("NOMBRE_COMPRADOR");
            this.IDENTIFICACION_COMPRADOR = rowInfo.Field<string>("IDENTIFICACION_COMPRADOR");
            this.CORREO_ELECTRONICO_COMPRADOR = rowInfo.Field<string>("CORREO_ELECTRONICO_COMPRADOR");
            this.TELEFONO_COMPRADOR = rowInfo.Field<string>("TELEFONO_COMPRADOR");
            this.CIUDAD_COMPRADOR = rowInfo.Field<string>("CIUDAD_COMPRADOR");
            this.DIRECCION_COMPRADOR = rowInfo.Field<string>("DIRECCION_COMPRADOR");
            this.NOMBRE_REPRESENTANTE_LEGAL = rowInfo.Field<string>("NOMBRE_REPRESENTANTE_LEGAL");
            this.IDENTIFICACION_REPRESENTANTE_LEGAL = rowInfo.Field<string>("IDENTIFICACION_REPRESENTANTE_LEGAL");
            this.FORMA_DE_PAGO = rowInfo.Field<string>("FORMA_DE_PAGO");
            this.VALOR_TOTAL_EQUIPO = rowInfo.Field<int?>("VALOR_TOTAL_EQUIPO");
            this.CUOTA_INICIAL = rowInfo.Field<int?>("CUOTA_INICIAL");
            this.NUMERO_CUOTAS = rowInfo.Field<int?>("NUMERO_CUOTAS");
            this.CUOTA_MENSUAL = rowInfo.Field<int?>("CUOTA_MENSUAL");
            this.VALOR_TOTAL = rowInfo.Field<int?>("VALOR_TOTAL");
            this.ID_CODIGO_NEGOCIO = rowInfo.Field<string>("ID_CODIGO_NEGOCIO");
        }
    }
}