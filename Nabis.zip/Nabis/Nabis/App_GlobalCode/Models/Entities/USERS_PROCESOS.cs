namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_PROCESOS
    {
        public int ID_PROCESO { get; set; }
        public string PROCESO { get; set; }
    }
}
