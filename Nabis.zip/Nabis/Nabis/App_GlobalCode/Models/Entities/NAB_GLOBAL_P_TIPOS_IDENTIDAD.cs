namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_GLOBAL_P_TIPOS_IDENTIDAD
    {
        public byte ID_IDENTIDAD { get; set; }
        public string TIPO_DOC { get; set; }
        public string TIPO_DOC_SCL { get; set; }
        public string USR_ID_ADICION { get; set; }
        public System.DateTime FECHA_ADICION { get; set; }
        public string USR_ID_MODIFICACION { get; set; }
        public Nullable<System.DateTime> FECHA_MODIFICACION { get; set; }
        public Nullable<bool> ACTIVO { get; set; }
    }
}
