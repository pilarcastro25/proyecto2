namespace Nabis.Models.Entities
{
    using System;
    
    public partial class Nab_Obtener_Planes_Tipos_Result
    {
        public int IdPlan { get; set; }
        public string CodigoPlan { get; set; }
        public string Planes { get; set; }
        public string TipoPlan { get; set; }
    }
}
