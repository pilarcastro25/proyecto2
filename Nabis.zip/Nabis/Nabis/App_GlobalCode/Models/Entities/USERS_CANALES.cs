namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_CANALES
    {
        public int IdCanal { get; set; }
        public string Canal { get; set; }
    }
}
