using System;
using System.Collections.Generic;
using System.Data;

namespace Nabis.Models.Entities
{
    public partial class NAB_GLOBAL_P_CONFIGURACION_SISTEMA
    {
        public int ID_CONFIGURACION { get; set; }
        public string NOMBRE { get; set; }
        public string ALIAS { get; set; }
        public string VALOR { get; set; }
        public string DESCRIPCION { get; set; }

        public NAB_GLOBAL_P_CONFIGURACION_SISTEMA()
        {

        }

        public NAB_GLOBAL_P_CONFIGURACION_SISTEMA(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio");
            }
            this.ID_CONFIGURACION = rowInfo.Field<int>("ID_CONFIGURACION");
            this.NOMBRE = rowInfo.Field<string>("NOMBRE");
            this.ALIAS = rowInfo.Field<string>("ALIAS");
            this.VALOR = rowInfo.Field<string>("VALOR");
            this.DESCRIPCION = rowInfo.Field<string>("DESCRIPCION");
        }
    }
}
