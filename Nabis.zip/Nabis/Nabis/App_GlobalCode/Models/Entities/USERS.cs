namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS
    {
        public string USR_ID { get; set; }
        public Nullable<decimal> CC { get; set; }
        public Nullable<decimal> COD_VEND { get; set; }
        public string USR_LOGIN { get; set; }
        public string USR_PASS { get; set; }
        public string USR_PASSW { get; set; }
        public string USR_NOMBRE { get; set; }
        public string USR_MAIL { get; set; }
        public Nullable<int> ID_PERFIL { get; set; }
        public Nullable<int> ID_REGIONAL { get; set; }
        public Nullable<int> ID_AREA { get; set; }
        public Nullable<int> ID_GRUPO { get; set; }
        public Nullable<int> ID_PROCESO { get; set; }
        public Nullable<decimal> USR_CELULAR { get; set; }
        public Nullable<int> USR_EXT { get; set; }
        public string USR_EQUIPO { get; set; }
        public string USR_IP { get; set; }
        public Nullable<int> HORA_INGRESO { get; set; }
        public Nullable<int> HORA_SALIDA { get; set; }
        public Nullable<System.DateTime> FEC_INGRESO { get; set; }
        public Nullable<decimal> NUM_RAD_IN { get; set; }
        public Nullable<System.DateTime> FEC_RETIRO { get; set; }
        public Nullable<decimal> NUM_RAD_RETIRO { get; set; }
        public Nullable<int> ID_TIPO { get; set; }
        public string NOTAS { get; set; }
        public Nullable<int> ID_ESTADO { get; set; }
        public Nullable<int> COD_AGENTE { get; set; }
        public Nullable<int> ID_ESTADOLOGIN { get; set; }
        public Nullable<System.DateTime> FECHABLOQUEO { get; set; }
        public Nullable<int> CONTLOGINERROR { get; set; }
        public Nullable<int> ID_CANAL { get; set; }
    }
}
