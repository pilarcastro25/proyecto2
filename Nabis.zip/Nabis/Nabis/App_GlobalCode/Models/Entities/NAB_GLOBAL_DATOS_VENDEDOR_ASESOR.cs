﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class NAB_GLOBAL_DATOS_VENDEDOR_ASESOR
    {
        #region Propiedades 

        /// <summary>
        /// Informacion del  Vendedor Y Asesor
        /// </summary>
        public string NombresVendedor { get; set; }
        public string NombresAsesor { get; set; }
        
        #endregion

    }
}