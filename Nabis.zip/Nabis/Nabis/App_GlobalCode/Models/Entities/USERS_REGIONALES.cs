namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_REGIONALES
    {
        public int ID_REGIONAL { get; set; }
        public string REGIONAL { get; set; }
    }
}
