namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Web.Script.Serialization;
    
    public partial class NAB_EB_NEGOCIOS
    {
        public NAB_EB_NEGOCIOS()
        {
            this.NAB_VENTAS_PLAN_ADQUIRIDO = new HashSet<NAB_VENTAS_PLAN_ADQUIRIDO>();
        }
    
        public string ID_EB { get; set; }
        public System.DateTime FEC_INGRESO { get; set; }
        public int COD_VENDEDOR { get; set; }
        public string CANAL_VENDEDOR { get; set; }
        public string NOMBRE_GRUPO { get; set; }
        public string USER_INGRESO { get; set; }
        public int CANT_LINEAS { get; set; }
        public int PEND_LINEAS { get; set; }
        public bool PORTADO { get; set; }
        public bool PEDIDO { get; set; }
        public Nullable<bool> ROBOT { get; set; }
        public Nullable<System.DateTime> FEC_PEDIDO { get; set; }
        public string USER_PEDIDO { get; set; }
        public Nullable<System.DateTime> FEC_CIERRE_PEDIDO { get; set; }
        public string USER_CIERRE_PEDIDO { get; set; }
        public Nullable<System.DateTime> FEC_ESTR_VENTA { get; set; }
        public string USER_ESTR_VENTA { get; set; }
        public Nullable<System.DateTime> FEC_CIERRE_ESTR_VENTA { get; set; }
        public string USER_CIERRE_ESTR_VENTA { get; set; }
        public string ESTRUCTURA_VENTA { get; set; }
        public Nullable<System.DateTime> FEC_DCTOS { get; set; }
        public string USER_DCTOS { get; set; }
        public Nullable<System.DateTime> FEC_CIERRE_DCTOS { get; set; }
        public string USER_CIERRE_DCTOS { get; set; }
        public Nullable<System.DateTime> FEC_CIERRE { get; set; }
        public string USER_CIERRE { get; set; }
        public Nullable<System.DateTime> FEC_CANCELACION { get; set; }
        public string USER_CANCELACION { get; set; }
        public Nullable<System.DateTime> FEC_ULT_MOD { get; set; }
        public string USER_ULT_MOD { get; set; }
        public string ID_ESTADO { get; set; }
        public Nullable<int> ID_GRUPO { get; set; }
        public Nullable<decimal> ID_TIPO_CONTRATO { get; set; }
        public Nullable<byte> ID_IDENTIDAD { get; set; }
        public string IDENTIDAD { get; set; }
        public string NOMBRE_CLIENTE { get; set; }
        public Nullable<byte> ID_TIPO_CLIENTE { get; set; }
        public Nullable<byte> ID_TIPO_SERVICIO { get; set; }
        public Nullable<byte> ID_TIPO_SOLICITUD { get; set; }
        public Nullable<System.DateTime> FECHA_CIERRE_CREDITO { get; set; }
        public Nullable<int> ID_CONVENIO { get; set; }
        public Nullable<int> REP_LEGAL_IDENTIDAD { get; set; }
        public string REP_LEGAL_NOMBRE { get; set; }
        public string REP_LEGAL_APELLIDO1 { get; set; }
        public string REP_LEGAL_APELLIDO2 { get; set; }
        public Nullable<int> REP_LEGAL_FIJO { get; set; }
        public Nullable<long> REP_LEGAL_CELULAR { get; set; }
        public Nullable<System.DateTime> REP_LEGAL_FECNACIMIENTO { get; set; }
        public Nullable<long> REP_LEGAL_SUP_IDENTIDAD { get; set; }
        public string REP_LEGAL_SUP_NOMBRE { get; set; }
        public string REP_LEGAL_SUP_APELLIDO1 { get; set; }
        public string REP_LEGAL_SUP_APELLIDO2 { get; set; }
        public Nullable<int> REP_LEGAL_SUP_FIJO { get; set; }
        public Nullable<long> REP_LEGAL_SUP_CELULAR { get; set; }
        public Nullable<System.DateTime> REP_LEGAL_SUP_FECNACIMIENTO { get; set; }
        public Nullable<int> COD_DISTRITO { get; set; }
        public Nullable<int> COD_BARRIO { get; set; }
        public string COD_TIPO_CALLE { get; set; }
        public string DIRECCION { get; set; }
        public string COMPLEMENTO { get; set; }
        public string COD_DANE { get; set; }
        public Nullable<long> ID_CONTRATO_MARCO { get; set; }
        public Nullable<System.DateTime> FEC_VENTANA { get; set; }
        public Nullable<short> ID_TIPO_CAMBIO_PLAN { get; set; }
        public bool ES_PYMES { get; set; }
    
        [ScriptIgnore]
        public virtual ICollection<NAB_VENTAS_PLAN_ADQUIRIDO> NAB_VENTAS_PLAN_ADQUIRIDO { get; set; }
    }
}
