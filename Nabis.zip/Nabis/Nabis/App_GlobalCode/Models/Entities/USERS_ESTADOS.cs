namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_ESTADOS
    {
        public int ID_ESTADO { get; set; }
        public string ESTADO { get; set; }
    }
}
