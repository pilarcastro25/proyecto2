namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    using Nabis.Models;   

    public partial class USERS_AREAS 

    {
        public int ID_AREA { get; set; }
        public string AREA { get; set; }
    }
}
