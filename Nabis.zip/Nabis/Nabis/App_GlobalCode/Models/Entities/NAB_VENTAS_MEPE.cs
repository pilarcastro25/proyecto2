﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class NAB_VENTAS_MEPE
    {
        #region Propiedades Mepe

        /// <summary>
        /// Informacion del negocio y del Vendedor
        /// </summary>
        public string IdUsuario { get; set; }
        public string CodNegocio { get; set; }
        public string CanalVenta { get; set; }
        public string NombreDistribuidor { get; set; }
        public DateTime FechaSolicitud { get; set; }

        /// <summary>
        /// Informacion del Cliente
        /// </summary>
        public int? CodCliente { get; set; }
        public string IdentificacionCliente { get; set; }
        public string RazonSocial { get; set; }
        public string TelCliente { get; set; }
        public string MailCliente { get; set; }
        public string ApartadoCliente { get; set; }
        public string CodigoDepartamentoCliente { get; set; }
        public string CodigoCiudadCliente { get; set; }
        public string NombreDepartamentoCliente { get; set; }
        public string NombreCiudadCliente { get; set; }
        public string ActividadEconomica { get; set; }
        public string CategoriaImpositiva { get; set; }
        public string DireccionCliente { get; set; }

        /// <summary>
        /// Informacion del Representante Legal
        /// </summary>
        public string NombreRepresentanteLegal { get; set; }
        public string Apellido1RepresentanteLegal { get; set; }
        public string Apellido2RepresentanteLegal { get; set; }
        public string IdentificacionRepresentanteLegal { get; set; }
        public string TelefonosRepresentanteLegal { get; set; }
        public string NombreCompletoRepresentanteLegal
        {
            get
            {
                return string.Format("{0} {1} {2}", this.NombreRepresentanteLegal, this.Apellido1RepresentanteLegal, this.Apellido2RepresentanteLegal);
            }
        }

        /// <summary>
        /// Informacion del Vendedor
        /// </summary>
        public int CodVendedor { get; set; }
        public string Nombres_Apellidos_Vendedor { get; set; }
        //public string Nombres_Apellidos_Asesor { get; set; }

        /// <summary>
        /// Informacion del plan
        /// </summary>
        public string CodPlan { get; set; }
        public string NombrePlan { get; set; }
        public string TipoPlan { get; set; }
        public string PorDemanda { get; set; }
        public string Bolsa { get; set; }
        public string On_Net { get; set; }
        public string Multioperador { get; set; }
        public string CantidadMensajes { get; set; }
        public string Valor_X_Mensaje { get; set; }
        public string CodigoActivar { get; set; }
        //public Int64 LineaEspecial { get; set; }
        //public int On_Net { get; set; }
        //public int LineaNumeroAbreviado { get; set; }
        //public int LineaXY { get; set; }
        //public Int64 NumeroEnrutamiento { get; set; }
        public string Cobertura { get; set; }



        /// <summary>
        /// Informacion del Contacto Autorizado
        /// </summary>

        public string NombreContactoAutorizado { get; set; }
        public string Apeliido1_ContactoAutorizado { get; set; }
        public string Apellido2_ContactoAutorizado { get; set; }
        public Int64 Identificacion_ContactoAutorizado { get; set; }
        public string Direccion_ContactoAutorizado { get; set; }
        public string Email_ContactoAutorizado { get; set; }
        public string CodigoCiudad_ContactoAutorizado { get; set; }
        public string CodigoDepto_ContactoAutorizado { get; set; }
        public string NombreDepto_ContactoAutorizado { get; set; }
        public string NombreCiudad_ContactoAutorizado { get; set; }
        public string Telefonos_ContactoAutorizado { get; set; }

        
        public bool Operacion { get; set; }

        #endregion

    }
}