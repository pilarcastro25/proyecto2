namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_MODULOS
    {
        public int IdModulo { get; set; }
        public string Modulo { get; set; }
    }
}
