namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_GLOBAL_CORREO_DESBLOQUEO
    {
        public int IdCorreo { get; set; }
        public string Correo { get; set; }
    }
}
