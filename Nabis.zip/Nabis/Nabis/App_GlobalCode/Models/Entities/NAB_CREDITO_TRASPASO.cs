namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_CREDITO_TRASPASO
    {
        public int IdTraspaso { get; set; }
        public string IdEb { get; set; }
        public long Celular { get; set; }
        public string MarcaEquipo { get; set; }
        public long Imei { get; set; }
        public string IdPlan { get; set; }
        public int IdProducto { get; set; }
        public System.DateTime FechaTraspaso { get; set; }
        public string UsuarioRegistro { get; set; }
        public int IdTipoIdentidadOrigen { get; set; }
        public string CedOrigen { get; set; }
        public string NombreOrigen { get; set; }
        public long CelularOrigen { get; set; }
        public int IdTipoIdentidadDestino { get; set; }
        public string CedDestino { get; set; }
        public string NombreDestino { get; set; }
        public long CelularDestino { get; set; }
        public string Nit { get; set; }
        public string CorreoNotificaciones { get; set; }
        public string ClausulasACargoDePersonaOrigen { get; set; }
        public string SaldosACargoDePersonaOrigen { get; set; }
        public string Adjunto1 { get; set; }
        public string Adjunto2 { get; set; }
        public string Adjunto3 { get; set; }
        public string Adjunto4 { get; set; }
    }
}
