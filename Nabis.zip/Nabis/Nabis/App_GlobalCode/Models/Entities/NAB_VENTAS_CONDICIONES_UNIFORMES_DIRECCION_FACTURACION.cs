﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Entidad que representa la informacion de direccion para un contrato de 
    /// condiciones uniformes
    /// </summary>
    public class NAB_VENTAS_CONDICIONES_UNIFORMES_DIRECCION_FACTURACION
    {
        public int ID_CONDICIONES_UNIFORMES_DIRECCION { get; set; }
        public bool ENVIO_FACTURA_EMAIL { get; set; }
        public string EMAIL_ENVIO_FACTURA { get; set; }
        public bool ENVIO_FACTURA_FISICA { get; set; }
        public string DIRECCION_ENVIO_FACTURA_FISICA { get; set; }
        public string TIPO_VIVIENDA { get; set; }
        public string BARRIO { get; set; }
        public string ID_DEPARTAMENTO { get; set; }
        public string DEPARTAMENTO { get; set; }
        public string ID_CIUDAD { get; set; }
        public string CIUDAD { get; set; }
        public string TELEFONO_RESIDENCIA { get; set; }
        public string TELEFONO_MOVIL { get; set; }
        public bool AUTORIZACION_ENVIO_EMAIL { get; set; }
        public bool AUTORIZACION_NUMERO_CELULAR { get; set; }
        public string ID_CODIGO_NEGOCIO { get; set; }

        /// <summary>
        /// Constructor basico.
        /// </summary>
        public NAB_VENTAS_CONDICIONES_UNIFORMES_DIRECCION_FACTURACION()
        {

        }

        /// <summary>
        /// Constructor que recibe por parametro el valor de un registro de un DataTable.
        /// </summary>
        /// <param name="rowInfo">Registro</param>
        public NAB_VENTAS_CONDICIONES_UNIFORMES_DIRECCION_FACTURACION(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio");
            }
            this.ID_CONDICIONES_UNIFORMES_DIRECCION = rowInfo.Field<int>("ID_CONDICIONES_UNIFORMES_DIRECCION");
            this.ENVIO_FACTURA_EMAIL = rowInfo.Field<bool>("ENVIO_FACTURA_EMAIL");
            this.EMAIL_ENVIO_FACTURA = rowInfo.Field<string>("EMAIL_ENVIO_FACTURA");
            this.ENVIO_FACTURA_FISICA = rowInfo.Field<bool>("ENVIO_FACTURA_FISICA");
            this.DIRECCION_ENVIO_FACTURA_FISICA = rowInfo.Field<string>("DIRECCION_ENVIO_FACTURA_FISICA");
            this.TIPO_VIVIENDA = rowInfo.Field<string>("TIPO_VIVIENDA");
            this.BARRIO = rowInfo.Field<string>("BARRIO");
            this.ID_DEPARTAMENTO = rowInfo.Field<string>("ID_DEPARTAMENTO");
            this.DEPARTAMENTO = rowInfo.Field<string>("DEPARTAMENTO");
            this.ID_CIUDAD = rowInfo.Field<string>("ID_CIUDAD");
            this.CIUDAD = rowInfo.Field<string>("CIUDAD");
            this.TELEFONO_RESIDENCIA = rowInfo.Field<string>("TELEFONO_RESIDENCIA");
            this.TELEFONO_MOVIL = rowInfo.Field<string>("TELEFONO_MOVIL");
            this.AUTORIZACION_ENVIO_EMAIL = rowInfo.Field<bool>("AUTORIZACION_ENVIO_EMAIL");
            this.AUTORIZACION_NUMERO_CELULAR = rowInfo.Field<bool>("AUTORIZACION_NUMERO_CELULAR");
            this.ID_CODIGO_NEGOCIO = rowInfo.Field<string>("ID_CODIGO_NEGOCIO");
        }
    }
}