﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class NAB_ANEXOS_NEGOCIO
    {
        public string CodigoNegocio_FK { get; set; }
        public string ImeiEquipo { get; set; }
        public double? ValorEquipo { get; set; }
        public double? ValorEquipoKoral { get; set; }
        public bool? EquipoACuotas { get; set; }
        public double? CuotaInicial { get; set; }
        public double? ValorADiferir { get; set; }
        public int? NumeroDeCuotas { get; set; }
        public string SerialSimCard { get; set; }
        public double? ValorDeLaSimCard { get; set; }
        public double? ValorBeneficio { get; set; }
        public string CondicionesBeneficio { get; set; }
        public string CodigoBeneficioRecurrente { get; set; }
        public string CondicionesBeneficioBasico { get; set; }
        public string CodigoBeneficioBasico { get; set; }

        public NAB_ANEXOS_NEGOCIO()
        {

        }

        public NAB_ANEXOS_NEGOCIO(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio");
            }
            this.CodigoNegocio_FK = rowInfo.Field<string>("CodigoNegocio_FK");
            this.ImeiEquipo = rowInfo.Field<string>("ImeiEquipo");
            this.ValorEquipo = rowInfo.Field<double?>("ValorEquipo");
            this.ValorEquipoKoral = rowInfo.Field<double?>("ValorEquipoKoral");
            this.EquipoACuotas = rowInfo.Field<bool?>("EquipoACuotas");
            this.CuotaInicial = rowInfo.Field<double?>("CuotaInicial");
            this.ValorADiferir = rowInfo.Field<double?>("ValorADiferir");
            this.NumeroDeCuotas = rowInfo.Field<int?>("NumeroDeCuotas");
            this.SerialSimCard = rowInfo.Field<string>("SerialSimCard");
            this.ValorDeLaSimCard = rowInfo.Field<double?>("ValorDeLaSimCard");
            this.ValorBeneficio = rowInfo.Field<double?>("ValorBeneficio");
            this.CondicionesBeneficio = rowInfo.Field<string>("CondicionesBeneficio");
            this.CodigoBeneficioRecurrente = rowInfo.Field<string>("CodigoBeneficioRecurrente");
            this.CondicionesBeneficioBasico = rowInfo.Field<string>("CondicionesBeneficioBasico");
            this.CodigoBeneficioBasico = rowInfo.Field<string>("CodigoBeneficioBasico");
        }
    }
}