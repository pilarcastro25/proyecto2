namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_ESTADOS_SOLICITUD
    {
        public int ID_ESTADO_SOLICITUD { get; set; }
        public string ESTADO_SOLICITUD { get; set; }
    }
}
