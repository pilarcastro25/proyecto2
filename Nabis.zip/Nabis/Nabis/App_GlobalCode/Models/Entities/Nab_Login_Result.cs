namespace Nabis.Models.Entities
{
    using System;
    
    public partial class Nab_Login_Result
    {
        public string USR_ID { get; set; }
        public Nullable<decimal> CC { get; set; }
        public string USR_LOGIN { get; set; }
        public string USR_PASS { get; set; }
        public string USR_NOMBRE { get; set; }
        public string USR_MAIL { get; set; }
        public Nullable<int> ID_TIPO { get; set; }
        public Nullable<int> ID_AREA { get; set; }
        public Nullable<int> ID_GRUPO { get; set; }
        public Nullable<int> ID_PROCESO { get; set; }
        public string ROL { get; set; }
        public Nullable<int> COD_AGENTE { get; set; }
        public Nullable<decimal> COD_VENDEDOR { get; set; }
        public int ID_CANAL_VENDEDOR { get; set; }
        public string CANAL_VENDEDOR { get; set; }
        public string ESTADO_VENDEDOR { get; set; }
    }
}
