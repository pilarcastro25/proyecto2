namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_GRUPOS
    {
        public Nullable<int> ID_AREA { get; set; }
        public int ID_GRUPO { get; set; }
        public string GRUPO { get; set; }
    }
}
