namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_GLOBAL_USER_PROCESOS_MODULOS
    {
        public int ID_PROCESO { get; set; }
        public Nullable<int> ID_MODULO { get; set; }
    }
}
