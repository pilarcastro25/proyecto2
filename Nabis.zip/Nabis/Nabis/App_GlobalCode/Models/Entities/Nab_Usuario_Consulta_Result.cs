namespace Nabis.Models.Entities
{
    using System;

    public partial class Nab_Usuario_Consulta_Result
    {
        public string USR_ID { get; set; }
        public string USR_LOGIN { get; set; }
        public string USR_NOMBRE { get; set; }
        public string USR_MAIL { get; set; }
        public string REGIONAL { get; set; }
        public string AREA { get; set; }
        public string GRUPO { get; set; }
        public string PROCESO { get; set; }
        public Nullable<decimal> USR_CELULAR { get; set; }
        public string TIPO { get; set; }
        public string ESTADO { get; set; }
        public string CLAVE { get; set; }
        public string PERFIL { get; set; }
        public Nullable<int> CONTADOR { get; set; }
        public long? CC { get; set; }
        public int? COD_VENDEDOR { get; set; }
        public int? COD_AGENTE { get; set; }
        public int? ID_CANAL_VENDEDOR { get; set; }
        public string CANAL_VENDEDOR { get; set; }
    }
}
