﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Entidad que representa la informacion de empresa en linea.
    /// </summary>
    public class nab_Empresa_linea
    {
        public int id_EmpresaLinea { get; set; }
        public string consecutivoNegocio { get; set; }
        public int cantLicencias { get; set; }
        public Int64 valorMensual { get; set; }
        public string ciudadFirma { get; set; }
        public string email { get; set; }

        public nab_Empresa_linea()
        {

        }

        public nab_Empresa_linea(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            /*this.consecutivoNegocio = rowInfo.Field<string>("consecutivoNegocio");
            this.cantLicencias = rowInfo.Field<int>("cantLicencias");
            this.valorMensual = rowInfo.Field<Int64>("valorMensual");
            this.ciudadFirma = rowInfo.Field<string>("ciudadFirma");
            this.email = rowInfo.Field<string>("email");*/
            this.consecutivoNegocio = rowInfo.Field<string>("ID_EB");
            this.cantLicencias = rowInfo.Field<int>("CANT_LICENCIAS");
            this.valorMensual = rowInfo.Field<Int64>("VALOR_MENSUAL");
            this.ciudadFirma = rowInfo.Field<string>("CIUDAD_FIRMA");
            this.email = rowInfo.Field<string>("E_MAIL");
        }
    }
}