﻿using Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Anexos de otros si de condiciones uniformes.
    /// </summary>
    public class NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES
    {
        public int ID_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES { get; set; }
        public string NUMERO_LINEA { get; set; }
        public string NUMERO_CELULAR { get; set; }
        public string CODIGO_PLAN_CODIGO_PLAN { get; set; }
        public string CODIGO_PLAN_RENTA_BASICA { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_VOZ_SI { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_VOZ_NO { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_SMS_SI { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_SMS_NO { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_DATOSSI { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_DATOSNO { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_LDISI { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_LDINO { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_PREMIUMSI { get; set; }
        public string CONTROL_CONDICIONES_SERVICIO_PREMIUMNO { get; set; }
        public string VALOR_MINUTO_INCLUIDO_VOZ_M { get; set; }
        public string VALOR_MINUTO_INCLUIDO_VOZ_F { get; set; }
        public string VALOR_MINUTO_INCLUIDO_VOZ_G { get; set; }
        public string VALOR_MINUTO_INCLUIDO_VOZ_O { get; set; }
        public string VALOR_MINUTO_ADICIONAL_VOZ_M { get; set; }
        public string VALOR_MINUTO_ADICIONAL_VOZ_F { get; set; }
        public string VALOR_MINUTO_ADICIONAL_VOZ_G { get; set; }
        public string VALOR_MINUTO_ADICIONAL_VOZ_O { get; set; }
        public string VALOR_MENSAJE_TEXTO_INCLUIDO_M { get; set; }
        public string VALOR_MENSAJE_TEXTO_INCLUIDO_G { get; set; }
        public string VALOR_MENSAJE_TEXTO_INCLUIDO_O { get; set; }
        public string VALOR_MENSAJE_TEXTO_ADICIONAL_M { get; set; }
        public string VALOR_MENSAJE_TEXTO_ADICIONAL_G { get; set; }
        public string VALOR_MENSAJE_TEXTO_ADICIONAL_O { get; set; }
        public string PLAN_DE_DATOS_CODIGO_SERVICIO { get; set; }
        public string PLAN_DE_DATOS_RENTA_MENSUAL { get; set; }
        public string PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN { get; set; }
        public string PLAN_DE_DATOSKBADICIONAL { get; set; }
        public string EQUIPO_TRAIDO { get; set; }
        public string EQUIPO_VENDIDO { get; set; }
        public string EQUIPO_MARCA_EQUIPO { get; set; }
        public string EQUIPO_REF_MODELO { get; set; }
        public string EQUIPO_NOSERIAL_IMEI { get; set; }
        public string BANDA_EQUIPO_AWS { get; set; }
        public string BANDA_EQUIPO_AWS_2500MHZ { get; set; }
        public string BANDA_EQUIPO_OTRA { get; set; }
        public string EQUIPO_VENTA_CUOTAS_SI { get; set; }
        public string EQUIPO_VENTA_CUOTAS_NO { get; set; }
        public string CUOTA_INICIAL { get; set; }
        public string VALOR_A_DIFERIR_EN_CUOTAS { get; set; }
        public string NO_DE_CUOTAS_A_DIFERIR { get; set; }
        public string NO_SIMCARD89 { get; set; }
        public string ID_CODIGO_NEGOCIO { get; set; }

        /// <summary>
        /// Constructor basico
        /// </summary>
        public NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES()
        {

        }

        /// <summary>
        /// Cosntructor que recibe por parametro el registro de un DataTable.
        /// </summary>
        /// <param name="rowInfo"></param>
        public NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.NUMERO_LINEA = rowInfo.Field<string>("NUMERO_LINEA");
            this.NUMERO_CELULAR = rowInfo.Field<string>("NUMERO_CELULAR");
            this.CODIGO_PLAN_CODIGO_PLAN = rowInfo.Field<string>("CODIGO_PLAN_CODIGO_PLAN");
            this.CODIGO_PLAN_RENTA_BASICA = rowInfo.Field<string>("CODIGO_PLAN_RENTA_BASICA");
            this.CONTROL_CONDICIONES_SERVICIO_VOZ_SI = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_VOZ_SI");
            this.CONTROL_CONDICIONES_SERVICIO_VOZ_NO = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_VOZ_NO");
            this.CONTROL_CONDICIONES_SERVICIO_SMS_SI = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_SMS_SI");
            this.CONTROL_CONDICIONES_SERVICIO_SMS_NO = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_SMS_NO");
            this.CONTROL_CONDICIONES_SERVICIO_DATOSSI = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_DATOSSI");
            this.CONTROL_CONDICIONES_SERVICIO_DATOSNO = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_DATOSNO");
            this.CONTROL_CONDICIONES_SERVICIO_LDISI = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_LDISI");
            this.CONTROL_CONDICIONES_SERVICIO_LDINO = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_LDINO");
            this.CONTROL_CONDICIONES_SERVICIO_PREMIUMSI = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_PREMIUMSI");
            this.CONTROL_CONDICIONES_SERVICIO_PREMIUMNO = rowInfo.Field<string>("CONTROL_CONDICIONES_SERVICIO_PREMIUMNO");
            this.VALOR_MINUTO_INCLUIDO_VOZ_M = rowInfo.Field<string>("VALOR_MINUTO_INCLUIDO_VOZ_M");
            this.VALOR_MINUTO_INCLUIDO_VOZ_F = rowInfo.Field<string>("VALOR_MINUTO_INCLUIDO_VOZ_F");
            this.VALOR_MINUTO_INCLUIDO_VOZ_G = rowInfo.Field<string>("VALOR_MINUTO_INCLUIDO_VOZ_G");
            this.VALOR_MINUTO_INCLUIDO_VOZ_O = rowInfo.Field<string>("VALOR_MINUTO_INCLUIDO_VOZ_O");
            this.VALOR_MINUTO_ADICIONAL_VOZ_M = rowInfo.Field<string>("VALOR_MINUTO_ADICIONAL_VOZ_M");
            this.VALOR_MINUTO_ADICIONAL_VOZ_F = rowInfo.Field<string>("VALOR_MINUTO_ADICIONAL_VOZ_F");
            this.VALOR_MINUTO_ADICIONAL_VOZ_G = rowInfo.Field<string>("VALOR_MINUTO_ADICIONAL_VOZ_G");
            this.VALOR_MINUTO_ADICIONAL_VOZ_O = rowInfo.Field<string>("VALOR_MINUTO_ADICIONAL_VOZ_O");
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_M = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_M");
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_G = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_G");
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_O = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_O");
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_M = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_M");
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_G = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_G");
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_O = rowInfo.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_O");
            this.PLAN_DE_DATOS_CODIGO_SERVICIO = rowInfo.Field<string>("PLAN_DE_DATOS_CODIGO_SERVICIO");
            this.PLAN_DE_DATOS_RENTA_MENSUAL = rowInfo.Field<string>("PLAN_DE_DATOS_RENTA_MENSUAL");
            this.PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN = rowInfo.Field<string>("PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN");
            this.PLAN_DE_DATOSKBADICIONAL = rowInfo.Field<string>("PLAN_DE_DATOSKBADICIONAL");
            this.EQUIPO_TRAIDO = rowInfo.Field<string>("EQUIPO_TRAIDO");
            this.EQUIPO_VENDIDO = rowInfo.Field<string>("EQUIPO_VENDIDO");
            this.EQUIPO_MARCA_EQUIPO = rowInfo.Field<string>("EQUIPO_MARCA_EQUIPO");
            this.EQUIPO_REF_MODELO = rowInfo.Field<string>("EQUIPO_REF_MODELO");
            this.EQUIPO_NOSERIAL_IMEI = rowInfo.Field<string>("EQUIPO_NOSERIAL_IMEI");
            this.BANDA_EQUIPO_AWS = rowInfo.Field<string>("BANDA_EQUIPO_AWS");
            this.BANDA_EQUIPO_AWS_2500MHZ = rowInfo.Field<string>("BANDA_EQUIPO_AWS_2500MHZ");
            this.BANDA_EQUIPO_OTRA = rowInfo.Field<string>("BANDA_EQUIPO_OTRA");
            this.EQUIPO_VENTA_CUOTAS_SI = rowInfo.Field<string>("EQUIPO_VENTA_CUOTAS_SI");
            this.EQUIPO_VENTA_CUOTAS_NO = rowInfo.Field<string>("EQUIPO_VENTA_CUOTAS_NO");
            this.CUOTA_INICIAL = rowInfo.Field<string>("CUOTA_INICIAL");
            this.VALOR_A_DIFERIR_EN_CUOTAS = rowInfo.Field<string>("VALOR_A_DIFERIR_EN_CUOTAS");
            this.NO_DE_CUOTAS_A_DIFERIR = rowInfo.Field<string>("NO_DE_CUOTAS_A_DIFERIR");
            this.NO_SIMCARD89 = rowInfo.Field<string>("NO_SIMCARD89");
            this.ID_CODIGO_NEGOCIO = rowInfo.Field<string>("ID_CODIGO_NEGOCIO");
        }

        /// <summary>
        /// Constructor que recibe por parametro la informacion de una linea 
        /// de anexos de otros si
        /// </summary>
        /// <param name="linea"></param>
        public NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES(LineaInfo linea)
        {
            if (linea == null)
            {
                throw new ArgumentNullException("linea", "El valor de linea no puede ser un valor nulo o vacio.");
            }
            this.NUMERO_LINEA = linea.NumeroLinea;
            this.NUMERO_CELULAR = linea.NumeroCelular;
            this.CODIGO_PLAN_CODIGO_PLAN = linea.CodigoPlanCodigodeplan;
            this.CODIGO_PLAN_RENTA_BASICA = linea.CodigoPlanRentaBasica;
            this.CONTROL_CONDICIONES_SERVICIO_VOZ_SI = linea.ControlCondicionesServicioVozSi;
            this.CONTROL_CONDICIONES_SERVICIO_VOZ_NO = linea.ControlCondicionesServicioVozNo;
            this.CONTROL_CONDICIONES_SERVICIO_SMS_SI = linea.ControlCondicionesServicioSMSSi;
            this.CONTROL_CONDICIONES_SERVICIO_SMS_NO = linea.ControlCondicionesServicioSMSNo;
            this.CONTROL_CONDICIONES_SERVICIO_DATOSSI = linea.ControlCondicionesServicioDatosSi;
            this.CONTROL_CONDICIONES_SERVICIO_DATOSNO = linea.ControlCondicionesServicioDatosNo;
            this.CONTROL_CONDICIONES_SERVICIO_LDISI = linea.ControlCondicionesServicioLDISi;
            this.CONTROL_CONDICIONES_SERVICIO_LDINO = linea.ControlCondicionesServicioLDINo;
            this.CONTROL_CONDICIONES_SERVICIO_PREMIUMSI = linea.ControlCondicionesServicioPremiumSi;
            this.CONTROL_CONDICIONES_SERVICIO_PREMIUMNO = linea.ControlCondicionesServicioPremiumNo;
            this.VALOR_MINUTO_INCLUIDO_VOZ_M = linea.ValorMinutoIncluidoVoz_M;
            this.VALOR_MINUTO_INCLUIDO_VOZ_F = linea.ValorMinutoIncluidoVoz_F;
            this.VALOR_MINUTO_INCLUIDO_VOZ_G = linea.ValorMinutoIncluidoVoz_G;
            this.VALOR_MINUTO_INCLUIDO_VOZ_O = linea.ValorMinutoIncluidoVoz_O;
            this.VALOR_MINUTO_ADICIONAL_VOZ_M = linea.ValorMinutoAdicionalVoz_M;
            this.VALOR_MINUTO_ADICIONAL_VOZ_F = linea.ValorMinutoAdicionalVoz_F;
            this.VALOR_MINUTO_ADICIONAL_VOZ_G = linea.ValorMinutoAdicionalVoz_G;
            this.VALOR_MINUTO_ADICIONAL_VOZ_O = linea.ValorMinutoAdicionalVoz_O;
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_M = linea.ValorMensajedeTextoIncluido_M;
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_G = linea.ValorMensajedeTextoIncluido_G;
            this.VALOR_MENSAJE_TEXTO_INCLUIDO_O = linea.ValorMensajedeTextoIncluido_O;
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_M = linea.ValorMensajedeTextoAdicional_M;
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_G = linea.ValorMensajedeTextoAdicional_G;
            this.VALOR_MENSAJE_TEXTO_ADICIONAL_O = linea.ValorMensajedeTextoAdicional_O;
            this.PLAN_DE_DATOS_CODIGO_SERVICIO = linea.PlanDeDatosCodigoServicio;
            this.PLAN_DE_DATOS_RENTA_MENSUAL = linea.PlanDeDatosRentaMensual;
            this.PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN = linea.PlanDeDatosCapacidaddelPlan;
            this.PLAN_DE_DATOSKBADICIONAL = linea.PlanDeDatosKBAdicional;
            this.EQUIPO_TRAIDO = linea.EquipoTraido;
            this.EQUIPO_VENDIDO = linea.EquipoVendido;
            this.EQUIPO_MARCA_EQUIPO = linea.EquipoMarcaEquipo;
            this.EQUIPO_REF_MODELO = linea.EquipoRefModelo;
            this.EQUIPO_NOSERIAL_IMEI = linea.EquipoNoSerialIMEI;
            this.BANDA_EQUIPO_AWS = linea.BandaEquipoAWS;
            this.BANDA_EQUIPO_AWS_2500MHZ = linea.BandaEquipoAWS_2500MHZ;
            this.BANDA_EQUIPO_OTRA = linea.BandaEquipoOTRA;
            this.EQUIPO_VENTA_CUOTAS_SI = linea.EquipoVentaCuotas_SI;
            this.EQUIPO_VENTA_CUOTAS_NO = linea.EquipoVentaCuotas_NO;
            this.CUOTA_INICIAL = linea.CuotaInicial;
            this.VALOR_A_DIFERIR_EN_CUOTAS = linea.ValoraDiferirenCuotas;
            this.NO_DE_CUOTAS_A_DIFERIR = linea.NodeCuotasaDiferir;
            this.NO_SIMCARD89 = linea.NoSIMCARD89;
            this.ID_CODIGO_NEGOCIO = linea.CodigoNegocio;
        }
    }
}

