﻿// ===================================================================================================
// Desarrollado Por		    :   Harold Caicedo
// Fecha de Creación		:   2016/09/28.
// Producto o sistema	    :   
// Empresa			        :   
// Proyecto			        :   
// Cliente			        :   
// ===================================================================================================
// Versión	        Descripción
// 1.0.0.0	        Entidad que mapea la informacion de clientes robot en E-bussines.
//             
// ===================================================================================================
// HISTORIAL DE CAMBIOS:
// ===================================================================================================
// Ver.	 Fecha		    Autor					Descripción
// ---	 -------------	----------------------	------------------------------------------------------
// XX	 yyyy/MM/dd	    [Nombre Completo]	    [Razón del cambio realizado] 
// ===================================================================================================
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    /// <summary>
    /// Entidad que mapea la informacion de clientes robot en E-bussines.
    /// </summary>
    public class BC_RobSCL_Clientes
    {
        /// <summary>
        /// Codigo del cliente
        /// </summary>
        public string  Cod_Cliente { get; set; }
        /// <summary>
        /// Codigo de la cuenta
        /// </summary>
        public int Cod_Cuenta { get; set; }
        /// <summary>
        /// Tipo de identificacion
        /// </summary>
        public string Tip_Ident { get; set; }
        /// <summary>
        /// Numero de identificacion
        /// </summary>
        public string Num_Ident { get; set; }
        /// <summary>
        /// Fecha de nacimiento del cliente
        /// </summary>
        public DateTime? Fec_Nacimiento { get; set; }

        public BC_RobSCL_Clientes()
        {

        }
        
        /// <summary>
        /// Constructor que recibe un datarow de un datatable.
        /// </summary>
        /// <param name="rowInfo"></param>
        public BC_RobSCL_Clientes(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor no puede ser un valor nulo o vacio.");
            }
            this.Cod_Cliente = rowInfo.Field<string>("Cod_Cliente");
            this.Cod_Cuenta = rowInfo.Field<int>("Cod_Cuenta");
            this.Tip_Ident = rowInfo.Field<string>("Tip_Ident");
            this.Num_Ident = rowInfo.Field<string>("Num_Ident");
            this.Fec_Nacimiento = rowInfo.Field<DateTime?>("Fec_Nacimiento");
        }
    }
}