﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.Entities
{
    public class AnexoCondicionesUniformesContrato
    {
        public string IdEb { get; set; }
        public bool Renovacion { get; set; }
    }
}