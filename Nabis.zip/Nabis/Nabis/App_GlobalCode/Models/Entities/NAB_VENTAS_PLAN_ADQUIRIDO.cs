namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Web.Script.Serialization;
    
    public partial class NAB_VENTAS_PLAN_ADQUIRIDO
    {
        public int ID_DESCRIPCION_PLAN { get; set; }
        public string ID_PLAN_TARIFARIO { get; set; }
        public int CANTIDAD_LINEAS { get; set; }
        public Nullable<int> VALOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> VALOR_OTROS_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_1_VALOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_1_VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_1_VALOR_OTROS_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_2_VALOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_2_VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_2_VALOR_OTROS_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_3_VAOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_3_VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> SERVICIO_ADICIONAL_3_VALOR_OTROS_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_1_VALOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_1_VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_1_VALOR_OTROS_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_2_VALOR_MOVISTAR_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_2_VALOR_FIJO_VOZ { get; set; }
        public Nullable<int> PLAN_ADICIONAL_2_VALOR_OTROS_VOZ { get; set; }
        public string PLAN_DATOS_RENTA_MES { get; set; }
        public string PLAN_DATOS_KB_INCLUIDO { get; set; }
        public string PLAN_DATOS_KB_ADICIONAL { get; set; }
        public string ID_CODIGO_NEGOCIO { get; set; }
    
        [ScriptIgnore]
        public virtual NAB_EB_NEGOCIOS NAB_EB_NEGOCIOS { get; set; }
    }
}
