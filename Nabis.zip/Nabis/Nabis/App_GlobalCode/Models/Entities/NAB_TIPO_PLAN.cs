namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class NAB_TIPO_PLAN
    {
        public NAB_TIPO_PLAN()
        {
            this.NAB_PLANES = new HashSet<NAB_PLANES>();
        }
    
        public int IdTipoPlan { get; set; }
        public string TipoPlan { get; set; }
    
        public virtual ICollection<NAB_PLANES> NAB_PLANES { get; set; }
    }
}
