namespace Nabis.Models.Entities
{
    using System;
    using System.Collections.Generic;
    
    public partial class USERS_PERFILES
    {
        public decimal ID_PERFIL { get; set; }
        public string PERFIL { get; set; }
        public Nullable<short> ID_MODULO { get; set; }
    }
}
