﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    public class CREDITO_ESTRUCTURA_VENTA
    {
        public string TipoVentaCelular { get; set; }
        public int CantidadLineas { get; set; }




        public CREDITO_ESTRUCTURA_VENTA(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("row", "El valor de registro no puede ser un valor nulo o vacio.");
            }
            this.TipoVentaCelular = rowInfo.Field<string>("Modalidad_Venta");
            this.CantidadLineas = rowInfo.Field<int>("Lineas");
    
        }
    }
}