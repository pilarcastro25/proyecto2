﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    public class AnexoModificatorioModel
    {
        public string Solicitud { get; set; }
        public string Cliente { get; set; }
        public string NIT { get; set; }
        #region firma digital
        //public int MyProperty { get; set; }
        #endregion
    }
}