﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using PlantillasTablas.Objetos;
using System.IO;
using System.Globalization;
using Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities;

namespace Nabis.Models.AnexoOtroSiCondicionesUniformes.Templates
{
    public class Anexo
    {
        /// <summary>
        /// Objeto tabla en el que se construye el cuerpo de la tabla
        /// </summary>
        private PdfPTable bodyTable;

        /// <summary>
        /// Objeto tabla en el que se construye el encabezado de la tabla
        /// </summary>
        private PdfPTable headerTable;

        /// <summary>
        /// Objeto tabla en el que se contruye el footer de la tabla
        /// </summary>
        private PdfPTable footerTable;

        /// <summary>
        /// Texto del encabezado
        /// </summary>
        Paragraph headerParagraph;
        Document doc;
        FileStream destinationStream;
        PdfWriter writer;
        protected Font myFont;
        protected float[] widths;
        BaseColor color;
        PdfPCell cell;

        public Anexo(string destino)
        {
            color = new BaseColor(228, 223, 236);
            myFont = FontFactory.GetFont("Calibri", 3);
            this.doc = new Document();
            destinationStream = new FileStream(destino, FileMode.Create);
            writer = PdfWriter.GetInstance(doc, destinationStream);
            doc.SetPageSize(iTextSharp.text.PageSize.LETTER.Rotate());
            doc.SetMargins(20, 20, 32, 32);
            doc.Open();
            doc.NewPage();

            #region Vector de Tamaños de celda
            widths = new float[]
            {
                1 // #0 No.
               ,5 // #1 Numero Celular
               ,3 // #2 Codigo de plan
               ,3 // #3 Renta Basica
               ,1 // #4 Voz Si
               ,1 // #5 Voz No
               ,1 // #6 SMS Si
               ,1 // #7 SMS No
               ,1 // #8 Datos Si
               ,1 // #9 Datos No
               ,1 // #10 LDI Si
               ,1 // #11 LDI No
               ,1 // #12 Premium Si
               ,1 // #13 Premium No
               ,1 // #14 Valor Minuto Incluido Voz 'M'
               ,1 // #15 Valor Minuto Incluido Voz 'F'
               ,1 // #16 Valor Minuto Incluido Voz 'G'
               ,1 // #17 Valor Minuto Incluido Voz 'O'
               ,1 // #18 Valor Minuto Adicional Voz 'M'
               ,1 // #19 Valor Minuto Adicional Voz 'F'
               ,1 // #20 Valor Minuto Adicional Voz 'G'
               ,1 // #21 Valor Minuto Adicional Voz 'O'
               ,1 // #22 Valor Mensaje de Texto Incluido 'M'
               ,1 // #23 Valor Mensaje de Texto Incluido 'G'
               ,1 // #24 Valor Mensaje de Texto Incluido 'O'
               ,1 // #25 Valor Mensaje de Texto Adicional 'M'
               ,1 // #26 Valor Mensaje de Texto Adicional 'G'
               ,1 // #27 Valor Mensaje de Texto Adicional 'O'
               ,5 // #28 Codigo Servicio
               ,5 // #29 Renta Mensual
               ,4 // #30 Capacidad del Plan
               ,3 // #31 KB Adicional
               ,1 // #32 Traido
               ,1 // #33 Vendido
               ,3 // #34 Marca Equipo
               ,3 // #35 Ref. Modelo
               ,3 // #36 No. Serial/IMEI
               ,2 // #37 AWS
               ,3 // #38 AWS-2500MHZ
               ,3 // #39 OTRA
               ,1 // #40 Equipo Venta a Cuotas 'SI'
               ,1 // #41 Equipo Venta a Cuotas 'NO'
               ,3 // #42 Cuota Inicial
               ,3 // #43 Valor a diferir en cuotas
               ,2 //#44 No. de Cuotas a diferir
               ,3 // #45 No. SIM CARD 89
            };
            #endregion

            bodyTable = new PdfPTable(widths.Length);
            bodyTable.Complete = false;
            bodyTable.WidthPercentage = 100f;
            bodyTable.SetWidths(widths);
            bodyTable.DefaultCell.FixedHeight = 6;

            footerTable = new PdfPTable(widths.Length);
            footerTable.WidthPercentage = 100f;
            footerTable.SetWidths(widths);
        }

        /// <summary>
        /// Genera el anexo
        /// </summary>
        public void GenerarTabla(AnexoInfo anexoInfo)
        {
            if (anexoInfo.Lineas.Count > 0 && anexoInfo != null)
            {
                GenerateHeader(anexoInfo);
                GenerateFooter(anexoInfo);

                int numeroObjetos = anexoInfo.Lineas.Count;
                int numeroColumnas = bodyTable.NumberOfColumns;

                int j = 0;

                AddHeader();

                foreach (LineaInfo linea in anexoInfo.Lineas)
                {
                    linea.NumeroLinea = (anexoInfo.Lineas.IndexOf(linea) + 1).ToString();
                    MapPropertiesToTable(linea, bodyTable);

                    if (j % 100 == 0 && j < numeroObjetos && j > 0)
                    {
                        this.doc.Add(bodyTable);
                    }
                    j++;
                }
                this.doc.Add(bodyTable);
                bodyTable.FlushContent();
                bodyTable.Complete = true;
                this.doc.Add(footerTable);
                this.doc.Close();
            }
        }

        /// <summary>
        /// Mapea las propiedades del objeto Linea a la tabla
        /// </summary>
        /// <param name="linea"></param>
        /// <param name="table"></param>
        private void MapPropertiesToTable(LineaInfo linea, PdfPTable table)
        {
            //#0
            this.AddCellText(table, linea.NumeroLinea);
            //#1
            this.AddCellText(table, linea.NumeroCelular);
            //#2
            this.AddCellText(table, linea.CodigoPlanCodigodeplan);
            //#3
            this.AddCellText(table, linea.CodigoPlanRentaBasica);
            //#4
            this.AddCellText(table, linea.ControlCondicionesServicioVozSi);
            //#5
            this.AddCellText(table, linea.ControlCondicionesServicioVozNo);
            //#6
            this.AddCellText(table, linea.ControlCondicionesServicioSMSSi);
            //#7
            this.AddCellText(table, linea.ControlCondicionesServicioSMSNo);
            //#8
            this.AddCellText(table, linea.ControlCondicionesServicioDatosSi);
            //#9
            this.AddCellText(table, linea.ControlCondicionesServicioDatosNo);
            //#10
            this.AddCellText(table, linea.ControlCondicionesServicioLDISi);
            //#11
            this.AddCellText(table, linea.ControlCondicionesServicioLDINo);
            //#12
            this.AddCellText(table, linea.ControlCondicionesServicioPremiumSi);
            //#13
            this.AddCellText(table, linea.ControlCondicionesServicioPremiumNo);
            //#14
            this.AddCellText(table, linea.ValorMinutoIncluidoVoz_M);
            //#15
            this.AddCellText(table, linea.ValorMinutoIncluidoVoz_F);
            //#16
            this.AddCellText(table, linea.ValorMinutoIncluidoVoz_G);
            //#17
            this.AddCellText(table, linea.ValorMinutoIncluidoVoz_O);
            //#18
            this.AddCellText(table, linea.ValorMinutoAdicionalVoz_M);
            //#19
            this.AddCellText(table, linea.ValorMinutoAdicionalVoz_F);
            //#20
            this.AddCellText(table, linea.ValorMinutoAdicionalVoz_G);
            //#21
            this.AddCellText(table, linea.ValorMinutoAdicionalVoz_O);
            //#22
            this.AddCellText(table, linea.ValorMensajedeTextoIncluido_M);
            //#23
            this.AddCellText(table, linea.ValorMensajedeTextoIncluido_G);
            //#24
            this.AddCellText(table, linea.ValorMensajedeTextoIncluido_O);
            //#25
            this.AddCellText(table, linea.ValorMensajedeTextoAdicional_M);
            //#26
            this.AddCellText(table, linea.ValorMensajedeTextoAdicional_G);
            //#27
            this.AddCellText(table, linea.ValorMensajedeTextoAdicional_O);
            //#28
            this.AddCellText(table, linea.PlanDeDatosCodigoServicio);
            //#29
            this.AddCellText(table, linea.PlanDeDatosRentaMensual);
            //#30
            this.AddCellText(table, linea.PlanDeDatosCapacidaddelPlan);
            //#31
            this.AddCellText(table, linea.PlanDeDatosKBAdicional);
            //#32
            this.AddCellText(table, linea.EquipoTraido);
            //#33
            this.AddCellText(table, linea.EquipoVendido);
            //#34
            this.AddCellText(table, linea.EquipoMarcaEquipo);
            //#35
            this.AddCellText(table, linea.EquipoRefModelo);
            //#36
            this.AddCellText(table, linea.EquipoNoSerialIMEI);
            //#37
            this.AddCellText(table, linea.BandaEquipoAWS);
            //#38
            this.AddCellText(table, linea.BandaEquipoAWS_2500MHZ);
            //#39
            this.AddCellText(table, linea.BandaEquipoOTRA);
            //#40
            this.AddCellText(table, linea.EquipoVentaCuotas_SI);
            //#41
            this.AddCellText(table, linea.EquipoVentaCuotas_NO);
            //#42
            this.AddCellText(table, linea.CuotaInicial);
            //#43
            this.AddCellText(table, linea.ValoraDiferirenCuotas);
            //#44
            this.AddCellText(table, linea.NodeCuotasaDiferir);
            //#45
            this.AddCellText(table, linea.NoSIMCARD89);
        }

        /// <summary>
        /// Añade el encabezado a la página
        /// </summary>
        private void AddHeader()
        {
            this.doc.Add(headerParagraph);
            this.doc.Add(headerTable);
        }

        /// <summary>
        /// Añade una celda a una tabla en específico
        /// </summary>
        /// <param name="table">Tabla para añadir la celda</param>
        /// <param name="text">Texto en la celda</param>
        private void AddCellText(PdfPTable table, string text)
        {
            if (text == null)
            {
                text = string.Empty;
            }
            cell = new PdfPCell(new Phrase(text, myFont));
            table.AddCell(cell);
        }

        /// <summary>
        /// Añade una celda a una tabla en específico
        /// </summary>
        /// <param name="table">Tabla para añadir la celda</param>
        /// <param name="text">Texto en la celda</param>
        /// <param name="colspan">Numero de columnas a fusionar</param>
        /// <param name="rowspan">Numero de filas a fusionar</param>
        private void AddCellText(PdfPTable table, string text, int colspan, int rowspan)
        {
            if (text == null)
            {
                text = string.Empty;
            }
            cell = new PdfPCell(new Phrase(text, myFont));
            cell.Padding = 1;
            cell.Rowspan = rowspan;
            cell.Colspan = colspan;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            cell.Normalize();
            table.AddCell(cell);
        }

        /// <summary>
        /// Añade una celda a una tabla en específico
        /// </summary>
        /// <param name="table">Tabla a añadir la celda</param>
        /// <param name="text">Texto en la celda</param>
        /// <param name="colspan">Numero de columnas a fusionar</param>
        /// <param name="rowspan">Numero de filas a fusionar</param>
        /// <param name="backgroundColor">Color de fondo de la celda</param>
        private void AddCellText(PdfPTable table, string text, int colspan, int rowspan, BaseColor backgroundColor)
        {
            if (text == null)
                text = string.Empty;

            cell = new PdfPCell(new Phrase(text, myFont));
            cell.Padding = 1;

            if (backgroundColor != null)
                cell.BackgroundColor = backgroundColor;

            cell.Rowspan = rowspan;
            cell.Colspan = colspan;
            cell.VerticalAlignment = Element.ALIGN_MIDDLE;
            cell.HorizontalAlignment = Element.ALIGN_CENTER;
            table.AddCell(cell);
        }

        private void AddCellParagraph(PdfPTable table, Phrase paragraph, int colspan, int rowspan)
        {
            cell = new PdfPCell();
            cell.VerticalAlignment = PdfPCell.ALIGN_TOP;
            cell.Rowspan = rowspan;
            cell.Colspan = colspan;
            cell.Phrase = paragraph;
            table.AddCell(cell);
        }

        /// <summary>
        /// Inicializa el header
        /// </summary>
        private void GenerateHeader(AnexoInfo obj)
        {
            //Texto header
            string str = string.Format("Otro si  N Contrato {0} o Formato de Condiciones uniformes para servicios de Telefonía Móvil Celular de Datos N° Contrato {0} ", obj.NoContrato);
            Chunk chu = new Chunk(str, FontFactory.GetFont(FontFactory.TIMES_BOLD, 4f));
            headerParagraph = new Paragraph(chu);
            headerParagraph.SpacingAfter = 2;

            //===========Primera fila del header===================//
            headerTable = new PdfPTable(bodyTable.NumberOfColumns);
            headerTable.DefaultCell.BackgroundColor = color;
            headerTable.WidthPercentage = 100f;
            headerTable.SetWidths(widths);
            headerTable.DefaultCell.MinimumHeight = 6;
            this.AddCellText(headerTable, "#", 1, 6, color);
            this.AddCellText(headerTable, "TABLA No.1", 1, 3, color);
            this.AddCellText(headerTable, "CODIGO PLAN", 2, 3, color);
            this.AddCellText(headerTable, "CONTROL CONDICIONES DEL SERVICIO", 10, 3, color);
            this.AddCellText(headerTable, "VALOR MINUTO INCLUIDO VOZ", 4, 3, color);
            this.AddCellText(headerTable, "VALOR MINUTO ADICIONAL VOZ", 4, 3, color);
            this.AddCellText(headerTable, "VALOR MENSAJE DE TEXTO INCLUIDO", 3, 3, color);
            this.AddCellText(headerTable, "VALOR MENSAJE DE TEXTO ADICIONAL", 3, 3, color);
            this.AddCellText(headerTable, "PLAN DE DATOS", 4, 3, color);
            this.AddCellText(headerTable, "EQUIPO", 5, 3, color);
            this.AddCellText(headerTable, "BANDA EN LA QUE OPERA EL EQUIPO", 3, 3, color);
            this.AddCellText(headerTable, "EQUIPO A CUOTAS", 2, 3, color);
            this.AddCellText(headerTable, "CUOTA INICIAL", 1, 6, color);
            this.AddCellText(headerTable, "VALOR A DIFERIR EN CUOTAS", 1, 6, color);
            this.AddCellText(headerTable, "No. DE CUOTAS A DIFERIR", 1, 6, color);
            this.AddCellText(headerTable, "No. SIM CARD 8957123", 1, 6, color);

            //============Segunda fila del header================//
            this.AddCellText(headerTable, "No.CELULAR", 1, 2, color);
            this.AddCellText(headerTable, "CODIGO", 1, 2, color);
            this.AddCellText(headerTable, "RENTA BASICA", 1, 2, color);
            this.AddCellText(headerTable, "VOZ", 2, 1, color);
            this.AddCellText(headerTable, "SMS", 2, 1, color);
            this.AddCellText(headerTable, "DATOS", 2, 1, color);
            this.AddCellText(headerTable, "LDI", 2, 1, color);
            this.AddCellText(headerTable, "PREMIUM", 2, 1, color);
            //Valor Incluido Voz
            this.AddCellText(headerTable, "M", 1, 2, color);
            this.AddCellText(headerTable, "F", 1, 2, color);
            this.AddCellText(headerTable, "G", 1, 2, color);
            this.AddCellText(headerTable, "O", 1, 2, color);
            //Valor Adicional Voz
            this.AddCellText(headerTable, "M", 1, 2, color);
            this.AddCellText(headerTable, "F", 1, 2, color);
            this.AddCellText(headerTable, "G", 1, 2, color);
            this.AddCellText(headerTable, "O", 1, 2, color);
            //Valor Mensaje de Texto Incluido
            this.AddCellText(headerTable, "M", 1, 2, color);
            this.AddCellText(headerTable, "G", 1, 2, color);
            this.AddCellText(headerTable, "O", 1, 2, color);
            //Valor Mensaje de Texto Adicional
            this.AddCellText(headerTable, "M", 1, 2, color);
            this.AddCellText(headerTable, "G", 1, 2, color);
            this.AddCellText(headerTable, "O", 1, 2, color);
            this.AddCellText(headerTable, "CODIGO SERVICIO", 1, 2, color);
            this.AddCellText(headerTable, "RENTA MENSUAL", 1, 2, color);
            this.AddCellText(headerTable, "CAPACIDAD DEL PLAN", 1, 2, color);
            this.AddCellText(headerTable, "KB ADICIONAL", 1, 2, color);
            this.AddCellText(headerTable, "TRAIDO", 1, 2, color);
            this.AddCellText(headerTable, "VENDIDO", 1, 2, color);
            this.AddCellText(headerTable, "MARCA EQUIPO", 1, 2, color);
            this.AddCellText(headerTable, "REF.MODELO", 1, 2, color);
            this.AddCellText(headerTable, "No.SERIAL/IMEI", 1, 2, color);
            this.AddCellText(headerTable, "AWS", 1, 2, color);
            this.AddCellText(headerTable, "AWS-2500MHZ", 1, 2, color);
            this.AddCellText(headerTable, "OTRA", 1, 2, color);
            // Equipo a cuotas
            this.AddCellText(headerTable, "SI", 1, 2, color);
            this.AddCellText(headerTable, "NO", 1, 2, color);

            //===============Ultima Fila Header==============//
            this.AddCellText(headerTable, "SI", 1, 1, color);
            this.AddCellText(headerTable, "NO", 1, 1, color);
            this.AddCellText(headerTable, "SI", 1, 1, color);
            this.AddCellText(headerTable, "NO", 1, 1, color);
            this.AddCellText(headerTable, "SI", 1, 1, color);
            this.AddCellText(headerTable, "NO", 1, 1, color);
            this.AddCellText(headerTable, "SI", 1, 1, color);
            this.AddCellText(headerTable, "NO", 1, 1, color);
            this.AddCellText(headerTable, "SI", 1, 1, color);
            this.AddCellText(headerTable, "NO", 1, 1, color);
        }

        private void GenerateFooter(AnexoInfo obj)
        {
            Chunk chu = new Chunk("OBSERVACIONES: ", FontFactory.GetFont(FontFactory.TIMES_BOLD, 4f));
            Chunk chu2 = new Chunk("En este campo es importante incluir los detalles y beneficios adquiridos por Pricingmas todas las observaciones adicionales que se desean incluir, que asegure el correcto flujo de la venta.\n\n", FontFactory.GetFont(FontFactory.TIMES_ITALIC, 4f));
            Chunk chu3 = new Chunk(string.Format("{0}\n\n", obj.Observaciones), FontFactory.GetFont(FontFactory.TIMES, 5f));
            Phrase p = new Phrase();
            p.Add(chu);
            p.Add(chu2);
            p.Add(chu3);
            AddCellParagraph(footerTable, p, widths.Length, 6);
        }
    }
}