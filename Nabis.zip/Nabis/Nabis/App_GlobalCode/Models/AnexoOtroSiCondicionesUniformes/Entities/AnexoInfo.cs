﻿using Nabis.Models.AnexoOtroSiCondicionesUniformes.Templates;
using Nabis.Models.Entities;
using Nabis.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities
{
    /// <summary>
    /// Clase que contiene información de cada uno de los renglones 
    /// </summary>
    public class AnexoInfo
    {
        [ThreadStatic]
        private RadicacionNegocioRepository radicacionNegocioRepository;
        /// <summary>
        /// Repositorio de radicacion de negocio.
        /// </summary>
        public RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this.radicacionNegocioRepository == null)
                {
                    this.radicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return this.radicacionNegocioRepository;
            }
        }
        private static AnexoInfo anexoInfo;
        public List<LineaInfo> Lineas;
        public string NoContrato { get; set; }
        public string IDKoral { get; set; }
        public string IDPricing { get; set; }
        public string Observaciones { get; set; }

        /// <summary>
        /// Ruta en la cual se creará el pdf
        /// </summary>
        public string RutaPdf { get; set; }

        /// <summary>
        /// Singleton de la clase
        /// </summary>
        public static AnexoInfo AnexoInfoOtroSi
        {
            get
            {
                if (anexoInfo == null)
                {
                    anexoInfo = new AnexoInfo();
                }
                return anexoInfo;
            }
            set
            {
                anexoInfo = value;
            }
        }

        /// <summary>
        /// Crea una instancia del objeto Objeto anexo
        /// </summary>
        public AnexoInfo()
        {
            this.Lineas = new List<LineaInfo>();
        }

        /// <summary>
        /// Crea una instancia del objeto AnexoInfo, y establece la ruta en la cual se creará el pdf con la información de las lineas de dicho objeto
        /// </summary>
        /// <param name="rutaPDF">ruta en la cual se guardará el PDF</param>
        public AnexoInfo(string rutaPDF)
            : this()
        {
            if (string.IsNullOrEmpty(rutaPDF))
            {
                throw new ArgumentNullException("ruta", "La ruta no puede ser un valor nulo o vacio.");
            }
            else
            {
                this.RutaPdf = rutaPDF;
            }
        }

        /// <summary>
        /// Limpia la lista de objetos línea guardadas en el AnexoInfo
        /// </summary>
        public void LimpiarListaLineas()
        {
            this.Lineas.Clear();
        }

        /// <summary>
        /// Guarda la información de las líneas en la base de datos.
        /// </summary>
        public void GuardarLineasEnBaseDeDatos()
        {
            if (Lineas.Count > 0)
            {
                foreach (LineaInfo linea in Lineas)
                {
                    NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES info = new NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES(linea);
                    this.RadicacionNegocioRepository.GuardarAnexosOtrosSiCondicionesUniformes(info);
                }
                this.LimpiarListaLineas();
            }
        }

        /// <summary>
        /// Guarda la información de las líneas en el Anexo Otro sí en formato PDF
        /// </summary>
        /// <param name="ruta">Ruta en la cual se guardará el PDF.</param>
        public void GuardarLineasEnAnexoOtroSiPDF(string ruta)
        {
            if (string.IsNullOrEmpty(ruta))
            {
                throw new ArgumentNullException("ruta", "La ruta no puede ser un valor nulo o vacio.");
            }
            else
            {
                if (Lineas.Count > 0)
                {
                    Anexo OtroSi = new Anexo(ruta);
                    OtroSi.GenerarTabla(this);
                }
            }
        }

        /// <summary>
        /// Guarda la información de las líneas en el Anexo Otro sí en formato PDF
        /// </summary>
        public void GuardarLineasEnAnexoOtroSiPDF()
        {
            if (string.IsNullOrEmpty(RutaPdf))
            {
                throw new NullReferenceException("La propiedad RutaPdf no puede estar vacía o nula.");
            }
            else
            {
                if (Lineas.Count > 0)
                {
                    Anexo OtroSi = new Anexo(RutaPdf);
                    OtroSi.GenerarTabla(this);
                }
            }
        }
    }
}