﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities
{

    public class LineaInfo
    {

        #region Propiedades
        /// <summary>
        /// #0
        /// </summary>
        public string NumeroLinea { get; set; }
        /// <summary>
        /// #1
        /// </summary>
        public string NumeroCelular { get; set; }
        /// <summary>
        /// #2
        /// </summary>
        public string CodigoPlanCodigodeplan { get; set; }
        /// <summary>
        /// #3
        /// </summary>
        public string CodigoPlanRentaBasica { get; set; }
        /// <summary>
        /// #4
        /// </summary>
        public string ControlCondicionesServicioVozSi { get; set; }
        /// <summary>
        /// #5
        /// </summary>
        public string ControlCondicionesServicioVozNo { get; set; }
        /// <summary>
        /// #6
        /// </summary>
        public string ControlCondicionesServicioSMSSi { get; set; }
        /// <summary>
        /// #7
        /// </summary>
        public string ControlCondicionesServicioSMSNo { get; set; }
        /// <summary>
        /// #8
        /// </summary>
        public string ControlCondicionesServicioDatosSi { get; set; }
        /// <summary>
        /// #9
        /// </summary>
        public string ControlCondicionesServicioDatosNo { get; set; }
        /// <summary>
        /// #10
        /// </summary>
        public string ControlCondicionesServicioLDISi { get; set; }
        /// <summary>
        /// #11
        /// </summary>
        public string ControlCondicionesServicioLDINo { get; set; }
        /// <summary>
        /// #12
        /// </summary>
        public string ControlCondicionesServicioPremiumSi { get; set; }
        /// <summary>
        /// #13
        /// </summary>
        public string ControlCondicionesServicioPremiumNo { get; set; }
        /// <summary>
        /// #14
        /// </summary>
        public string ValorMinutoIncluidoVoz_M { get; set; }
        /// <summary>
        /// #15
        /// </summary>
        public string ValorMinutoIncluidoVoz_F { get; set; }
        /// <summary>
        /// #16
        /// </summary>
        public string ValorMinutoIncluidoVoz_G { get; set; }
        /// <summary>
        /// #17
        /// </summary>
        public string ValorMinutoIncluidoVoz_O { get; set; }
        /// <summary>
        /// #18
        /// </summary>
        public string ValorMinutoAdicionalVoz_M { get; set; }
        /// <summary>
        /// #19
        /// </summary>
        public string ValorMinutoAdicionalVoz_F { get; set; }
        /// <summary>
        /// #20
        /// </summary>
        public string ValorMinutoAdicionalVoz_G { get; set; }
        /// <summary>
        /// #21
        /// </summary>
        public string ValorMinutoAdicionalVoz_O { get; set; }
        /// <summary>
        /// #22
        /// </summary>
        public string ValorMensajedeTextoIncluido_M { get; set; }
        /// <summary>
        /// #23
        /// </summary>
        public string ValorMensajedeTextoIncluido_G { get; set; }
        /// <summary>
        /// #24
        /// </summary>
        public string ValorMensajedeTextoIncluido_O { get; set; }
        /// <summary>
        /// #25
        /// </summary>
        public string ValorMensajedeTextoAdicional_M { get; set; }
        /// <summary>
        /// #26
        /// </summary>
        public string ValorMensajedeTextoAdicional_G { get; set; }
        /// <summary>
        /// #27
        /// </summary>
        public string ValorMensajedeTextoAdicional_O { get; set; }
        /// <summary>
        /// #28
        /// </summary>
        public string PlanDeDatosCodigoServicio { get; set; }
        /// <summary>
        /// #29
        /// </summary>
        public string PlanDeDatosRentaMensual { get; set; }
        /// <summary>
        /// #30
        /// </summary>
        public string PlanDeDatosCapacidaddelPlan { get; set; }
        /// <summary>
        /// #31
        /// </summary>
        public string PlanDeDatosKBAdicional { get; set; }
        /// <summary>
        /// #32
        /// </summary>
        public string EquipoTraido { get; set; }
        /// <summary>
        /// #33
        /// </summary>
        public string EquipoVendido { get; set; }
        /// <summary>
        /// #34
        /// </summary>
        public string EquipoMarcaEquipo { get; set; }
        /// <summary>
        /// #35
        /// </summary>
        public string EquipoRefModelo { get; set; }
        /// <summary>
        /// #36
        /// </summary>
        public string EquipoNoSerialIMEI { get; set; }
        /// <summary>
        /// #37
        /// </summary>
        public string BandaEquipoAWS { get; set; }
        /// <summary>
        /// #38
        /// </summary>
        public string BandaEquipoAWS_2500MHZ { get; set; }
        /// <summary>
        /// #39
        /// </summary>
        public string BandaEquipoOTRA { get; set; }
        /// <summary>
        /// #40
        /// </summary>
        public string EquipoVentaCuotas_SI { get; set; }
        /// <summary>
        /// #41
        /// </summary>
        public string EquipoVentaCuotas_NO { get; set; }
        /// <summary>
        /// #42
        /// </summary>
        public string CuotaInicial { get; set; }
        /// <summary>
        /// #43
        /// </summary>
        public string ValoraDiferirenCuotas { get; set; }
        /// <summary>
        /// #44
        /// </summary>
        public string NodeCuotasaDiferir { get; set; }
        /// <summary>
        /// #45
        /// </summary>
        public string NoSIMCARD89 { get; set; }
        /// <summary>
        /// Codigo del negocio.
        /// </summary>
        public string CodigoNegocio { get; set; }
        /// <summary>
        /// Observaciones de la linea
        /// </summary>
        public string Observaciones { get; set; }

        #endregion Propiedades
    }
}