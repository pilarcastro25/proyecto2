﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.App_GlobalCode;
using System.Reflection;
using PlantillasTablas.Objetos;
using Nabis.Models.Entities;
using System.Text;
using System.Data;
using System.Diagnostics;
using Nabis_BS.BComercial;

namespace Nabis.Models.ANEXO
{
    public class AnexoDAL
    {
        public static bool InsertarAnexos(ObjetoLinea objLinea)
        {
            var currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();

            Conect con = new Conect(currentLine);
            con.commandQuery = "Nab_SP_Comercial_Anexo_Insert";
            con.addParameters("CodigoNegocio_FK", objLinea.ID);
            con.addParameters("Numero", objLinea.Numero );
            con.addParameters("CodigoDePlan", objLinea.CodigoDePlan);
            con.addParameters("CodServSuplementario", objLinea.CodServSuplementario);
            con.addParameters("RentaBasica", objLinea.RentaBasica);
            con.addParameters("RentaBasicaServSuplementario", objLinea.RentaBasicaServSuplementario);
            con.addParameters("CapacidadDeDatosServSupl", objLinea.CapacidadDeDatosServSupl);
            con.addParameters("ImeiEquipo", objLinea.Imei);
            con.addParameters("EsVoz", (string.IsNullOrEmpty(objLinea.VozNo) && string.IsNullOrEmpty(objLinea.VozSi)) ? (int?)null : objLinea.VozSi.ToLower() == "x" ? 1 : 0);
            con.addParameters("EsDatos", (string.IsNullOrEmpty(objLinea.DatoNo) && string.IsNullOrEmpty(objLinea.DatoSi)) ? (int?)null : objLinea.DatoSi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0);
            con.addParameters("EsSMS", (string.IsNullOrEmpty(objLinea.SMSNo) && string.IsNullOrEmpty(objLinea.SMSSi)) ? (int?)null : objLinea.SMSSi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0);
            con.addParameters("EsLDI", (string.IsNullOrEmpty(objLinea.LDINo) && string.IsNullOrEmpty(objLinea.LDISi)) ? (int?)null : objLinea.LDISi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0);
            con.addParameters("EsPremium", (string.IsNullOrEmpty(objLinea.PremiumNo) && string.IsNullOrEmpty(objLinea.PremiumSi)) ? (int?)null : objLinea.PremiumSi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0);
            con.addParameters("EsPortabilidad", (string.IsNullOrEmpty(objLinea.PortabilidadSi) && string.IsNullOrEmpty(objLinea.PortabilidadNo) ? (int?)null : objLinea.PortabilidadSi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1 : 0));
            con.addParameters("OperadorDonante", objLinea.OperadorDonante);
            con.addParameters("NoNIP", objLinea.NoNIP);
            con.addParameters("EquipoTraidoVendido", objLinea.EquipoTraidoVendido);
            con.addParameters("NoSerial", objLinea.NoSerial);
            con.addParameters("Imei", objLinea.Imei);
            con.addParameters("MarcaRefEquipo", objLinea.MarcaYRefEquipo);
            con.addParameters("ValorEquipo", objLinea.ValorEquipo);
            con.addParameters("ValorEquipoKoralOPricing", objLinea.ValorEquipoKoralOPricing);
            con.addParameters("EquipoACuotas", (string.IsNullOrEmpty(objLinea.EsEquipoACuotasNo) && string.IsNullOrEmpty(objLinea.EsEquipoACuotasSi)) ? (int?)null : objLinea.EsEquipoACuotasSi.Equals("x", StringComparison.InvariantCultureIgnoreCase) ? 1:0);
            con.addParameters("CuotaInicial", objLinea.EquipoCuotaInicial);
            con.addParameters("ValorADiferir", objLinea.EquipoValorADiferirEnCuotas);
            con.addParameters("NumeroDeCuotas", objLinea.EquipoNumeroDeCuotasADiferir);
            con.addParameters("SerialSimCard", objLinea.NumeroDeSimCard);
            con.addParameters("ValorDeLaSimCard", objLinea.ValorDeLaSimCard);
            con.addParameters("ValorBeneficio", objLinea.EquipoValorBeneficio);
            con.addParameters("CondicionesBeneficio", objLinea.CondicionesDeBeneficio);
            con.addParameters("CodigoBeneficioRecurrente", objLinea.CodigoBeneficio);
            con.addParameters("CondicionesBeneficioBasico", objLinea.CondicionesBeneficioBasico);
            con.addParameters("CodigoBeneficioBasico", objLinea.CodigoBeneficioBasico);
            con.addParameters("Observaciones", objLinea.Observaciones);
            con.execTransac(true);

            //con.conectClose();
            return (con.numRows > 0);
        }

        public static List<ObjetoLinea> RetornarListadeLineasDeBD(string id_eb)
        {
            List<ObjetoLinea> lineas = new List<ObjetoLinea>();
            DataTable dt = BNegocio.GetOtroSi(HttpContext.Current.User.Identity.Name, id_eb);

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    ObjetoLinea lin = new ObjetoLinea();
                    lin.Numero = (row.Field<long?>("NUMERO_MOVIL") != null) ? row.Field<long>("NUMERO_MOVIL").ToString() : null;
                    lin.CodigoDePlan = row.Field<string>("ID_PLAN");
                    lin.CodServSuplementario = row.Field<string>("COD_SERV_SUPLEMENTARIO") ?? string.Empty;
                    lin.RentaBasica = row.Field<string>("CARGO_BASICO");
                    lin.RentaBasicaServSuplementario = row.Field<string>("CARGO_BASICO_SERV_SUPLEMENTARIO") ?? string.Empty;
                    lin.CapacidadDeDatosServSupl = row.Field<string>("CAPACIDAD_SERV_SUPLEMENTARIO") ?? string.Empty;

                    if (row.Field<bool?>("CONTROL_VOZ") != null)
                    {
                        if (row.Field<bool>("CONTROL_VOZ"))
                            lin.VozSi = "X";
                        else
                            lin.VozNo = "X";
                    }

                    if (row.Field<bool?>("CONTROL_DATOS") != null)
                    {
                        if (row.Field<bool>("CONTROL_DATOS"))
                            lin.DatoSi = "X";
                        else
                            lin.DatoNo = "X";
                    }

                    if (row.Field<bool?>("CONTROL_SMS") != null)
                    {
                        if (row.Field<bool>("CONTROL_SMS"))
                            lin.SMSSi = "X";
                        else
                            lin.SMSNo = "X";
                    }

                    if (row.Field<bool?>("CONTROL_LDI") != null)
                    {
                        if (row.Field<bool>("CONTROL_LDI"))
                            lin.LDISi = "X";
                        else
                            lin.LDINo = "X";
                    }


                    if (row.Field<bool?>("CONTROL_PREMIUM") != null)
                    {
                        if (row.Field<bool>("CONTROL_PREMIUM"))
                            lin.PremiumSi = "X";
                        else
                            lin.PremiumNo = "X";
                    }


                    if (row.Field<bool?>("IS_PORTADO") != null)
                    {
                        if (row.Field<bool>("IS_PORTADO"))
                            lin.PortabilidadSi = "X";
                        else
                            lin.PortabilidadNo = "X";
                    }

                    lin.OperadorDonante = row.Field<string>("OPERADOR");

                    lin.NoNIP = row.Field<string>("ID_WEB");

                    lin.EquipoTraidoVendido = row.Field<string>("TRAIDO") == "S"? "Traído" : "Vendido";

                    lin.NoSerial = null;// row.Field<string>("NoSerial");

                    lin.Imei = row.Field<string>("IMEI");

                    lin.MarcaYRefEquipo = row.Field<string>("EQUIPO_REFERENCIA");

                    lin.ValorEquipo = row["VALOR_EQUIPO"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["VALOR_EQUIPO"]));

                    lin.ValorEquipoKoralOPricing = row["VALOR_EQUIPO_KORAL"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["VALOR_EQUIPO_KORAL"]));

                    if (row.Field<bool?>("IS_VENTA_CUOTAS") != null)
                    {
                        if (row.Field<bool>("IS_VENTA_CUOTAS"))
                            lin.EsEquipoACuotasSi = "X";
                        else
                            lin.EsEquipoACuotasNo = "X";
                    }

                    lin.EquipoCuotaInicial = row["CUOTA_INICIAL"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["CUOTA_INICIAL"]));

                    lin.EquipoValorADiferirEnCuotas = row["VALOR_EQUIPO_DIFERIDO"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["VALOR_EQUIPO_DIFERIDO"]));

                    lin.EquipoNumeroDeCuotasADiferir = row.Field<int?>("NUM_CUOTAS");

                    lin.ValorDeLaSimCard = row["VALOR_SIM_CARD"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["VALOR_SIM_CARD"]));

                    lin.NumeroDeSimCard = row.Field<string>("SIMCARD")??string.Empty;

                    lin.EquipoValorBeneficio = row["VALOR_EQUIPO_BENEFICIO"] == DBNull.Value ? (float?)null : (float?)(Convert.ToDouble(row["VALOR_EQUIPO_BENEFICIO"]));

                    lin.CondicionesDeBeneficio = row.Field<string>("COD_BENEFICIO_RECURRENTE");

                    lin.CodigoBeneficio = row.Field<string>("BENEFICIO_CONDICIONES");

                    lin.CondicionesBeneficioBasico = row.Field<string>("BENEFICIO_CONDICIONES_CARGO_BASICO");

                    lin.CodigoBeneficioBasico = row.Field<string>("COD_BENEFICIO_CARGO_BASICO");

                    lin.Observaciones = row.Field<string>("OBSERVACIONES");

                    lineas.Add(lin);

                }
            }

            return lineas;
        }

        /// <summary>
        /// Obtener lineas anexas a un negocio.
        /// </summary>
        /// <param name="codigoNegocio"></param>
        /// <returns></returns>
        public static IEnumerable<NAB_ANEXOS_NEGOCIO> ObtenerLineasAnexas(string codigoNegocio)
        {
            List<NAB_ANEXOS_NEGOCIO> items = new List<NAB_ANEXOS_NEGOCIO>();
            try
            {
                StringBuilder stbQuery = new StringBuilder();
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect lineasAnexas = new Conect(currentLine);
                stbQuery.Append("SELECT * ");
                stbQuery.Append("FROM NAB_ANEXOS_NEGOCIO ");
                stbQuery.Append(string.Format("WHERE RTRIM(LTRIM(CodigoNegocio_FK)) = RTRIM(LTRIM('{0}'))", codigoNegocio));
                lineasAnexas.commandQuery = stbQuery.ToString();
                var data = lineasAnexas.getDataTable(false);
                if (data == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in data.Rows)
                {
                    var item = new NAB_ANEXOS_NEGOCIO(dr);
                    items.Add(item);
                }
            }
            catch (Exception)
            {
                items = new List<NAB_ANEXOS_NEGOCIO>();
            }
            return items;
        }
    }
}