﻿// ===================================================================================================
// Desarrollado Por		    :   Harold Caicedo.
// Fecha de Creación		:   2016/09/12.
// ===================================================================================================
// Versión	        Descripción
// 1.0.0.0	        Entidad que representa la informacion asociada a los contactos autorizados con su
//                  perfil respectivo.
//             
// ===================================================================================================
// HISTORIAL DE CAMBIOS:
// ===================================================================================================
// Ver.	 Fecha		    Autor					Descripción
// ---	 -------------	----------------------	------------------------------------------------------
// XX	 yyyy/MM/dd	    [Nombre Completo]	    [Razón del cambio realizado] 
// ===================================================================================================

using System;
using System.Data;

namespace Nabis.Models
{
    /// <summary>
    /// Entidad que representa la informacion asociada a los contactos autorizados
    /// con su perfil respectivo
    /// </summary>
    public class ContratoUsuarioAutorizado
    {
        public string CONTACTO_1_NOMBRE { get; set; }
        public string CONTACTO_1_MOVIL { get; set; }
        public string CONTACTO_1_EMAIL { get; set; }
        public string CONTACTO_1_PERFIL_AUTORIZADO { get; set; }
        public string CONTACTO_1_CEDULA { get; set; }
        public string CONTACTO_2_NOMBRE { get; set; }
        public string CONTACTO_2_MOVIL { get; set; }
        public string CONTACTO_2_EMAIL { get; set; }
        public string CONTACTO_2_PERFIL_AUTORIZADO { get; set; }
        public string CONTACTO_2_CEDULA { get; set; }
        public string CONTACTO_3_NOMBRE { get; set; }
        public string CONTACTO_3_MOVIL { get; set; }
        public string CONTACTO_3_EMAIL { get; set; }
        public string CONTACTO_3_PERFIL_AUTORIZADO { get; set; }
        public string CONTACTO_3_CEDULA { get; set; }
        public string CONTACTO_4_NOMBRE { get; set; }
        public string CONTACTO_4_MOVIL { get; set; }
        public string CONTACTO_4_EMAIL { get; set; }
        public string CONTACTO_4_PERFIL_AUTORIZADO { get; set; }
        public string CONTACTO_4_CEDULA { get; set; }
        public string ID_CODIGO_NEGOCIO { get; set; }

        public ContratoUsuarioAutorizado()
        {

        }

        public ContratoUsuarioAutorizado(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor del registro no puede ser un valor nulo o vacio.");
            }
            this.CONTACTO_1_NOMBRE = rowInfo.Field<string>("CONTACTO_1_NOMBRE");
            this.CONTACTO_1_MOVIL = rowInfo.Field<string>("CONTACTO_1_MOVIL");
            this.CONTACTO_1_EMAIL = rowInfo.Field<string>("CONTACTO_1_EMAIL");
            this.CONTACTO_1_PERFIL_AUTORIZADO = rowInfo.Field<string>("CONTACTO_1_PERFIL_AUTORIZADO");
            this.CONTACTO_1_CEDULA = rowInfo.Field<string>("CONTACTO_1_CEDULA");
            this.CONTACTO_2_NOMBRE = rowInfo.Field<string>("CONTACTO_2_NOMBRE");
            this.CONTACTO_2_MOVIL = rowInfo.Field<string>("CONTACTO_2_MOVIL");
            this.CONTACTO_2_EMAIL = rowInfo.Field<string>("CONTACTO_2_EMAIL");
            this.CONTACTO_2_PERFIL_AUTORIZADO = rowInfo.Field<string>("CONTACTO_2_PERFIL_AUTORIZADO");
            this.CONTACTO_2_CEDULA = rowInfo.Field<string>("CONTACTO_2_CEDULA");
            this.CONTACTO_3_NOMBRE = rowInfo.Field<string>("CONTACTO_3_NOMBRE");
            this.CONTACTO_3_MOVIL = rowInfo.Field<string>("CONTACTO_3_MOVIL");
            this.CONTACTO_3_EMAIL = rowInfo.Field<string>("CONTACTO_3_EMAIL");
            this.CONTACTO_3_PERFIL_AUTORIZADO = rowInfo.Field<string>("CONTACTO_3_PERFIL_AUTORIZADO");
            this.CONTACTO_3_CEDULA = rowInfo.Field<string>("CONTACTO_3_CEDULA");
            this.CONTACTO_4_NOMBRE = rowInfo.Field<string>("CONTACTO_4_NOMBRE");
            this.CONTACTO_4_MOVIL = rowInfo.Field<string>("CONTACTO_4_MOVIL");
            this.CONTACTO_4_EMAIL = rowInfo.Field<string>("CONTACTO_4_EMAIL");
            this.CONTACTO_4_PERFIL_AUTORIZADO = rowInfo.Field<string>("CONTACTO_4_PERFIL_AUTORIZADO");
            this.CONTACTO_4_CEDULA = rowInfo.Field<string>("CONTACTO_4_CEDULA");
            this.ID_CODIGO_NEGOCIO = rowInfo.Field<string>("ID_CODIGO_NEGOCIO");
        }
    }
}