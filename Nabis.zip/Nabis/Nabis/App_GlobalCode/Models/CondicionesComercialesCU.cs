﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    public class CondicionesComercialesCU
    {
        #region Propiedades Compartidas
        public string CodigoPlan { get; set; }
        public string CargoBasico { get; set; }
        public long CantidadLineas { get; set; }
        public string ValorTotal { get; set; }
        #endregion
        #region Voz
        public string MinutosIncluidos { get; set; }
        public string ValorMinutoMovistar { get; set; }
        public string ValorMinutoFijo { get; set; }
        public string ValorMinutoOtro { get; set; } 
        #endregion
        #region Datos
        public string RentaDatos { get; set; }
        public string GbIncluidos { get; set; }
        public string ValorKb { get; set; } 
        #endregion
    }
}