﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    public class CamposTraspaso
    {
        public string Imei { get; set; }
        public string Celular { get; set; }
        public string Modelo { get; set; }
    }
}