﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    /// <summary>
    /// Entidad que representa la informacion parametrizada del sistema.
    /// </summary>
    public class ConfiguracionSistema
    {
        /// <summary>
        /// Id de configuracion.
        /// </summary>
        public int ID_CONFIGURACION { get; set; }
        /// <summary>
        /// Nombre
        /// </summary>
        public string NOMBRE { get; set; }
        /// <summary>
        /// Alias
        /// </summary>
        public string ALIAS { get; set; }
        /// <summary>
        /// Valor
        /// </summary>
        public string VALOR { get; set; }
        /// <summary>
        /// Descripcion
        /// </summary>
        public string DESCRIPCION { get; set; }

        /// <summary>
        /// Constructor basico
        /// </summary>
        public ConfiguracionSistema()
        {

        }

        /// <summary>
        /// Constructor que recibe un datarow de un datatable.
        /// </summary>
        /// <param name="rowInfo"></param>
        public ConfiguracionSistema(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor de rowInfo no puede ser un valor nulo o vacio.");
            }
            this.ID_CONFIGURACION = rowInfo.Field<int>("ID_CONFIGURACION");
            this.NOMBRE = rowInfo.Field<string>("NOMBRE");
            this.ALIAS = rowInfo.Field<string>("ALIAS");
            this.DESCRIPCION = rowInfo.Field<string>("DESCRIPCION");
        }
    }
}