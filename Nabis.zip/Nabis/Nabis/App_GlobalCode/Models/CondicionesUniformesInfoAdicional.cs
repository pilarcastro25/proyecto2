﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Nabis.Models
{
    /// <summary>
    /// Entidad que representa la informacion adicional de un 
    /// contrato de condiciones uniformes
    /// </summary>
    public class CondicionesUniformesInfoAdicional
    {
        public string GENERO_PERSONA_NATURAL { get; set; }
        public string TIPO_TRABAJO { get; set; }
        public string TIPO_CONTRATO { get; set; }
        public string EMPRESA_DONDE_LABORA { get; set; }
        public string ASIGNACION_SALARIAL { get; set; }
        public string TARJETA_CREDITO { get; set; }
        public string TARJETA_CREDITO_OTRO { get; set; }
        public string TARJERTA_CREDITO_NUMERO { get; set; }
        public DateTime? TARJETA_CREDITO_FECHA_VENCIMIENTO { get; set; }
        public string NOMBRE_USUARIO_AUTORIZADO { get; set; }
        public string TIPO_DOCUMENTO_USUARIO_AUTORIZADO { get; set; }
        public string NUMERO_IDENTIFICACION_USUARIO_AUTORIZADO { get; set; }
        public string REFERENCIA_PERSONAL_NOMBRE_1 { get; set; }
        public string REFERENCIA_PERSONAL_TELEFONO_1 { get; set; }
        public string REFERENCIA_PERSONAL_NOMBRE_2 { get; set; }
        public string REFERENCIA_PERSONAL_EMPRESA_2 { get; set; }
        public string REFERENCIA_PERSONAL_TELEFONO_2 { get; set; }
        public string PERSONA_JURIDICA_EMPRESA_1 { get; set; }
        public string PERSONA_JURIDICA_NOMBRE_CONTACTO_1 { get; set; }
        public string PERSONA_JURIDICA_FIJO_1 { get; set; }
        public string PERSONA_JURIDICA_MOVIL_1 { get; set; }
        public string PERSONA_JURIDICA_EMPRESA_2 { get; set; }
        public string PERSONA_JURIDICA_NOMBRE_CONTACTO_2 { get; set; }
        public string PERSONA_JURIDICA_FIJO_2 { get; set; }
        public string PERSONA_JURIDICA_MOVIL_2 { get; set; }
        public string PERSONA_JURIDICA_INFO_ADICIONAL_EMAIL { get; set; }
        public string ID_PRICING_ID_KORAL { get; set; }
        public string COD_NEGOCIO { get; set; }

        /// <summary>
        /// Constructor basico.
        /// </summary>
        public CondicionesUniformesInfoAdicional()
        {

        }

        /// <summary>
        /// Constructor que recibe por parametro el registro de un datatable.
        /// </summary>
        /// <param name="rowInfo"></param>
        public CondicionesUniformesInfoAdicional(DataRow rowInfo)
        {
            if (rowInfo == null)
            {
                throw new ArgumentNullException("rowInfo", "El valor del registro no puede ser nulo o vacio.");
            }
            this.GENERO_PERSONA_NATURAL = rowInfo.Field<string>("GENERO_PERSONA_NATURAL");
            this.TIPO_TRABAJO = rowInfo.Field<string>("TIPO_TRABAJO");
            this.TIPO_CONTRATO = rowInfo.Field<string>("TIPO_CONTRATO");
            this.EMPRESA_DONDE_LABORA = rowInfo.Field<string>("EMPRESA_DONDE_LABORA");
            this.ASIGNACION_SALARIAL = rowInfo.Field<string>("ASIGNACION_SALARIAL");
            this.TARJETA_CREDITO = rowInfo.Field<string>("TARJETA_CREDITO");
            this.TARJETA_CREDITO_OTRO = rowInfo.Field<string>("TARJETA_CREDITO_OTRO");
            this.TARJERTA_CREDITO_NUMERO = rowInfo.Field<string>("TARJERTA_CREDITO_NUMERO");
            this.TARJETA_CREDITO_FECHA_VENCIMIENTO = rowInfo.Field<DateTime?>("TARJETA_CREDITO_FECHA_VENCIMIENTO");
            this.NOMBRE_USUARIO_AUTORIZADO = rowInfo.Field<string>("NOMBRE_USUARIO_AUTORIZADO");
            this.TIPO_DOCUMENTO_USUARIO_AUTORIZADO = rowInfo.Field<string>("TIPO_DOCUMENTO_USUARIO_AUTORIZADO");
            this.NUMERO_IDENTIFICACION_USUARIO_AUTORIZADO = rowInfo.Field<string>("NUMERO_IDENTIFICACION_USUARIO_AUTORIZADO");
            this.REFERENCIA_PERSONAL_NOMBRE_1 = rowInfo.Field<string>("REFERENCIA_PERSONAL_NOMBRE_1");
            this.REFERENCIA_PERSONAL_TELEFONO_1 = rowInfo.Field<string>("REFERENCIA_PERSONAL_TELEFONO_1");
            this.REFERENCIA_PERSONAL_NOMBRE_2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_NOMBRE_2");
            this.REFERENCIA_PERSONAL_EMPRESA_2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_EMPRESA_2");
            this.REFERENCIA_PERSONAL_TELEFONO_2 = rowInfo.Field<string>("REFERENCIA_PERSONAL_TELEFONO_2");
            this.PERSONA_JURIDICA_EMPRESA_1 = rowInfo.Field<string>("PERSONA_JURIDICA_EMPRESA_1");
            this.PERSONA_JURIDICA_NOMBRE_CONTACTO_1 = rowInfo.Field<string>("PERSONA_JURIDICA_NOMBRE_CONTACTO_1");
            this.PERSONA_JURIDICA_FIJO_1 = rowInfo.Field<string>("PERSONA_JURIDICA_FIJO_1");
            this.PERSONA_JURIDICA_MOVIL_1 = rowInfo.Field<string>("PERSONA_JURIDICA_MOVIL_1");
            this.PERSONA_JURIDICA_EMPRESA_2 = rowInfo.Field<string>("PERSONA_JURIDICA_EMPRESA_2");
            this.PERSONA_JURIDICA_NOMBRE_CONTACTO_2 = rowInfo.Field<string>("PERSONA_JURIDICA_NOMBRE_CONTACTO_2");
            this.PERSONA_JURIDICA_FIJO_2 = rowInfo.Field<string>("PERSONA_JURIDICA_FIJO_2");
            this.PERSONA_JURIDICA_MOVIL_2 = rowInfo.Field<string>("PERSONA_JURIDICA_MOVIL_2");
            this.PERSONA_JURIDICA_INFO_ADICIONAL_EMAIL = rowInfo.Field<string>("PERSONA_JURIDICA_INFO_ADICIONAL_EMAIL");
            this.ID_PRICING_ID_KORAL = rowInfo.Field<string>("ID_PRICING_ID_KORAL");
            this.COD_NEGOCIO = rowInfo.Field<string>("COD_NEGOCIO");
        }
    }
}