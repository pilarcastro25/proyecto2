﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Configuration;
using System.Web.Hosting;
using System.Globalization;
//using Teradata.Client.Provider;

namespace Nabis.App_GlobalCode
{
    public partial class Conect
    {

        #region constantes
            private const string NAB_SP_GOABL_LOG_EXCEPCIONES = "Nab_SP_Global_Log_Excepciones_Registro";
        #endregion

        //Atributos
        private static bool modeTest = ConfigurationManager.AppSettings["ModeTest"] == "true";
        //private SqlConnection conexion = new SqlConnection(modeTest ? App_GlobalResources.SourcesConection.Nabis_Test : App_GlobalResources.SourcesConection.Nabis);
        private SqlConnection conexion = new SqlConnection(modeTest ? App_GlobalResources.SourcesConection.NabisP_Test : App_GlobalResources.SourcesConection.NabisP);
        private Dictionary<string, object> parameters = new Dictionary<string, object>();
        private Dictionary<string, SqlParameter> parametersOutput = new Dictionary<string, SqlParameter>();
        public string commandQuery;
        public Double timeQuery;
        public int numRows = 0;
        public int numColumns = 0;
        public SqlDataReader data;
        public string[] dataColumns;
        public List<object[]> dataRows = new List<object[]>();
        public string currentHost;
        public string currentUrlPath;
        public string currentPath;
        public int currentLine;
        public string currentIP;
        public string currentEquipo;
        public bool error = false;
        public Dictionary<string, Dictionary<string, string>> formKeyValues = new Dictionary<string, Dictionary<string, string>>();

        //Metodos
        public static object IIF(Boolean valueEval, Object truePart, Object falsePart)
        {
            if (valueEval)
            {
                return truePart;
            }
            else
            {
                return falsePart;
            }
        }

        public SqlConnection getConexion()
        {
            return conexion;
        }

        public static SqlConnection Get_Conexion()
        {
            bool modeTest = ConfigurationManager.AppSettings["ModeTest"] == "true";
            //SqlConnection conexion = new SqlConnection(modeTest ? App_GlobalResources.SourcesConection.Nabis_Test : App_GlobalResources.SourcesConection.Nabis);
            SqlConnection conexion = new SqlConnection(modeTest ? App_GlobalResources.SourcesConection.NabisP_Test : App_GlobalResources.SourcesConection.NabisP);
            return conexion;
        }

        public void conectOpen()
        {
            conexion.Open();
        }

        public void conectClose()
        {
            conexion.Close();
        }

        public void addParameters(string key, object value)
        {
            if (value == null)
            {
                value = DBNull.Value;
            }
            else if (value.GetType().ToString() == "System.String")
            {
                value = (value == null) ? (DBNull.Value) : (value);
            }
            parameters.Add(key, value);
        }

        public void addParameters(string key, object value, object defaultValue, object setValue)
        {
            if (value == defaultValue)
            {
                value = setValue;
            }
            parameters.Add(key, value);
        }

        public void addParametersOutPut(string key, object value, SqlDbType type)
        {
            SqlParameter param = new SqlParameter(key, value);
            param.SqlDbType = type;
            param.Direction = ParameterDirection.Output;
            parametersOutput.Add(key, param);
        }

        public void addParametersOutPut(string key, object value, SqlDbType type, int longVarchar)
        {
            SqlParameter param = new SqlParameter(key, value);
            param.SqlDbType = type;
            param.Direction = ParameterDirection.Output;
            param.Size = longVarchar;
            parametersOutput.Add(key, param);
        }

        public object getValueParameterOut(string keyParameter)
        {

            object value = parametersOutput[keyParameter].Value;
            return value;
        }

        public void Reset()
        {
            if (parameters.Count > 0) { this.parameters.Clear(); }
            if (this.parametersOutput != null) { this.parametersOutput.Clear(); }
            this.dataColumns = null;
            this.dataRows.Clear();
            this.numRows = 0;
            this.numColumns = 0;
            this.timeQuery = 0;
            this.parametersOutput = null;
        }

        public void execQuery(Boolean execStoreProcedure)
        {
            try
            {
                SqlCommand command = new SqlCommand(commandQuery, conexion);
                //verifica si es procedimiento almacenado
                if (execStoreProcedure)
                {
                    command.CommandType = CommandType.StoredProcedure;
                    //Asigna parametros de consulta o de procedimiento
                    if (parameters != null)
                    {
                        foreach (KeyValuePair<string, object> parameter in parameters)
                        {
                            if (parameter.Value.GetType().ToString() == "System.String")
                            {
                                SqlParameter param = new SqlParameter("@" + parameter.Key, SqlDbType.VarChar);
                                param.Value = parameter.Value;
                                command.Parameters.Add(param);
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@" + parameter.Key, parameter.Value);
                            }
                            //command.Parameters.Add(paramsKeys[i], paramsTypes[i]).Value = paramsValues[i]; --> desactivado por estar obsoleto > fuente: http://msdn.microsoft.com/es-es/library/vstudio/9dd8zze1%28v=vs.80%29.aspx, http://msdn.microsoft.com/es-es/library/9dd8zze1%28v=vs.80%29.aspx
                            //System.Web.HttpContext.Current.Response.Write(paramsKeys(index) & ":" & paramsValues(index) & "(" & paramsTypes(index) & ")")
                        }
                    }
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter row in parametersOutput.Values)
                        {
                            command.Parameters.Add(row);
                        }
                    }
                }
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                data = command.ExecuteReader();
                //Verifica si hubo resultados (filas)
                if (data.HasRows)
                {
                    //Obtiene estructura de Columnas del dataReader
                    DataTable dataTable = data.GetSchemaTable();
                    //Define la dimensión de dataColumns con base en el total de columnas 
                    dataColumns = new string[dataTable.Rows.Count];
                    //Recorre las filas que contienen la información de las columnas
                    foreach (DataRow item in dataTable.Rows)
                    {
                        //Almacena en indice actual el nombre de la columna actual
                        dataColumns[numColumns] = item[0].ToString();
                        numColumns++;
                    }
                    dataTable.Clear();
                    int i = 0;
                    while (data.Read())
                    {
                        object[] row = new object[data.FieldCount];
                        data.GetValues(row);
                        dataRows.Add(row);
                        i++;
                    }
                    numRows = i;
                    data.Close();
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter item in parametersOutput.Values)
                        {
                            item.Value = command.Parameters[item.ParameterName].Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                error = true;
                conexion.Close();
                if (commandQuery != NAB_SP_GOABL_LOG_EXCEPCIONES)
                {
                    this.Reset();
                    this.errorLog(ex, commandQuery, "execQuery");
                }
            }
            finally
            {
                data = null;
                conexion.Close();
                conexion.Dispose();
            }
        }

        /*public void ExecQueryTd(string bodega)
        {
            TdConnection conexionTd = null;
            try
            {
                string dsn = String.Format("Data Source={0};User Id=jcortes;Password=Teradata2015;", (bodega == "movil") ? ("10.80.4.20") : ("10.201.14.12"));
                conexionTd = new TdConnection(dsn);
                TdCommand commandTd = new TdCommand(commandQuery, conexionTd);
                conexionTd.Open();
                TdDataReader data = commandTd.ExecuteReader();
                if (data.HasRows)
                {
                    //Obtiene estructura de Columnas del dataReader
                    DataTable dataTable = data.GetSchemaTable();
                    //Define la dimensión de dataColumns con base en el total de columnas 
                    dataColumns = new string[dataTable.Rows.Count]; 
                    //Recorre las filas que contienen la información de las columnas
                    foreach (DataRow item in dataTable.Rows)
                    {
                        //Almacena en indice actual el nombre de la columna actual
                        dataColumns[numColumns] = item[0].ToString();
                        numColumns++;
                    }
                    dataTable.Clear();
                    int i = 0;
                    while (data.Read())
                    {
                        object[] row = new object[data.FieldCount];
                        data.GetValues(row);
                        dataRows.Add(row);
                        i++;
                    }
                    numRows = i;
                    data.Close();
                }
                commandTd.Dispose();
            }
            catch (TdException ex)
            {
                error = true;
                conexionTd.Close();
                if (commandQuery != "Nab_Log_Excepciones_Registro")
                {
                    this.Reset();
                    this.errorLog(ex, commandQuery, "execQuery");
                }
            }
            finally
            {
                if (null != conexionTd)
                {
                    conexionTd.Close();
                }
                data = null;
                conexionTd.Dispose();
            }
        }*/

        public void execTransac(Boolean execStoreProcedure)
        {
            try
            {
                SqlCommand command = new SqlCommand(commandQuery, conexion);
                //verifica si es procedimiento almacenado
                if (execStoreProcedure)
                {
                    command.CommandType = CommandType.StoredProcedure;
                    //Asigna parametros de consulta o de procedimiento
                    if (parameters != null)
                    {
                        foreach (KeyValuePair<string, object> parameter in parameters)
                        {
                            string typeParam = parameter.Value.GetType().ToString();
                            if (typeParam == "System.String")
                            {
                                SqlParameter param = new SqlParameter("@" + parameter.Key, SqlDbType.VarChar);
                                param.Value = parameter.Value;
                                command.Parameters.Add(param);
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@" + parameter.Key, parameter.Value);
                            }
                            //command.Parameters.Add(paramsKeys[i], paramsTypes[i]).Value = paramsValues[i]; --> desactivado por estar obsoleto > fuente: http://msdn.microsoft.com/es-es/library/vstudio/9dd8zze1%28v=vs.80%29.aspx, http://msdn.microsoft.com/es-es/library/9dd8zze1%28v=vs.80%29.aspx
                            //System.Web.HttpContext.Current.Response.Write(paramsKeys(index) & ":" & paramsValues(index) & "(" & paramsTypes(index) & ")")
                        }
                    }
                    //Asigna parametros Output
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter parameter in parametersOutput.Values)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }
                }
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                data = command.ExecuteReader();
                //Verifica si hubo resultados (filas)
                if (data.HasRows)
                {
                    //Obtiene estructura de Columnas del dataReader
                    DataTable dataTable = data.GetSchemaTable();
                    //Define la dimensión de dataColumns con base en el total de columnas 
                    dataColumns = new string[dataTable.Rows.Count];
                    //Recorre las filas que contienen la información de las columnas
                    foreach (DataRow item in dataTable.Rows)
                    {
                        //Almacena en indice actual el nombre de la columna actual
                        dataColumns[numColumns] = item[0].ToString();
                        numColumns++;
                    }
                    dataTable.Clear();
                    int i = 0;
                    while (data.Read())
                    {
                        object[] row = new object[data.FieldCount];
                        data.GetValues(row);
                        dataRows.Add(row);
                        i++;
                    }
                    numRows = i;
                    data.Close();

                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter item in parametersOutput.Values)
                        {
                            item.Value = command.Parameters[item.ParameterName].Value;
                        }
                    }
                }
                else if (data.RecordsAffected > 0)
                {
                    data.Close();
                    numRows = data.RecordsAffected;
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter item in parametersOutput.Values)
                        {
                            item.Value = command.Parameters[item.ParameterName].Value;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                conexion.Close();
                if (commandQuery != NAB_SP_GOABL_LOG_EXCEPCIONES)
                {
                    this.Reset();
                    error = true;
                    this.errorLog(ex, commandQuery, "execQuery");
                }
            }
            finally
            {
                conexion.Close();
            }
        }

        public DataTable getDataTable(Boolean execStoreProcedure)
        {
            DataTable dataTable = new DataTable();
            SqlCommand command = new SqlCommand(commandQuery, conexion);
            SqlDataAdapter adapterData = new SqlDataAdapter();
            try
            {
                //verifica si es procedimiento almacenado
                if (execStoreProcedure)
                {
                    command.CommandType = CommandType.StoredProcedure;
                    //Asigna parametros de consulta o de procedimiento
                    if (parameters != null)
                    {
                        foreach (KeyValuePair<string, object> parameter in parameters)
                        {
                            if (parameter.Value.GetType().ToString() == "System.String")
                            {
                                SqlParameter param = new SqlParameter("@" + parameter.Key, SqlDbType.VarChar);
                                param.Value = parameter.Value;
                                command.Parameters.Add(param);
                            }
                            else
                            {
                                command.Parameters.AddWithValue("@" + parameter.Key, parameter.Value);
                            }
                            //command.Parameters.Add(paramsKeys[i], paramsTypes[i]).Value = paramsValues[i]; --> desactivado por estar obsoleto > fuente: http://msdn.microsoft.com/es-es/library/vstudio/9dd8zze1%28v=vs.80%29.aspx, http://msdn.microsoft.com/es-es/library/9dd8zze1%28v=vs.80%29.aspx
                            //System.Web.HttpContext.Current.Response.Write(paramsKeys(index) & ":" & paramsValues(index) & "(" & paramsTypes(index) & ")")
                        }
                    }
                    if (parametersOutput != null)
                    {
                        foreach (SqlParameter parameter in parametersOutput.Values)
                        {
                            command.Parameters.Add(parameter);
                        }
                    }
                }
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                
                adapterData.SelectCommand = command;
                dataTable.Locale = CultureInfo.InvariantCulture;
                adapterData.Fill(dataTable);
                return dataTable;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally {
                adapterData.Dispose();
                conexion.Close();
            }
        }

        public string getColumnValue(string columnName)
        {
            int indexColumn = Array.IndexOf(dataColumns, columnName);
            if (indexColumn != -1)
            {
                string value = dataRows[0][indexColumn].ToString();
                return value;
            }
            else
            {
                return indexColumn.ToString();
            }
        }

        public string getColumnValue(int indexColumn)
        {
            indexColumn -= 1;
            return dataRows[0][indexColumn].ToString();
        }

        public string getRowColumnValue(string value, string columnName)
        {
            return "true";
        }

        public string getRowColumnValue(int indexColumn)
        {
            indexColumn -= 1;
            return dataRows[0][indexColumn].ToString();
        }

        public void printValuesForm(System.Web.UI.ControlCollection Controls)
        {
            string value = null;
            foreach (System.Web.UI.Control control in Controls)
            {
                if (control.HasControls())
                {
                    this.printValuesForm(control.Controls);
                }
                else if (control is TextBox && control.ID != null)
                {
                    TextBox texBox = (TextBox)control;
                    value = this.getColumnValue(control.ID);
                    value = (value == "") ? (String.Empty) : (value);
                    texBox.Text = (String.IsNullOrEmpty(texBox.Text)) ? (value) : (texBox.Text);
                }
                else if (control is DropDownList && control.ID != null)
                {
                    DropDownList drop = (DropDownList)control;
                    if (drop.SelectedIndex == 0) {
                        value = this.getColumnValue(control.ID);
                        drop.SelectedValue = value == "-1" ? "" : value;
                    }
                }
            }
        }

        public void resetValuesForm(System.Web.UI.ControlCollection Controls)
        {
            foreach (System.Web.UI.Control control in Controls)
            {
                if (control.HasControls())
                {
                    this.resetValuesForm(control.Controls);
                }
                else if (control is TextBox && control.ID != null)
                {
                    TextBox texBox = (TextBox)control;
                    texBox.Text = String.Empty;
                }
                else if (control is DropDownList && control.ID != null)
                {
                    DropDownList drop = (DropDownList)control;
                    drop.SelectedIndex = 0;
                }
            }
        }

        public void printDataKeysForm(System.Web.UI.Control controlWrapper)
        {
            int columnKeyIndex = Array.IndexOf(this.dataColumns, "ALIAS");
            int columnValueIndex = Array.IndexOf(this.dataColumns, "VALOR");
            int columnIdIndex = Array.IndexOf(this.dataColumns, "ID_CAMPO");
            int columnIdInputIndex = Array.IndexOf(this.dataColumns, "ID_INPUT");
            int columnNameSubCampoPadre = Array.IndexOf(this.dataColumns, "SUB_CAMPO_PADRE");
            int columnNameSubCampo = Array.IndexOf(this.dataColumns, "SUB_CAMPO");

            foreach (object[] item in this.dataRows)
            {
                string subCampos = item[0].ToString();
                string idCampo = item[columnIdIndex].ToString();
                string key = item[columnKeyIndex].ToString();
                string value = item[columnValueIndex].ToString();
                string idInput = item[columnIdInputIndex].ToString();
                string nomSubcampoPadre = item[columnNameSubCampoPadre].ToString();
                string nomSubcampo = item[columnNameSubCampo].ToString().Replace(" ", "_");

                value = (value == String.Empty || value == null) ? (String.Empty) : (value);
                Control control = controlWrapper.FindControl(key);
                if (control != null)
                {
                    if (control is TextBox)
                    {
                        TextBox txtControl = ((TextBox)control);
                        txtControl.Attributes.Add("data-colsource", idCampo);
                        txtControl.Text = value;
                        txtControl.Attributes.Add("data-colparent", subCampos);
                        txtControl.Attributes.Add("data-rowsource", idInput);
                    }
                    else if (control is DropDownList)
                    {
                        DropDownList drpControl = ((DropDownList)control);
                        drpControl.Attributes.Add("data-colsource", idCampo);
                        ListItem valueItemSelected = drpControl.Items.FindByValue(value) ?? drpControl.Items.FindByText(nomSubcampoPadre);
                        if (value == "-1" && subCampos == "S")
                        {
                            valueItemSelected = drpControl.Items.FindByText(nomSubcampoPadre);
                        }

                        if (valueItemSelected != null)
                        {
                            drpControl.SelectedValue = valueItemSelected.Value;
                        }

                        drpControl.Attributes.Add("data-colparent", subCampos);
                        if (drpControl.Attributes["data-rowsource"] == null)
                        {
                            drpControl.Attributes.Add("data-rowsource", idInput);
                        }

                        if (subCampos == "S")
                        {
                            Control subControl = controlWrapper.FindControl(nomSubcampo);
                            if (subControl != null)
                            {
                                if (subControl is TextBox)
                                {
                                    TextBox txtControl = ((TextBox)subControl);
                                    txtControl.Attributes.Add("data-colsource", idCampo);
                                    txtControl.Text = value;
                                    txtControl.Attributes.Add("data-colparent", subCampos);
                                    txtControl.Attributes.Add("data-rowsource", idInput);
                                }
                                else if (subControl is DropDownList)
                                {
                                    drpControl = ((DropDownList)subControl);
                                    drpControl.Attributes.Add("data-colsource", idCampo);
                                    valueItemSelected = drpControl.Items.FindByValue(value) ?? drpControl.Items.FindByText(nomSubcampoPadre);
                                    if (value == "-1" && subCampos == "S")
                                    {
                                        valueItemSelected = drpControl.Items.FindByText(nomSubcampoPadre);
                                    }

                                    if (valueItemSelected != null)
                                    {
                                        drpControl.SelectedValue = valueItemSelected.Value;
                                    }

                                    drpControl.Attributes.Add("data-colparent", subCampos);
                                    drpControl.Attributes.Add("data-rowsource", idInput);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void GetDataKeyValuesForm(System.Web.UI.ControlCollection Controls)
        {
            string key;
            string value;
            foreach (System.Web.UI.Control control in Controls)
            {
                Dictionary<string, string> sourceKeyValues = new Dictionary<string, string>();
                key = "";
                value = "";
                if (control.HasControls())
                {
                    this.GetDataKeyValuesForm(control.Controls);
                }
                else if (control is TextBox && control.ID != null)
                {
                    TextBox texBox = (TextBox)control;
                    if (texBox.Attributes["data-colsource"] != null)
                    {
                        key = control.ID;
                        value = texBox.Text.ToString().Trim();
                        sourceKeyValues.Add("SubCampos", texBox.Attributes["data-colparent"] ?? "N");
                        sourceKeyValues.Add("IdCampo", texBox.Attributes["data-colsource"] ?? "0");
                        sourceKeyValues.Add("IdSubCampoPadre", texBox.Attributes["data-colsourcesubparent"] ?? "0");
                        sourceKeyValues.Add("IdSubCampo", texBox.Attributes["data-colsourcesub"] ?? "0");
                        sourceKeyValues.Add("IdInput", texBox.Attributes["data-rowsource"] ?? "0");
                        sourceKeyValues.Add("Valor", value);
                    }
                }
                else if (control is DropDownList && control.ID != null)
                {
                    DropDownList drop = (DropDownList)control;
                    if (drop.Attributes["data-colsource"] != null)
                    {
                        key = control.ID;
                        value = drop.SelectedValue.ToString().Trim();
                        sourceKeyValues.Add("SubCampos", drop.Attributes["data-colparent"] ?? "N");
                        sourceKeyValues.Add("IdCampo", drop.Attributes["data-colsource"] ?? "0");
                        sourceKeyValues.Add("IdSubCampoPadre", drop.Attributes["data-colsourcesubparent"] ?? "0");
                        sourceKeyValues.Add("IdSubCampo", drop.Attributes["data-colsourcesub"] ?? "0");
                        sourceKeyValues.Add("IdInput", drop.Attributes["data-rowsource"] ?? "0");
                        sourceKeyValues.Add("Valor", value);
                    }
                }

                if (key != "")
                {
                    this.formKeyValues.Add(key, sourceKeyValues);
                }
            }
        }

        public Dictionary<string, string> GetDataKeyNamesControls()
        {
            if (numRows > 0)
            {
                Dictionary<string, string> PairKeyValue = new Dictionary<string, string>();
                for (int i = 1; i <= numRows; i++)
                {
                    int index = i - 1;
                    int size = dataRows[index].Length;
                    PairKeyValue.Add(dataRows[index][1].ToString(), dataRows[index][0].ToString());
                }
                return PairKeyValue;
            }
            else
            {
                Dictionary<string, string> dir = new Dictionary<string, string>();
                dir.Add("Error", "No hay data o información disponible");
                return dir;
            }
        }

        public Dictionary<string, Dictionary<string, string>> GetDataKeyNamesControls(string IdCampo, string IdSubCampoPadre)
        {
            Dictionary<string, Dictionary<string, string>> KeyValuesCampos = new Dictionary<string, Dictionary<string, string>>();
            if (numRows > 0)
            {
                for (int i = 1; i <= numRows; i++)
                {
                    Dictionary<string, string> keyValuesCamposProp = new Dictionary<string, string>();
                    keyValuesCamposProp.Clear();
                    int index = i - 1;
                    int size = dataRows[index].Length;
                    keyValuesCamposProp.Add("SubCampos", "N");
                    keyValuesCamposProp.Add("IdCampo", IdCampo);
                    keyValuesCamposProp.Add("IdSubCampoPadre", IdSubCampoPadre);
                    keyValuesCamposProp.Add("IdSubCampo", dataRows[index][0].ToString());
                    keyValuesCamposProp.Add("IdInput", "0");
                    keyValuesCamposProp.Add("Valor", null);
                    keyValuesCamposProp.Add("Type", dataRows[index][2].ToString().ToLower());
                    keyValuesCamposProp.Add("Alias", dataRows[index][1].ToString().ToLower().Replace(" ", "_"));
                    KeyValuesCampos.Add(dataRows[index][1].ToString(), keyValuesCamposProp);
                }
                return KeyValuesCampos;
            }
            else
            {
                Dictionary<string, string> keyValuesCamposProp = new Dictionary<string, string>();
                keyValuesCamposProp.Add("IdCampo", "Error");
                keyValuesCamposProp.Add("Valor", "Error");
                KeyValuesCampos.Add("Error", keyValuesCamposProp);
                return KeyValuesCampos;
            }
        }

        public string GetCommand()
        {
            StringBuilder command = new StringBuilder();
            command.Append(this.commandQuery);
            if (parameters != null)
            {
                foreach (KeyValuePair<string, object> parameter in parameters)
                {
                    command.Append(parameter.Key + ": '" + parameter.Value + "'");
                    command.Append(", ");
                }
            }
            if (parametersOutput != null)
            {
                foreach (SqlParameter parameter in parametersOutput.Values)
                {
                    command.Append(parameter.ParameterName + ": '" + parameter.Value + "'");
                    command.Append(", ");
                }
            }
            return command.ToString();
        }

        public ListItem[] getListItems()
        {
            if (numRows > 0)
            {
                ListItem[] list = new ListItem[numRows + 1];
                list[0] = new ListItem("Seleccione", "");
                for (int i = 1; i <= numRows; i++)
                {
                    int index = i - 1;
                    int size = dataRows[index].Length;
                    switch (size)
                    {
                        case 1:
                            list[i] = new ListItem(dataRows[index][0].ToString(), dataRows[index][0].ToString());
                            break;
                        case 2:
                            list[i] = new ListItem(dataRows[index][1].ToString(), dataRows[index][0].ToString());
                            break;
                        default:
                            list[i] = new ListItem("Error de origen de datos");
                            break;
                    }
                }
                return list;
            }
            else
            {
                return new ListItem[] { new ListItem("No hay datos", "-1") };
            }
        }

        public ListItem[] getListItems(String valueFirstOption, String textFirstOption)
        {
            if (numRows > 0)
            {
                ListItem[] list = new ListItem[numRows + 1];
                list[0] = new ListItem(textFirstOption, valueFirstOption);
                for (int i = 1; i <= numRows; i++)
                {
                    int index = i - 1;
                    int size = dataRows[index].Length;
                    switch (size)
                    {
                        case 1:
                            list[i] = new ListItem(dataRows[index][0].ToString(), dataRows[index][0].ToString());
                            break;
                        case 2:
                            list[i] = new ListItem(dataRows[index][1].ToString(), dataRows[index][0].ToString());
                            break;
                        default:
                            list[i] = new ListItem("Error de origen de datos");
                            break;
                    }
                }
                return list;
            }
            else
            {
                return new ListItem[] { new ListItem("No hay datos", "-1") };
            }
        }

        public static void ExportExcel(GridView gridExport)
        {
            Page pagTmp = new Page();
            StringWriter sw = new StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(sw);
            HtmlForm formTmp = new HtmlForm();

            gridExport.EnableViewState = false;
            if (gridExport.AllowPaging)
            {
                gridExport.AllowPaging = false;
                if (gridExport.DataSourceID != "")
                {
                    gridExport.DataBind();
                }
            }
            pagTmp.EnableEventValidation = false;
            pagTmp.DesignerInitialize();
            pagTmp.Controls.Add(formTmp);
            formTmp.Controls.Add(gridExport);
            pagTmp.RenderControl(htw);


            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.Buffer = true;
            HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=data.xls");
            HttpContext.Current.Response.Charset = "UTF-8";
            HttpContext.Current.Response.ContentEncoding = Encoding.Default;

            HttpContext.Current.Response.Write(sw.ToString());
            HttpContext.Current.Response.End();
        }

        public static void printScript(ClientScriptManager sender, string content, bool redirectPage, string url, bool noCache = false)
        {
            if (noCache)
            {
                HttpContext.Current.Response.Cache.SetNoStore();
                HttpContext.Current.Response.Cache.AppendCacheExtension("no-cache");
                HttpContext.Current.Response.Expires = 0;
            }
            StringBuilder script = new StringBuilder();
            script.Append("$(function(){ ");
            script.Append(content);
            if (redirectPage)
            {
                url = "setTimeout(function(){ window.location ='" + url + "'; }, 100);";
                script.Append(url);
            }
            script.Append("});");

            sender.RegisterStartupScript(sender.GetType()
                                        , "script"
                                        , script.ToString()
                                        , true);
        }

        public static void printScript(Control sender, string content, bool redirectPage, string url, bool noCache = false)
        {
            if (noCache)
            {
                HttpContext.Current.Response.Cache.SetNoStore();
                HttpContext.Current.Response.Cache.AppendCacheExtension("no-cache");
                HttpContext.Current.Response.Expires = 0;
            }
            StringBuilder script = new StringBuilder();
            script.Append("$(function(){ ");
            script.Append(content);
            if (redirectPage)
            {
                url = "setTimeout(function(){ window.location ='" + url + "'; }, 100);";
                script.Append(url);
            }
            script.Append("});");

            ScriptManager.RegisterClientScriptBlock(sender, sender.GetType(), "script", script.ToString(), true);
        }

        public static void printScript(Page sender, string content, bool redirectPage, string url, bool noCache = false)
        {
            if (noCache)
            {
                HttpContext.Current.Response.Cache.SetNoStore();
                HttpContext.Current.Response.Cache.AppendCacheExtension("no-cache");
                HttpContext.Current.Response.Expires = 0;
            }
            StringBuilder script = new StringBuilder();
            script.Append("$(function(){ ");
            script.Append(content);
            if (redirectPage)
            {
                url = "setTimeout(function(){ window.location ='" + url + "'; }, 100);";
                script.Append(url);
            }
            script.Append("});");
            ScriptManager.RegisterClientScriptBlock(sender, sender.GetType(), "script", script.ToString(), true);
        }

        public static bool SendSMS(Int64 movil_vendedor, string msg)
        {
            bool Respuesta = false;
            try
            {
                //Consumo de WebService
                EnvioSMS.SMSSoapClient notifSMS = new EnvioSMS.SMSSoapClient("SMSSoap");
                String resultSMS = notifSMS.EnviarSMS_83682_TEST(movil_vendedor, msg);
                Respuesta = true;
                //Fin Consumo WebService
            }
            catch (Exception ex)
            {
                Conect error = new Conect(1005);
                error.errorLog(ex, movil_vendedor.ToString(), "EnvioSMS");
            }
            return Respuesta;
        }

        public static void GridViewToHtmlTable(GridView Grid)
        {
            if (Grid.Rows.Count > 0)
            {
                Grid.UseAccessibleHeader = true;
                Grid.HeaderRow.TableSection = TableRowSection.TableHeader;
                Grid.FooterRow.TableSection = TableRowSection.TableFooter;
            }

            if (Grid.TopPagerRow != null)
            {
                Grid.TopPagerRow.TableSection = TableRowSection.TableHeader;
            }

            if (Grid.BottomPagerRow != null)
            {
                Grid.BottomPagerRow.TableSection = TableRowSection.TableFooter;
            }
        }

        public void errorLog(Exception ex, string query, string origen)
        {
            string usrID = null;
            int codError = -1;
            if (ex is HttpException)
            {
                HttpException checkException = (HttpException)ex;
                codError = checkException.GetHttpCode();
            }

            try
            {
                if (HttpContext.Current.Session["usr_Login"] != null)
                {
                    usrID = HttpContext.Current.Session["usr_Login"].ToString();
                }
                else if (HttpContext.Current.Session["user_LoginTMP"] != null)
                {
                    usrID = HttpContext.Current.Session["user_LoginTMP"].ToString();
                }
                string mensaje = ex.Message.ToString();
                addParameters("host", currentHost);
                addParameters("url_path", currentUrlPath);
                addParameters("path", currentPath);
                addParameters("linea", currentLine);
                addParameters("usr_Login", usrID);
                addParameters("ip", currentIP);
                addParameters("equipo", usrID);
                addParameters("script", query);
                addParameters("cod_excepcion", codError);
                addParameters("mensaje", mensaje);
                addParameters("notas", "Se produce excepcion en " + origen);
                addParameters("fec_evento", DateTime.Now);
                SqlCommand command = new SqlCommand(NAB_SP_GOABL_LOG_EXCEPCIONES, conexion);
                command.CommandType = CommandType.StoredProcedure;
                foreach (KeyValuePair<string, object> item in parameters)
                {
                    if (item.Value.GetType().ToString() == "System.String")
                    {
                        SqlParameter param = new SqlParameter("@" + item.Key, SqlDbType.VarChar);
                        param.Value = item.Value;
                        command.Parameters.Add(param);
                    }
                    else
                    {
                        command.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                data = command.ExecuteReader();
                data.Close();
            }
            catch (Exception exLog)
            {
                StringBuilder text = new StringBuilder();
                int i = 0;
                foreach (KeyValuePair<string, object> item in parameters)
                {
                    text.Append(item.Value);
                    if (parameters.Count > i)
                    {
                        text.Append("^");
                    }
                }
                text.AppendLine();
                //Write the string to a file.
                string filePathSql = HttpContext.Current.Server.MapPath("~/App_Data/Logs/LogsExceptionSql.txt");
                //StreamWriter fileSql = new StreamWriter(filePathSql);
                //fileSql.WriteLine(text.ToString());
                //fileSql.Close();
                string filePathGeneral = HttpContext.Current.Server.MapPath("~/App_Data/Logs/LogsExceptionSql.txt");
                StreamWriter fileGeneral = new StreamWriter(filePathGeneral);
                fileGeneral.WriteLine(exLog.ToString());
                fileGeneral.Close();
            }
            finally
            {
                data = null;
                this.Reset();
                conexion.Close();
                conexion.Dispose();
            }
        }

        public void errorLog(string usrID, int codError, string origenMetodo, string msg, string pila)
        {
            try
            {
                usrID = (usrID == null) ? ("anonimo") : (usrID);
                addParameters("host", currentHost);
                addParameters("url_path", currentUrlPath);
                addParameters("path", currentPath);
                addParameters("linea", currentLine);
                addParameters("usr_Login", usrID);
                addParameters("ip", currentIP);
                addParameters("equipo", usrID);
                addParameters("script", origenMetodo);
                addParameters("cod_excepcion", codError);
                addParameters("mensaje", msg);
                addParameters("notas", "Exception: " + pila);
                addParameters("fec_evento", DateTime.Now);
                SqlCommand command = new SqlCommand(NAB_SP_GOABL_LOG_EXCEPCIONES, conexion);
                command.CommandType = CommandType.StoredProcedure;
                foreach (KeyValuePair<string, object> item in parameters)
                {
                    if (item.Value.GetType().ToString() == "System.String")
                    {
                        SqlParameter param = new SqlParameter("@" + item.Key, SqlDbType.VarChar);
                        param.Value = item.Value;
                        command.Parameters.Add(param);
                    }
                    else
                    {
                        command.Parameters.AddWithValue(item.Key, item.Value);
                    }
                }
                string query = this.GetCommand();
                //Time out de conexión a 0
                command.CommandTimeout = 0;
                //Abre conexión
                conexion.Open();
                //Ejecuta sentencia
                data = command.ExecuteReader();
                data.Close();
            }
            catch (Exception exLog)
            {
                StringBuilder text = new StringBuilder();
                int i = 0;
                foreach (KeyValuePair<string, object> item in parameters)
                {
                    text.Append(item.Value);
                    if (parameters.Count > i)
                    {
                        text.Append("^");
                    }
                }
                text.AppendLine();
                 //Write the string to a file.
                string filePathSql = HttpContext.Current.Server.MapPath("~/App_Data/Logs/LogsExceptionSql.txt");
                StreamWriter fileSql = new StreamWriter(filePathSql);
                fileSql.WriteLine(text.ToString());
                fileSql.Close();
                string filePathGeneral = HttpContext.Current.Server.MapPath("~/App_Data/Logs/LogsException.txt");
                StreamWriter fileGeneral = new StreamWriter(filePathGeneral);
                fileGeneral.WriteLine(exLog.ToString());
                fileGeneral.Close();
            }
            finally
            {
                data = null;
                this.Reset();
                conexion.Close();
                conexion.Dispose();
            }
        }

        public Conect(int fileLine)
        {
            HttpRequest currentRequest = HttpContext.Current.Request;
            string ipAddress = (currentRequest.ServerVariables["HTTP_X_FORWARDED_FOR"]) ?? currentRequest.ServerVariables["REMOTE_ADDR"].Split(',')[0].Trim();
            this.currentIP = ipAddress;
            this.currentEquipo = currentRequest.UserHostName; //System.Net.Dns.GetHostEntry(ipAddress).HostName;
            this.currentHost = currentRequest.Url.Host;
            this.currentUrlPath = currentRequest.Url.AbsoluteUri;
            this.currentPath = currentRequest.Url.AbsolutePath;
            this.currentLine = fileLine;
        }

        public Conect(int fileLine, string conexionName)
        {
            HttpRequest currentRequest = HttpContext.Current.Request;
            string ipAddress = (currentRequest.ServerVariables["HTTP_X_FORWARDED_FOR"]) ?? currentRequest.ServerVariables["REMOTE_ADDR"].Split(',')[0].Trim();
            this.currentIP = ipAddress;
            this.currentEquipo = currentRequest.UserHostName; //System.Net.Dns.GetHostEntry(ipAddress).HostName;
            this.currentHost = currentRequest.Url.Host;
            this.currentUrlPath = currentRequest.Url.AbsoluteUri;
            this.currentPath = currentRequest.Url.AbsolutePath;
            this.currentLine = fileLine;
            //string Physicalpath =             .ApplicationPhysicalPath;
            //string  pathConection = Physicalpath + @"App_Data\SourcesConection.resx";

            string conexionString = (HttpContext.GetGlobalResourceObject("SourcesConection", modeTest ? conexionName + "_Test" : conexionName) ?? "").ToString();
            if (!String.IsNullOrEmpty(conexionString))
            {
                this.conexion = new SqlConnection(conexionString);
            }
            else
            {
                throw new Exception("El nombre de conexión " + conexionName + " no es válido.");
            }
        }

        public string GetArrayJS()
        {
            if (numRows > 0)
            {
                StringBuilder arrJS = new StringBuilder();

                for (int i = 1; i <= numRows; i++)
                {
                    int index = i - 1;
                    int size = dataRows[index].Length;
                    string split = index > 0 ? ":" : String.Empty;
                    switch (size)
                    {
                        case 1:
                            arrJS.Append(split + dataRows[index][0].ToString());
                            break;
                        case 2:
                            arrJS.Append(split + dataRows[index][1].ToString());
                            break;
                        default:
                            arrJS.Append("Error de origen de datos");
                            break;
                    }
                }
                return arrJS.ToString();
            }
            else
            {
                return "[No hay datos]";
            }
        }


        public static ArrayList Get_Pager(int PageSize)
        {
            ArrayList listPages = new ArrayList(PageSize);
            for (int i = 1; i <= PageSize; i++)
            {
                object itemPage = new { key = i, value = i };
                listPages.Add(itemPage);
            }
            return listPages;
        }

        public static string GetConfigValue(string alias)
        {
            Conect configValue = new Conect(1185);
            configValue.commandQuery = "Nab_Controller_Config_GetList";
            configValue.addParameters("alias", alias);
            configValue.execQuery(true);
            return configValue.getColumnValue(1);
        }

        public static void PropertyObject(object obj, System.Web.UI.ControlCollection Controls)
        {
            Dictionary<string, string> DataEntity = new Dictionary<string, string>();
            foreach (PropertyDescriptor prop in TypeDescriptor.GetProperties(obj)) {
                string nameProperty = prop.Name;
                string Value = (prop.GetValue(obj)??"").ToString();
                DataEntity.Add(nameProperty, Value);
            }

            foreach (System.Web.UI.Control control in Controls)
            {
                string value;
                if (control.HasControls())
                {
                    Conect.PropertyObject(obj, control.Controls);
                }
                else if (control is TextBox && control.ID != null)
                {
                    TextBox texBox = (TextBox)control;
                    value = DataEntity.ContainsKey(control.ID) ? DataEntity[control.ID] : null;
                    value = value??String.Empty;

                    texBox.Text = (String.IsNullOrEmpty(texBox.Text)) ? (value) : (texBox.Text);
                }
                else if (control is DropDownList && control.ID != null)
                {
                    DropDownList drop = (DropDownList)control;
                    value = DataEntity.ContainsKey(control.ID) ? DataEntity[control.ID] : null;
                    drop.SelectedValue = value ?? String.Empty;

                }
            }
        }
    }
}