﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.SessionState;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    public enum TipoTraspaso
    {
        Normal, Portabilidad
    }
    public sealed class TraspasoImpresion
    {
        #region Propiedades
        private string IdEb { get; set; }

        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        #endregion
        #region Métodos públicos
        //Constructor de la clase
        public TraspasoImpresion(string idEb)
        {
            if (idEb != null)
            {
                this.IdEb = idEb;
            }
            else throw new Exception("Ninguno de los parámetros ingresados puede ser nulo!");
        }

        //Método de generación de traspasos pertenecientes a un negocio
        public void Imprimir()
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.IdEb, "0");
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                string NombreCompletoRL = negocio.RepLegalNombre + " " + negocio.RepLegalApellido1 + " " + negocio.RepLegalApellido2;
                MappingRepository mappingRepository = new MappingRepository(0);
                List<NegocioTraspaso> negocioTraspasos = BNegocio.GetTraspasos(HttpContext.Current.User.Identity.Name, this.IdEb, "Resumen");
                List<NegocioTraspaso> negocioTraspasosLineas = BNegocio.GetTraspasos(HttpContext.Current.User.Identity.Name, this.IdEb, "Detalles");

                if (negocioTraspasos.Count > 0) {
                    negocioTraspasos.ForEach(negocioTraspaso =>
                    {
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("Traspaso");
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string nombreArchivo = String.Format("Traspaso-{0}-{1}.pdf", negocioTraspaso.NumIdentOrigen ?? "", this.IdEb);
                        string plantillaRutaTemp = String.Format("{0}{1}/{2}", RutaTemporales, this.IdEb, nombreArchivo);
                        DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        DiligenciadorPDF p2 = null;

                        p.AbrirPDFParaLlenar();
                        p.DiligenciarCampo("fecha", negocio.FecIngreso.ToShortDateString());
                        p.DiligenciarCampo("cel1", (negocioTraspaso.CelularOrigen.HasValue ? negocioTraspaso.CelularOrigen.ToString() : String.Empty));
                        p.DiligenciarCampo("cel2", negocio.RepLegalCelular.HasValue ? negocio.RepLegalCelular.ToString() : String.Empty);
                        p.DiligenciarCampo("name", negocioTraspaso.NombreClienteOrigen);
                        p.DiligenciarCampo("cC", negocioTraspaso.NumIdentOrigen);
                        p.DiligenciarCampo("razonSocialOrigen", negocio.razonSocial);
                        p.DiligenciarCampo("razonSocialDestino", negocio.razonSocial);
                        p.DiligenciarCampo("direccion", negocio.EmailCliente ?? String.Empty);
                        p.DiligenciarCampo("nameC", NombreCompletoRL);
                        p.DiligenciarCampo("nidC", negocio.RepLegalIdentidad.ToString());
                        p.DiligenciarCampo("doc1", negocioTraspaso.Adjunto1 ?? String.Empty);
                        p.DiligenciarCampo("doc2", negocioTraspaso.Adjunto2 ?? String.Empty);
                        p.DiligenciarCampo("doc3", negocioTraspaso.Adjunto3 ?? String.Empty);
                        p.DiligenciarCampo("doc4", negocioTraspaso.Adjunto4 ?? String.Empty);
                        p.DiligenciarCampo("csi", negocioTraspaso.ClausulasACargoOrigen.Value ? "X" : String.Empty);
                        p.DiligenciarCampo("cno", !negocioTraspaso.ClausulasACargoOrigen.Value ? "X" : String.Empty);
                        p.DiligenciarCampo("ssi", negocioTraspaso.SaldosACargoOrigen.Value ? "X" : String.Empty);
                        p.DiligenciarCampo("sno", !negocioTraspaso.SaldosACargoOrigen.Value ? "X" : String.Empty);
                        p.DiligenciarCampo("ccX", negocioTraspaso.IdTipoIdentOrigen == 1 ? "X" : String.Empty);
                        p.DiligenciarCampo("ceX", negocioTraspaso.IdTipoIdentOrigen == 4 ? "X" : String.Empty);
                        p.DiligenciarCampo("nitX", negocioTraspaso.IdTipoIdentOrigen == 7 ? "X" : String.Empty);
                        p.DiligenciarCampo("cCXC", negocio.RepLegalTipoID == 1 ? "X" : String.Empty);
                        p.DiligenciarCampo("ceXC", negocio.RepLegalTipoID == 4 ? "X" : String.Empty);
                        p.DiligenciarCampo("nitXC", negocio.RepLegalTipoID == 7 ? "X" : String.Empty);

                        List<NegocioTraspaso> negocioTraspasoLineas = negocioTraspasosLineas.Where(tl => tl.NumIdentOrigen == negocioTraspaso.NumIdentOrigen).ToList();
                        int i = 0;
                        int j = 0;
                        negocioTraspasoLineas.ForEach(x =>
                        {
                            if (i <= 4)
                            {
                                p.DiligenciarCampo(String.Format("NumCel[{0}]", i), x.LineaCelular != null ? x.LineaCelular.ToString() : String.Empty);
                                p.DiligenciarCampo(String.Format("Plan[{0}]", i), x.LineaCodPlan ?? String.Empty);
                                p.DiligenciarCampo(String.Format("Marca[{0}]", i), x.LineaRefEquipo ?? String.Empty);
                                i++;
                            }
                            else
                            {
                                while (i == 5)
                                {
                                    nombreArchivo = String.Format("Traspaso-Anexo-{0}-{1}.pdf", this.IdEb, negocioTraspaso.NombreClienteOrigen);
                                    plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("TraspasoAnexo");
                                    plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                                    plantillaRutaTemp = String.Format("{0}{1}/{2}", RutaTemporales, this.IdEb, nombreArchivo);
                                    p2 = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                                    p2.AbrirPDFParaLlenar();
                                    i++;
                                }
                                if (j < 23)
                                {
                                    p2.DiligenciarCampo(String.Format("NumCel[{0}]", i), x.LineaCelular != null ? x.LineaCelular.ToString() : String.Empty);
                                    p2.DiligenciarCampo(String.Format("Plan[{0}]", i), x.LineaCodPlan ?? String.Empty);
                                    p2.DiligenciarCampo(String.Format("Marca[{0}]", i), x.LineaRefEquipo ?? String.Empty);
                                    j++;
                                }
                                i++;
                            }
                        });
                        p.CerrarPDF();
                        if (p2 != null)
                        {
                            p2.CerrarPDF();
                        }
                    });
                }
            }
            catch (Exception)
            {
                throw new Exception("Error diligenciando el formarto de traspaso");
            }
        }
        #endregion
    }
}