﻿using Nabis.Models;
using Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis.Utilities;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using PlantillasTablas.Objetos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Impresion para otro si de contrato de condiciones
    /// uniformes.
    /// </summary>
    public class AnexoOtroSiCondicionesUniformesImpresion
    {
        /// <summary>
        /// Codigo asociado al negocio
        /// </summary>
        private string CodigoNegocio { get; set; }

        /// <summary>
        /// Ruta Temporal de archivos descargados.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        private RadicacionNegocioRepository radicacionNegocioRepository;
        /// <summary>
        /// Repositorio de Radicacion de negocio.
        /// </summary>
        public RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this.radicacionNegocioRepository == null)
                {
                    this.radicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return this.radicacionNegocioRepository;
            }
        }

        /// <summary>
        /// Constructor que recibe por parametro el codigo del negocio.
        /// </summary>
        /// <param name="codigoNegocio"></param>
        public AnexoOtroSiCondicionesUniformesImpresion(string codigoNegocio)
        {
            if (string.IsNullOrWhiteSpace(codigoNegocio))
            {
                throw new ArgumentNullException("codigoNegocio", "El codigo del negocio no puede ser un valor nulo o vacio");
            }
            this.CodigoNegocio = codigoNegocio;
        }

        /// <summary>
        /// Imprimir documentos asociados al otro si.
        /// </summary>
        public void ImprimirOtroSi()
        {
            this.ImprimirPDFOtroSi();
            this.ImprimirExcelOtroSi();
        }

        /// <summary>
        /// Imprimir otro si de contrato de condiciones uniformes.
        /// </summary>
        protected void ImprimirPDFOtroSi()
        {
            List<LineaInfo> lineas = this.RetornarListadeLineasDeBD();
            DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodigoNegocio, "1");
            NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(HttpContext.Current.User.Identity.Name, this.CodigoNegocio);
            if (lineas.Count > 0)
            {
                AnexoInfo Anexo = new AnexoInfo();
                string numeroContratoMarco = negocio.numContrato;
                if (infoAdicional != null)
                {
                    Anexo.IDKoral = infoAdicional.IdKoral;
                    Anexo.IDPricing = infoAdicional.IdPricing;
                }
                Anexo.NoContrato = string.IsNullOrWhiteSpace(numeroContratoMarco) ? this.CodigoNegocio : numeroContratoMarco;
                Anexo.Lineas = lineas;
                Anexo.Observaciones = negocio.Observaciones;
                Anexo.RutaPdf = String.Format("{0}/{1}/OtroSI-{2}.pdf", RutaTemporales, this.CodigoNegocio, this.CodigoNegocio);
                Anexo.GuardarLineasEnAnexoOtroSiPDF();
            }
        }

        protected void ImprimirExcelOtroSi()
        {
            List<LineaInfo> lineas = this.RetornarListadeLineasDeBD();
            if (lineas.Count > 0)
            {
                int i = 0;
                DataTable datos = new DataTable();
                datos.Columns.Add("NUMERO LINEA", typeof(string));
                datos.Columns.Add("NUMERO CELULAR", typeof(string));
                datos.Columns.Add("CODIGO PLAN CODIGO PLAN", typeof(string));
                datos.Columns.Add("CODIGO PLAN RENTA BASICA", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO VOZ SI", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO VOZ NO", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO SMS SI", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO SMS NO", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO DATOSSI", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO DATOSNO", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO LDISI", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO LDINO", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO PREMIUMSI", typeof(string));
                datos.Columns.Add("CONTROL CONDICIONES SERVICIO PREMIUMNO", typeof(string));
                datos.Columns.Add("VALOR MINUTO INCLUIDO VOZ M", typeof(string));
                datos.Columns.Add("VALOR MINUTO INCLUIDO VOZ F", typeof(string));
                datos.Columns.Add("VALOR MINUTO INCLUIDO VOZ G", typeof(string));
                datos.Columns.Add("VALOR MINUTO INCLUIDO VOZ O", typeof(string));
                datos.Columns.Add("VALOR MINUTO ADICIONAL VOZ M", typeof(string));
                datos.Columns.Add("VALOR MINUTO ADICIONAL VOZ F", typeof(string));
                datos.Columns.Add("VALOR MINUTO ADICIONAL VOZ G", typeof(string));
                datos.Columns.Add("VALOR MINUTO ADICIONAL VOZ O", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO INCLUIDO M", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO INCLUIDO G", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO INCLUIDO O", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO ADICIONAL M", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO ADICIONAL G", typeof(string));
                datos.Columns.Add("VALOR MENSAJE TEXTO ADICIONAL O", typeof(string));
                datos.Columns.Add("PLAN DE DATOS CODIGO SERVICIO", typeof(string));
                datos.Columns.Add("PLAN DE DATOS RENTA MENSUAL", typeof(string));
                datos.Columns.Add("PLAN DE DATOS CAPACIDAD DEL PLAN", typeof(string));
                datos.Columns.Add("PLAN DE DATOSKBADICIONAL", typeof(string));
                datos.Columns.Add("EQUIPO TRAIDO", typeof(string));
                datos.Columns.Add("EQUIPO VENDIDO", typeof(string));
                datos.Columns.Add("EQUIPO MARCA EQUIPO", typeof(string));
                datos.Columns.Add("EQUIPO REF MODELO", typeof(string));
                datos.Columns.Add("EQUIPO NOSERIAL IMEI", typeof(string));
                datos.Columns.Add("BANDA EQUIPO AWS", typeof(string));
                datos.Columns.Add("BANDA EQUIPO AWS 2500MHZ", typeof(string));
                datos.Columns.Add("BANDA EQUIPO OTRA", typeof(string));
                datos.Columns.Add("EQUIPO VENTA CUOTAS SI", typeof(string));
                datos.Columns.Add("EQUIPO VENTA CUOTAS NO", typeof(string));
                datos.Columns.Add("CUOTA INICIAL", typeof(string));
                datos.Columns.Add("VALOR A DIFERIR EN CUOTAS", typeof(string));
                datos.Columns.Add("NO DE CUOTAS A DIFERIR", typeof(string));
                datos.Columns.Add("NO SIMCARD89", typeof(string));
                datos.Columns.Add("CODIGO NEGOCIO", typeof(string));

                lineas.ForEach(x =>
                {
                    i++;
                    datos.Rows.Add(x.NumeroLinea, x.NumeroCelular, x.CodigoPlanCodigodeplan, x.CodigoPlanRentaBasica, x.ControlCondicionesServicioVozSi, x.ControlCondicionesServicioVozNo, x.ControlCondicionesServicioSMSSi
                                    , x.ControlCondicionesServicioSMSNo, x.ControlCondicionesServicioDatosSi, x.ControlCondicionesServicioDatosNo, x.ControlCondicionesServicioLDISi, x.ControlCondicionesServicioLDINo, x.ControlCondicionesServicioPremiumSi
                                    , x.ControlCondicionesServicioPremiumNo, x.ValorMinutoIncluidoVoz_M, x.ValorMinutoIncluidoVoz_F, x.ValorMinutoIncluidoVoz_G, x.ValorMinutoIncluidoVoz_O, x.ValorMinutoAdicionalVoz_M, x.ValorMinutoAdicionalVoz_F
                                    , x.ValorMinutoAdicionalVoz_G, x.ValorMinutoAdicionalVoz_O, x.ValorMensajedeTextoIncluido_M, x.ValorMensajedeTextoIncluido_G, x.ValorMensajedeTextoIncluido_O, x.ValorMensajedeTextoAdicional_M, x.ValorMensajedeTextoAdicional_G
                                    , x.ValorMensajedeTextoAdicional_O, x.PlanDeDatosCodigoServicio, x.PlanDeDatosRentaMensual, x.PlanDeDatosCapacidaddelPlan, x.PlanDeDatosKBAdicional, x.EquipoTraido, x.EquipoVendido, x.EquipoMarcaEquipo, x.EquipoRefModelo, x.EquipoNoSerialIMEI
                                    , x.BandaEquipoAWS, x.BandaEquipoAWS_2500MHZ, x.BandaEquipoOTRA, x.EquipoVentaCuotas_SI, x.EquipoVentaCuotas_NO, x.CuotaInicial, x.ValoraDiferirenCuotas, x.NodeCuotasaDiferir, x.NoSIMCARD89, x.CodigoNegocio);
                });
                GestionarArchivos.CrearExcel(String.Format("{0}/{1}/OtroSi-{2}", this.RutaTemporales, this.CodigoNegocio, this.CodigoNegocio), datos);
            }
        }


        /// <summary>
        /// Retornas las lineas de la base de datos.
        /// </summary>
        /// <param name="codigoNegocio">Codigo del negocio.</param>
        /// <returns></returns>
        public List<LineaInfo> RetornarListadeLineasDeBD()
        {
            if (string.IsNullOrEmpty(this.CodigoNegocio))
            {
                throw new ApplicationException("El valor del codigo negocio no puede ser un valor nulo o vacio.");
            }
            List<LineaInfo> lineas = new List<LineaInfo>();
            DataTable dt = BNegocio.GetOtroSi(HttpContext.Current.User.Identity.Name, this.CodigoNegocio);
            if (dt != null && dt.Rows.Count > 0)
            {
                int numeroLinea = 1;
                foreach (DataRow row in dt.Rows)
                {
                    LineaInfo linea = new LineaInfo();
                    linea.NumeroLinea = numeroLinea.ToString();
                    linea.NumeroCelular = (row.Field<long?>("NUMERO_MOVIL") != null) ? row.Field<long>("NUMERO_MOVIL").ToString() : null;
                    linea.CodigoPlanCodigodeplan = (row.Field<string>("ID_PLAN") != null) ? row.Field<string>("ID_PLAN").ToString() : null;
                    linea.CodigoPlanRentaBasica = row.Field<string>("CARGO_BASICO");
                    linea.ControlCondicionesServicioVozSi = ((row.Field<bool?>("CONTROL_VOZ") != null) && (row.Field<bool?>("CONTROL_VOZ").Equals(true))) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioVozNo = string.IsNullOrEmpty(linea.ControlCondicionesServicioVozSi) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioSMSSi = ((row.Field<bool?>("CONTROL_SMS") != null) && (row.Field<bool?>("CONTROL_SMS").Equals(true))) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioSMSNo = string.IsNullOrEmpty(linea.ControlCondicionesServicioSMSSi) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioDatosSi = ((row.Field<bool?>("CONTROL_DATOS") != null) && (row.Field<bool?>("CONTROL_DATOS").Equals(true))) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioDatosNo = string.IsNullOrEmpty(linea.ControlCondicionesServicioDatosSi) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioLDISi = ((row.Field<bool?>("CONTROL_LDI") != null) && (row.Field<bool?>("CONTROL_LDI").Equals(true))) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioLDINo = string.IsNullOrEmpty(linea.ControlCondicionesServicioLDISi) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioPremiumSi = ((row.Field<bool?>("CONTROL_PREMIUM") != null) && (row.Field<bool?>("CONTROL_PREMIUM").Equals(true))) ? "X" : string.Empty;
                    linea.ControlCondicionesServicioPremiumNo = string.IsNullOrEmpty(linea.ControlCondicionesServicioPremiumSi) ? "X" : string.Empty;
                    linea.ValorMinutoIncluidoVoz_M = (row.Field<string>("VALOR_MOVISTAR_VOZ") != null) ? row.Field<string>("VALOR_MOVISTAR_VOZ").ToString() : null;
                    linea.ValorMinutoIncluidoVoz_F = (row.Field<string>("VALOR_FIJO_VOZ") != null) ? row.Field<string>("VALOR_FIJO_VOZ").ToString() : null;
                    linea.ValorMinutoIncluidoVoz_G = string.Empty;
                    linea.ValorMinutoIncluidoVoz_O = (row.Field<string>("VALOR_OTROS_VOZ") != null) ? row.Field<string>("VALOR_OTROS_VOZ").ToString() : null;
                    linea.ValorMinutoAdicionalVoz_M = (row.Field<string>("VALOR_MOVISTAR_ADICIONAL_VOZ") != null) ? row.Field<string>("VALOR_MOVISTAR_ADICIONAL_VOZ").ToString() : null;
                    linea.ValorMinutoAdicionalVoz_F = (row.Field<string>("VALOR_FIJO_ADICIONAL_VOZ") != null) ? row.Field<string>("VALOR_FIJO_ADICIONAL_VOZ").ToString() : null;
                    linea.ValorMinutoAdicionalVoz_G = string.Empty;
                    linea.ValorMinutoAdicionalVoz_O = (row.Field<string>("VALOR_OTROS_ADICIONAL_VOZ") != null) ? row.Field<string>("VALOR_OTROS_ADICIONAL_VOZ").ToString() : null;
                    linea.ValorMensajedeTextoIncluido_M = (row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_M") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_M").ToString() : null;
                    linea.ValorMensajedeTextoIncluido_G = (row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_G") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_G").ToString() : null;
                    linea.ValorMensajedeTextoIncluido_O = (row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_O") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_INCLUIDO_O").ToString() : null;
                    linea.ValorMensajedeTextoAdicional_M = (row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_M") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_M").ToString() : null;
                    linea.ValorMensajedeTextoAdicional_G = (row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_G") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_G").ToString() : null;
                    linea.ValorMensajedeTextoAdicional_O = (row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_O") != null) ? row.Field<string>("VALOR_MENSAJE_TEXTO_ADICIONAL_O").ToString() : null;
                    linea.PlanDeDatosCodigoServicio = row.Field<string>("COD_SERV_SUPLEMENTARIO")??string.Empty;
                    linea.PlanDeDatosRentaMensual = row.Field<string>("CARGO_BASICO_SERV_SUPLEMENTARIO")??string.Empty;
                    linea.PlanDeDatosCapacidaddelPlan = row.Field<string>("CAPACIDAD_SERV_SUPLEMENTARIO") ?? string.Empty;
                    linea.PlanDeDatosKBAdicional = row.Field<string>("KB_ADICIONAL_SERV_SUPLEMENTARIO") ?? string.Empty;
                    linea.EquipoTraido = row.Field<string>("TRAIDO") == "S" ? "X" : string.Empty;
                    linea.EquipoVendido = row.Field<string>("TRAIDO") != "S" ? "X" : string.Empty;
                    linea.EquipoMarcaEquipo = row.Field<string>("EQUIPO_MARCA");
                    linea.EquipoRefModelo = row.Field<string>("EQUIPO_REFERENCIA");
                    linea.EquipoNoSerialIMEI = row.Field<string>("IMEI");
                    linea.BandaEquipoAWS = string.Empty;
                    linea.BandaEquipoAWS_2500MHZ = string.Empty;
                    linea.BandaEquipoOTRA = "X";
                    linea.EquipoVentaCuotas_SI = row.Field<bool?>("IS_VENTA_CUOTAS") != null ? row.Field<bool>("IS_VENTA_CUOTAS") ? "X" : string.Empty : string.Empty;
                    linea.EquipoVentaCuotas_NO = linea.EquipoVentaCuotas_SI == "X" ? "" : "X";
                    linea.CuotaInicial = row["CUOTA_INICIAL"] == DBNull.Value ? string.Empty : row["CUOTA_INICIAL"].ToString();
                    linea.ValoraDiferirenCuotas = row["VALOR_EQUIPO_DIFERIDO"] != DBNull.Value ? row["VALOR_EQUIPO_DIFERIDO"].ToString() : string.Empty;
                    linea.NodeCuotasaDiferir = row.Field<int?>("NUM_CUOTAS")!= null ? row.Field<int?>("NUM_CUOTAS").ToString(): string.Empty;
                    linea.NoSIMCARD89 = row.Field<string>("SIMCARD")??string.Empty;
                    linea.CodigoNegocio = "COD NEGOCIO";
                    lineas.Add(linea);
                    numeroLinea++;
                }
            }
            return lineas;
        }
    }
}
