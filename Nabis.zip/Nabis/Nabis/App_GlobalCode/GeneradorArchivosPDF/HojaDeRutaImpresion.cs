﻿using DiligenciadorPDFT;
using Nabis.Models;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.SessionState;

namespace Nabis.GeneradorArchivosPDF
{
    public class HojaDeRutaImpresion
    {
        #region Propiedades
        private string IdEb { get; set; }

        private string UsarioLogin { get; set; }

        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        private bool HojaDeRuta
        {
            get
            {
                //Se obtienen los documentos asociados al negocio y sino se solicita no se genera
                DocumentoTipoContratoRepository docsRepository = new DocumentoTipoContratoRepository();
                List<DocumentoTipoContrato> documentos = docsRepository.ObtenerDocumentos(this.IdEb).ToList();
                return (documentos.Find(doc => doc.NOMBRE_DOCUMENTO == "HOJA DE RUTA") != null);
            }
        }

        #endregion
        #region Métodos públicos
        public HojaDeRutaImpresion(string idEb, string usuarioLogin)
        {
            if (idEb != null && usuarioLogin != null)
            {
                this.IdEb = idEb;
                this.UsarioLogin = usuarioLogin;
            }
            else throw new Exception("Ninguno de los parámetros ingresados puede ser nulo!");
        }

        /// <summary>
        /// Inprimir la hoja de ruta del negocio
        /// </summary>
        public void Imprimir()
        {
            try
            {
                if (HojaDeRuta)
                {
                    DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.IdEb, "0");
                    NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(HttpContext.Current.User.Identity.Name, this.IdEb);

                    //Se inicializa y se le dal el nombre a la plantilla de Hoja de ruta
                    NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("HojaRuta");
                    string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                    string nombreArchivo = String.Format("Hoja de ruta-{0}.pdf", this.IdEb);
                    string plantillaRutaTemp = String.Format("{0}{1}/{2}", this.RutaTemporales, this.IdEb, nombreArchivo);
                    DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);

                    //Fecha actual
                    DateTime fecha = DateTime.Now;

                    //Validar si tiene o no ofertas el cliente
                    bool ofertas = String.IsNullOrEmpty(infoAdicional.IdKoral) && String.IsNullOrEmpty(infoAdicional.IdPricing);
                    string barrio = negocio.Complemento;
                    //Se obtiene el barrio del contrato
                    string contratoMarco = negocio.numContrato;

                    //Se obtiene la ciudad por codigo del distrito
                    string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                    //Ciudad opcional
                    string valCiudad = !String.IsNullOrEmpty(Convert.ToInt32(((int?)infoAdicional.CiudadOpcional)).ToString()) ? ((int?)infoAdicional.CiudadOpcional).ToString() : null;
                    string ciudadOpcional = string.Empty;
                    if (!string.IsNullOrEmpty(valCiudad)) {
                        ciudadOpcional = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", valCiudad).ToList()[0].Value;
                    }

                    //Se obtiene venta a cuotas
                    List<NAB_VENTAS_VENTA_A_CUOTAS> ventaCuotas = ObtenerVentaCuotaPorContrato(this.IdEb).ToList();
                    //Se obtiene la modalidad de venta de los equipos
                    List<NegocioModalidadesVenta> modalidades = BNegocio.GetModalidadesVenta(HttpContext.Current.User.Identity.Name, this.IdEb);
                    string equiposCredito = modalidades.Where(x => x.ModalidadVenta == "CREDITO").Sum(x => x.CantidadLineas).ToString();
                    string equiposContado = modalidades.Where(x => x.ModalidadVenta.Equals("CONTADO")).Sum(e => e.CantidadLineas).ToString();
                    string equiposTraidos = modalidades.Where(x => x.ModalidadVenta == "TRAIDOS").Sum(e => e.CantidadLineas).ToString();
                    int lineasVoz = modalidades.Where(x => x.Producto.ToUpper().Contains("VOZ")).Sum(e => e.CantidadLineas);
                    int lineasDatos = modalidades.Where(x =>!x.Producto.ToUpper().Equals("VOZ Y DATOS") && x.ModalidadVenta.ToUpper().Contains("DATOS") || x.ModalidadVenta.ToUpper().Contains("VERTICALES")).Sum(e => e.CantidadLineas);

                    //Obtener Nombre de agente
                    Vendedor vendedor = ComercialBL.GetVendedor(HttpContext.Current.User.Identity.Name, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
                    //Se diligencia pdf
                    p.AbrirPDFParaLlenar();
                    p.DiligenciarCampo("contrato", !String.IsNullOrEmpty(negocio.numContrato) ? negocio.numContrato : String.Empty);
                    p.DiligenciarCampo("regional", negocio.Regional);
                    p.DiligenciarCampo("canal", negocio.CanalVendedor);
                    p.DiligenciarCampo("numFun", this.IdEb);
                    p.DiligenciarCampo("ciudad", ciudad);
                    p.DiligenciarCampo("nombreAgente", !String.IsNullOrEmpty(vendedor.NombreAgente) ? vendedor.NombreAgente : String.Empty);
                    p.DiligenciarCampo("clienteNuevoSi", HojaDeRuta ? "X" : String.Empty);
                    p.DiligenciarCampo("clienteNuevoNo", HojaDeRuta ? String.Empty : "X");
                    p.DiligenciarCampo("razonSocial", negocio.razonSocial.ToUpper());
                    p.DiligenciarCampo("direccionNotificaciones", negocio.CodTipoCalle + " " + negocio.Direccion);
                    p.DiligenciarCampo("direccionComercial", !String.IsNullOrEmpty(infoAdicional.DireccionOpcional) ? infoAdicional.DireccionOpcional.ToUpper() : negocio.CodTipoCalle + " " + negocio.Direccion);
                    p.DiligenciarCampo("barrio", !String.IsNullOrEmpty(barrio) ? barrio.ToUpper() : String.Empty);
                    p.DiligenciarCampo("nit", !String.IsNullOrEmpty(negocio.numIdent) ? negocio.numIdent.ToUpper() : String.Empty);
                    p.DiligenciarCampo("ciudadNotificaciones", !String.IsNullOrEmpty(ciudad) ? ciudad.ToUpper() : String.Empty);
                    p.DiligenciarCampo("ciudadComercial", !String.IsNullOrEmpty(ciudadOpcional) ? ciudadOpcional : !String.IsNullOrEmpty(ciudad) ? ciudad.ToUpper() : String.Empty);
                    p.DiligenciarCampo("telefonosContacto", !String.IsNullOrEmpty(negocio.TelefonoCliente) ? negocio.TelefonoCliente : String.Empty);
                    p.DiligenciarCampo("fechaRadicacion", fecha.ToShortDateString());
                    p.DiligenciarCampo("duracionContrato", infoAdicional.DuracionServicios.ToString() + " MESES");
                    p.DiligenciarCampo("ofertaEstandarSi", ofertas ? "X" : String.Empty);
                    p.DiligenciarCampo("ofertaEstandarNo", ofertas ? String.Empty : "X");
                    p.DiligenciarCampo("direccionContrato", String.IsNullOrEmpty(negocio.Direccion) ? negocio.Direccion.ToUpper() : String.Empty);
                    p.DiligenciarCampo("idKoralOPricing", String.IsNullOrEmpty(infoAdicional.IdKoral) ? infoAdicional.IdPricing.ToUpper() : infoAdicional.IdKoral.ToUpper());
                    p.DiligenciarCampo("numLineasVoz", lineasVoz.ToString());
                    p.DiligenciarCampo("numLineasDatos", lineasDatos.ToString());
                    p.DiligenciarCampo("nombreCial", !String.IsNullOrEmpty(infoAdicional.Profesionalcia) ? infoAdicional.Profesionalcia.ToUpper() : String.Empty);
                    p.DiligenciarCampo("nombreZona", !String.IsNullOrEmpty(infoAdicional.Jefezona) ? infoAdicional.Jefezona.ToUpper() : String.Empty);
                    p.DiligenciarCampo("nombreGteComercial", !String.IsNullOrEmpty(infoAdicional.Gerenteregional) ? infoAdicional.Gerenteregional.ToUpper() : String.Empty);
                    p.DiligenciarCampo("clienteSalienteSi", Convert.ToBoolean((bool?)infoAdicional.Perfilsaliente) ? "X" : String.Empty);
                    p.DiligenciarCampo("clienteSalienteNo", Convert.ToBoolean((bool?)infoAdicional.Perfilsaliente) ? String.Empty : "X");

                    if (infoAdicional.Observaciones.Length > 84)
                    {
                        p.DiligenciarCampo("desComercial[0]", infoAdicional.Observaciones.Substring(0, 84));
                        p.DiligenciarCampo("desComercial[1]", infoAdicional.Observaciones.Substring(84, infoAdicional.Observaciones.Length - 84));
                    }
                    else
                    {
                        p.DiligenciarCampo("desComercial[0]", !String.IsNullOrEmpty(infoAdicional.Observaciones) ? infoAdicional.Observaciones.ToUpper() : String.Empty);
                    }

                    p.DiligenciarCampo("clienteCuotasSi", ventaCuotas.Count > 0 ? "X" : String.Empty);
                    p.DiligenciarCampo("clienteCuotasNo", ventaCuotas.Count > 0 ? String.Empty : "X");
                    p.DiligenciarCampo("equiposVendidos", !String.IsNullOrEmpty(equiposContado) ? equiposContado : String.Empty);
                    p.DiligenciarCampo("equiposTraidos", !String.IsNullOrEmpty(equiposTraidos) ? equiposTraidos : String.Empty);
                    p.DiligenciarCampo("equiposFinanciados", !String.IsNullOrEmpty(equiposCredito) ? equiposCredito : String.Empty);
                    if (ventaCuotas.Count > 0)
                    {
                        var cuotas = ventaCuotas.FirstOrDefault();
                        p.DiligenciarCampo("tresCuotasX", cuotas.NUMERO_CUOTAS == 3 ? "X" : String.Empty);
                        p.DiligenciarCampo("seisCuotasX", cuotas.NUMERO_CUOTAS == 6 ? "X" : String.Empty);
                        p.DiligenciarCampo("doceCuotasX", cuotas.NUMERO_CUOTAS == 12 ? "X" : String.Empty);
                        p.DiligenciarCampo("cuotaInicial", cuotas.CUOTA_INICIAL.ToString());
                    }
                    p.CerrarPDF();
                }
            }
            catch (Exception)
            {
                throw new Exception("Error generando PDF de Hoja de ruta");
            }
        }
        #endregion
        #region Métodos privados
        /// <summary>
        /// Método para obtener las ventas a cuotas por un determinado contrato
        /// </summary>
        /// <param name="idEb">Código del negocio</param>
        /// <returns></returns>
        private IEnumerable<NAB_VENTAS_VENTA_A_CUOTAS> ObtenerVentaCuotaPorContrato(string idEb)
        {
            RadicacionNegocioRepository RadicacionNegocioRepository = new RadicacionNegocioRepository(); ;
            return RadicacionNegocioRepository.ObtenerVentaACoutas(idEb).ToList();
        }
        #endregion
    }
}