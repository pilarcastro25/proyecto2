﻿using Nabis.Models.ANEXO;
using PlantillasTablas.Objetos;
using PlantillasTablas.Plantillas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.Repository;
using Nabis.Models.Entities;
using Nabis.Models;
using System.Data;
using Nabis.Utilities;
using Nabis.Models.AnexoOtroSiCondicionesUniformes.Entities;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using Nabis.Models.Entities;
using Nabis.Repository;
using System.Globalization;


namespace Nabis.GeneradorArchivosPDF
{
    public class AnexoOtroSiImpresion
    {
        /// <summary>
        /// Alias para obtener el IVA para aplicar a un equipo
        /// </summary>
        private const string VALOR_IVA = "valor_iva";
        /// <summary>
        /// Alias para obtener el valor minimo para aplicar IVA a un equipo.
        /// </summary>
        private const string VALOR_EQUIPO_IVA = "valor_equipo_iva";

        #region Campos clase
        /// <summary>
        /// Codigo del negocio
        /// </summary>
        private string IdEb { get; set; }
        /// <summary>
        /// Permite validar si el negocio selecionado es contrato marco.
        /// </summary>
        private bool EsContratoMarco { get; set; }
        #endregion

        #region Propiedades


        [ThreadStatic]
        private AnexoOtroSiCondicionesUniformesImpresion _AnexoOtroSiCondicionesUniformesImpresion;

        public AnexoOtroSiCondicionesUniformesImpresion AnexoOtroSiCondicionesUniformesImpresion
        {
            get
            {
                if (this._AnexoOtroSiCondicionesUniformesImpresion == null)
                {
                    this._AnexoOtroSiCondicionesUniformesImpresion = new AnexoOtroSiCondicionesUniformesImpresion(this.IdEb);
                }
                return this._AnexoOtroSiCondicionesUniformesImpresion;
            }
        }


        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        /// <summary>
        /// Obtener valor de parametro seleccionado por alias
        /// </summary>
        /// <param name="alias">alias de parametro</param>
        /// <returns></returns>
        protected string ObtenerValorParametro(string alias)
        {
            string plantillaRuta = string.Empty;
            NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(alias);
            if (plantilla != null)
            {
                plantillaRuta = plantilla.VALOR;
            }
            return plantillaRuta;
        }

        #endregion

        #region Métodos Públicos

        public AnexoOtroSiImpresion(String idEb, bool esContratoMarco)
        {
            if (string.IsNullOrEmpty(idEb))
            {
                throw new ArgumentNullException("idEb", "El codigo del negocio no puede ser un valor nulo o vacio.");
            }
            this.IdEb = idEb;
            this.EsContratoMarco = esContratoMarco;
        }

        /// <summary>
        /// Imprime los formatos del Otro si del contrato
        /// </summary>
        public void Imprimir()
        {
            if (this.EsContratoMarco)
            {
                ImprimirPDFOtroSi();
                ImprimirExcelOtroSi();
            }
            else
            {
                this.ImprimirPDFOtroSi_CondicionesUniformes();
            }
        }

        #region Contrato FUN
        /// <summary>
        /// Imprimir Otro Si en formato PDF
        /// </summary>
        public void ImprimirPDFOtroSi()
        {
            try
            {
                List<ObjetoLinea> objetosLinea = AnexoDAL.RetornarListadeLineasDeBD(this.IdEb);
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.IdEb, "0");
                NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(HttpContext.Current.User.Identity.Name, this.IdEb);
                if (objetosLinea.Count > 0)
                {
                    ObjetoAnexo Anexo = new ObjetoAnexo();
                    if (infoAdicional != null)
                    {
                        Anexo.IDKoral = infoAdicional.IdKoral;
                        Anexo.IDPricing = infoAdicional.IdPricing;
                    }
                    Anexo.NoContrato = negocio.numContrato;
                    Anexo.objetosLinea = objetosLinea;
                    Anexo.Observaciones = negocio.Observaciones;
                    // Anexar valor de IVA a aplicar 
                    string valorIVA = this.ObtenerValorParametro(VALOR_IVA);
                    if (!string.IsNullOrWhiteSpace(valorIVA))
                    {
                        Anexo.objetosLinea.ForEach(f => f.ValorIVAporAplicar = Convert.ToSingle(valorIVA, CultureInfo.InvariantCulture));
                    }
                    // Anexar valor minimo de equipo para aplicar IVA
                    string valorEquipoIVA = this.ObtenerValorParametro(VALOR_EQUIPO_IVA);
                    if (!string.IsNullOrWhiteSpace(valorEquipoIVA))
                    {
                        Anexo.objetosLinea.ForEach(f => f.ValorEquipoSinIVA = Convert.ToSingle(valorEquipoIVA, CultureInfo.InvariantCulture));
                    }
                    Anexo.RutaPdf = String.Format("{0}/{1}/OtroSI-{2}.pdf", RutaTemporales, this.IdEb, this.IdEb);
                    Anexo.GuardarLineasEnAnexoOtroSiPDF();
                }
            }
            catch (Exception)
            {

                throw new Exception("Error generando pdf OtroSi");
            }
        }

        /// <summary>
        /// Imprimir Otro Si en Excel
        /// </summary>
        public void ImprimirExcelOtroSi()
        {
            try
            {
                List<ObjetoLinea> objetosLinea = AnexoDAL.RetornarListadeLineasDeBD(this.IdEb);

                if (objetosLinea.Count > 0)
                {
                    int i = 0;
                    DataTable datos = new DataTable();
                    datos.Columns.Add("Indice de línea", typeof(int));
                    datos.Columns.Add("Numero", typeof(string));
                    datos.Columns.Add("Codigo del Plan", typeof(string));
                    datos.Columns.Add("Codigo servicio suplementario", typeof(string));
                    datos.Columns.Add("Renta básica", typeof(string));
                    datos.Columns.Add("Renta básica de servicio suplementario", typeof(string));
                    datos.Columns.Add("Capacidad de datos servicio suplementario", typeof(string));
                    datos.Columns.Add("Voz Si", typeof(string));
                    datos.Columns.Add("Voz No", typeof(string));
                    datos.Columns.Add("Dato Si", typeof(string));
                    datos.Columns.Add("Dato No", typeof(string));
                    datos.Columns.Add("SMS Si", typeof(string));
                    datos.Columns.Add("SMS No", typeof(string));
                    datos.Columns.Add("LDI Si", typeof(string));
                    datos.Columns.Add("LDI No", typeof(string));
                    datos.Columns.Add("Premium Si", typeof(string));
                    datos.Columns.Add("Premium No", typeof(string));
                    datos.Columns.Add("Portabilidad Si", typeof(string));
                    datos.Columns.Add("Portabilidad No", typeof(string));
                    datos.Columns.Add("Operador donante", typeof(string));
                    datos.Columns.Add("No NIP", typeof(string));
                    datos.Columns.Add("Equipo traido vendido", typeof(string));
                    datos.Columns.Add("No serial", typeof(string));
                    datos.Columns.Add("Imei", typeof(string));
                    datos.Columns.Add("Serial", typeof(string));
                    datos.Columns.Add("Marca y referencia del equipo", typeof(string));
                    datos.Columns.Add("Valor equipo", typeof(string));
                    datos.Columns.Add("Valor equipo Koral o Pricing", typeof(string));
                    datos.Columns.Add("Es a cuotas", typeof(string));
                    datos.Columns.Add("Es equipo a cuotas Si", typeof(string));
                    datos.Columns.Add("Es equipo a cuotas No", typeof(string));
                    datos.Columns.Add("Vuota inicial", typeof(double));
                    datos.Columns.Add("Valor a diferir en cuotas", typeof(double));
                    datos.Columns.Add("Número de cuotas a diferir", typeof(string));
                    datos.Columns.Add("Valor de la SimCard", typeof(string));
                    datos.Columns.Add("Numero de SimCard", typeof(string));
                    datos.Columns.Add("Valor beneficio", typeof(string));
                    datos.Columns.Add("Condiciones de beneficio", typeof(string));
                    datos.Columns.Add("Codigo beneficio", typeof(string));
                    datos.Columns.Add("Condiciones beneficio basico", typeof(string));
                    datos.Columns.Add("Codigo de beneficio basico", typeof(string));
                    datos.Columns.Add("Observaciones", typeof(string));

                    objetosLinea.ForEach(x =>
                    {
                        i++;
                        datos.Rows.Add(i, x.Numero, x.CodigoDePlan, x.CodServSuplementario, x.RentaBasica, x.RentaBasicaServSuplementario, x.CapacidadDeDatosServSupl, x.VozSi, x.VozNo, x.DatoSi, x.DatoNo, x.SMSSi, x.SMSNo, x.LDISi, x.LDINo, x.PremiumSi, x.PremiumNo, x.PortabilidadSi, x.PortabilidadNo, x.OperadorDonante, x.NoNIP, x.EquipoTraidoVendido, x.NoSerial, x.Imei, x.Serial, x.MarcaYRefEquipo, x.ValorEquipo, x.ValorEquipoKoralOPricing, x.EsACuotas, x.EsEquipoACuotasSi, x.EsEquipoACuotasNo, x.EquipoCuotaInicial, x.EquipoValorADiferirEnCuotas, x.EquipoNumeroDeCuotasADiferir, x.ValorDeLaSimCard, x.NumeroDeSimCard, x.EquipoValorBeneficio, x.CondicionesDeBeneficio, x.CodigoBeneficio, x.CondicionesBeneficioBasico, x.CodigoBeneficioBasico, x.Observaciones);
                    });

                    GestionarArchivos.CrearExcel(String.Format("{0}/{1}/OtroSi-{2}", this.RutaTemporales, this.IdEb, this.IdEb), datos);
                }
            }
            catch (Exception)
            {
                throw new Exception("Error generando excel del OtroSi");
            }
        }
        #endregion Contrato FUN

        /// <summary>
        /// Imprimir Otro Si en formato PDF
        /// </summary>
        protected void ImprimirPDFOtroSi_CondicionesUniformes()
        {
            this.AnexoOtroSiCondicionesUniformesImpresion.ImprimirOtroSi();
        }
        #endregion
    }
}