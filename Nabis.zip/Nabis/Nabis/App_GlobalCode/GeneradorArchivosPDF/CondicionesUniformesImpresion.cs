﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.GeneradorArchivosPDF;
using Nabis.Utilities;
using Nabis.Models.Entities;
using Nabis.Repository;
using DiligenciadorPDFT;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Fachada que permite la impresion de un documento de condiciones uniformes.
    /// </summary>
    public class CondicionesUniformesImpresion
    {
        /// <summary>
        /// Documentos asociados a una persona juridica
        /// </summary>
        string[] documentosPersonaJuridica = new string[] { "CDV", "CDV EXTRANJERIA", "NIT", "NIT EXTRANJERIA" };
        /// <summary>
        /// Documentos asociados a una persona natural.
        /// </summary>
        string[] documentosPersonaNatural = new string[] { "CC", "CEDULA EXTRANJERIA", "H2", "H2 EXTRANJERIA", "PASAPORTE" };
        /// <summary>
        /// Alias de plantilla para formato de condiciones uniformes de operador.
        /// </summary>
        private const string CONDICIONES_UNIFORMES_OPERADOR = "SSM_OPERADOR";
        /// <summary>
        /// Alias de plantilla para formato de condiciones uniformes de cliente.
        /// </summary>
        private const string CONDICIONES_UNIFORMES_CLIENTE = "SSM_CLIENTE";

        #region Propiedades

        /// <summary>
        /// Conversor de numeros en letras.
        /// </summary>
        NumLetra Valorenletras = new NumLetra();

        [ThreadStatic]
        private RadicacionNegocioRepository radicacionNegocioRepository;
        /// <summary>
        /// Repositorio que permite el acceso a la informacion asociada al negocio.
        /// </summary>
        public RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this.radicacionNegocioRepository == null)
                {
                    this.radicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return this.radicacionNegocioRepository;
            }
        }

        protected NabGlobalVendedoresRepository nabGlobalVendedoresRepository;
        /// <summary>
        /// Repositorio que permite el acceso a la informacion asociada al vendedor
        /// </summary>
        protected NabGlobalVendedoresRepository NabGlobalVendedoresRepository
        {
            get
            {
                if (this.nabGlobalVendedoresRepository == null)
                {
                    this.nabGlobalVendedoresRepository = new NabGlobalVendedoresRepository();
                }
                return this.nabGlobalVendedoresRepository;
            }
        }


        /// <summary>
        /// Codigo asociado al negocio.
        /// </summary>
        private string CodigoNegocio { get; set; }
        /// <summary>
        /// Nombre de usuario.
        /// </summary>
        private string NombreUsuario { get; set; }

        /// <summary>
        /// Rta temporal de los archivos.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        #endregion

        /// <summary>
        /// Constructor que recibe el codigo del negocio.
        /// </summary>
        /// <param name="codigoNegocio">Codigo del Negocio.</param>
        public CondicionesUniformesImpresion(string codigoNegocio)
        {
            if (string.IsNullOrWhiteSpace(codigoNegocio))
            {
                throw new ArgumentNullException("codigoNegocio", "El valor de codigo del negocio no puede ser un valor nulo o vacio.");
            }
            this.CodigoNegocio = codigoNegocio;
            this.NombreUsuario = HttpContext.Current.User.Identity.Name;
        }

        /// <summary>
        /// Diligenciar solicitud de servicios moviles.
        /// </summary>
        /// <param name="plantillaRuta">Plantilla de ruta</param>
        /// <param name="plantillaRutaTemp">Plnatilla de ruta temporal.</param>
        private void DiligenciarSolicitudServiciosMoviles(string plantillaRuta, string plantillaRutaTemp)
        {
            try
            {
                DateTime fecha = DateTime.Now;
                NumLetra conversorFecha = new NumLetra();
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(this.NombreUsuario, this.CodigoNegocio, "1");
                if (negocio != null)
                {
                    DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                    archivoPdf.AbrirPDFParaLlenar();
                    //Mapeo de cada uno de los valores a la plantilla
                    archivoPdf.DiligenciarCampo("txtFechaSolicitudDia", negocio.FecIngreso.ToString("dd"));
                    archivoPdf.DiligenciarCampo("txtFechaSolicitudMes", negocio.FecIngreso.ToString("MM"));
                    archivoPdf.DiligenciarCampo("txtFechaSolicitudAnio", negocio.FecIngreso.ToString("yyyy"));
                    archivoPdf.DiligenciarCampo("txt_codigo_negocio", negocio.idEb);
                    // Seccion Informacion de Vendedor.
                    this.DiligenciarInformacionVendedor(negocio, archivoPdf);
                    // Validar si el documento es de persona natural.
                    if (this.documentosPersonaNatural.Any(s => s.Equals(negocio.TipoIdentidad, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        // Seccion Persona natural
                        this.DiligenciarPersonaNatural(negocio, archivoPdf);
                    }
                    else
                    {
                        // Seccion Persona Juridica
                        this.DiligenciarPersonaJurica(negocio, archivoPdf);
                    }
                    // Seccion de facturacion.
                    this.DiligenciarDireccionFacturacion(negocio, archivoPdf);
                    // Seccion de pagare.
                    this.DiligenciarPagare(negocio, archivoPdf);
                    // Seccion de Venta a Cuotas.
                    this.DiligenciarVentaCuotas(negocio, archivoPdf);
                    // Seccion de Declaracion de Autorizacion.
                    this.DiligenciarDeclaracionAutorizacion(negocio, archivoPdf);
                    // Seccion de usuarios autorizados.
                    this.DiligenciarUsuariosAutorizados(archivoPdf);
                    archivoPdf.CerrarPDF();
                }
            }
            catch (Exception exc)
            {
                throw new Exception("Error en solicitud servicios Moviles");
            }
        }

        /// <summary>
        /// Diligenciar informacion de vendedor.
        /// </summary>
        /// <param name="negocio"></param>
        /// <param name="archivoPdf"></param>
        private void DiligenciarInformacionVendedor(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            //Informacion de vendedor
            Vendedor vendedor = ComercialBL.GetVendedor(this.NombreUsuario, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
            if (vendedor != null)
            {
                // Distribuidor
                archivoPdf.DiligenciarCampo("txtNombreDistribuidor", !string.IsNullOrWhiteSpace(vendedor.NombreResponsable) ? vendedor.NombreResponsable.ToUpperInvariant() : string.Empty);
                archivoPdf.DiligenciarCampo("txtCodigoDistribuidor", vendedor.CodAgente.HasValue ? vendedor.CodAgente.Value.ToString().ToUpperInvariant() : string.Empty);
                archivoPdf.DiligenciarCampo("txtCanal", !string.IsNullOrWhiteSpace(vendedor.CanalComercial) ? vendedor.CanalComercial.ToUpperInvariant() : string.Empty);

                // Vendedor
                archivoPdf.DiligenciarCampo("txtNombreVendedor", vendedor.NombreVendedor.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtCodigoVendedor", negocio.CodVendedor.ToString().ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVendedorCertificoCC", vendedor.NumIdent.ToString().ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtCelularVendedor", vendedor.NumCelular.ToString().ToUpperInvariant());
            }
        }

        /// <summary>
        /// Diligenciar la informacion de persona natural en un contrato de condiciones uniformes
        /// </summary>
        /// <param name="negocio">Informacion del negocio.</param>
        /// <param name="archivoPdf">Diligenciador de PDF.</param>
        private void DiligenciarPersonaNatural(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            // Obtener informacion adicional del negocio de condiciones uniformes.
            NegocioInformacionAdicionalPersonaNatural informacionAdicionalPersonaNatural = BNegocio.ObtenerInformacionAdicionalCondicionesUniformesPersonaNatural(this.CodigoNegocio, this.NombreUsuario);
            if (informacionAdicionalPersonaNatural != null)
            {
                // ======================= Persona Natural =================================//
                // Informacion Basica.
                archivoPdf.DiligenciarCampo("txtPersonaNatural", "X");
                archivoPdf.DiligenciarCampo("txtPersonaNaturalNombreCompleto", negocio.razonSocial.ToUpperInvariant());
                if (negocio.RepLegalFecnacimiento.HasValue)
                {
                    archivoPdf.DiligenciarCampo("txtPNFecNacDia", negocio.RepLegalFecnacimiento.Value.ToString("dd"));
                    archivoPdf.DiligenciarCampo("txtPNFecNacMes", negocio.RepLegalFecnacimiento.Value.ToString("MM"));
                    archivoPdf.DiligenciarCampo("txtPNFecNacAnio", negocio.RepLegalFecnacimiento.Value.ToString("yyyy"));
                }

                if (!string.IsNullOrWhiteSpace(negocio.TipoIdentidad))
                {
                    archivoPdf.DiligenciarCampo("txtPNTipIdentCC", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNTipIdentCE", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNTipIdentOtro", string.Empty);
                    switch (negocio.TipoIdentidad)
                    {
                        case "CC":
                            archivoPdf.DiligenciarCampo("txtPNTipIdentCC", "X");
                            break;
                        case "CE":
                            archivoPdf.DiligenciarCampo("txtPNTipIdentCE", "X");
                            break;
                        default:
                            archivoPdf.DiligenciarCampo("txtPNTipIdentOtro", "X");
                            break;
                    }
                }
                archivoPdf.DiligenciarCampo("txtPNNumeroIdentificacion", negocio.numIdent);

                // Informacion basica adicional
                if (!string.IsNullOrWhiteSpace(informacionAdicionalPersonaNatural.GeneroPersonaNatural))
                {
                    archivoPdf.DiligenciarCampo("txtSexoM", string.Empty);
                    archivoPdf.DiligenciarCampo("txtSexoF", string.Empty);
                    switch (informacionAdicionalPersonaNatural.GeneroPersonaNatural)
                    {
                        case "M":
                            archivoPdf.DiligenciarCampo("txtSexoM", "X");
                            break;
                        case "F":
                            archivoPdf.DiligenciarCampo("txtSexoF", "X");
                            break;
                        default:
                            archivoPdf.DiligenciarCampo("txtSexoM", "X");
                            break;
                    }
                }

                //Informacion Laboral.
                if (!string.IsNullOrWhiteSpace(informacionAdicionalPersonaNatural.TipoTrabajo))
                {
                    archivoPdf.DiligenciarCampo("txtILIndependiente", string.Empty);
                    archivoPdf.DiligenciarCampo("txtILHogar", string.Empty);
                    archivoPdf.DiligenciarCampo("txtILEmpleado", string.Empty);
                    archivoPdf.DiligenciarCampo("txtILAntiguedad", string.Empty);
                    switch (informacionAdicionalPersonaNatural.TipoTrabajo)
                    {
                        case "INDEPENDIENTE":
                            archivoPdf.DiligenciarCampo("txtILIndependiente", "X");
                            break;
                        case "HOGAR":
                            archivoPdf.DiligenciarCampo("txtILHogar", "X");
                            break;
                        case "EMPLEADO":
                            archivoPdf.DiligenciarCampo("txtILEmpleado", "X");
                            break;
                        case "ANTIGUEDAD":
                            archivoPdf.DiligenciarCampo("txtILAntiguedad", "X");
                            break;
                        default:
                            archivoPdf.DiligenciarCampo("txtILIndependiente", "X");
                            break;
                    }
                }
                archivoPdf.DiligenciarCampo("txtPNTipoContrato", informacionAdicionalPersonaNatural.TipoContrato.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtPNEmpresaDondeLabora", informacionAdicionalPersonaNatural.EmpresaDondeLabora.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtPNAsignacionSalarial", informacionAdicionalPersonaNatural.AsignacionSalarial);
                // Informacion Bancaria.
                if (!string.IsNullOrWhiteSpace(informacionAdicionalPersonaNatural.TarjetaCredito))
                {
                    archivoPdf.DiligenciarCampo("txtPNVisa", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNMasterCard", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNDinners", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNOtra", string.Empty);
                    switch (informacionAdicionalPersonaNatural.TarjetaCredito)
                    {
                        case "VISA":
                            archivoPdf.DiligenciarCampo("txtPNVisa", "X");
                            break;
                        case "MASTERCARD":
                            archivoPdf.DiligenciarCampo("txtPNMasterCard", "X");
                            break;
                        case "DINERS":
                            archivoPdf.DiligenciarCampo("txtPNDinners", "X");
                            break;
                        case "OTRA":
                        default:
                            archivoPdf.DiligenciarCampo("txtPNOtra", "X");
                            break;
                    }
                }
                archivoPdf.DiligenciarCampo("txtNumeroTarjeta", informacionAdicionalPersonaNatural.TarjertaCreditoNumero);
                if (informacionAdicionalPersonaNatural.TarjetaCreditoFechaVencimiento.HasValue)
                {
                    archivoPdf.DiligenciarCampo("txtFecVecMes", informacionAdicionalPersonaNatural.TarjetaCreditoFechaVencimiento.Value.ToString("MM"));
                    archivoPdf.DiligenciarCampo("txtFecVecAnio", informacionAdicionalPersonaNatural.TarjetaCreditoFechaVencimiento.Value.ToString("yyyy"));
                }

                // Usuario autorizado
                archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoNombre", informacionAdicionalPersonaNatural.NombreUsuarioAutorizado.ToUpperInvariant());
                if (!string.IsNullOrWhiteSpace(informacionAdicionalPersonaNatural.TipoDocumentoUsuarioAutorizado))
                {
                    archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoCC", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoCE", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoOtro", string.Empty);
                    switch (informacionAdicionalPersonaNatural.TipoDocumentoUsuarioAutorizado)
                    {
                        case "CC":
                            archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoCC", "X");
                            break;
                        case "CE":
                            archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoCE", "X");
                            break;
                        case "OTRO":
                            archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoOtro", "X");
                            break;
                        default:
                            archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoCC", "X");
                            break;
                    }
                }
                // Referencias personales - laborales.
                archivoPdf.DiligenciarCampo("txtPNUsuarioAutorizadoNumeroIdentificacion", informacionAdicionalPersonaNatural.NumeroIdentificacionUsuarioAutorizado);
                archivoPdf.DiligenciarCampo("txtRefPersonalNombre_1", informacionAdicionalPersonaNatural.ReferenciaPersonalNombre1.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtRefPersonalTelefono_1", informacionAdicionalPersonaNatural.ReferenciaPersonalTelefono1);
                archivoPdf.DiligenciarCampo("txtRefPersonalNombre_2", informacionAdicionalPersonaNatural.ReferenciaPersonalNombre2.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtRefPersonalEmpresa_2", informacionAdicionalPersonaNatural.ReferenciaPersonalEmpresa2.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtRefPersonalTelefono_2", informacionAdicionalPersonaNatural.ReferenciaPersonalTelefono2);

                archivoPdf.DiligenciarCampo("txtONECantidadLineas", negocio.cantLineas.ToString());
                archivoPdf.DiligenciarCampo("txtONECantidadLineasLetras", Valorenletras.Convertir(negocio.cantLineas.ToString(), true));
            }

            archivoPdf.DiligenciarCampo("txtONESI", string.Empty);
            archivoPdf.DiligenciarCampo("txtONENO", "X");
            archivoPdf.DiligenciarCampo("txtONEIdNegociacion", string.Empty);
            // Traer informacion adicional del negocio
            NegocioInformacionAdicional informacionAdicional = BNegocio.GetInfoAdicional(this.NombreUsuario, this.CodigoNegocio);
            if (informacionAdicional != null)
            {
                // Informacion adicional del negocio.
                if (!string.IsNullOrEmpty(informacionAdicional.IdKoral) || !string.IsNullOrEmpty(informacionAdicional.IdPricing))
                {
                    var id_koral_id_pricing = !string.IsNullOrEmpty(informacionAdicional.IdKoral) ? informacionAdicional.IdKoral : informacionAdicional.IdPricing;
                    archivoPdf.DiligenciarCampo("txtONESI", "X");
                    archivoPdf.DiligenciarCampo("txtONEIdNegociacion", id_koral_id_pricing.ToUpperInvariant());
                }
            }
        }

        /// <summary>
        /// Diligenciar persona juridica
        /// </summary>
        /// <param name="negocio">Informacion del negocio</param>
        /// <param name="archivoPdf">Diligencias informacion del PDF</param>
        private void DiligenciarPersonaJurica(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            // Obtener informacion adicional del negocio de condiciones uniformes.
            NegocioInformacionAdicional informacionAdicional = BNegocio.GetInfoAdicional(this.NombreUsuario, this.CodigoNegocio);
            if (informacionAdicional != null)
            {
                // ======================= Persona Juridica =================================//
                // Informacion Basica Cliente.
                archivoPdf.DiligenciarCampo("txtPersonaJuridica", "X");
                archivoPdf.DiligenciarCampo("txtPJNombre", negocio.razonSocial.ToUpperInvariant());
                if (negocio.RepLegalFecnacimiento.HasValue)
                {
                    archivoPdf.DiligenciarCampo("txtPJFecConsDia", negocio.RepLegalFecnacimiento.Value.ToString("dd"));
                    archivoPdf.DiligenciarCampo("txtPJFecConsMes", negocio.RepLegalFecnacimiento.Value.ToString("MM"));
                    archivoPdf.DiligenciarCampo("txtPJFecConsAnio", negocio.RepLegalFecnacimiento.Value.ToString("yyyy"));
                }
                if (!string.IsNullOrWhiteSpace(negocio.TipoIdentidad))
                {
                    archivoPdf.DiligenciarCampo("txtPJNit", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPJCDV", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPJNITExtranjeria", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPJOtro", string.Empty);
                    archivoPdf.DiligenciarCampo("txtPJOtroCual", string.Empty);
                    switch (negocio.TipoIdentidad)
                    {
                        case "NIT":
                            archivoPdf.DiligenciarCampo("txtPJNit", "X");
                            break;
                        case "CDV":
                            archivoPdf.DiligenciarCampo("txtPJCDV", "X");
                            break;
                        case "NIT EXTRANJERIA":
                            archivoPdf.DiligenciarCampo("txtPJNITExtranjeria", "X");
                            break;
                        default:
                            archivoPdf.DiligenciarCampo("txtPJOtro", "X");
                            archivoPdf.DiligenciarCampo("txtPJOtroCual", negocio.TipoIdentidad);
                            break;
                    }
                }
                archivoPdf.DiligenciarCampo("txtPJNumeroIdentificacion", negocio.numIdent);
                archivoPdf.DiligenciarCampo("txtPJTelefono", negocio.TelefonoCliente);
                // Representante legal.
                archivoPdf.DiligenciarCampo("txtPJRepLegalNombre", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                //if (!string.IsNullOrWhiteSpace(negocio.RepLegalIdentidad))
                //{
                archivoPdf.DiligenciarCampo("txtPJTipIdentCC", string.Empty);
                archivoPdf.DiligenciarCampo("txtPJTipIdentCE", string.Empty);
                archivoPdf.DiligenciarCampo("txtPJTipIdentCDV", string.Empty);
                archivoPdf.DiligenciarCampo("txtPJTipIdentOtro", string.Empty);
                archivoPdf.DiligenciarCampo("txtPJTipIdentCual", string.Empty);
                // Valor por defecto
                archivoPdf.DiligenciarCampo("txtPJTipIdentCC", "X");
                archivoPdf.DiligenciarCampo("txtPJRepLegalNumIdentificacion", negocio.RepLegalIdentidad.ToString());
                archivoPdf.DiligenciarCampo("txtPJRepLegalEmail", string.Empty);
                //}
                // Referencias comerciales.
                archivoPdf.DiligenciarCampo("txtPJRefComEmpresa_1", !string.IsNullOrWhiteSpace(informacionAdicional.InstitucionReferencia1) ? informacionAdicional.InstitucionReferencia1 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComNombreContacto_1", !string.IsNullOrWhiteSpace(informacionAdicional.NombreClienteSocio2) ? informacionAdicional.NombreClienteSocio2 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComFijo_1", !string.IsNullOrWhiteSpace(informacionAdicional.TelcontactoReferencia1) ? informacionAdicional.TelcontactoReferencia1 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComMovil_1", !string.IsNullOrWhiteSpace(informacionAdicional.MovilContactoReferencia1) ? informacionAdicional.MovilContactoReferencia1 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComEmpresa_2", !string.IsNullOrWhiteSpace(informacionAdicional.InstitucionReferencia2) ? informacionAdicional.InstitucionReferencia2 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComNombreContacto_2", !string.IsNullOrWhiteSpace(informacionAdicional.NombreClienteSocio2) ? informacionAdicional.NombreClienteSocio2 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComFijo_2", !string.IsNullOrWhiteSpace(informacionAdicional.TelcontactoReferencia2) ? informacionAdicional.TelcontactoReferencia2 : string.Empty);
                archivoPdf.DiligenciarCampo("txtPJRefComMovil_2", !string.IsNullOrWhiteSpace(informacionAdicional.MovilContactoReferencia2) ? informacionAdicional.MovilContactoReferencia2 : string.Empty);
                // Cantidad de lineas.
                archivoPdf.DiligenciarCampo("txtONECantidadLineas", negocio.cantLineas.ToString());
                archivoPdf.DiligenciarCampo("txtONECantidadLineasLetras", Valorenletras.Convertir(negocio.cantLineas.ToString(), true));

                archivoPdf.DiligenciarCampo("txtONESI", string.Empty);
                archivoPdf.DiligenciarCampo("txtONENO", "X");
                archivoPdf.DiligenciarCampo("txtONEIdNegociacion", string.Empty);
                // Informacion adicional del negocio.
                if (!string.IsNullOrWhiteSpace(informacionAdicional.IdKoral) || !string.IsNullOrWhiteSpace(informacionAdicional.IdPricing))
                {
                    var id_koral_id_pricing = !string.IsNullOrEmpty(informacionAdicional.IdKoral) ?
                        informacionAdicional.IdKoral : informacionAdicional.IdPricing;
                    archivoPdf.DiligenciarCampo("txtONESI", "X");
                    archivoPdf.DiligenciarCampo("txtONENO", string.Empty);
                    archivoPdf.DiligenciarCampo("txtONEIdNegociacion", id_koral_id_pricing.ToUpperInvariant());
                }
            }
        }

        /// <summary>
        /// Diligencias Seccion de Pagare
        /// </summary>
        /// <param name="negocio"></param>
        /// <param name="archivoPdf"></param>
        private void DiligenciarPagare(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            // Digitar informacion de Pagare
            archivoPdf.DiligenciarCampo("txtPagNombreFirma", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
            archivoPdf.DiligenciarCampo("txtPagCedulaFirma", negocio.RepLegalIdentidad.ToString());
        }

        /// <summary>
        /// Diligenciar seccion de direccion para facturacion.
        /// </summary>
        /// <param name="negocio">Informacion de Negocio</param>
        /// <param name="archivoPdf">Diligenciador PDF</param>
        private void DiligenciarDireccionFacturacion(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            //TODO: Traer informacion de direccion de facturacion de tabla de cuenta.
            // Obtener informacion adicional del negocio de condiciones uniformes.
            NegocioInformacionAdicional informacionAdicional = BNegocio.GetInfoAdicional(this.NombreUsuario, this.CodigoNegocio);
            if (informacionAdicional != null)
            {
                archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmailSI", string.Empty);
                archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmailNO", "X");
                archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmail", string.Empty);
                archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaSI", string.Empty);
                archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaNO", "X");
                archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaDireccion", string.Empty);
                if (informacionAdicional.EnvioCorreoElectronico.HasValue)
                {
                    archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmailSI", informacionAdicional.EnvioCorreoElectronico.Value ? "X" : string.Empty);
                    archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmailNO", !informacionAdicional.EnvioCorreoElectronico.Value ? "X" : string.Empty);
                    archivoPdf.DiligenciarCampo("txtDFAceptoFacturacionEmail", informacionAdicional.CorreoElectronico);

                    archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaSI", string.Empty);
                    archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaNO", "X");
                    archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaDireccion", string.Empty);
                    if (!informacionAdicional.EnvioCorreoElectronico.Value)
                    {
                        archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaSI", "X");
                        archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaNO", string.Empty);
                        archivoPdf.DiligenciarCampo("txtAceptoFacturacionFisicaDireccion", negocio.Direccion);
                    }
                }

                NegocioInformacionCuentas informacionCuenta = BNegocio.ObtenerInformacionCuentasNegocio(this.CodigoNegocio, this.NombreUsuario);
                if (informacionCuenta != null)
                {
                    archivoPdf.DiligenciarCampo("txtDCCasa", "X");
                    archivoPdf.DiligenciarCampo("txtDCApto", string.Empty);
                    archivoPdf.DiligenciarCampo("txtDCBloque", string.Empty);
                    archivoPdf.DiligenciarCampo("txtDCInterior", string.Empty);
                    archivoPdf.DiligenciarCampo("txtDCOtro", string.Empty);
                    if (!string.IsNullOrWhiteSpace(informacionCuenta.TipoVivienda))
                    {

                        switch (informacionCuenta.TipoVivienda)
                        {
                            case "CASA":
                                archivoPdf.DiligenciarCampo("txtDCCasa", "X");
                                break;
                            case "APTO":
                                archivoPdf.DiligenciarCampo("txtDCApto", "X");
                                break;
                            case "BLOQUE":
                                archivoPdf.DiligenciarCampo("txtDCBloque", "X");
                                break;
                            case "INTERIOR":
                                archivoPdf.DiligenciarCampo("txtDCInterior", "X");
                                break;
                            case "OTRO":
                                archivoPdf.DiligenciarCampo("txtDCOtro", "X");
                                break;
                            default:
                                break;
                        }
                    }

                    archivoPdf.DiligenciarCampo("txtDCBarrio", informacionCuenta.Barrio);
                    archivoPdf.DiligenciarCampo("txtDCCiudad", informacionCuenta.NombreCiudad);
                    archivoPdf.DiligenciarCampo("txtDCDepartamento", informacionCuenta.NombreDepartamento);
                    archivoPdf.DiligenciarCampo("txtDCTelefonoResidencia", informacionCuenta.Telefono);
                    archivoPdf.DiligenciarCampo("txtDCTelefonoMovil", string.IsNullOrWhiteSpace(informacionCuenta.TelefonoMovil) ? "" : informacionCuenta.TelefonoMovil);
                }


                archivoPdf.DiligenciarCampo("txtDCEnvioEmailSI",
                    informacionAdicional.AutorizacionEnvioEmail.HasValue && informacionAdicional.AutorizacionEnvioEmail.Value ? "X" : string.Empty);
                archivoPdf.DiligenciarCampo("txtDCEnvioEmailNO",
                    !(informacionAdicional.AutorizacionEnvioEmail.HasValue && informacionAdicional.AutorizacionEnvioEmail.Value) ? "X" : string.Empty);
                archivoPdf.DiligenciarCampo("txtDCIncluirNumeroCelularSI",
                    informacionAdicional.AutorizacionNumeroCelular.HasValue && informacionAdicional.AutorizacionNumeroCelular.Value ? "X" : string.Empty);
                archivoPdf.DiligenciarCampo("txtDCIncluirNumeroCelularNO",
                    !(informacionAdicional.AutorizacionNumeroCelular.HasValue && informacionAdicional.AutorizacionNumeroCelular.Value) ? "X" : string.Empty);
            }
        }

        /// <summary>
        /// Diligenciar seccion de venta a cuotas
        /// </summary>
        /// <param name="archivoPdf"></param>
        [Obsolete]
        private void DiligenciarVentaCuotas(DiligenciadorPDF archivoPdf)
        {
            // TODO: implementar segun contrato FUN.

            //Digitar formato de venta a cuotas.
            NAB_VENTAS_VENTA_A_CUOTAS ventaACuotas = this.RadicacionNegocioRepository.ObtenerVentaACoutas(this.CodigoNegocio).FirstOrDefault();
            if (ventaACuotas != null)
            {
                string numerocontratoMarco = MappingRepository.ObtenerNumeroContratoMarco(ventaACuotas.IDENTIFICACION_COMPRADOR);
                string lugarFecha = string.Format("{0}-{1}", ventaACuotas.LUGAR_DE_CELEBRACION_DEL_CONTRATO, ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.Value.ToString("yyyy/MM/dd"));
                //Mapeo de cada uno de los valores a la plantilla
                archivoPdf.DiligenciarCampo("txtNumeroContratoMarco", numerocontratoMarco);
                archivoPdf.DiligenciarCampo("txtVACFechaCelebracionContrato", lugarFecha);
                archivoPdf.DiligenciarCampo("txtVACFecContDia", ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.HasValue ? ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.Value.ToString("dd") : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACFecContMes", ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.HasValue ? ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.Value.ToString("MM") : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACFecContAnio", ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.HasValue ? ventaACuotas.FECHA_DE_CELEBRACION_DEL_CONTRATO.Value.ToString("yyyy") : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACNombreComprador", ventaACuotas.NOMBRE_COMPRADOR.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACDocumentoIdentidad", ventaACuotas.IDENTIFICACION_COMPRADOR.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACDireccion", ventaACuotas.DIRECCION_COMPRADOR.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACCiudad", ventaACuotas.CIUDAD_COMPRADOR.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACCorreoElectronico", ventaACuotas.CORREO_ELECTRONICO_COMPRADOR.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACTelefonoContacto", ventaACuotas.TELEFONO_COMPRADOR);
                archivoPdf.DiligenciarCampo("txtVACValorTotalEquipos", ventaACuotas.VALOR_TOTAL_EQUIPO.HasValue ? ventaACuotas.VALOR_TOTAL_EQUIPO.Value.ToString() : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACValorCuotaInicial", ventaACuotas.CUOTA_INICIAL.HasValue ? ventaACuotas.CUOTA_INICIAL.Value.ToString() : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACNumeroCuotas", ventaACuotas.NUMERO_CUOTAS.HasValue ? ventaACuotas.NUMERO_CUOTAS.Value.ToString() : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACValorCuota", ventaACuotas.CUOTA_MENSUAL.HasValue ? ventaACuotas.CUOTA_MENSUAL.Value.ToString() : string.Empty);
                archivoPdf.DiligenciarCampo("txtVACNombreFirma", ventaACuotas.NOMBRE_REPRESENTANTE_LEGAL.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACCedulaFirma", ventaACuotas.IDENTIFICACION_REPRESENTANTE_LEGAL.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACPagNombreFirma", ventaACuotas.NOMBRE_REPRESENTANTE_LEGAL.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtVACPagCedulaFirma", ventaACuotas.IDENTIFICACION_REPRESENTANTE_LEGAL.ToUpperInvariant());
            }
        }

        /// <summary>
        /// Diligenciar seccion de venta cuotas
        /// </summary>
        /// <param name="archivoPdf"></param>
        private void DiligenciarVentaCuotas(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            //DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(this.NombreUsuario, this.CodigoNegocio, "0");
            NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(this.NombreUsuario, this.CodigoNegocio);
            List<NegocioModalidadesVenta> modalidadesVentas = BNegocio.GetModalidadesVenta(this.NombreUsuario, this.CodigoNegocio);
            //Fecha actual
            DateTime fecha = DateTime.Now;
            bool ofertas = String.IsNullOrEmpty(infoAdicional.IdKoral) && String.IsNullOrEmpty(infoAdicional.IdPricing);
            string barrio = negocio.Complemento;
            string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
            if (negocio != null && modalidadesVentas.Count > 0)
            {
                NegocioModalidadesVenta item = modalidadesVentas.FirstOrDefault(it => it.IsVentaCuotas.HasValue && it.IsVentaCuotas.Value);
                if (item != null)
                {
                    archivoPdf.DiligenciarCampo("txtNumeroContratoMarco", negocio.numContrato);
                    archivoPdf.DiligenciarCampo("txtVACFechaCelebracionContrato", string.Format("{0}-{1}", ciudad, negocio.FecIngreso.ToString("yyyy/MM/dd")));
                    archivoPdf.DiligenciarCampo("txtVACFecContDia", negocio.FecIngreso.ToString("dd"));
                    archivoPdf.DiligenciarCampo("txtVACFecContMes", negocio.FecIngreso.ToString("MM"));
                    archivoPdf.DiligenciarCampo("txtVACFecContAnio", negocio.FecIngreso.ToString("yyyy"));
                    archivoPdf.DiligenciarCampo("txtVACNombreComprador", negocio.razonSocial.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVACDocumentoIdentidad", negocio.numIdent.ToString());
                    archivoPdf.DiligenciarCampo("txtVACDireccion", negocio.CodTipoCalle + " " + negocio.Direccion.ToUpperInvariant() + " " + barrio);
                    archivoPdf.DiligenciarCampo("txtVACCiudad", ciudad.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVACCorreoElectronico", negocio.EmailCliente.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVACTelefonoContacto", negocio.TelefonoCliente);
                    archivoPdf.DiligenciarCampo("txtVACValorTotalEquipos", item.ValorTotalEquipos.HasValue ? item.ValorTotalEquipos.Value.ToString() : string.Empty);
                    archivoPdf.DiligenciarCampo("txtVACValorCuotaInicial", item.CuotaInicial.HasValue ? item.CuotaInicial.ToString() : string.Empty);
                    archivoPdf.DiligenciarCampo("txtVACNumeroCuotas", item.NumeroCuotas.HasValue ? item.NumeroCuotas.Value.ToString() : string.Empty);
                    archivoPdf.DiligenciarCampo("txtVACValorCuota", item.CuotaMensual.HasValue ? item.CuotaMensual.Value.ToString() : string.Empty);
                    archivoPdf.DiligenciarCampo("txtVACNombreFirma", negocio.RepLegalNombre.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVACCedulaFirma", negocio.RepLegalIdentidad.ToString());
                    archivoPdf.DiligenciarCampo("txtVACPagNombreFirma", negocio.RepLegalNombre.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVACPagCedulaFirma", negocio.RepLegalIdentidad.ToString());
                }
            }
        }


        /// <summary>
        /// Diligencias de seccion de declaracion de autorizacion.
        /// </summary>
        /// <param name="negocio"></param>
        /// <param name="archivoPdf"></param>
        private void DiligenciarDeclaracionAutorizacion(DatosNegocio negocio, DiligenciadorPDF archivoPdf)
        {
            archivoPdf.DiligenciarCampo("txtFNNombreFirma", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
            archivoPdf.DiligenciarCampo("txtFNCedulaFirma", negocio.RepLegalIdentidad.ToString());
        }

        /// <summary>
        /// Diligencias seccion de usuarios autorizados.
        /// </summary>
        /// <param name="archivoPdf"></param>
        private void DiligenciarUsuariosAutorizados(DiligenciadorPDF archivoPdf)
        {
            // Informacion de usuarios autorizados
            NegocioContactosAutorizados contratoUsuarioAutorizado = BNegocio.GetContactosAutorizados(this.NombreUsuario, this.CodigoNegocio);
            if (contratoUsuarioAutorizado != null)
            {
                // Usuario autorizado 1
                archivoPdf.DiligenciarCampo("txtAUTNombreAutorizado_1", contratoUsuarioAutorizado.Contacto1Nombre.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTNumeroCelular_1", contratoUsuarioAutorizado.Contacto1Movil.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTCorreoElectronico_1", contratoUsuarioAutorizado.Contacto1Email.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTCCFirma_1", contratoUsuarioAutorizado.Contacto1Cedula.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUT_A_1", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_C_1", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_D_1", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_AD_1", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_CD_1", string.Empty);
                if (!string.IsNullOrWhiteSpace(contratoUsuarioAutorizado.Contacto1PerfilAutorizado))
                {
                    switch (contratoUsuarioAutorizado.Contacto1PerfilAutorizado.ToUpperInvariant())
                    {
                        case "A":
                            archivoPdf.DiligenciarCampo("txtAUT_A_1", "X");
                            break;
                        case "C":
                            archivoPdf.DiligenciarCampo("txtAUT_C_1", "X");
                            break;
                        case "D":
                            archivoPdf.DiligenciarCampo("txtAUT_D_1", "X");
                            break;
                        case "AD":
                            archivoPdf.DiligenciarCampo("txtAUT_AD_1", "X");
                            break;
                        case "CD":
                            archivoPdf.DiligenciarCampo("txtAUT_CD_1", "X");
                            break;
                        default:
                            break;
                    }
                }
                // Usuario autorizado 2
                archivoPdf.DiligenciarCampo("txtAUTNombreAutorizado_2", contratoUsuarioAutorizado.Contacto2Nombre.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTNumeroCelular_2", contratoUsuarioAutorizado.Contacto2Movil.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTCorreoElectronico_2", contratoUsuarioAutorizado.Contacto2Email.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUTCCFirma_2", contratoUsuarioAutorizado.Contacto2Cedula.ToUpperInvariant());
                archivoPdf.DiligenciarCampo("txtAUT_A_2", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_C_2", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_D_2", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_AD_2", string.Empty);
                archivoPdf.DiligenciarCampo("txtAUT_CD_2", string.Empty);
                if (!string.IsNullOrWhiteSpace(contratoUsuarioAutorizado.Contacto2PerfilAutorizado.ToUpperInvariant()))
                {
                    switch (contratoUsuarioAutorizado.Contacto2PerfilAutorizado.ToUpperInvariant())
                    {
                        case "A":
                            archivoPdf.DiligenciarCampo("txtAUT_A_2", "X");
                            break;
                        case "C":
                            archivoPdf.DiligenciarCampo("txtAUT_C_2", "X");
                            break;
                        case "D":
                            archivoPdf.DiligenciarCampo("txtAUT_D_2", "X");
                            break;
                        case "AD":
                            archivoPdf.DiligenciarCampo("txtAUT_AD_2", "X");
                            break;
                        case "CD":
                            archivoPdf.DiligenciarCampo("txtAUT_CD_2", "X");
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Diligenciar solicitud de servicios moviles.
        /// </summary>
        public void DiligenciarPDFSolicitudServiciosMoviles()
        {
            string nombreArchivo = string.Format("SOLICITU_SERVICIOS_MOVILES_OPERADOR-{0}.pdf", this.CodigoNegocio);
            //Se trae la ruta en la cual se encuentra almacenado el Template del contrato
            NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONDICIONES_UNIFORMES_OPERADOR);
            string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
            string plantillaRutaTemp = String.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoNegocio, nombreArchivo);
            // Generar documento de solicitud de servicios moviles para operador.
            this.DiligenciarSolicitudServiciosMoviles(plantillaRuta, plantillaRutaTemp);

            nombreArchivo = string.Format("SOLICITU_SERVICIOS_MOVILES_CLIENTE-{0}.pdf", this.CodigoNegocio);
            //Se trae la ruta en la cual se encuentra almacenado el Template del contrato
            plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONDICIONES_UNIFORMES_CLIENTE);
            plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
            plantillaRutaTemp = String.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoNegocio, nombreArchivo);
            // Generar documento de solicitud de servicios moviles para cliente.
            this.DiligenciarSolicitudServiciosMoviles(plantillaRuta, plantillaRutaTemp);
        }
    }
}