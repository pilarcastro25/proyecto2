﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Entidad que representa la funcionalidad de imprimir archivos de multidestino.
    /// </summary>
    public class MultiDestinoImpresion
    {
        /// <summary>
        /// Alias Anexo multidestino.
        /// </summary>
        private const string DOCUMENTO_MULTIDESTINO_ALIAS = "A_MULTIDESTINO";

        private const string CONFIGURACION_PLANTILLA_PDF_MULTIDESTINO = "Multidestino";

        protected string CodigoNegocio { get; set; }

        /// <summary>
        /// Rta temporal de los archivos.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        /// <summary>
        /// Constructor que recibe por parametro el codigo del negocio.
        /// </summary>
        /// <param name="codigoNegocio">Codigo del negocio.</param>
        public MultiDestinoImpresion(string codigoNegocio)
        {
            if (string.IsNullOrWhiteSpace(codigoNegocio))
            {
                throw new ArgumentNullException("codigoNegocio", "El valor de codigo del negocio no puede ser un valo nulo o vacio.");
            }
            this.CodigoNegocio = codigoNegocio;
        }

        /// <summary>
        /// Generar archivo de anexo multidestino.
        /// </summary>
        public void GenerarFormatoMultidestino()
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodigoNegocio, "0");
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;

                if (negocio != null)
                {
                    GestionarArchivos.CrearCarpeta(string.Format("{0}{1}", this.RutaTemporales, this.CodigoNegocio));
                    if (negocio != null)
                    {
                        string nombreArchivo = String.Format("MULTIDESTINO-{0}.pdf", this.CodigoNegocio);
                        //Se trae la ruta en la cual se encuentra almacenado el Template del traspaso
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONFIGURACION_PLANTILLA_PDF_MULTIDESTINO);
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = string.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoNegocio, nombreArchivo);
                        DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        archivoPdf.AbrirPDFParaLlenar();
                        archivoPdf.DiligenciarCampo("txtContratoMarco", negocio.numContrato);
                        archivoPdf.DiligenciarCampo("txtRazonSocial", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtIdentificacionRS", negocio.numIdent);
                        archivoPdf.DiligenciarCampo("txtRepLegalFirma", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                        archivoPdf.DiligenciarCampo("txtIdentificacionFirma", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.DiligenciarCampo("txtFecha", DateTime.Now.ToString("yyyy-MM-dd"));
                        archivoPdf.CerrarPDF();
                    }
                }
            }
            catch
            {
                throw new Exception("Error en generacion de PDF de Multidestino.");
            }
        }

    }
}