﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.App_GlobalCode;
using Nabis.Repository;
using Nabis.Models;
using Nabis.Utilities;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Fachada que contiene la funcionalidad para generar los archivos PDF.
    /// </summary>
    public class GeneradorArchivos
    {
        private const int ID_TIPO_CONTRATO_FUN = 1;

        #region Propiedades
        public bool Portado { get; set; }
        private string CodNegocio { get; set; }
        private string IdUsuario { get; set; }
        private string IdCliente { get; set; }
        private int TipoContrato { get; set; }
        private string NombreTipoContrato { get; set; }

        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        [ThreadStatic]
        FUN_Impresion _imprimirFUN;
        /// <summary>
        /// Entidad que representa la funcionalida para imprimir archivo FUN.
        /// </summary>
        FUN_Impresion ImprimirFun
        {
            get
            {
                if (this._imprimirFUN == null)
                {
                    this._imprimirFUN = new FUN_Impresion(this.CodNegocio, this.IdCliente);
                }
                return this._imprimirFUN;
            }
        }

        [ThreadStatic]
        CobroRevertidoImpresion _ImprimirCobroRevertido;
        /// <summary>
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Cobro Revertido.
        /// </summary>
        CobroRevertidoImpresion ImprimirCobroRevertido
        {
            get
            {
                if (this._ImprimirCobroRevertido == null)
                {
                    this._ImprimirCobroRevertido = new CobroRevertidoImpresion(this.CodNegocio, this.IdUsuario);
                }
                return this._ImprimirCobroRevertido;
            }
        }

        [ThreadStatic]
        private CondicionesUniformesImpresion condicionesUniformesImpresion;

        public CondicionesUniformesImpresion CondicionesUniformesImpresion
        {
            get
            {
                if (this.condicionesUniformesImpresion == null)
                {
                    this.condicionesUniformesImpresion = new CondicionesUniformesImpresion(this.CodNegocio);
                }
                return this.condicionesUniformesImpresion;
            }
        }

        [ThreadStatic]
        private AnexoCondicionesUniformesImpresion anexoCondicionesUniformes;
        /// <summary>
        /// Instancia de la clase necesaria para imprimir el anexo de condisiones uniformes
        /// </summary>
        public AnexoCondicionesUniformesImpresion AnexoCondicionesUniformes
        {
            get
            {
                if (anexoCondicionesUniformes == null)
                {
                    anexoCondicionesUniformes = new AnexoCondicionesUniformesImpresion(this.CodNegocio, this.IdUsuario);
                }
                return anexoCondicionesUniformes;
            }
            set
            {
                anexoCondicionesUniformes = value;
            }
        }

        [ThreadStatic]
        PagareImpresion _ImprimirPagare;
        /// <summary>
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Pagaré.
        /// </summary>
        PagareImpresion ImprimirPagare
        {
            get
            {
                if (this._ImprimirPagare == null)
                {
                    this._ImprimirPagare = new PagareImpresion(this.CodNegocio);
                }
                return this._ImprimirPagare;
            }
        }

        [ThreadStatic]
        PortabilidadImpresion _ImprimirPortabilidad;
        /// <summary>
        /// Entidad que representa la funcionalidad para imprimir archivos de Portabilidad.
        /// </summary>
        PortabilidadImpresion ImprimirPortabilidad
        {
            get
            {
                if (this._ImprimirPortabilidad == null)
                {
                    this._ImprimirPortabilidad = new PortabilidadImpresion(this.CodNegocio, this.IdUsuario);
                }
                return this._ImprimirPortabilidad;
            }
        }

        [ThreadStatic]
        EmpresaEnLineaImpresion empresaEnLineaImpresion;
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Empresa En Linea.
        EmpresaEnLineaImpresion EmpresaEnLineaImpresion
        {
            get
            {
                if (this.empresaEnLineaImpresion == null)
                {
                    this.empresaEnLineaImpresion = new EmpresaEnLineaImpresion(this.CodNegocio);
                }
                return this.empresaEnLineaImpresion;
            }
        }

        [ThreadStatic]
        M2MImpresion _M2MImpresion;
        /// Entidad que represtenta la funcionalidad para imprimir archivos de M2M.
        M2MImpresion M2MImpresion
        {
            get
            {
                if (this._M2MImpresion == null)
                {
                    this._M2MImpresion = new M2MImpresion(this.CodNegocio);
                }
                return this._M2MImpresion;
            }
        }

        [ThreadStatic]
        MovistarLibre movistarLibre;
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Movistar Libre.
        MovistarLibre MovistarLibre
        {
            get
            {
                if (this.movistarLibre == null)
                {
                    this.movistarLibre = new MovistarLibre(this.CodNegocio);
                }
                return this.movistarLibre;
            }
        }

        [ThreadStatic]
        MultiDestinoImpresion multiDestinoImpresion;
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Multi Destino.
        MultiDestinoImpresion MultiDestinoImpresion
        {
            get
            {
                if (this.multiDestinoImpresion == null)
                {
                    this.multiDestinoImpresion = new MultiDestinoImpresion(this.CodNegocio);
                }
                return this.multiDestinoImpresion;
            }
        }
        [ThreadStatic]
        private HojaDeRutaImpresion hojaDeRutaImpresion;
        //Propiedad para realizar la instancia de la clase Hoja de ruta
        private HojaDeRutaImpresion HojaDeRutaImpresion
        {
            get
            {
                if (this.hojaDeRutaImpresion == null)
                {
                    this.hojaDeRutaImpresion = new HojaDeRutaImpresion(this.CodNegocio, this.IdUsuario);
                }
                return this.hojaDeRutaImpresion;
            }
        }
        [ThreadStatic]
        private TraspasoImpresion traspasoImpresion;
        //Propiedad para instanciar la clase que genera los traspasos
        private TraspasoImpresion TraspasoImpresion
        {
            get
            {
                if (this.traspasoImpresion == null)
                {
                    this.traspasoImpresion = new TraspasoImpresion(this.CodNegocio);
                }
                return this.traspasoImpresion;
            }
        }
        [ThreadStatic]
        private AnexoImpresion anexoImprimir;
        /// <summary>
        /// Propiedad para instanciar la clase que genera los anexos
        /// </summary>
        private AnexoImpresion AnexoImprimir
        {
            get
            {
                if (this.anexoImprimir == null)
                {
                    this.anexoImprimir = new AnexoImpresion(this.CodNegocio);
                }
                return this.anexoImprimir;
            }
        }
        [ThreadStatic]
        private AnexoOtroSiImpresion anexoOtroSiImprimir;
        /// <summary>
        /// Entidad que represtenta la funcionalidad para imprimir archivos de Otros si.
        /// </summary>
        private AnexoOtroSiImpresion AnexoOtroSiImprimir
        {
            get
            {
                if (this.anexoOtroSiImprimir == null)
                {
                    this.anexoOtroSiImprimir = new AnexoOtroSiImpresion(this.CodNegocio, this.TipoContrato.Equals(ID_TIPO_CONTRATO_FUN));
                }
                return this.anexoOtroSiImprimir;
            }
        }


        [ThreadStatic]
        private VentaACuotasImpresion ventaACuotasImpresion;
        /// <summary>
        /// Generador de venta a cuotas.
        /// </summary>
        public VentaACuotasImpresion VentaACuotasImpresion
        {
            get
            {
                if (this.ventaACuotasImpresion == null)
                {
                    this.ventaACuotasImpresion = new VentaACuotasImpresion(this.CodNegocio);
                }
                return this.ventaACuotasImpresion;
            }
        }
        [ThreadStatic]
        MepeImpresion imprimirMepe;
        /// <summary>
        /// Entidad que represtenta la funcionalidad para imprimir archivos de MEPE.
        /// </summary>
        MepeImpresion ImprimirMepe
        {
            get
            {
                if (this.imprimirMepe == null)
                {
                    this.imprimirMepe = new MepeImpresion(this.CodNegocio, IdUsuario);
                }
                return this.imprimirMepe;
            }
        }

        #endregion


        public GeneradorArchivos(string codNegocio, string idUsuario, string idCliente)
        {
            if (string.IsNullOrWhiteSpace(codNegocio))
            {
                throw new ArgumentNullException("codNegocio", "El valor no puede ser nulo o vacio.");
            }
            this.CodNegocio = codNegocio;
            this.IdUsuario = idUsuario;
            this.IdCliente = idCliente;
        }

        /// <summary>
        /// Generacion de todos los documentos por codigo del negocio.
        /// </summary>
        [Obsolete("Implementación antigua, usar ImprimirArchivos", true)]
        public void ImprimirArchivos()
        {

            if (this.TipoContrato > 0)
            {
                //CONTRATO MARCO FUN
                if (this.TipoContrato == ID_TIPO_CONTRATO_FUN)
                {
                    // Imprimir formulario FUN.
                    this.ImprimirFun.DiligenciarPDF_FUN();
                    // Generar cobro revertido.
                    this.ImprimirCobroRevertido.GeneraCobroRevertidoPDF();
                    // Generar empresa en linea.
                    this.EmpresaEnLineaImpresion.GenerarFormatoEmpresaLinea();
                    // Generar M2M
                    this.M2MImpresion.GenerarFormatoM2M();
                    // Generar Movistar Libre.
                    this.MovistarLibre.GenerarFormatoMovistarLibre();
                    // Generar Multidestino.
                    this.MultiDestinoImpresion.GenerarFormatoMultidestino();
                    // Generar Venta a cuotas.
                    this.VentaACuotasImpresion.GenerarFormatoVentaCuotas();
                    //Diligenciar el Mepe
                    this.ImprimirMepe.GeneraMepePDF();
                    //Diligenciar el Pagaré
                    this.ImprimirPagare.DiligenciaPagare();
                    //Generar OtroSi
                    this.AnexoOtroSiImprimir.Imprimir();
                }
                //CONDICIONES UNIFORMES
                else
                {
                    this.CondicionesUniformesImpresion.DiligenciarPDFSolicitudServiciosMoviles();
                }
                //Generar Hoja de ruta
                this.HojaDeRutaImpresion.Imprimir();
                //Generar traspaso
                //this.TraspasoImpresion.Imprimir();
                //Generar anexo planes Pro
                this.AnexoImprimir.Imprimir(TipoAnexos.PlanesPro);
                //Generar anexo planes ilimitados
                this.AnexoImprimir.Imprimir(TipoAnexos.PlanesIlimitados);
            }

        }


        /// <summary>
        /// Generacion de todos los documentos por codigo del negocio.
        /// </summary>
        public void ImprimirArchivosPDF(List<DocumentoTipoContrato> documentos, string rutaCarpetaContrato)
        {
            GestionarArchivos.CrearCarpeta(rutaCarpetaContrato);

            this.TipoContrato = MappingRepository.ObtenerTipoContrato(this.CodNegocio);

            foreach (var item in documentos)
            {
                //PENDIENTE IMPLEMENTAR PATRON CADENA DE RESPONSABILIDAD
                switch (item.ALIAS)
                {
                    case "FUN":
                        // Imprimir formulario FUN.
                        this.ImprimirFun.DiligenciarPDF_FUN();
                        break;

                    case "COBRO_REVERTIDO":
                        // Generar cobro revertido.
                        this.ImprimirCobroRevertido.GeneraCobroRevertidoPDF();
                        break;

                    case "CEL":
                        // Generar empresa en linea.
                        this.EmpresaEnLineaImpresion.GenerarFormatoEmpresaLinea();
                        break;

                    case "M2M":
                        // Generar M2M
                        this.M2MImpresion.GenerarFormatoM2M();
                        break;

                    case "M_LIBRE":
                        // Generar Movistar Libre.
                        this.MovistarLibre.GenerarFormatoMovistarLibre();
                        break;

                    case "A_MULTIDESTINO":
                        // Generar Multidestino.
                        this.MultiDestinoImpresion.GenerarFormatoMultidestino();
                        break;

                    case "VAC":
                        // Generar Venta a cuotas.
                        this.VentaACuotasImpresion.GenerarFormatoVentaCuotas();
                        break;

                    case "MEPE":
                        //Diligenciar el Mepe
                        this.ImprimirMepe.GeneraMepePDF();
                        break;

                    case "PAGARE":
                        //Diligenciar el Pagaré
                        this.ImprimirPagare.DiligenciaPagare();
                        break;

                    case "OTROS_SI":
                        //Generar OtroSi
                        this.AnexoOtroSiImprimir.Imprimir();
                        break;

                    case "CUSM":
                        //Generar Formato de Condiciones Uniformes
                        this.CondicionesUniformesImpresion.DiligenciarPDFSolicitudServiciosMoviles();
                        //this.AnexoCondicionesUniformes.Imprimir();
                        break;

                    case "HR":
                        //Generar Hoja de ruta
                        this.HojaDeRutaImpresion.Imprimir();
                        break;

                    case "TRASPASO":
                        //Generar traspaso
                        this.TraspasoImpresion.Imprimir();
                        break;

                    case "A_PRO":
                        //Generar anexo planes Pro
                        this.AnexoImprimir.Imprimir(TipoAnexos.PlanesPro);
                        break;

                    case "A_ILIMITADO":
                        //Generar anexo planes ilimitados
                        this.AnexoImprimir.Imprimir(TipoAnexos.PlanesIlimitados);
                        break;

                    case "Portabilidad":
                        //Generar formato de portabilidad
                        this.ImprimirPortabilidad.IsPortado = true;
                        this.ImprimirPortabilidad.CargaDatosResumenFormatoPortabilidad();
                        break;
                }
            }
        }
    }
}
