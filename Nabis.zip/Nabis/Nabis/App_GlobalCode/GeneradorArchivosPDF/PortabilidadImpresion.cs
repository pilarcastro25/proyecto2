﻿using DiligenciadorPDFT;
using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using Nabis.Models.PORTABILIDAD;
using Nabis.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Nabis_ET.Comercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class PortabilidadImpresion
    {
        #region Propiedades o Campos
        private string CodNegocio { get; set; }
        private string IdUsuario { get; set; }
        public bool IsPortado = false;
        private int currentLine;
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        [ThreadStatic]
        private LineaPortadaRepository _LineaPortadaRepository;
        /// <summary>
        /// Repositorio que contiene funciones para lineas de portabilidad.
        /// </summary>
        public LineaPortadaRepository LineaPortadaRepository
        {
            get
            {
                if (this._LineaPortadaRepository == null)
                {
                    this._LineaPortadaRepository = new LineaPortadaRepository();
                }
                return this._LineaPortadaRepository;
            }
        }

        [ThreadStatic]
        private TraspasoImpresion traspasoImpresion;
        //Propiedad para instanciar la clase que genera los traspasos
        private TraspasoImpresion TraspasoImpresion
        {
            get
            {
                if (this.traspasoImpresion == null)
                {
                    this.traspasoImpresion = new TraspasoImpresion(this.CodNegocio);
                }
                return this.traspasoImpresion;
            }
        }

        #endregion

        #region Constructor

        public PortabilidadImpresion(string codNegocio, string idusuario)
        {
            if (string.IsNullOrWhiteSpace(codNegocio))
            {
                throw new ArgumentNullException("codNegocio", "El valor no puede ser nulo o vacio.");
            }
            this.CodNegocio = codNegocio;
            this.IdUsuario = idusuario;
        }

        #endregion

        #region Funciones

        /// <summary>
        /// Función que carga la informacion del negocio
        /// </summary>
        public void ImprimirPortabilidad()
        {

        }

        /// <summary>
        /// Función que carga la informacion del negocio
        /// </summary>
        public bool ValidarNegocio()
        {
            IsPortado = false;
            Nab_Negocio_SP negocio = MappingRepository.GetNegocio(CodNegocio);
            if (negocio != null)
            {
                IsPortado = negocio.PORTADO;
            }
            return IsPortado;
        }

        /// <summary>
        /// Función que diligencia la Portabilidad
        /// </summary>
        public void DiligenciarPortabilidad()
        {
            if (ValidarNegocio())
            {
                CargaDatosResumenFormatoPortabilidad();
            }
        }


        /// <summary>
        /// Función que carga resumen Portabilidad del negocio asociado
        /// </summary>
        public void CargaDatosResumenFormatoPortabilidad()
        {
            if (IsPortado)
            {
                TablaPortabilidad.Tabla.Operacion = IsPortado;
                DataTable Dt = new DataTable();
                Dt = LineaPortadaRepository.RetornarLineasPortadas(this.IdUsuario, this.CodNegocio, "Resumen");
                bool IsPortabilidadTraspaso = false;
                if (Dt.Rows.Count > 0)
                {
                    int index = 0;
                    TablaPortabilidad.Tabla.RutaTemporales = RutaTemporales;
                    string nombreArchivo = String.Format("Portabilidad-{0}.pdf", this.CodNegocio);
                    string rutaCarpetaContrato = RutaTemporales + this.CodNegocio;
                    //GestionarArchivos.CrearCarpeta(rutaCarpetaContrato);


                    //foreach (DataRow d in Dt.Rows)
                    for (index = 0; index < Dt.Rows.Count; index++)
                    {
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("Portabilidad");
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = RutaTemporales + this.CodNegocio + "/" + index + "-" + nombreArchivo;
                        DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        TablaPortabilidad.Tabla.p = p;

                        Portabilidad.InstancePortabilidad().Cod_negocio = Dt.Rows[index]["ID_EB"].ToString();
                        Portabilidad.InstancePortabilidad().Operador = Dt.Rows[index]["OPERADOR"].ToString();
                        Portabilidad.InstancePortabilidad().Traspaso = ((bool)(Dt.Rows[index]["TRASPASO"])) == true ? 1 : 0;
                        Portabilidad.InstancePortabilidad().CantidadLineas = int.Parse(Dt.Rows[index]["CANT_LINEAS"].ToString());

                        if ((bool)(Dt.Rows[index]["TRASPASO"]))
                        {
                            //valida si es un trasposo con portabilidad
                            IsPortabilidadTraspaso = !IsPortabilidadTraspaso ? (bool)(Dt.Rows[index]["TRASPASO"]) : IsPortabilidadTraspaso;

                            Portabilidad.InstancePortabilidad().TipoIdent = Dt.Rows[index]["TIPO_IDENT_ORIGEN"].ToString();
                            Portabilidad.InstancePortabilidad().NumeroIdentOrigen = Dt.Rows[index]["NUM_IDENT_ORIGEN"].ToString();
                            string tipiden = string.Empty;
                            tipiden = Portabilidad.InstancePortabilidad().TipoIdent;

                            int tipPJ = 0;

                            int tipPN = 0;

                            string Cod = Portabilidad.InstancePortabilidad().Cod_negocio;
                            string Operador = Portabilidad.InstancePortabilidad().Operador;
                            string NumeroOrigen = Portabilidad.InstancePortabilidad().NumeroIdentOrigen;

                            List<Linea> LineasPortabilidadNegocioList = ObtenerLineasNegocio(Cod, Operador, NumeroOrigen);
                            TablaPortabilidad.Tabla.Listalinea = LineasPortabilidadNegocioList;

                            Portabilidad.InstancePortabilidad().NombreClienteOrigen = Dt.Rows[index]["NOMBRE_CLIENTE_ORIGEN"].ToString();
                            Portabilidad.InstancePortabilidad().ApellidoClienteOrigen = Dt.Rows[index]["APELLIDO_CLIENTE_ORIGEN"].ToString();
                            if (tipiden == "NIT" || tipiden == "H2 EXTRANJERIA")
                            {
                                //tipPJ = tipiden == "NIT" ? 7 : 0;
                                tipPJ = (tipiden == "H2 EXTRANJERIA" || tipiden == "NIT") ? 7 : 0;

                                Portabilidad.InstancePortabilidad().TipoIdentRl = tipPJ;
                                Portabilidad.InstancePortabilidad().Nit = Portabilidad.InstancePortabilidad().NumeroIdentOrigen;
                                Portabilidad.InstancePortabilidad().NombreCompletoRL = Portabilidad.InstancePortabilidad().NombreClienteOrigen;
                                //Portabilidad.InstancePortabilidad().NumeroIdentOrigen = "";
                                //Portabilidad.InstancePortabilidad().NombreClienteOrigen = "";
                                TablaPortabilidad.Tabla.SolicitudPersonaJuridica = true;
                                TablaPortabilidad.Tabla.SolicitudPersonaNatural = false;
                            }
                            else
                            {

                                tipPN = tipiden == "CC" ? 1 : tipiden == "CE" ? 4 : tipiden == "OTRO" ? 7 : 0;
                                //tipPN = tipiden == "CE" ? 4 : 0;
                                //tipPN = tipiden == "OTRO" ? 7 : 0;
                                Portabilidad.InstancePortabilidad().Tipo_ide_PN = tipPN;
                                TablaPortabilidad.Tabla.SolicitudPersonaNatural = true;
                                Portabilidad.InstancePortabilidad().Identificacion_PN = Portabilidad.InstancePortabilidad().NumeroIdentOrigen;
                                Portabilidad.InstancePortabilidad().NombresPersonaNatural = Portabilidad.InstancePortabilidad().NombreClienteOrigen;
                                Portabilidad.InstancePortabilidad().ApellidosPersonaNatural = Portabilidad.InstancePortabilidad().ApellidoClienteOrigen;
                                //Portabilidad.InstancePortabilidad().NumeroIdentOrigen = "";
                                //Portabilidad.InstancePortabilidad().NombreClienteOrigen = "";

                                TablaPortabilidad.Tabla.SolicitudPersonaJuridica = false;
                            }
                        }
                        else
                        {
                            Nab_Negocio_SP negocio = MappingRepository.GetNegocio(this.CodNegocio);
                            if (negocio != null)
                            {
                                Portabilidad.InstancePortabilidad().Nit = negocio.IDENTIDAD;
                                //string TipoIdentPJ = negocio.ID_IDENTIDAD.ToString();
                                string TipoIdentPJ = "1";
                                Portabilidad.InstancePortabilidad().TipoIdent = TipoIdentPJ;
                                Portabilidad.InstancePortabilidad().TipoIdentRl = int.Parse(TipoIdentPJ);
                                string tipiden = Portabilidad.InstancePortabilidad().TipoIdent;
                                Portabilidad.InstancePortabilidad().TipoIdent = tipiden;
                                Portabilidad.InstancePortabilidad().RazonSocial = negocio.NOMBRE_CLIENTE;
                                Portabilidad.InstancePortabilidad().NombreRL = negocio.REP_LEGAL_NOMBRE;
                                Portabilidad.InstancePortabilidad().primerApellidoRL = negocio.REP_LEGAL_APELLIDO1;
                                Portabilidad.InstancePortabilidad().segundoApellidoRL = negocio.REP_LEGAL_APELLIDO2;
                                Portabilidad.InstancePortabilidad().IdentificacionRL = negocio.REP_LEGAL_IDENTIDAD;
                            }
                            string Cod = Portabilidad.InstancePortabilidad().Cod_negocio;
                            string Operador = Portabilidad.InstancePortabilidad().Operador;
                            string NumeroOrigen = Portabilidad.InstancePortabilidad().NumeroIdentOrigen;

                            List<Linea> LineasPortabilidadNegocioList = ObtenerLineasNegocio(Cod, Operador, NumeroOrigen);
                            TablaPortabilidad.Tabla.Listalinea = LineasPortabilidadNegocioList;
                            TablaPortabilidad.Tabla.SolicitudPersonaNatural = false;
                            TablaPortabilidad.Tabla.SolicitudPersonaJuridica = true;

                        }
                        TablaPortabilidad.Tabla.Cod_negocio = this.CodNegocio;
                        TablaPortabilidad.Tabla.mapeodatos();

                    }
                }

                if (IsPortabilidadTraspaso)
                {
                    this.TraspasoImpresion.Imprimir();
                }
            }
        }

        /// <summary>
        /// Obtengo lineas relacionadas con un negocio, operador, y documento de origen
        /// </summary>
        /// <param name="idNegocio">Id del negocio</param>
        /// <param name="operador">Operador donante</param>
        /// <param name="DocumentoOrigen">Documento del que porta la linea</param>
        /// <returns></returns>
        protected List<Linea> ObtenerLineasNegocio(string idNegocio, string operador, string DocumentoOrigen)
        {
            Conect con = new Conect(1);
            con.commandQuery = "Nab_SP_Comercial_Informacion_Lineas_Portadas";
            con.addParameters("user", "");
            con.addParameters("id_eb", idNegocio);
            con.addParameters("vista", "Agrupado");
            con.addParameters("identidad_origen", DocumentoOrigen);
            DataTable dat = con.getDataTable(true);

            if (dat.Rows.Count > 0)
            {
                List<Linea> lin = new List<Linea>();

                foreach (DataRow row in dat.Rows)
                {
                    Linea li = new Linea();
                    li.linea = row["CELULAR"].ToString();

                    li.prepagoact = row["planOrigen"].ToString() == "2" ? "X" : "";
                    li.postpagoact = row["planOrigen"].ToString() == "1" ? "X" : "";
                    li.prepagonuevo = row["planDestino"].ToString() == "2" ? "X" : "";
                    li.postpagonuevo = row["planDestino"].ToString() == "1" ? "X" : "";
                    li.nip = "";

                    lin.Add(li);
                }
                return lin;
            }
            else
            {
                return new List<Linea>();
            }
        }

        #endregion
    }
}