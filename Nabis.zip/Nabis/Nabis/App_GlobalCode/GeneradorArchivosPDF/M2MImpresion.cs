﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class M2MImpresion
    {
        /// <summary>
        /// Alias M2M
        /// </summary>
        private const string DOCUMENTO_M2M_ALIAS = "M2M";
        /// <summary>
        /// Plantilla para formato M2M.
        /// </summary>
        private const string CONFIGURACION_PLANTILLA_PDF_M2M = "M2M";

        protected string CodigoNegocio { get; set; }

        /// <summary>
        /// Rta temporal de los archivos.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        /// <summary>
        /// Constructor que recibe el codigo del negocio.
        /// </summary>
        /// <param name="codigoNegocio">Codigo del negocio.</param>
        public M2MImpresion(string codigoNegocio)
        {
            if (string.IsNullOrWhiteSpace(codigoNegocio))
            {
                throw new ArgumentNullException("codigoNegocio", "El valor no puede ser un valo nulo o vacio.");
            }
            this.CodigoNegocio = codigoNegocio;
        }

        /// <summary>
        /// Generar formato M2M.
        /// </summary>
        public void GenerarFormatoM2M()
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodigoNegocio, "0");
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                
                if (negocio != null)
                {
                    GestionarArchivos.CrearCarpeta(string.Format("{0}{1}", this.RutaTemporales, this.CodigoNegocio));
                    if (negocio != null)
                    {
                        string nombreArchivo = String.Format("M2M-{0}.pdf", this.CodigoNegocio);
                        //Se trae la ruta en la cual se encuentra almacenado el Template del traspaso
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONFIGURACION_PLANTILLA_PDF_M2M);
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = string.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoNegocio, nombreArchivo);
                        DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        archivoPdf.AbrirPDFParaLlenar();
                        //Mapeo de cada uno de los valores a la plantilla
                        archivoPdf.DiligenciarCampo("txtEmpresaA", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaB", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaC", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaD", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaE", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaF", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaG", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresaH", negocio.razonSocial.ToUpperInvariant());
                        //archivoPdf.DiligenciarCampo("txtCiudad", this.clienteDistrito.SelectedItem.Text.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtDia", DateTime.Now.ToString("dd"));
                        archivoPdf.DiligenciarCampo("txtMes", DateTime.Now.ToString("MM"));
                        archivoPdf.DiligenciarCampo("txtAnio", DateTime.Now.ToString("yy"));
                        archivoPdf.DiligenciarCampo("txtRepLegal", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                        archivoPdf.DiligenciarCampo("txtIdentificacion", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.CerrarPDF();
                    }
                }
            }
            catch
            {
                throw new Exception("Error en generacion de PDF de M2M.");
            }
        }
    }
}