﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Nabis.GeneradorArchivosPDF
{
    public enum TipoAnexos
    {
        PlanesIlimitados,
        PlanesPro
    };
    public class AnexoImpresion
    {
        #region Propiedades
        private TipoAnexos TipoAnexos
        {
            get
            {
                return new TipoAnexos();
            }
        }
        private string IdEb { get; set; }

        private string TipoAnexo { get; set; }

        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        #endregion
        #region Métodos Públicos
        /// <summary>
        /// Constructor de la clase.
        /// Tipo Anexo: AnexoPlanesIlimitados-AnexoPlanesPro
        /// </summary>

        public AnexoImpresion(string idEb)
        {
            if (idEb != null)
            {
                this.IdEb = idEb;
            }
            else throw new Exception("El parámetro ingresado no puede ser nulo!");
        }
        /// <summary>
        /// Imprimir los anexos del negocio
        /// </summary>
        public void Imprimir(TipoAnexos anexo)
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.IdEb, "0");
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                if(negocio!=null){
                    TipoAnexo = TipoAnexos.PlanesIlimitados == anexo ? "AnexoPlanesIlimitados" : "AnexoPlanesPro";
                    string nombreArchivo = String.Format("{0}-{1}.pdf", this.TipoAnexo, this.IdEb);
                    NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(this.TipoAnexo);
                    string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                    string plantillaRutaTemp = String.Format("{0}{1}/{2}", RutaTemporales, this.IdEb, nombreArchivo);
                    
                    DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                    p.AbrirPDFParaLlenar();
                    //Mapeo de cada uno de los valores a la plantilla
                    p.DiligenciarCampo("contrato", this.IdEb != String.Empty ? this.IdEb : String.Empty);
                    p.DiligenciarCampo("name", string.Format("{0} {1} {2}", negocio.RepLegalNombre, negocio.RepLegalApellido1, negocio.RepLegalApellido2));
                    p.DiligenciarCampo("cC", negocio.RepLegalIdentidad.ToString());
                    p.DiligenciarCampo("fecha", negocio.FecIngreso.ToShortDateString());
                    p.CerrarPDF();
                }
            }
            catch (Exception)
            {
                throw new Exception("Error en el método de la generación anexos");
            }
        }
        #endregion
    }
}
