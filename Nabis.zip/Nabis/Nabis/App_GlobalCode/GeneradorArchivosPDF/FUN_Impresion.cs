﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.GeneradorArchivosPDF;
using Nabis.Utilities;
using Nabis.Models.Entities;
using Nabis.Repository;
using DiligenciadorPDFT;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Entidad que encapsula la funcionalidad de generar archivos para PDF 
    /// para contrato FUN
    /// </summary>
    public class FUN_Impresion
    {
        #region Propiedades
        /// <summary>
        /// Codigo del negocio
        /// </summary>
        private string CodNegocio { get; set; }
        /// <summary>
        /// Codigo del cliente.
        /// </summary>
        private string CodigoCliente { get; set; }
        /// <summary>
        /// Valida si es cuenta nueva.
        /// </summary>
        private bool EsCuentaNueva
        {
            get
            {
                return string.IsNullOrWhiteSpace(this.CodigoCliente);
            }
        }
        /// <summary>
        /// Rta temporal de los archivos.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        private string IdUser { get; set; }

        [ThreadStatic]
        private RadicacionNegocioRepository _RadicacionNegocioRepository;
        /// <summary>
        /// Repositorio que permite el acceso a los datos relacionados al negocio.
        /// </summary>
        private RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this._RadicacionNegocioRepository == null)
                {
                    this._RadicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return _RadicacionNegocioRepository;
            }
        }

        [ThreadStatic]
        private MappingRepository _MappingRepository;
        /// <summary>
        /// Repositorio que permite el acceso a los datos relacionados al negocio.
        /// </summary>
        private MappingRepository MappingRepository
        {
            get
            {
                if (this._MappingRepository == null)
                {
                    this._MappingRepository = new MappingRepository(0);
                }
                return _MappingRepository;
            }
        }

        private NumLetra _ConversorLetraNumero;
        /// <summary>
        /// Entidad que permite convertir numeros en letras.
        /// </summary>
        private NumLetra ConversorLetraNumero
        {
            get
            {
                if (this._ConversorLetraNumero == null)
                {
                    this._ConversorLetraNumero = new NumLetra();
                }
                return this._ConversorLetraNumero;
            }
        }

        #endregion Propiedades


        /// <summary>
        /// Constructor que recibe como parametro el codigo del negocio.
        /// </summary>
        /// <param name="codNegocio">Codigo del negocio</param>
        public FUN_Impresion(string codNegocio, string codigoCliente = null)
        {
            if (string.IsNullOrWhiteSpace(codNegocio))
            {
                throw new ArgumentNullException("codnegocio", "El valor no puede ser nulo o vacio.");
            }
            this.CodNegocio = codNegocio;
            this.CodigoCliente = codigoCliente;
            this.IdUser = HttpContext.Current.User.Identity.Name;
        }

        /// <summary>
        /// Diligenciar formulario FUN.
        /// </summary>
        public void DiligenciarPDF_FUN()
        {
            try
            {
                GestionarArchivos.CrearCarpeta(string.Format("{0}{1}", this.RutaTemporales, this.CodNegocio));
                string nombreArchivo = String.Format("FUN-{0}.pdf", this.CodNegocio);
                //Se trae la ruta en la cual se encuentra almacenado el Template del traspaso
                NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("FUN");
                string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                string plantillaRutaTemp = string.Format("{0}{1}/{2}", this.RutaTemporales, this.CodNegocio, nombreArchivo);
                DateTime fecha = DateTime.Now;
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodNegocio, "0");
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                if (negocio != null)
                {
                    DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                    archivoPdf.AbrirPDFParaLlenar();
                    //Mapeo de cada uno de los valores a la plantilla
                    archivoPdf.DiligenciarCampo("txtRazonSocialIG", string.Format("{0}", negocio.razonSocial.ToUpperInvariant()));
                    archivoPdf.DiligenciarCampo("txtNit", negocio.numIdent.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtFechaSolicitudIG", negocio.FecIngreso.ToString("yyyy-MM-dd"));
                    archivoPdf.DiligenciarCampo("txtDireccionIG", negocio.CodTipoCalle.ToUpperInvariant() + " " + negocio.Direccion.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtNumeroContratoIG", negocio.numContrato);
                    archivoPdf.DiligenciarCampo("txtIdEb", "Radicado FUN: " + this.CodNegocio);
                    archivoPdf.DiligenciarCampo("txtCodClienteIG", this.CodigoCliente.ToUpperInvariant());
                    archivoPdf.DiligenciarCampo("txtVentaInicialIG", negocio.tipoVenta.Equals("NUEVO", StringComparison.InvariantCultureIgnoreCase) ? "SI" : "NO");
                    archivoPdf.DiligenciarCampo("txtCuentaNuevaIG", negocio.tipoVenta.Equals("NUEVO", StringComparison.InvariantCultureIgnoreCase) ? "SI" : "NO");
                    archivoPdf.DiligenciarCampo("txtLineasSolicitadas", negocio.cantLineas.ToString());
                    archivoPdf.DiligenciarCampo("txtNumeroLineasSolictadasLetras", this.ConversorLetraNumero.Convertir(negocio.cantLineas.ToString().ToUpperInvariant(), false));
                    archivoPdf.DiligenciarCampo("txtNombreRepresentanteLegal", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                    archivoPdf.DiligenciarCampo("txtIdentificacionRepresentanteLegal", negocio.RepLegalIdentidad.ToString());
                    archivoPdf.DiligenciarCampo("txtTelefonosIG", negocio.TelefonoCliente);
                    archivoPdf.DiligenciarCampo("txtCiudadIG", ciudad);
                    archivoPdf.DiligenciarCampo("txtObservaciones", negocio.Observaciones);
                    //Informacion adicional
                    NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(this.IdUser, this.CodNegocio);
                    if (infoAdicional != null)
                    {
                        string ClientesAsociadosNits = string.Format("{0} | {1} | {2}", infoAdicional.NitClienteSocio1??"", infoAdicional.NitClienteSocio2??"", infoAdicional.NitClienteSocio3??"");
                        string ClientesAsociadosNombres = string.Format("{0} | {1} | {2}", infoAdicional.NombreClienteSocio1??"", infoAdicional.NombreClienteSocio2??"", infoAdicional.NombreClienteSocio3??"");
                        string ClientesAsociadosCodigos = string.Format("{0} | {1} | {2}", infoAdicional.CodigoClienteSocio1 ?? "", infoAdicional.CodigoClienteSocio2 ?? "", infoAdicional.CodigoClienteSocio3 ?? "");
                        archivoPdf.DiligenciarCampo("txtIdKoralIG", !string.IsNullOrEmpty(infoAdicional.IdKoral) ? infoAdicional.IdKoral.ToUpperInvariant() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtIdPricingIG", !string.IsNullOrEmpty(infoAdicional.IdPricing) ? infoAdicional.IdPricing.ToUpperInvariant() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtNombreClienteAsociado", ClientesAsociadosNombres);
                        archivoPdf.DiligenciarCampo("txtNitClienteAsociado", ClientesAsociadosNits);
                        archivoPdf.DiligenciarCampo("txtCodigoClienteAsociado", ClientesAsociadosCodigos);
                        archivoPdf.DiligenciarCampo("txtEsCorreoElectronico", infoAdicional.EnvioCorreoElectronico.HasValue && infoAdicional.EnvioCorreoElectronico.Value ? "SI" : "NO");
                        archivoPdf.DiligenciarCampo("txtCorreoElectronicoFactura", !string.IsNullOrEmpty(infoAdicional.CorreoElectronico) ? infoAdicional.CorreoElectronico : string.Empty);
                        archivoPdf.DiligenciarCampo("txtFacturaFisica", !infoAdicional.EnvioCorreoElectronico.HasValue && !infoAdicional.EnvioCorreoElectronico.Value ? "SI" : "NO");
                        archivoPdf.DiligenciarCampo("txtDuracionServicios", infoAdicional.DuracionServicios.ToString() + " MESES");
                        //Codigo adicional de relleno :@
                        archivoPdf.DiligenciarCampo("txtReposicionIG", "NO");
                        archivoPdf.DiligenciarCampo("txtBeneficiosServicioIG", !string.IsNullOrEmpty(infoAdicional.Beneficios) ? infoAdicional.Beneficios : "");
                        archivoPdf.DiligenciarCampo("txtNombreReferenciaComercial_1", !string.IsNullOrEmpty(infoAdicional.NombreReferencia1) ? infoAdicional.NombreReferencia1 : "");
                        archivoPdf.DiligenciarCampo("txtTelefonoReferenciaComercial_1", !string.IsNullOrEmpty(infoAdicional.TelcontactoReferencia1) ? infoAdicional.TelcontactoReferencia1 : "");
                        archivoPdf.DiligenciarCampo("txtIntitucionReferenciaComercial_1", !string.IsNullOrEmpty(infoAdicional.InstitucionReferencia1) ? infoAdicional.InstitucionReferencia1 : "");
                        archivoPdf.DiligenciarCampo("txtNombreReferenciaComercial_2", !string.IsNullOrEmpty(infoAdicional.NombreReferencia2) ? infoAdicional.NombreReferencia2 : "");
                        archivoPdf.DiligenciarCampo("txtTelefonoReferenciaComercial_2", !string.IsNullOrEmpty(infoAdicional.TelcontactoReferencia2) ? infoAdicional.TelcontactoReferencia2 : "");
                        archivoPdf.DiligenciarCampo("txtIntitucionReferenciaComercial_2", !string.IsNullOrEmpty(infoAdicional.InstitucionReferencia2) ? infoAdicional.InstitucionReferencia2 : "");
                    }

                    //Cargar los planes adquiridos asociados al negocio
                    List<NegocioPlanesAdquiridos> negocioPlanes = BNegocio.GetPlanesAdquiridos(this.IdUser, this.CodNegocio);
                    if (negocioPlanes.Count() > 0)
                    {
                        int contador = 1;
                        int contadorDatos = 1;
                        int contadorPlanesServiciosAdicionales = 1;
                        bool esTraspaso = this.MappingRepository.GetTraspasos(this.CodNegocio).Count() > 0;
                        foreach (NegocioPlanesAdquiridos item in negocioPlanes)
                        {
                            if (item.Producto.ToUpper().Contains("VOZ"))
                            {
                                archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineas_{0}", contador), item.CantidadLineas.ToString());
                                archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifario_{0}", contador), item.IdPlanTarifario ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorMovistarVoz_{0}", contador), item.ValorMovistarVoz ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorFijoVoz_{0}", contador), item.ValorFijoVoz ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorOtrosVoz_{0}", contador), item.ValorOtrosVoz ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorMovistarAdicionalVoz_{0}", contador), item.ValorMovistarAdicionalVoz ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorFijosAdicionalVoz_{0}", contador), item.ValorFijoAdicionalVoz ?? string.Empty);
                                archivoPdf.DiligenciarCampo(string.Format("txtValorOtrosAdicionalVoz_{0}", contador), item.ValorOtrosAdicionalVoz ?? string.Empty);
                                contador++;
                            }

                            if (contadorDatos < 10)
                            {
                                if (!item.Producto.ToUpper().Equals("VOZ Y DATOS") && item.Producto.ToUpper().Contains("DATOS") || item.Producto.ToUpper().Contains("VERTICALES"))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanTarifario ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.PlanDatosRentaMes ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.PlanDatosKbIncluido ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.PlanDatosKbAdicional ?? string.Empty);
                                    contadorDatos++;
                                }
                                //Plan adicional 1
                                if (!string.IsNullOrEmpty(item.IdPlanPlanAdicional1) && (!string.IsNullOrEmpty(item.RentaMesPlanDatosPlanAdicional1) || !string.IsNullOrEmpty(item.KbIncluidoPlanDatosPlanAdicional1)))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanPlanAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.RentaMesPlanDatosPlanAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.KbIncluidoPlanDatosPlanAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.KbAdicionalPlanDatosPlanAdicional1 ?? string.Empty);
                                    contadorDatos++;
                                }

                                //Plan adicional 2
                                if (!string.IsNullOrEmpty(item.IdPlanPlanAdicional2) && (!string.IsNullOrEmpty(item.RentaMesPlanDatosPlanAdicional2) || !string.IsNullOrEmpty(item.KbIncluidoPlanDatosPlanAdicional2)))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanPlanAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.RentaMesPlanDatosPlanAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.KbIncluidoPlanDatosPlanAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.KbAdicionalPlanDatosPlanAdicional2 ?? string.Empty);
                                    contadorDatos++;
                                }

                                //Servicio adicional 1
                                if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional1) && (!string.IsNullOrEmpty(item.RentaMesPlanDatosServicioAdicional1) || !string.IsNullOrEmpty(item.KbIncluidoPlanDatosServicioAdicional1)))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanServicioAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.RentaMesPlanDatosServicioAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.KbIncluidoPlanDatosServicioAdicional1 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.KbAdicionalPlanDatosServicioAdicional1 ?? string.Empty);
                                    contadorDatos++;
                                }

                                //Servicio adicional 2
                                if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional2) && (!string.IsNullOrEmpty(item.RentaMesPlanDatosServicioAdicional2) || !string.IsNullOrEmpty(item.KbIncluidoPlanDatosServicioAdicional2)))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanServicioAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.RentaMesPlanDatosServicioAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.KbIncluidoPlanDatosServicioAdicional2 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.KbAdicionalPlanDatosServicioAdicional2 ?? string.Empty);
                                    contadorDatos++;
                                }


                                //Servicio adicional 3
                                if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional3) && (!string.IsNullOrEmpty(item.RentaMesPlanDatosServicioAdicional3) || !string.IsNullOrEmpty(item.KbIncluidoPlanDatosServicioAdicional3)))
                                {
                                    archivoPdf.DiligenciarCampo(string.Format("txtCantidadLineasDatos_{0}", contadorDatos), item.CantidadLineas.ToString());
                                    archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioDatos_{0}", contadorDatos), item.IdPlanServicioAdicional3 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtRentaMesDatos_{0}", contadorDatos), item.RentaMesPlanDatosServicioAdicional3 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtCapacidadDatos_Datos_{0}", contadorDatos), item.KbIncluidoPlanDatosServicioAdicional3 ?? string.Empty);
                                    archivoPdf.DiligenciarCampo(string.Format("txtKBAdicionalDatos_{0}", contadorDatos), item.KbAdicionalPlanDatosServicioAdicional3 ?? string.Empty);
                                    contadorDatos++;
                                }

                                // Maximo 10 ofertas adicionales por contrato
                                if (contadorPlanesServiciosAdicionales < 10)
                                {
                                    // Servicios adicionales
                                    if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional1) && !string.IsNullOrEmpty(item.ServicioAdicional1ValorMovistarVoz))
                                    {
                                        archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioOtros_{0}", contadorPlanesServiciosAdicionales), item.IdPlanServicioAdicional1);
                                        archivoPdf.DiligenciarCampo(string.Format("txtValorServicioOtros_{0}", contadorPlanesServiciosAdicionales), item.ServicioAdicional1ValorMovistarVoz);
                                        contadorPlanesServiciosAdicionales++;
                                    }
                                    if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional2) && !string.IsNullOrEmpty(item.ServicioAdicional2ValorMovistarVoz))
                                    {
                                        archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioOtros_{0}", contadorPlanesServiciosAdicionales), item.IdPlanServicioAdicional2);
                                        archivoPdf.DiligenciarCampo(string.Format("txtValorServicioOtros_{0}", contadorPlanesServiciosAdicionales), item.ServicioAdicional2ValorMovistarVoz);
                                        contadorPlanesServiciosAdicionales++;
                                    }
                                    if (!string.IsNullOrEmpty(item.IdPlanServicioAdicional3) && !string.IsNullOrEmpty(item.ServicioAdicional3ValorMovistarVoz))
                                    {
                                        archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioOtros_{0}", contadorPlanesServiciosAdicionales), item.IdPlanServicioAdicional3);
                                        archivoPdf.DiligenciarCampo(string.Format("txtValorServicioOtros_{0}", contadorPlanesServiciosAdicionales), item.ServicioAdicional3ValorMovistarVoz);
                                        contadorPlanesServiciosAdicionales++;
                                    }
                                    // Planes adicionales
                                    if (!string.IsNullOrEmpty(item.IdPlanPlanAdicional1) && !string.IsNullOrEmpty(item.PlanAdicional1ValorMovistarVoz))
                                    {
                                        archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioOtros_{0}", contadorPlanesServiciosAdicionales), item.IdPlanPlanAdicional1);
                                        archivoPdf.DiligenciarCampo(string.Format("txtValorServicioOtros_{0}", contadorPlanesServiciosAdicionales), item.PlanAdicional1ValorMovistarVoz);
                                        contadorPlanesServiciosAdicionales++;
                                    }
                                    if (!string.IsNullOrEmpty(item.IdPlanPlanAdicional2) && !string.IsNullOrEmpty(item.PlanAdicional2ValorMovistarVoz))
                                    {
                                        archivoPdf.DiligenciarCampo(string.Format("txtPlanTarifarioOtros_{0}", contadorPlanesServiciosAdicionales), item.IdPlanPlanAdicional2);
                                        archivoPdf.DiligenciarCampo(string.Format("txtValorServicioOtros_{0}", contadorPlanesServiciosAdicionales), item.PlanAdicional2ValorMovistarVoz);
                                        contadorPlanesServiciosAdicionales++;
                                    }
                                }
                                if (contador > 11)
                                {
                                    break;
                                }
                            }
                        }
                    }
                    // Informacion de usuarios autorizados
                    NegocioContactosAutorizados contactos = BNegocio.GetContactosAutorizados(this.IdUser, this.CodNegocio);
                    if (contactos != null)
                    {
                        archivoPdf.DiligenciarCampo("txtNombreUsuarioAutorizado_1", contactos.Contacto1Nombre.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNombreUsuarioAutorizado_2", contactos.Contacto2Nombre.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNombreUsuarioAutorizado_3", contactos.Contacto3Nombre.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNombreUsuarioAutorizado_4", contactos.Contacto4Nombre.ToUpperInvariant());

                        archivoPdf.DiligenciarCampo("txtMovilUsuarioAutorizado_1", contactos.Contacto1Movil.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtMovilUsuarioAutorizado_2", contactos.Contacto2Movil.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtMovilUsuarioAutorizado_3", contactos.Contacto3Movil.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtMovilUsuarioAutorizado_4", contactos.Contacto4Movil.ToUpperInvariant());

                        archivoPdf.DiligenciarCampo("txtEmailUsuarioAutorizado_1", contactos.Contacto1Email.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmailUsuarioAutorizado_2", contactos.Contacto2Email.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmailUsuarioAutorizado_3", contactos.Contacto3Email.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmailUsuarioAutorizado_4", contactos.Contacto4Email.ToUpperInvariant());

                        archivoPdf.DiligenciarCampo("txtCedulaUsuarioAutorizado_1", contactos.Contacto1Cedula.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaUsuarioAutorizado_2", contactos.Contacto2Cedula.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaUsuarioAutorizado_3", contactos.Contacto3Cedula.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaUsuarioAutorizado_4", contactos.Contacto4Cedula.ToUpperInvariant());

                        archivoPdf.DiligenciarCampo("txtPerfilUsuarioAutorizado_1", contactos.Contacto1PerfilAutorizado.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtPerfilUsuarioAutorizado_2", contactos.Contacto2PerfilAutorizado.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtPerfilUsuarioAutorizado_3", contactos.Contacto3PerfilAutorizado.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtPerfilUsuarioAutorizado_4", contactos.Contacto4PerfilAutorizado.ToUpperInvariant());
                    }
                    //Informacion de vendedor
                    Vendedor vendedor = ComercialBL.GetVendedor(this.IdUser, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
                    if (vendedor != null)
                    {
                        archivoPdf.DiligenciarCampo("txtNombreAsesorComercial", vendedor.NombreVendedor.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaAsesorComercial", vendedor.NumIdent.ToString().ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNumeroCelularAsesorComercial", vendedor.NumCelular.ToString().ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCodigoAsesorComercial", negocio.CodVendedor.ToString());
                        archivoPdf.DiligenciarCampo("txtNombreJefeAsesor", !string.IsNullOrEmpty(infoAdicional.Jefezona) ? infoAdicional.Jefezona : "");
                    }
                    archivoPdf.CerrarPDF();
                }
            }
            catch (Exception)
            {
                throw new Exception("Error en generacion  de archivos PDF FUN");
            }
        }
    }
}