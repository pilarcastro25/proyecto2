﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Models.PORTABILIDAD;
using Nabis.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class PagareImpresion
    {
        #region Propiedades
        private const string DOCUMENTO_PAGARE_ALIAS = "PAGARE";
        private const string CONFIGURACION_PLANTILLA_PDF_PAGARE = "Pagare";
        private string CodNegocio { get; set; }
        

        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        
        #endregion

        #region Constructor

        public PagareImpresion(string codNegocio)
        {
            if (string.IsNullOrWhiteSpace(codNegocio))
            {
                throw new ArgumentNullException("codNegocio", "El valor no puede ser nulo o vacio.");
            }
            this.CodNegocio = codNegocio;
        }

        #endregion

        #region Funciones

        /// <summary>
        /// Función que llena los datos del pagaré
        /// </summary>
        public void DiligenciaPagare()
        {
            try
            {
                List<GenericOption> documentos = BNegocio.GetDocumentos(HttpContext.Current.User.Identity.Name, this.CodNegocio, DOCUMENTO_PAGARE_ALIAS);
                if (documentos.Count > 0)
                {
                    string nombreArchivo = String.Format("Pagare-{0}.pdf", this.CodNegocio);
                    //Ruta en la cual se van a almacenar los archivos
                    string rutaCarpetaContrato = RutaTemporales + this.CodNegocio;
                    //GestionarArchivos.CrearCarpeta(rutaCarpetaContrato);
                    NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONFIGURACION_PLANTILLA_PDF_PAGARE);
                    string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                    string plantillaRutaTemp = RutaTemporales + this.CodNegocio + "/" + nombreArchivo;
                    DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                    DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodNegocio, "0");
                    string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                    if (negocio != null)
                    {
                        p.AbrirPDFParaLlenar();
                        p.DiligenciarCampo("NOMBRE_EMPRESA", negocio.razonSocial.ToUpperInvariant());
                        p.DiligenciarCampo("NOMBRE_REPRESENTANTE_LEGAL", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                        p.DiligenciarCampo("IDENTIFICACION_RL", negocio.RepLegalIdentidad.ToString());
                        p.CerrarPDF();
                    }
                }
            }
            catch
            {
                throw new Exception("Error diligenciando PDF de Pagaré");
            }
        }

        #endregion
    }
}