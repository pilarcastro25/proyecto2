﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis.Utilities;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Entidad que tiene la funcionalidad de impresion de empresa en linea.
    /// </summary>
    public class EmpresaEnLineaImpresion
    {
        /// <summary>
        /// Alias Empresa en Linea.
        /// </summary>
        private const string DOCUMENTO_EMPRESA_LINEA_ALIAS = "CEL";
        /// <summary>
        /// Plantilla de empresa en linea.
        /// </summary>
        private const string CONFIGURACION_PLANTILLA_PDF_EMPRESA_LINEA = "EmpresaLinea";

        protected string CodigoNegocio { get; set; }

        /// <summary>
        /// Rta temporal de los archivos.
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        [ThreadStatic]
        RadicacionNegocioRepository radicacionNegocioRepository;
        /// <summary>
        /// Repositorio de radicacion de negocio.
        /// </summary>
        RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (radicacionNegocioRepository == null)
                {
                    radicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return radicacionNegocioRepository;
            }
        }

        /// <summary>
        /// Constructor de empresa en linea que reciba el codigo del negocio.
        /// </summary>
        /// <param name="codigoNegocio">Codigo del negocio.</param>
        public EmpresaEnLineaImpresion(string codigoNegocio)
        {
            if (string.IsNullOrWhiteSpace(codigoNegocio))
            {
                throw new ArgumentNullException("codigoNegocio", "El valor del condigo del negocio no puede ser un valor nulo o vacio.");
            }
            this.CodigoNegocio = codigoNegocio;
        }

        /// <summary>
        /// Generar formato de empresa en linea.
        /// </summary>
        public void GenerarFormatoEmpresaLinea()
        {
            try
            {
                    GestionarArchivos.CrearCarpeta(string.Format("{0}{1}", this.RutaTemporales, this.CodigoNegocio));
                    DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodigoNegocio, "0");
                    string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;

                    if (negocio != null)
                    {
                        string nombreArchivo = String.Format("EMPRESA_LINEA-{0}.pdf", this.CodigoNegocio);
                        //Se trae la ruta en la cual se encuentra almacenado el Template del traspaso
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONFIGURACION_PLANTILLA_PDF_EMPRESA_LINEA);
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = string.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoNegocio, nombreArchivo);
                        DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        archivoPdf.AbrirPDFParaLlenar();
                        archivoPdf.DiligenciarCampo("txtEmpresa", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtEmpresa1", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNIT", negocio.numIdent);
                        archivoPdf.DiligenciarCampo("txtNomRepreLegal", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                        archivoPdf.DiligenciarCampo("txtIdentificRL", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.DiligenciarCampo("txtTipoIdent", "CEDULA");
                        var empresaEnLinea = this.RadicacionNegocioRepository.ObtenerEmpresaLinea(this.CodigoNegocio).FirstOrDefault();
                        if (empresaEnLinea != null)
                        {
                            archivoPdf.DiligenciarCampo("txtCantidadLicencias", empresaEnLinea.cantLicencias.ToString());
                            archivoPdf.DiligenciarCampo("txtValorMensual", empresaEnLinea.valorMensual.ToString());
                            archivoPdf.DiligenciarCampo("txtCiudadFirma", empresaEnLinea.ciudadFirma.ToUpperInvariant());
                            archivoPdf.DiligenciarCampo("txtCorreoEletronico", empresaEnLinea.email.ToUpperInvariant());
                        }
                        archivoPdf.DiligenciarCampo("txtDireccion", negocio.Direccion.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtTelefono", negocio.TelefonoCliente);
                        archivoPdf.DiligenciarCampo("txtCiudadC", ciudad);

                        //Informacion de vendedor
                        Vendedor vendedor = ComercialBL.GetVendedor(HttpContext.Current.User.Identity.Name, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
                        if (vendedor != null)
                        {
                            archivoPdf.DiligenciarCampo("txtNomVendedor", vendedor.NombreVendedor.ToUpperInvariant());
                            archivoPdf.DiligenciarCampo("txtIdentVendedor", vendedor.NumIdent.ToString().ToUpperInvariant());
                            archivoPdf.DiligenciarCampo("txtCelularVendedor", vendedor.NumCelular.ToString().ToUpperInvariant());
                            archivoPdf.DiligenciarCampo("txtCodVendedor", negocio.CodVendedor.ToString());
                            // TODO: Informacion Agente
                            archivoPdf.DiligenciarCampo("txtNomAsesor", vendedor.NombreVendedor.ToUpperInvariant());

                        }
                        // TODO: Informacion Agente
                        archivoPdf.DiligenciarCampo("txtCodAsesor", negocio.CodVendedor.ToString());
                        archivoPdf.DiligenciarCampo("txtCanal", negocio.canalVenta.ToUpperInvariant());

                        archivoPdf.DiligenciarCampo("txtDia", DateTime.Now.ToString("dd"));
                        archivoPdf.DiligenciarCampo("txtMes", DateTime.Now.ToString("MM"));
                        archivoPdf.DiligenciarCampo("txtAnio", DateTime.Now.ToString("yy"));
                        archivoPdf.DiligenciarCampo("txtRepLegalFirma", string.Format("{0} {1} {2}", negocio.RepLegalNombre.ToUpperInvariant(), negocio.RepLegalApellido1.ToUpperInvariant(), negocio.RepLegalApellido2.ToUpperInvariant()));
                        archivoPdf.DiligenciarCampo("txtIdentificacionFirma", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.CerrarPDF();
                    }
                //}
            }
            catch
            {
                throw new Exception("Error en generacion de PDF de Empresa en Linea.");
            }
        }
    }
}