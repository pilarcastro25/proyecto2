﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.App_GlobalCode;
using Nabis.App_Root.Modules;
using DiligenciadorPDFT;
using Nabis.Utilities;
using Nabis.Models.Entities;
using Nabis.Repository;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class MepeImpresion
    {

        #region Constructor
        private string IdEb;
        private string User;
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        public MepeImpresion(string codnegocio, string IdUser)
        {
            if (string.IsNullOrWhiteSpace(codnegocio))
            {
                throw new ArgumentNullException("codnegocio", "El valor no puede ser nulo o vacio.");
            }
            this.IdEb = codnegocio;
            this.User = HttpContext.Current.User.Identity.Name;
        }

        #endregion

        #region Funciones
        /// <summary>
        /// Función que llena los datos de MEPE en el formato PDF
        /// </summary>
        public void GeneraMepePDF()
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(this.User, this.IdEb, "0");
                List<NegocioCobroRevertidoMepe> Mepes = BNegocio.GetCobroRevertidoMepe(this.User, this.IdEb);
                Vendedor vendedor = ComercialBL.GetVendedor(this.User, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                if (negocio != null && Mepes.Count > 0)
                {
                    int i = 1;
                    bool Multiples = Mepes.Count > 1;
                    foreach (NegocioCobroRevertidoMepe mepe in Mepes)
                    {
                        NumLetra conversorFecha = new NumLetra();
                        string nombreArchivo = String.Format("{0}-MEPE.pdf", this.IdEb, Multiples ? string.Format("-{0}", i.ToString()) : string.Empty);
                        string rutaCarpetaContrato = RutaTemporales + this.IdEb;
                        GestionarArchivos.CrearCarpeta(rutaCarpetaContrato);
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("MEPE");
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = RutaTemporales + this.IdEb + "/" + nombreArchivo;
                        DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        p.AbrirPDFParaLlenar();

                        p.DiligenciarCampo("CANAL DE VENTARow1", negocio.canalVenta);
                        p.DiligenciarCampo("CODCLIENTE", (mepe.CodCliente??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("DIA", negocio.FecIngreso.Day.ToString());
                        p.DiligenciarCampo("MES", negocio.FecIngreso.Month.ToString());
                        p.DiligenciarCampo("ANO", negocio.FecIngreso.Year.ToString());
                        p.DiligenciarCampo("NOMBRE Y APELLIDO VENDEDORRow1", vendedor.NombreVendedor);
                        p.DiligenciarCampo("CODIGO DE VENTASRow1", negocio.CodVendedor.ToString());
                        p.DiligenciarCampo("NOMBRE DISTRIBUIDORRow1", vendedor.NombreAgente);
                        p.DiligenciarCampo("DEPARTAMENTORow1", negocio.Departamento.ToString());
                        p.DiligenciarCampo("CIUDADRow1", ciudad);
                        p.DiligenciarCampo("VALOR POR MENSAJE", (mepe.MepeValorMensaje??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("POR DEMANDA", mepe.TipoPlan == "POR DEMANDA" ? "X" : "");
                        p.DiligenciarCampo("ON_NET", mepe.TipoPlan == "ON NET" ? "X" : "");
                        p.DiligenciarCampo("MULTIOPERADOR", mepe.TipoPlan == "MULTIOPERADOR" ? "X" : "");
                        p.DiligenciarCampo("BOLSA", mepe.TipoPlan == "BOLSA" ? "X" : "");
                        p.DiligenciarCampo("CODIGO A ACTIVAR", (mepe.MepeCodActivacion??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("PLAN", mepe.CodPlan);
                        p.DiligenciarCampo("NOMBRE_PLAN", mepe.NombrePlan??"");
                        p.DiligenciarCampo("COBERTURA", mepe.Cobertura??"");
                        p.DiligenciarCampo("CANTIDAD MENSAJES", (mepe.MepeCantidadMensajes??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("RAZON SOCIAL", negocio.razonSocial);
                        p.DiligenciarCampo("NIT", negocio.numIdent);
                        p.DiligenciarCampo("TELEFONOS", negocio.TelefonoCliente);
                        p.DiligenciarCampo("DIRECCION CORRESPONDENCIARow1", negocio.Direccion);
                        p.DiligenciarCampo("EMAIL", negocio.EmailCliente);
                        p.DiligenciarCampo("APARTADO", (mepe.ApartadoCliente??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("CIUDAD", ciudad);
                        p.DiligenciarCampo("DEPARTAMENTO", negocio.Departamento.ToString());
                        p.DiligenciarCampo("ACTIVIDAD ECONOMICA", mepe.ActividadEconomica??"");
                        p.DiligenciarCampo("CATEGORIA IMPOSITIVA", mepe.CategoriaImpositiva??"");
                        p.DiligenciarCampo("NOMBRE REPRESENTANTE LEGALRow1", negocio.RepLegalNombre + " " + negocio.RepLegalApellido1 + " " + negocio.RepLegalApellido2);
                        p.DiligenciarCampo("IDENTIFICACIONRow1", negocio.RepLegalIdentidad.ToString());
                        p.DiligenciarCampo("TELEFONOSRow1", negocio.RepLegalFijo.ToString());
                        p.DiligenciarCampo("NOMBRERow1", mepe.ContactoAutNombre);
                        p.DiligenciarCampo("PRIMER APELLIDORow1", mepe.ContactoAutApellido1);
                        p.DiligenciarCampo("SEGUNDO APELLIDORow1", mepe.ContactoAutApellido2);
                        p.DiligenciarCampo("IDENTIFICACIONRow1_2", mepe.ContactoAutNumIdent.ToString());
                        p.DiligenciarCampo("DIRECCION", mepe.ContactoAutDireccion);
                        p.DiligenciarCampo("EMAIL_2", mepe.ContactoAutDireccion);
                        p.DiligenciarCampo("CIUDAD_2", mepe.ContactoAutCiudad);
                        p.DiligenciarCampo("DEPARTAMENTO_2", mepe.ContactoAutDepartamento);
                        p.DiligenciarCampo("TELEFONOS_2", (mepe.ContactoAutNumFijo??1).ToString().Replace("-1","") + "/" + mepe.ContactoAutNumCelular.ToString());
                        p.CerrarPDF();
                        i++;
                    }
                }
            }
            catch
            {
                throw new Exception("Error diligenciando PDF MEPE");
            }
        }

        #endregion
    }
}