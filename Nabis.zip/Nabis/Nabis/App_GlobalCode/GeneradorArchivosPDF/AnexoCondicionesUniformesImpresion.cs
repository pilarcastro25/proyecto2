﻿using DiligenciadorPDFT;
using Nabis.Models;
using Nabis.Models.Entities;
using Nabis.Repository;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Hosting;
using System.Web.UI.WebControls;
using Nabis.Utilities;
using Nabis_ET.Comercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class AnexoCondicionesUniformesImpresion
    {
        #region Propiedades
        private string IdNegocio { get; set; }
        private string UsarioLogin { get; set; }
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        [ThreadStatic]
        private RadicacionNegocioRepository _RadicacionNegocioRepository;
        /// <summary>
        /// Repositorio que permite el acceso a los datos relacionados al negocio.
        /// </summary>
        private RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this._RadicacionNegocioRepository == null)
                {
                    this._RadicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return _RadicacionNegocioRepository;
            }
        }
        #endregion

        #region Métodos públicos
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="idNegocio"></param>
        /// <param name="usuario"></param>
        public AnexoCondicionesUniformesImpresion(string idNegocio, string usuario)
        {
            if (!String.IsNullOrEmpty(idNegocio) && !String.IsNullOrEmpty(usuario))
            {
                this.IdNegocio = idNegocio;
            }
            else
            {
                throw new Exception("El código del negocio no puede estar vacío");
            }
        }
        /// <summary>
        /// /Imprimir pdf del anexo del contrato de condiciones uniformes
        /// </summary>
        public void Imprimir()
        {
            try
            {
                RadicacionNegocioRepository negocioRepository = new RadicacionNegocioRepository();
                AnexoCondicionesUniformesContrato contrato = negocioRepository.ObtenerAnexoCondicionesUniformes(this.IdNegocio);
                if (contrato != null)
                {
                    //Se obtiene la información del negocio
                    Nab_Negocio_SP negocio = MappingRepository.GetNegocio(this.IdNegocio);
                    //Se obtiene la ciudad por codigo del distrito
                    string ciudad = MappingRepository.ObtenerCiudad(negocio.COD_DISTRITO.ToString(), this.UsarioLogin);
                    //Se instancia el repositorio RadicacionNegocioRepository
                    RadicacionNegocioRepository radicacionRepository = new RadicacionNegocioRepository();
                    //Se trae la fecha de activación
                    //DateTime fechaActivacion = radicacionRepository.ObtenerActivacionRobot(this.IdNegocio).FirstOrDefault().FechaActivacion;
                    //string mesActivacion = ((negocio.FEC_INGRESO - fechaActivacion).TotalDays / 30).ToString();
                    NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("AnexoCU");
                    string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                    string nombreArchivo = String.Format("Anexo Condiciones Uniformes-{0}.pdf", this.IdNegocio);
                    string plantillaRutaTemp = String.Format("{0}{1}/{2}", this.RutaTemporales, this.IdNegocio, nombreArchivo);

                    //Cargar los planes adquiridos asociados al negocio
                    List<PlanAdquiridoNegocio> informacionEstructuraVenta = RadicacionNegocioRepository.ObtenerPlanesAdquiridosNegocio(this.IdNegocio).ToList();
                    DateTime fecha = negocio.FEC_INGRESO.AddDays(15);
                    //Obtener fecha de acticación
                    int diaCorte = radicacionRepository.ObtenerActivacionRobot(this.IdNegocio).First().FechaActivacion.Day;
                    //Se trae la cantidad de lineas de voz y datos asociadas a un contrato 
                    int lineasVoz = MappingRepository.ObtenerCantidadDeLineasNegocio(this.IdNegocio, "voz");
                    int lineasDatos = MappingRepository.ObtenerCantidadDeLineasNegocio(this.IdNegocio, "dato");

                    //Informacion de todas las lineas guardadas
                    List<NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES> lineasInfo = RadicacionNegocioRepository.ObtenerAnexoOtrosSiCondicionesUniformes(this.IdNegocio).ToList();
                    bool validacionLineas = lineasInfo.Count > 0;
                    //Verificación de sí tiene sms
                    bool smsincluido = validacionLineas ? lineasInfo.Any(sms => !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_INCLUIDO_G) || !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_INCLUIDO_M) || !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_INCLUIDO_O)) : false;
                    bool smsincluido2 = validacionLineas ? lineasInfo.Any(sms => !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_ADICIONAL_G) || !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_ADICIONAL_M) || !String.IsNullOrEmpty(sms.VALOR_MENSAJE_TEXTO_ADICIONAL_O)) : false;

                    string smss = validacionLineas ? lineasInfo.Sum(smsTotal => smsTotal.VALOR_MENSAJE_TEXTO_ADICIONAL_G.ConvertirStrDouble() + smsTotal.VALOR_MENSAJE_TEXTO_ADICIONAL_M.ConvertirStrDouble() + smsTotal.VALOR_MENSAJE_TEXTO_ADICIONAL_O.ConvertirStrDouble()).ToString() : String.Empty;
                    //Validar si la voz es controlada
                    bool vozControlada = validacionLineas ? !String.IsNullOrEmpty(lineasInfo.FirstOrDefault().CONTROL_CONDICIONES_SERVICIO_VOZ_SI) : false;
                    //Validar si los msjs son controlados
                    bool msmControlado = validacionLineas ? !String.IsNullOrEmpty(lineasInfo.FirstOrDefault().CONTROL_CONDICIONES_SERVICIO_SMS_SI) : false;
                    //Validar si los datos son controlados
                    bool datosControlado = validacionLineas ? !String.IsNullOrEmpty(lineasInfo.FirstOrDefault().CONTROL_CONDICIONES_SERVICIO_DATOSSI) : false;
                    //Obtener condiciones comerciales del contrato
                    List<CondicionesComercialesCU> condicionesComerciales = ObtenerCondicionesComercialesContrato(informacionEstructuraVenta).ToList();
                    //X del sms 
                    bool smsPlan = smsincluido || (smsincluido2 && !msmControlado);
                    //Servicios adicionales
                    ListItem servicios = ObtenerServiciosAdicionales(informacionEstructuraVenta, condicionesComerciales);

                    List<String> planesLista = condicionesComerciales.Select(cC => cC.CodigoPlan).Distinct().ToList();

                    CondicionesComercialesCU x = null;
                    //Se obtienen los minutos adicionales de la estructura de venta
                    string minutosAdicionales = MinutosSegundosAdicionales(informacionEstructuraVenta).ToString();
                    //Se obtienen los KbAdicionales de la estructura de venta
                    string kbAdicionales = KbAdicionales(informacionEstructuraVenta).ToString();

                    //Mapeo del pdf
                    DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                    p.AbrirPDFParaLlenar();
                    var s = "";
                    string mensualidad = String.Format("$ {0:#,#}", (condicionesComerciales.Sum(cantidad => cantidad.ValorTotal.ConvertirStrDouble()) +
                                        servicios.Value.ConvertirStrDouble()));

                    p.DiligenciarCampo("cantidad$", mensualidad);
                    p.DiligenciarCampo("vigencia", "12");
                    p.DiligenciarCampo("aceptoPlazo", contrato.Renovacion ? "X" : String.Empty);
                    p.DiligenciarCampo("telefoniaX", servicios.Value.Vacio() ? "X" : String.Empty);
                    p.DiligenciarCampo("smsX", smsPlan ? "X" : String.Empty);
                    p.DiligenciarCampo("otrosServicios", servicios.Text);
                    p.DiligenciarCampo("dia", fecha.Day.ToString());
                    p.DiligenciarCampo("mes", fecha.Month.ToString());
                    p.DiligenciarCampo("anio", fecha.Year.ToString());
                    //Descomentar las lineas en caso que vaya algo a lado del formato
                    //p.DiligenciarCampo("condicionesPlan", !String.IsNullOrEmpty(contrato.));
                    //p.DiligenciarCampo("descripcion", s);
                    p.DiligenciarCampo("vozControladaX", vozControlada ? "X" : String.Empty);
                    p.DiligenciarCampo("vozAbiertaX", vozControlada ? String.Empty : "X");
                    int i = 0;
                    int j = 0;
                    planesLista.ForEach(y =>
                    {
                        x = condicionesComerciales.First(cu => cu.CodigoPlan == y);
                        long numLineas = condicionesComerciales.Where(liCod => liCod.CodigoPlan == y).Sum(li => li.CantidadLineas);
                        if (x.MinutosIncluidos.Vacio())
                        {
                            p.DiligenciarCampo("telefoniaX", "X");
                            p.DiligenciarCampo(String.Format("codPlan[{0}]", i), x.CodigoPlan);
                            p.DiligenciarCampo(String.Format("cargoBasico[{0}]", i), String.Format("${0:#,#}", x.CargoBasico));
                            p.DiligenciarCampo(String.Format("minIncluido[{0}]", i), x.MinutosIncluidos);
                            p.DiligenciarCampo(String.Format("valorMinM[{0}]", i), String.Format("${0:#,#}", x.ValorMinutoMovistar));
                            p.DiligenciarCampo(String.Format("valorMinF[{0}]", i), String.Format("${0:#,#}", x.ValorMinutoFijo));
                            p.DiligenciarCampo(String.Format("valorMinO[{0}]", i), String.Format("${0:#,#}", x.ValorMinutoOtro));
                            p.DiligenciarCampo(String.Format("cantidadLineas[{0}]", i), numLineas.ToString());
                            p.DiligenciarCampo(String.Format("valor[{0}]", i), String.Format("${0:#,#}", (numLineas * x.CargoBasico.ConvertirStrDouble())));
                            i++;

                            if (x.GbIncluidos.Vacio())
                            {
                                p.DiligenciarCampo("internetX", "X");
                                p.DiligenciarCampo(String.Format("codPlanDatos[{0}]", j), x.CodigoPlan);
                                p.DiligenciarCampo(String.Format("cargoBasicoDatos[{0}]", j), x.RentaDatos);
                                p.DiligenciarCampo(String.Format("gbIncluido[{0}]", j), x.GbIncluidos.ConvertirStrDouble() > 1 ? x.GbIncluidos.Substring(0, 4) : String.Format(CultureInfo.InvariantCulture, "{0:00.000}", Math.Round(x.GbIncluidos.ConvertirStrDouble(), 3))); p.DiligenciarCampo(String.Format("valorKb[{0}]", j), String.Format("$ {0:#,#}", x.ValorKb.ConvertirStrDouble()));
                                p.DiligenciarCampo(String.Format("valorKb[{0}]", j), String.Format("${0:00.00}", x.ValorKb.ConvertirStrDouble()));
                                p.DiligenciarCampo(String.Format("cantidadLineasDatos[{0}]", j), numLineas.ToString());
                                p.DiligenciarCampo(String.Format("valorDatos[{0}]", j), String.Empty);
                                j++;
                            }
                        }
                        else
                        {
                            p.DiligenciarCampo("internetX", "X");
                            p.DiligenciarCampo(String.Format("codPlanDatos[{0}]", j), x.CodigoPlan);
                            p.DiligenciarCampo(String.Format("cargoBasicoDatos[{0}]", j), String.Format("${0:#,#}", (x.CargoBasico.ConvertirStrDouble() + x.RentaDatos.ConvertirStrDouble()).ToString()));
                            p.DiligenciarCampo(String.Format("gbIncluido[{0}]", j), x.GbIncluidos.ConvertirStrDouble() > 1 ? x.GbIncluidos.Substring(0, 4) : String.Format(CultureInfo.InvariantCulture, "{0:00.000}", Math.Round(x.GbIncluidos.ConvertirStrDouble(), 3)));
                            p.DiligenciarCampo(String.Format("valorKb[{0}]", j), String.Format("${0:00.00}", x.ValorKb.ConvertirStrDouble()));
                            p.DiligenciarCampo(String.Format("cantidadLineasDatos[{0}]", j), numLineas.ToString());
                            p.DiligenciarCampo(String.Format("valorDatos[{0}]", j), String.Format("${0:#,#}", numLineas * x.CargoBasico.ConvertirStrDouble()));
                            j++;
                        }
                    });
                    p.DiligenciarCampo("minAdicional", !vozControlada ? String.Format("${0:#,#}", minutosAdicionales.ConvertirStrDouble()) : String.Empty);
                    p.DiligenciarCampo("smsAdicional", !msmControlado ? String.Format("${0}", smss) : String.Empty);
                    p.DiligenciarCampo("kbAdicional", !datosControlado ? String.Format("${0:#,#}", kbAdicionales.ConvertirStrDouble()) : String.Empty);
                    p.DiligenciarCampo("valor", String.Format("${0:#,#}", servicios.Value.ConvertirStrDouble()));
                    p.DiligenciarCampo("mensualidadTotal", String.Format("${0:#,#}", (condicionesComerciales.Sum(mT => mT.ValorTotal.ConvertirStrDouble()))));
                    p.DiligenciarCampo("serviciosAdicionales", servicios.Text);
                    p.DiligenciarCampo("numUsuarioInternet", !String.IsNullOrEmpty(negocio.ID_EB) ? negocio.ID_EB : String.Empty);
                    p.DiligenciarCampo("razonSocial", negocio.NOMBRE_CLIENTE);
                    p.DiligenciarCampo("nit", !String.IsNullOrEmpty(negocio.IDENTIDAD) ? negocio.IDENTIDAD.ToUpper() : String.Empty);
                    p.DiligenciarCampo("email", !String.IsNullOrEmpty(negocio.EMAIL_CLIENTE) ? negocio.EMAIL_CLIENTE : String.Empty);
                    p.DiligenciarCampo("direccion", negocio.DIRECCION);
                    p.DiligenciarCampo("municipio", !String.IsNullOrEmpty(ciudad) ? ciudad.ToUpper() : String.Empty);
                    p.DiligenciarCampo("diaTerminacion", diaCorte.ToString());
                    p.DiligenciarCampo("cc", negocio.REP_LEGAL_IDENTIDAD.ToString());
                    p.DiligenciarCampo("capMaxGb", condicionesComerciales.Max(gBMax => gBMax.GbIncluidos.ConvertirStrDouble()) > 1 ? Math.Round(condicionesComerciales.Max(gBMax => gBMax.GbIncluidos.ConvertirStrDouble()), 1).ToString().Substring(0, 2) : String.Format("{0:0.00}", Math.Round(condicionesComerciales.Max(gBMax => gBMax.GbIncluidos.ConvertirStrDouble()), 3)).Substring(0, 3));
                    p.CerrarPDF();
                }
            }
            catch (Exception)
            {
                throw new Exception("Error generando archivo de anexo de condiciones uniformes");
            }
        }
        /// <summary>
        /// Informacion de los minutos o segundos adicionales de la estructura de venta
        /// </summary>
        /// <param name="informacionEstructuraVenta"></param>
        /// <returns></returns>
        private double MinutosSegundosAdicionales(List<PlanAdquiridoNegocio> informacionEstructuraVenta)
        {
            double minutoAdicional = (informacionEstructuraVenta.Sum(valorMoAdi => valorMoAdi.VALOR_MOVISTAR_ADICIONAL_VOZ.ConvertirStrDouble() * valorMoAdi.CANTIDAD_LINEAS) +
                                    informacionEstructuraVenta.Sum(valorFiAdi => valorFiAdi.VALOR_FIJO_ADICIONAL_VOZ.ConvertirStrDouble() * valorFiAdi.CANTIDAD_LINEAS) +
                                    informacionEstructuraVenta.Sum(valorOtAdi => valorOtAdi.VALOR_OTROS_ADICIONAL_VOZ.ConvertirStrDouble() * valorOtAdi.CANTIDAD_LINEAS) +
                                    informacionEstructuraVenta.Sum(valorGAdi => valorGAdi.VALOR_G_ADICIONAL_VOZ.ConvertirStrDouble() * valorGAdi.CANTIDAD_LINEAS));
            return minutoAdicional;
        }
        /// <summary>
        /// Obtener Kb adicionales de la estructura de venta
        /// </summary>
        /// <param name="informacionEstructuraVenta"></param>
        /// <returns></returns>
        private double KbAdicionales(List<PlanAdquiridoNegocio> informacionEstructuraVenta)
        {
            double kbAdicional = informacionEstructuraVenta.Sum(planDatos => planDatos.PLAN_DATOS_KB_ADICIONAL.ConvertirStrDouble() * planDatos.CANTIDAD_LINEAS) +
                informacionEstructuraVenta.Sum(rentaServicioAdicional1 => rentaServicioAdicional1.KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble() * rentaServicioAdicional1.CANTIDAD_LINEAS) +
                                 informacionEstructuraVenta.Sum(rentaServicioAdicional2 => rentaServicioAdicional2.KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble() * rentaServicioAdicional2.CANTIDAD_LINEAS) +
                                 informacionEstructuraVenta.Sum(rentaServicioAdicional3 => rentaServicioAdicional3.KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble() * rentaServicioAdicional3.CANTIDAD_LINEAS);

            return kbAdicional;
        }
        /// <summary>
        /// /Obtener información específica de la los planes adquiridos
        /// </summary>
        /// <param name="informacionEstructuraVenta"></param>
        /// <returns></returns>
        private IEnumerable<CondicionesComercialesCU> ObtenerCondicionesComercialesContrato(List<PlanAdquiridoNegocio> informacionEstructuraVenta)
        {
            List<CondicionesComercialesCU> condicionesComerciales = new List<CondicionesComercialesCU>();
            informacionEstructuraVenta.ForEach(x =>
            {
                condicionesComerciales.Add(new CondicionesComercialesCU()
                {
                    CodigoPlan = x.ID_PLAN_TARIFARIO,
                    CargoBasico = (x.CARGO_BASICO.ConvertirStrDouble()).ToString(),
                    RentaDatos = (x.PLAN_DATOS_RENTA_MES),
                    CantidadLineas = x.CANTIDAD_LINEAS,
                    GbIncluidos = !String.IsNullOrEmpty(x.PLAN_DATOS_KB_INCLUIDO) ? (x.PLAN_DATOS_KB_INCLUIDO.ConvertirStrDouble() / Math.Pow(1024, 2)).ToString() : String.Empty,
                    MinutosIncluidos = x.MINUTOS_INCLUIDOS,
                    ValorMinutoFijo = x.VALOR_FIJO_VOZ,
                    ValorMinutoMovistar = x.VALOR_MOVISTAR_VOZ,
                    ValorMinutoOtro = (x.VALOR_OTROS_VOZ.ConvertirStrDouble() + x.VALOR_OTROS_G.ConvertirStrDouble()).ToString(),
                    ValorKb = (x.PLAN_DATOS_RENTA_MES.ConvertirStrDouble() / x.PLAN_DATOS_KB_INCLUIDO.ConvertirStrDouble()).ToString(),
                    ValorTotal = ((x.CARGO_BASICO.ConvertirStrDouble() + x.PLAN_DATOS_RENTA_MES.ConvertirStrDouble()) * x.CANTIDAD_LINEAS).ToString()
                });
            });
            return condicionesComerciales;
        }
        /// <summary>
        /// Se obtienen los servicios adicionales
        /// </summary>
        /// <param name="informacionEstructuraVenta"></param>
        /// <returns></returns>
        private ListItem ObtenerServiciosAdicionales(List<PlanAdquiridoNegocio> informacionEstructuraVenta, List<CondicionesComercialesCU> condicionesComerciales)
        {
            string cadena = String.Empty;
            List<string> otrosServicios1 = informacionEstructuraVenta.Select(x => x.ID_PLAN_SERVICIO_ADICIONAL_1).Distinct().ToList();
            List<string> otrosServicios2 = informacionEstructuraVenta.Select(x => x.ID_PLAN_SERVICIO_ADICIONAL_2).Distinct().ToList();
            List<string> otrosServicios3 = informacionEstructuraVenta.Select(x => x.ID_PLAN_SERVICIO_ADICIONAL_3).Distinct().ToList();
            List<string> totalServicios = otrosServicios1.Union(otrosServicios2).Union(otrosServicios3).Distinct().ToList();
            double vozServicioAdicional = 0;
            if (totalServicios.Any())
            {
                totalServicios.ForEach(x =>
                {
                    var p1 = informacionEstructuraVenta.Where(iPlan => iPlan.SERVICIO_ADICIONAL_1_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_1 == x).Sum(suma => suma.SERVICIO_ADICIONAL_1_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() * suma.CANTIDAD_LINEAS);
                    var p2 = informacionEstructuraVenta.Where(iPlan => iPlan.SERVICIO_ADICIONAL_2_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_2 == x).Sum(suma => suma.SERVICIO_ADICIONAL_2_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() * suma.CANTIDAD_LINEAS);
                    var p3 = informacionEstructuraVenta.Where(iPlan => iPlan.SERVICIO_ADICIONAL_3_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_3 == x).Sum(suma => suma.SERVICIO_ADICIONAL_3_VALOR_MOVISTAR_VOZ.ConvertirStrDouble() * suma.CANTIDAD_LINEAS);

                    var adiDatos1 = informacionEstructuraVenta.Where(iPlan => iPlan.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_1 == x).ToList();
                    var adiDatos2 = informacionEstructuraVenta.Where(iPlan => iPlan.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_2 == x).ToList();
                    var adiDatos3 = informacionEstructuraVenta.Where(iPlan => iPlan.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble() != 0 && iPlan.ID_PLAN_SERVICIO_ADICIONAL_3 == x).ToList();

                    if (p1 != 0 || p2 != 0 || p3 != 0)
                    {
                        cadena += String.Format("{0}-", x);
                        //hay que sumar el precio de todo lo de voz
                        vozServicioAdicional += p1 + p2 + p3;
                    }

                    adiDatos1.ForEach(nA =>
                     {
                         condicionesComerciales.Add(new CondicionesComercialesCU
                         {
                             CantidadLineas = nA.CANTIDAD_LINEAS,
                             CargoBasico = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble()).ToString(),
                             CodigoPlan = x,
                             GbIncluidos = ((nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble()) / Math.Pow(1024, 2)).ToString(),
                             ValorKb = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble() / nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble()).ToString(),
                             ValorTotal = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_1.ConvertirStrDouble() * nA.CANTIDAD_LINEAS).ToString()
                         });
                     });

                    adiDatos2.ForEach(nA =>
                    {
                        condicionesComerciales.Add(new CondicionesComercialesCU
                        {
                            CantidadLineas = nA.CANTIDAD_LINEAS,
                            CargoBasico = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble()).ToString(),
                            CodigoPlan = x,
                            GbIncluidos = ((nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble()) / Math.Pow(1024, 2)).ToString(),
                            ValorKb = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble() / nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble()).ToString(),
                            ValorTotal = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_2.ConvertirStrDouble() * nA.CANTIDAD_LINEAS).ToString()
                        });
                    });

                    adiDatos3.ForEach(nA =>
                    {
                        condicionesComerciales.Add(new CondicionesComercialesCU
                        {
                            CantidadLineas = nA.CANTIDAD_LINEAS,
                            CargoBasico = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble()).ToString(),
                            CodigoPlan = x,
                            GbIncluidos = ((nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble()) / Math.Pow(1024, 2)).ToString(),
                            ValorKb = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble() / nA.KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble()).ToString(),
                            ValorTotal = (nA.RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_3.ConvertirStrDouble() * nA.CANTIDAD_LINEAS).ToString()
                        });
                    });
                });
            }

            ListItem item = new ListItem(cadena, vozServicioAdicional.ToString());
            return item;
        }
        #endregion
    }
}