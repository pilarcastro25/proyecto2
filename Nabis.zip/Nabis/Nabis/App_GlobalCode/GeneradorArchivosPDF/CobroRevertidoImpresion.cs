﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.App_GlobalCode;
using Nabis.App_Root.Modules;
using DiligenciadorPDFT;
using Nabis.Utilities;
using Nabis.Models.Entities;
using Nabis.Repository;
using System.Web.Hosting;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis.GeneradorArchivosPDF
{
    public class CobroRevertidoImpresion
    {

        #region Propiedades
        private string IdEb;
        private string IdUser;
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }
        #endregion

        #region Constructor

        public CobroRevertidoImpresion(string codnegocio, string IdUser)
        {
            if (string.IsNullOrWhiteSpace(codnegocio))
            {
                throw new ArgumentNullException("codnegocio", "El valor no puede ser nulo o vacio.");
            }
            this.IdEb = codnegocio;
            this.IdUser = HttpContext.Current.User.Identity.Name;
        }

        #endregion

        #region Métodos        
        /// <summary>
        /// Función que llena los datos de cobro revertido en el formato PDF
        /// </summary>
        public void GeneraCobroRevertidoPDF()
        {
            try
            {
                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(this.IdUser, this.IdEb, "0");
                List<NegocioCobroRevertidoMepe> CobrosRevertidos = BNegocio.GetCobroRevertidoMepe(this.IdUser, this.IdEb);
                Vendedor vendedor = ComercialBL.GetVendedor(this.IdUser, negocio.CodVendedor, negocio.CanalVendedor.Equals("DIRECTO", StringComparison.InvariantCulture) ? 1 : 2);
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                if (negocio != null && CobrosRevertidos.Count > 0)
                {
                    int i = 1;
                    bool Multiples = CobrosRevertidos.Count > 1;
                    foreach (NegocioCobroRevertidoMepe cobroRevertido in CobrosRevertidos) {
                        string nombreArchivo = String.Format("{0}{1}-Cobro_Revertido.pdf", this.IdEb, Multiples ? string.Format("-{0}", i.ToString()) : string.Empty);
                        NumLetra conversorFecha = new NumLetra();
                        //Ruta en la cual se van a almacenar los archivos
                        string rutaCarpetaContrato = RutaTemporales + this.IdEb;
                        GestionarArchivos.CrearCarpeta(rutaCarpetaContrato);
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias("CobroRevertido");
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = RutaTemporales + this.IdEb + "/" + nombreArchivo;
                        DiligenciadorPDF p = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        p.AbrirPDFParaLlenar();

                        p.DiligenciarCampo("CANAL DE VENTARow1", negocio.canalVenta);
                        p.DiligenciarCampo("CODCLIENTE", (cobroRevertido.CodCliente ?? -1).ToString().Replace("-1", ""));
                        p.DiligenciarCampo("DIA_SOLICITUD", negocio.FecIngreso.Day.ToString());
                        p.DiligenciarCampo("MES_SOLICITUD", negocio.FecIngreso.Month.ToString());
                        p.DiligenciarCampo("ANO_SOLICITUD ", negocio.FecIngreso.Year.ToString());
                        p.DiligenciarCampo("NOMBRE Y APELLIDO VENDEDORRow1", vendedor.NombreVendedor.ToUpperInvariant());
                        p.DiligenciarCampo("CODIGO DE VENTASRow1", negocio.CodVendedor.ToString());
                        p.DiligenciarCampo("NOMBRE DISTRIBUIDORRow1", vendedor.NombreAgente);
                        p.DiligenciarCampo("DEPARTAMENTORow1", negocio.Departamento.ToString());
                        p.DiligenciarCampo("CIUDADRow1", ciudad);
                        p.DiligenciarCampo("VALOR POR MINUTO", cobroRevertido.CobroValorMinuto.ToString());
                        p.DiligenciarCampo("POR DEMANDA",cobroRevertido.TipoPlan=="POR DEMANDA" ? "X":"");
                        p.DiligenciarCampo("BOLSA", cobroRevertido.TipoPlan == "BOLSA" ? "X" : "");
                        p.DiligenciarCampo("CANTIDAD MINUTOS", cobroRevertido.TipoPlan == "CANTIDAD MINUTOS" ? "X" : "");
                        p.DiligenciarCampo("NUMERAL ABREVIADO", cobroRevertido.CobroIsNumeralAbreviado.HasValue && cobroRevertido.CobroIsNumeralAbreviado.Value ? "X":"");
                        p.DiligenciarCampo("LINEA_018000", cobroRevertido.CobroIsLinea018000.HasValue && cobroRevertido.CobroIsLinea018000.Value ? "X":"");
                        p.DiligenciarCampo("LINEA_1XY", cobroRevertido.CobroIsLinea1xy.HasValue && cobroRevertido.CobroIsLinea1xy.Value ? "X" : "");
                        p.DiligenciarCampo("CODIGO", cobroRevertido.CodPlan);
                        p.DiligenciarCampo("NOMBRE_PLAN", cobroRevertido.NombrePlan);
                        p.DiligenciarCampo("COBERTURA", cobroRevertido.Cobertura);
                        p.DiligenciarCampo("LÍNEA ESPECIAL A ACTIVAR", (cobroRevertido.CobroLineaEspecial??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("NÚMERO DE ENRUTAMIENTO", (cobroRevertido.CobroNumEnrutamiento ?? -1).ToString().Replace("-1", ""));
                        p.DiligenciarCampo("RAZON SOCIAL", negocio.razonSocial);
                        p.DiligenciarCampo("NIT", negocio.numIdent);
                        p.DiligenciarCampo("TELEFONOS", negocio.TelefonoCliente);
                        p.DiligenciarCampo("DIRECCION CORRESPONDENCIARow1", negocio.Direccion);
                        p.DiligenciarCampo("EMAIL", negocio.EmailCliente);
                        p.DiligenciarCampo("APARTADO", (cobroRevertido.ApartadoCliente??-1).ToString().Replace("-1",""));
                        p.DiligenciarCampo("CIUDAD", ciudad);
                        p.DiligenciarCampo("DEPARTAMENTO", negocio.Departamento.ToString());
                        p.DiligenciarCampo("ACTIVIDAD ECONOMICA", cobroRevertido.ActividadEconomica);
                        p.DiligenciarCampo("CATEGORIA IMPOSITIVA", cobroRevertido.CategoriaImpositiva);
                        p.DiligenciarCampo("NOMBRE REPRESENTANTE LEGALRow1", negocio.RepLegalNombre + " " + negocio.RepLegalApellido1 + " " + negocio.RepLegalApellido2);
                        p.DiligenciarCampo("IDENTIFICACIONRow1", negocio.RepLegalIdentidad.ToString());
                        p.DiligenciarCampo("TELEFONOSRow1", (negocio.RepLegalFijo??-1).ToString().Replace("1",""));
                        p.DiligenciarCampo("NOMBRERow1", cobroRevertido.ContactoAutNombre);
                        p.DiligenciarCampo("PRIMER APELLIDORow1", cobroRevertido.ContactoAutApellido1);
                        p.DiligenciarCampo("SEGUNDO APELLIDORow1", cobroRevertido.ContactoAutApellido2);
                        p.DiligenciarCampo("IDENTIFICACIONRow1_2", cobroRevertido.ContactoAutNumIdent.ToString());
                        p.DiligenciarCampo("DIRECCION", cobroRevertido.ContactoAutDireccion);
                        p.DiligenciarCampo("EMAIL_2", cobroRevertido.ContactoAutMail);
                        p.DiligenciarCampo("CIUDAD_2", cobroRevertido.ContactoAutCiudad);
                        p.DiligenciarCampo("DEPARTAMENTO_2", cobroRevertido.ContactoAutDepartamento);
                        p.DiligenciarCampo("TELEFONOS_2", cobroRevertido.ContactoAutNumFijo.ToString() + " / "+ cobroRevertido.ContactoAutNumCelular.ToString());
                        p.CerrarPDF();
                        i++;
                    }
                }
            }
            catch
            {
                throw new Exception("Error diligenciando PDF de Cobro revertido");
            }
        }

        #endregion
    }
}