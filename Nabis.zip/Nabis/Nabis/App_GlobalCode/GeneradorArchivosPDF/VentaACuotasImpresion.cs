﻿using DiligenciadorPDFT;
using Nabis.Models.Entities;
using Nabis.Repository;
using Nabis.Utilities;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace Nabis.GeneradorArchivosPDF
{
    /// <summary>
    /// Fachada encargada de la impresion del documento de venta a cuotas.
    /// </summary>
    public class VentaACuotasImpresion
    {
        /// <summary>
        /// Template para venta a cuotas.
        /// </summary>
        private const string CONFIGURACION_PLANTILLA_PDF_VENTA_A_CUOTAS_ALIAS = "VAC";

        public string CodigoContrato { get; set; }

        /// <summary>
        /// Ubicacacion de archivos temportales
        /// </summary>
        private string RutaTemporales
        {
            get
            {
                return String.Format("{0}/Temp/", AppDomain.CurrentDomain.BaseDirectory);
            }
        }

        [ThreadStatic]
        private RadicacionNegocioRepository _RadicacionNegocioRepository;
        /// <summary>
        /// Repositorio que me permite el acceso a los datos del negocio.
        /// </summary>
        private RadicacionNegocioRepository RadicacionNegocioRepository
        {
            get
            {
                if (this._RadicacionNegocioRepository == null)
                {
                    this._RadicacionNegocioRepository = new RadicacionNegocioRepository();
                }
                return this._RadicacionNegocioRepository;
            }
        }

        private IEnumerable<NAB_VENTAS_VENTA_A_CUOTAS> ObtenerVentaCuotaPorContrato(string numeroContrato)
        {
            return this.RadicacionNegocioRepository.ObtenerVentaACoutas(numeroContrato).ToList();
        }

        /// <summary>
        /// Constructor que recibe por parametro el codigo del negocio
        /// </summary>
        /// <param name="codigoContrato"></param>
        public VentaACuotasImpresion(string codigoContrato)
        {
            if (string.IsNullOrWhiteSpace(codigoContrato))
            {
                throw new ArgumentNullException("codigoContrato", "El valor de codigo de contrato no puede ser un valor nulo o vacio.");
            }
            this.CodigoContrato = codigoContrato;
        }

        /// <summary>
        /// Generar Formato de venta a cuotas para contrato FUN
        /// </summary>
        /// <param name="CodigoContrato"></param>
        public void GenerarFormatoVentaCuotas()
        {
            try
            {
                GestionarArchivos.CrearCarpeta(string.Format("{0}{1}", this.RutaTemporales, this.CodigoContrato));

                DatosNegocio negocio = BNegocio.ConsultarDatosNegocio(HttpContext.Current.User.Identity.Name, this.CodigoContrato, "0");
                NegocioInformacionAdicional infoAdicional = BNegocio.GetInfoAdicional(HttpContext.Current.User.Identity.Name, this.CodigoContrato);
                List<NegocioModalidadesVenta> modalidadesVentas = BNegocio.GetModalidadesVenta(HttpContext.Current.User.Identity.Name, this.CodigoContrato);
                //Fecha actual
                DateTime fecha = DateTime.Now;
                bool ofertas = String.IsNullOrEmpty(infoAdicional.IdKoral) && String.IsNullOrEmpty(infoAdicional.IdPricing);
                string barrio = negocio.Complemento;
                string ciudad = ComercialBL.GetGenericList(HttpContext.Current.User.Identity.Name, "CiudadXId", negocio.CodDistrito.ToString()).ToList()[0].Value;
                int indexDoc = 1;
                if (negocio != null && modalidadesVentas.Count > 0)
                {
                    foreach (NegocioModalidadesVenta item in modalidadesVentas) {
                        if (item.IsVentaCuotas.HasValue && !item.IsVentaCuotas.Value) {
                            continue;
                        }
                        string nombreArchivo = String.Format("VAC-{0}-{1}.pdf", this.CodigoContrato, indexDoc);
                        //Se trae la ruta en la cual se encuentra almacenado el Template del traspaso
                        NAB_GLOBAL_P_CONFIGURACION_SISTEMA plantilla = ConfiguracionSistemaRepository.EncontrarPorAlias(CONFIGURACION_PLANTILLA_PDF_VENTA_A_CUOTAS_ALIAS);
                        string plantillaRuta = HostingEnvironment.MapPath(plantilla.VALOR);
                        string plantillaRutaTemp = string.Format("{0}{1}/{2}", this.RutaTemporales, this.CodigoContrato, nombreArchivo);
                        DiligenciadorPDF archivoPdf = new DiligenciadorPDF(plantillaRuta, plantillaRutaTemp);
                        string numerocontratoMarco = negocio.numContrato;
                        string lugarFecha = string.Format("{0}-{1}", ciudad, negocio.FecIngreso.ToString("yyyy/MM/dd"));
                        archivoPdf.AbrirPDFParaLlenar();
                        //Mapeo de cada uno de los valores a la plantilla
                        archivoPdf.DiligenciarCampo("txtNumeroContratoMarco", numerocontratoMarco);
                        archivoPdf.DiligenciarCampo("txtLugarFechaCelebracionIG", lugarFecha);
                        archivoPdf.DiligenciarCampo("txtDiaIG", negocio.FecIngreso.ToString("dd"));
                        archivoPdf.DiligenciarCampo("txtMesIG", negocio.FecIngreso.ToString("MM"));
                        archivoPdf.DiligenciarCampo("txtAnoIG", negocio.FecIngreso.ToString("yyyy"));
                        archivoPdf.DiligenciarCampo("txtRazonSocialIG", negocio.razonSocial.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtNitIG", negocio.numIdent);
                        archivoPdf.DiligenciarCampo("txtDireccionIG", negocio.CodTipoCalle + " " + negocio.Direccion.ToUpperInvariant() + " " +  barrio);
                        archivoPdf.DiligenciarCampo("txtCiudadIG", ciudad);
                        archivoPdf.DiligenciarCampo("txtCorreoElectronicoIG", negocio.EmailCliente.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtTelefonoIG", negocio.TelefonoCliente);
                        archivoPdf.DiligenciarCampo("txtValorTotalEquipos", item.ValorTotalEquipos.HasValue ? item.ValorTotalEquipos.Value.ToString() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtFormaPago", item.DescripcionCuota.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCuotaInicial", item.CuotaInicial.HasValue ? item.CuotaInicial.Value.ToString() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtNumeroCuotas", item.NumeroCuotas.HasValue ? item.NumeroCuotas.Value.ToString() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtValorCuotaIgual", item.CuotaMensual.HasValue ? item.CuotaMensual.Value.ToString() : string.Empty);
                        archivoPdf.DiligenciarCampo("txtNombreCompradorFirma", negocio.RepLegalNombre.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaCompradorFirma", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.DiligenciarCampo("txtNombrePagare", negocio.RepLegalNombre.ToUpperInvariant());
                        archivoPdf.DiligenciarCampo("txtCedulaPagare", negocio.RepLegalIdentidad.ToString());
                        archivoPdf.CerrarPDF();
                    }
                }
            }
            catch (Exception)
            {
                throw new Exception("Error en generacion de PDF de Venta a Cuotas.");
            }
        }
    }
}