﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.App_GlobalCode
{
    public class GenericResponse
    {
        public string Msg { get; set; }
        public string TypeAlert { get; set; }
        public string PanelWraper { get; set; }
        public bool Hiden { get; set; }
        public string Html { get; set; }
        public object Data { get; set; }
    }
}
