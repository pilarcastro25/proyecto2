﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Web;

namespace Nabis.Repository
{
    public static class AppLog
    {
        public static void Registrar(string mensaje, string codigoExcepcion)
        {
            /*ConectL conexion = new ConectL();
            conexion.CommandQuery = "Nab_Log_Excepciones_Registro";
            conexion.AddParameters("host", AppDomain.CurrentDomain.ToString() ?? AppDomain.CurrentDomain.ToString().ToUpper());
            conexion.AddParameters("usr_login", HttpContext.Current.Session["usr_Login"]);
            conexion.AddParameters("url_path", AppDomain.CurrentDomain.BaseDirectory ?? AppDomain.CurrentDomain.BaseDirectory.ToUpper());
            conexion.AddParameters("path", String.Empty);
            conexion.AddParameters("linea", 0);
            conexion.AddParameters("ip", AppLog.GetLocalIPAddress());
            conexion.AddParameters("equipo", String.Empty);
            conexion.AddParameters("script", String.Empty);
            conexion.AddParameters("cod_excepcion", codigoExcepcion);
            conexion.AddParameters("mensaje", mensaje);
            conexion.AddParameters("notas", String.Empty);
            conexion.AddParameters("fec_evento", DateTime.Now);
            conexion.ExecQuery(true);*/
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("Local IP Address Not Found!");
        }
    }
}