﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis_ET.Comercial;
using Nabis.Models.Entities;
using System.Web.UI.WebControls;
using Nabis.App_GlobalCode;
using System.Data;
using Nabis.Utilities;
using System.Diagnostics;
using System.Text;
using System.Web.Caching;
using Nabis.Models;

namespace Nabis.Repository
{
    public class MappingRepository
    {
        #region private properties
        //private const string NAB_VENTA_OBTENER_DATOS_CONTRATO_MARCO = "Nab_Venta_Obtener_Datos_Contrato_Marco";
        private const string NAB_VENTA_OBTENER_DATOS_CONTRATO_MARCO = "Nab_SP_Comercial_Obtener_Datos_Contrato_Marco";
        private int currentLine;
        public MappingRepository(int currentLine)
        {
            this.currentLine = currentLine;

        }
        #endregion
        #region Constantes
        /// <summary>
        /// SP para la extracción de planes de la base de datos 
        /// </summary>
        private const string AST_INFORMACION_PLAN = "PA_CP_INFORMACION_PLAN";
        #endregion

        #region Métodos públicos estáticos
        /// <summary>
        /// Obtener el numero de contrato marco por numero de identificacion
        /// </summary>
        /// <param name="numeroIdentificacion">Numero de identifiacacion de cliente</param>
        /// <returns></returns>
        public static string ObtenerNumeroContratoMarco(string numeroIdentificacion)
        {
            string numeroContrato = string.Empty;
            try
            {
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect contrato = new Conect(currentLine);
                contrato.commandQuery = NAB_VENTA_OBTENER_DATOS_CONTRATO_MARCO;
                contrato.addParameters("NUMERO_IDENTIFICACION", numeroIdentificacion);
                DataTable data = contrato.getDataTable(true);
                if (data != null)
                {
                    DataRow dr = data.Rows[0];
                    numeroContrato = dr[1].ToString();
                }
            }
            catch
            {
                numeroContrato = string.Empty;
            }
            return numeroContrato;
        }

        /// <summary>
        /// Obtener registro de documento por contrato.
        /// </summary>
        /// <param name="codigoNegocio"></param>
        /// <param name="aliasDocumento"></param>
        /// <returns></returns>
        public static string ObtenerDocumentoPorContrato(string codigoNegocio, string aliasDocumento)
        {
            string documento = string.Empty;
            try
            {
                StringBuilder stbQuery = new StringBuilder();
                stbQuery.Append("SELECT ND.IdEb, ND.IdDocumento, GD.ALIAS ");
                stbQuery.Append("FROM NAB_NEGOCIO_DOCUMENTOS ND ");
                stbQuery.Append("JOIN NAB_GLOBAL_DOCUMENTOS GD ON GD.ID_DOCUMENTO = ND.IdDocumento ");
                stbQuery.Append(string.Format("WHERE ND.IdEb = '{0}' AND ALIAS = '{1}'", codigoNegocio, aliasDocumento));
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect contrato = new Conect(currentLine);
                contrato.commandQuery = "Nab_SP_Comercial_Negocio_Documentos";
                contrato.addParameters("user", "");
                contrato.addParameters("id_eb", codigoNegocio);
                contrato.addParameters("alias", aliasDocumento);
                contrato.execQuery(false);
                if (contrato.numRows > 0)
                {
                    documento = contrato.getColumnValue(3);
                }
            }
            catch
            {
                documento = string.Empty;
            }

            return documento;
        }

        /// <summary>
        /// Obtener el id de contrato marco.
        /// </summary>
        /// <param name="numeroIdentificacion"></param>
        /// <returns></returns>
        public static string ObtenerIdContratoMarco(string numeroIdentificacion)
        {
            string numeroContrato = string.Empty;
            try
            {
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect contrato = new Conect(currentLine);
                contrato.commandQuery = NAB_VENTA_OBTENER_DATOS_CONTRATO_MARCO;
                contrato.addParameters("NUMERO_IDENTIFICACION", numeroIdentificacion);
                DataTable data = contrato.getDataTable(true);
                if (data != null)
                {
                    DataRow dr = data.Rows[0];
                    numeroContrato = dr[0].ToString();
                }
            }
            catch
            {
                numeroContrato = string.Empty;
            }
            return numeroContrato;
        }


        public IEnumerable<ListItem> GetTipoPlan()
        {
            try
            {
                List<ListItem> read = null;
                Conect userConection = new Conect(currentLine);
                //Falta migrar
                userConection.commandQuery = "Nab_Obtener_Tipo_Plan";
                DataTable data = userConection.getDataTable(true);
                if (data.Rows.Count > 0)
                {
                    read = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("IdTipoPlan").ToString(),
                        Text = m.Field<string>("TipoPlan"),
                    }).ToList();
                    return read;
                }
                else return null;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public IEnumerable<NAB_PLANES> GetPlanes()
        {
            List<NAB_PLANES> read = new List<NAB_PLANES>();
            try
            {
                Conect userConection = new Conect(currentLine);
                //userConection.commandQuery = "Nab_Obtener_Planes";
                userConection.commandQuery = "Nab_SP_Comercial_Planes_X_Anexo_Consulta";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    read = data.AsEnumerable().Select(m => new NAB_PLANES()
                    {
                        IdPlan = m.Field<int>("ID_PLAN_ANEXO"),
                        CodigoPlan = m.Field<string>("COD_PLAN"),
                        Planes = m.Field<string>("NOMBRE_PLAN"),
                        IdTipoPlan = m.Field<int>("ID_TIPO_ANEXO")
                    }).ToList();
                }
                return read.ToList();
            }
            catch (Exception)
            {
                return read.ToList();
            }
        }
        public IEnumerable<ListItem> GetCanales()
        {
            try
            {
                List<ListItem> canales = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_SP_Comercial_GetList";
                userConection.addParameters("user", HttpContext.Current.User.Identity.Name);
                userConection.addParameters("vista", HttpContext.Current.User.Identity.Name);
                
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    canales = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("ID_CANAL").ToString(),
                        Text = m.Field<string>("CANAL"),
                    }).ToList();
                    return canales;
                }
                else return null;


            }
            catch (Exception)
            {
                return null;
            }

        }

        public IEnumerable<ListItem> GetTipos()
        {
            try
            {
                List<ListItem> tipo = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Usuarios_Tipos";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    tipo = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("ID_TIPO").ToString(),
                        Text = m.Field<string>("TIPO"),
                    }).ToList();
                    return tipo;
                }
                else return null;
            }
            catch (Exception)
            {
                return null;
            }

        }

        public IEnumerable<ListItem> GetGrupos()
        {
            try
            {
                //IEnumerable<ListItem> grupo = ctx.USERS_GRUPOS.Select(x => new ListItem { Value = x.ID_GRUPO.ToString(), Text = x.GRUPO }).ToList();
                //return grupo.ToList();

                List<ListItem> grupo = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Usuario_Grupos";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    grupo = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("ID_GRUPO").ToString(),
                        Text = m.Field<string>("GRUPO"),
                    }).ToList();
                    return grupo;
                }
                else return null;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public IEnumerable<ListItem> GetRegiones()
        {
            try
            {
                //IEnumerable<ListItem> region = ctx.USERS_REGIONALES.Select(x => new ListItem { Value = x.ID_REGIONAL.ToString(), Text = x.REGIONAL }).ToList();
                //return region.ToList();
                List<ListItem> region = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Regionales";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    region = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("ID_REGIONAL").ToString(),
                        Text = m.Field<string>("REGIONAL"),
                    }).ToList();
                    return region;
                }
                else return null;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public IEnumerable<ListItem> GetAreas()
        {
            try
            {
                //IEnumerable<ListItem> area = ctx.USERS_AREAS.Select(x => new ListItem { Value = x.ID_AREA.ToString(), Text = x.AREA }).ToList();
                //return area.ToList();
                List<ListItem> area = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Areas";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    area = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("ID_AREA").ToString(),
                        Text = m.Field<string>("AREA"),
                    }).ToList();
                    return area;
                }
                else return null;

            }
            catch (Exception)
            {

                return null;
            }
        }

        public IEnumerable<ListItem> GetPerfiles()
        {
            try
            {
                //IEnumerable<ListItem> perfil = ctx.USERS_PERFILES.Select(x => new ListItem { Value = x.ID_PERFIL.ToString(), Text = x.PERFIL }).ToList();
                //return perfil.ToList();
                List<ListItem> perfil = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Perfiles";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    perfil = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<decimal>("ID_PERFIL").ToString(),
                        Text = m.Field<string>("PERFIL").ToString(),
                    }).ToList();
                    return perfil;
                }
                else return null;
            }
            catch (Exception)
            {

                return null;
            }
        }

        public IEnumerable<ListItem> GetModulos()
        {
            try
            {
                //IEnumerable<ListItem> modulos = ctx.NAB_MODULOS.Select(x => new ListItem { Value = x.IdModulo.ToString(), Text = x.Modulo }).ToList();
                //return modulos.ToList();
                List<ListItem> modulos = null;
                Conect userConection = new Conect(currentLine);

                userConection.commandQuery = "Nab_Obtener_Modulos";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    modulos = data.AsEnumerable().Select(m => new ListItem()
                    {
                        Value = m.Field<int>("IdModulo").ToString(),
                        Text = m.Field<string>("Modulo"),
                    }).ToList();
                    return modulos;
                }
                else return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public IEnumerable<Nab_Obtener_Planes_Tipos_Result> GetPlanesTipoPlan(string cod = null, string idPlan = null)
        {
            try
            {
                //IEnumerable<Nab_Obtener_Planes_Tipos_Result> planesTipos = ctx.Nab_Obtener_Planes_Tipos(cod);
                //return planesTipos.ToList();
                List<Nab_Obtener_Planes_Tipos_Result> planesTipos = null;
                Conect userConection = new Conect(currentLine);
                userConection.commandQuery = "Nab_Obtener_Planes_Tipos";
                userConection.addParameters("cod", cod);
                userConection.addParameters("idPlan", idPlan);
                if (cod == null)
                {
                    DataTable data = userConection.getDataTable(true);

                    if (data.Rows.Count > 0)
                    {
                        planesTipos = data.AsEnumerable().Select(m => new Nab_Obtener_Planes_Tipos_Result()
                        {

                            IdPlan = m.Field<int>("IdPlan"),
                            CodigoPlan = m.Field<string>("CodigoPlan").ToString(),
                            Planes = m.Field<string>("Planes").ToString(),
                            TipoPlan = m.Field<string>("TipoPlan").ToString()
                        }).ToList();
                        return planesTipos;
                    }
                    else return null;
                }
                else
                {
                    userConection.execQuery(true);

                    if (userConection.numRows > 0)
                    {
                        planesTipos = new List<Nab_Obtener_Planes_Tipos_Result>();

                        planesTipos.Add(new Nab_Obtener_Planes_Tipos_Result
                        {
                            IdPlan = Convert.ToInt32(userConection.getColumnValue("IdPlan")),
                            CodigoPlan = userConection.getColumnValue("CodigoPlan"),
                            Planes = userConection.getColumnValue("Planes"),
                            TipoPlan = userConection.getColumnValue("TipoPlan")
                        });
                        return planesTipos.ToList();
                    }
                    else return null;
                }
            }

            catch (Exception)
            {
                return null;
            }

        }

        public IEnumerable<NAB_CREDITO_TRASPASO> GetTraspasos(string idNegocio)
        {
            List<NAB_CREDITO_TRASPASO> traspasoResult = new List<NAB_CREDITO_TRASPASO>();

            try
            {
                //IEnumerable<NAB_CREDITO_TRASPASO> traspasoResult = ctx.NAB_CREDITO_TRASPASO.Where(x => x.IdEb == idNegocio);
                //return traspasoResult;
                Conect userConection = new Conect(currentLine);
                userConection.commandQuery = "Nab_Credito_Obtener_Traspaso";
                userConection.addParameters("eb", idNegocio);
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    traspasoResult = data.AsEnumerable().Select(m => new NAB_CREDITO_TRASPASO()
                    {

                        IdTraspaso = m.Field<int>("IdTraspaso"),
                        IdEb = m.Field<string>("IdEb"),
                        Celular = m.Field<long>("Celular"),
                        MarcaEquipo = m.Field<string>("MarcaEquipo"),
                        Imei = m.Field<long>("Imei"),
                        IdPlan = m.Field<string>("IdPlan"),
                        IdProducto = m.Field<int>("IdProducto"),
                        FechaTraspaso = m.Field<DateTime>("FechaTraspaso"),
                        UsuarioRegistro = m.Field<string>("UsuarioRegistro"),
                        IdTipoIdentidadOrigen = m.Field<int>("IdTipoIdentidadOrigen"),
                        CedOrigen = m.Field<string>("CedOrigen"),
                        NombreOrigen = m.Field<string>("NombreOrigen"),
                        CelularOrigen = m.Field<long>("CelularOrigen"),
                        IdTipoIdentidadDestino = m.Field<int>("IdTipoIdentidadDestino"),
                        CedDestino = m.Field<string>("CedDestino"),
                        NombreDestino = m.Field<string>("NombreDestino"),
                        CelularDestino = m.Field<long>("CelularDestino"),
                        Nit = m.Field<string>("Nit"),
                        CorreoNotificaciones = m.Field<string>("CorreoNotificaciones"),
                        ClausulasACargoDePersonaOrigen = m.Field<string>("ClausulasACargoDePersonaOrigen"),
                        SaldosACargoDePersonaOrigen = m.Field<string>("SaldosACargoDePersonaOrigen"),
                        Adjunto1 = m.Field<string>("Adjunto1"),
                        Adjunto2 = m.Field<string>("Adjunto2"),
                        Adjunto3 = m.Field<string>("Adjunto3"),
                        Adjunto4 = m.Field<string>("Adjunto4"),

                    }).ToList();

                }
                return traspasoResult.ToList();
            }
            catch (Exception)
            {
                return traspasoResult.ToList();
            }
        }

        public static Nab_Negocio_SP GetNegocio(string negocio)
        {
            try
            {
                //Nab_Negocio_SP result = ctx.Nab_Eb_Obtener_Negocio(negocio).FirstOrDefault();
                //return result;
                int currentLines = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Nab_Negocio_SP result = null;
                Conect userConection = new Conect(currentLines);
                //userConection.commandQuery = "Nab_Eb_Obtener_Negocio";
                userConection.commandQuery = "Nab_SP_Comercial_Obtener_Negocio";
                userConection.addParameters("eb", negocio);
                userConection.execQuery(true);

                if (userConection.numRows > 0)
                {
                    result = new Nab_Negocio_SP();
                    result.ID_EB = userConection.getColumnValue("ID_EB");
                    result.FEC_INGRESO = Convert.ToDateTime(userConection.getColumnValue("FEC_INGRESO"));
                    result.COD_VENDEDOR = Convert.ToInt32(userConection.getColumnValue("COD_VENDEDOR"));
                    result.CANAL_VENDEDOR = userConection.getColumnValue("CANAL_VENDEDOR");
                    result.NOMBRE_GRUPO = userConection.getColumnValue("NOMBRE_GRUPO");
                    result.USER_INGRESO = userConection.getColumnValue("USER_INGRESO");
                    result.CANT_LINEAS = Convert.ToInt32(userConection.getColumnValue("CANT_LINEAS"));
                    result.PEND_LINEAS = Convert.ToInt32(userConection.getColumnValue("PEND_LINEAS"));
                    result.PORTADO = Convert.ToBoolean(userConection.getColumnValue("PORTADO"));
                    result.PEDIDO = Convert.ToBoolean(userConection.getColumnValue("PEDIDO"));
                    result.ROBOT = !String.IsNullOrEmpty(userConection.getColumnValue("ROBOT")) ? Convert.ToBoolean(userConection.getColumnValue("ROBOT")) : (bool?)null;
                    result.FEC_PEDIDO = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_PEDIDO")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_PEDIDO")) : (DateTime?)null;
                    result.USER_PEDIDO = userConection.getColumnValue("USER_PEDIDO");
                    result.FEC_CIERRE_PEDIDO = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_CIERRE_PEDIDO")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_CIERRE_PEDIDO")) : (DateTime?)null;
                    result.USER_CIERRE_PEDIDO = userConection.getColumnValue("USER_CIERRE_PEDIDO");
                    result.FEC_ESTR_VENTA = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_ESTR_VENTA")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_ESTR_VENTA")) : (DateTime?)null; ;
                    result.USER_ESTR_VENTA = userConection.getColumnValue("USER_ESTR_VENTA");
                    result.FEC_CIERRE_ESTR_VENTA = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_CIERRE_ESTR_VENTA")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_CIERRE_ESTR_VENTA")) : (DateTime?)null;
                    result.USER_CIERRE_ESTR_VENTA = userConection.getColumnValue("USER_CIERRE_ESTR_VENTA");
                    result.ESTRUCTURA_VENTA = userConection.getColumnValue("ESTRUCTURA_VENTA");
                    result.FEC_DCTOS = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_DCTOS")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_DCTOS")) : (DateTime?)null;
                    result.USER_DCTOS = userConection.getColumnValue("USER_DCTOS");
                    result.FEC_CIERRE_DCTOS = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_CIERRE_DCTOS")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_CIERRE_DCTOS")) : (DateTime?)null;
                    result.USER_CIERRE_DCTOS = userConection.getColumnValue("USER_CIERRE_DCTOS");
                    result.FEC_CIERRE = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_CIERRE")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_CIERRE")) : (DateTime?)null;
                    result.USER_CIERRE = userConection.getColumnValue("USER_CIERRE");
                    result.FEC_CANCELACION = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_CANCELACION")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_CANCELACION")) : (DateTime?)null;
                    result.USER_CANCELACION = userConection.getColumnValue("USER_CANCELACION");
                    result.FEC_ULT_MOD = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_ULT_MOD")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_ULT_MOD")) : (DateTime?)null;
                    result.USER_ULT_MOD = userConection.getColumnValue("USER_ULT_MOD");
                    result.ID_ESTADO = userConection.getColumnValue("ID_ESTADO");
                    result.ID_GRUPO = !String.IsNullOrEmpty(userConection.getColumnValue("ID_GRUPO")) ? Convert.ToInt32(userConection.getColumnValue("ID_GRUPO")) : (int?)null;
                    result.ID_TIPO_CONTRATO = !String.IsNullOrEmpty(userConection.getColumnValue("ID_TIPO_CONTRATO")) ? Convert.ToDecimal(userConection.getColumnValue("ID_TIPO_CONTRATO")) : (decimal?)null;
                    result.ID_IDENTIDAD = !String.IsNullOrEmpty(userConection.getColumnValue("ID_IDENTIDAD")) ? Convert.ToByte(userConection.getColumnValue("ID_IDENTIDAD")) : (byte?)null;
                    result.IDENTIDAD = userConection.getColumnValue("IDENTIDAD");
                    result.NOMBRE_CLIENTE = userConection.getColumnValue("NOMBRE_CLIENTE");
                    result.ID_TIPO_CLIENTE = !String.IsNullOrEmpty(userConection.getColumnValue("ID_TIPO_CLIENTE")) ? Convert.ToByte(userConection.getColumnValue("ID_TIPO_CLIENTE")) : (byte?)null;
                    result.ID_TIPO_SERVICIO = !String.IsNullOrEmpty(userConection.getColumnValue("ID_TIPO_SERVICIO")) ? Convert.ToByte(userConection.getColumnValue("ID_TIPO_SERVICIO")) : (byte?)null;
                    result.ID_TIPO_SOLICITUD = !String.IsNullOrEmpty(userConection.getColumnValue("ID_TIPO_SOLICITUD")) ? Convert.ToByte(userConection.getColumnValue("ID_TIPO_SOLICITUD")) : (byte?)null;
                    result.FECHA_CIERRE_CREDITO = !String.IsNullOrEmpty(userConection.getColumnValue("FECHA_CIERRE_CREDITO")) ? Convert.ToDateTime(userConection.getColumnValue("FECHA_CIERRE_CREDITO")) : (DateTime?)null;
                    result.ID_CONVENIO = !String.IsNullOrEmpty(userConection.getColumnValue("ID_CONVENIO")) ? Convert.ToInt32(userConection.getColumnValue("ID_CONVENIO")) : (int?)null;
                    result.REP_LEGAL_IDENTIDAD = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_IDENTIDAD")) ? Convert.ToInt32(userConection.getColumnValue("REP_LEGAL_IDENTIDAD")) : (int?)null;
                    result.REP_LEGAL_NOMBRE = userConection.getColumnValue("REP_LEGAL_NOMBRE");
                    result.REP_LEGAL_APELLIDO1 = userConection.getColumnValue("REP_LEGAL_APELLIDO1");
                    result.REP_LEGAL_APELLIDO2 = userConection.getColumnValue("REP_LEGAL_APELLIDO2");
                    result.REP_LEGAL_FIJO = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_FIJO")) ? Convert.ToInt32(userConection.getColumnValue("REP_LEGAL_FIJO")) : (int?)null;
                    result.REP_LEGAL_CELULAR = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_CELULAR")) ? Convert.ToInt64(userConection.getColumnValue("REP_LEGAL_CELULAR")) : (long?)null;
                    result.REP_LEGAL_FECNACIMIENTO = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_FECNACIMIENTO")) ? Convert.ToDateTime(userConection.getColumnValue("REP_LEGAL_FECNACIMIENTO")) : (DateTime?)null;
                    result.REP_LEGAL_SUP_IDENTIDAD = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_SUP_IDENTIDAD")) ? Convert.ToInt64(userConection.getColumnValue("REP_LEGAL_SUP_IDENTIDAD")) : (long?)null;
                    result.REP_LEGAL_SUP_NOMBRE = userConection.getColumnValue("REP_LEGAL_SUP_NOMBRE");
                    result.REP_LEGAL_SUP_APELLIDO1 = userConection.getColumnValue("REP_LEGAL_SUP_APELLIDO1");
                    result.REP_LEGAL_SUP_APELLIDO2 = userConection.getColumnValue("REP_LEGAL_SUP_APELLIDO2");
                    result.REP_LEGAL_SUP_FIJO = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_SUP_FIJO")) ? Convert.ToInt32(userConection.getColumnValue("REP_LEGAL_SUP_FIJO")) : (int?)null;
                    result.REP_LEGAL_SUP_CELULAR = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_SUP_CELULAR")) ? Convert.ToInt64(userConection.getColumnValue("REP_LEGAL_SUP_CELULAR")) : (long?)null;
                    result.REP_LEGAL_SUP_FECNACIMIENTO = !String.IsNullOrEmpty(userConection.getColumnValue("REP_LEGAL_SUP_FECNACIMIENTO")) ? Convert.ToDateTime(userConection.getColumnValue("REP_LEGAL_SUP_FECNACIMIENTO")) : (DateTime?)null;
                    result.COD_DISTRITO = !String.IsNullOrEmpty(userConection.getColumnValue("COD_DISTRITO")) ? Convert.ToInt32(userConection.getColumnValue("COD_DISTRITO")) : (int?)null;
                    result.COD_BARRIO = !String.IsNullOrEmpty(userConection.getColumnValue("COD_BARRIO")) ? Convert.ToInt32(userConection.getColumnValue("COD_BARRIO")) : (int?)null;
                    result.COD_TIPO_CALLE = userConection.getColumnValue("COD_TIPO_CALLE");
                    result.DIRECCION = userConection.getColumnValue("DIRECCION");
                    result.COMPLEMENTO = userConection.getColumnValue("COMPLEMENTO");
                    result.COD_DANE = userConection.getColumnValue("COD_DANE");
                    result.ID_CONTRATO_MARCO = !String.IsNullOrEmpty(userConection.getColumnValue("ID_CONTRATO_MARCO")) ? Convert.ToInt64(userConection.getColumnValue("ID_CONTRATO_MARCO")) : (long?)null;
                    result.FEC_VENTANA = !String.IsNullOrEmpty(userConection.getColumnValue("FEC_VENTANA")) ? Convert.ToDateTime(userConection.getColumnValue("FEC_VENTANA")) : (DateTime?)null;
                    result.ID_TIPO_CAMBIO_PLAN = !String.IsNullOrEmpty(userConection.getColumnValue("ID_TIPO_CAMBIO_PLAN")) ? Convert.ToInt16(userConection.getColumnValue("ID_TIPO_CAMBIO_PLAN")) : (short?)null;
                    result.TELEFONO_CLIENTE = userConection.getColumnValue("TELEFONO_CLIENTE");
                    result.OBSERVACIONES = userConection.getColumnValue("OBSERVACIONES");
                    result.TIPO_VENTA = userConection.getColumnValue("TIPO_VENTA");
                    result.TIPO_DOCUMENTO = userConection.getColumnValue("TIPO_DOCUMENTO");
                    result.EMAIL_CLIENTE = userConection.getColumnValue("EMAIL_CLIENTE");
                    return result;
                }
                else return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Obtener los planes 
        /// </summary>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public IEnumerable<NAB_VENTAS_PLAN_ADQUIRIDO> ObtenerPlanesNegocio(string negocio)
        {
            List<NAB_VENTAS_PLAN_ADQUIRIDO> planesResult = new List<NAB_VENTAS_PLAN_ADQUIRIDO>();
            try
            {
                //IEnumerable<NAB_VENTAS_PLAN_ADQUIRIDO> planesResult = ctx.NAB_VENTAS_PLAN_ADQUIRIDO.Where(x => x.ID_CODIGO_NEGOCIO == negocio);
                //return planesResult;

                Conect userConection = new Conect(currentLine);
                //userConection.commandQuery = "Nab_Obtener_Planes_Negocio";
                //userConection.addParameters("eb", negocio);
                userConection.commandQuery = "Nab_SP_Comercial_Planes_Negocio_Obtener";
                userConection.addParameters("id_eb", negocio);
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    planesResult = data.AsEnumerable().Select(m => new NAB_VENTAS_PLAN_ADQUIRIDO()
                    {
                        ID_PLAN_TARIFARIO = m.Field<string>("ID_PLAN_TARIFARIO"),
                        CANTIDAD_LINEAS = m.Field<int>("CANTIDAD_LINEAS")
                    }).ToList();

                }

                return planesResult.ToList();
            }
            catch (Exception)
            {
                return planesResult.ToList();
            }
        }

        /// <summary>
        /// Obtener lineas Portados
        /// </summary>
        /// <param name="usuario"></param>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static IEnumerable<NAB_LINEAS_PORTADAS> ObtenerLineasPortadas(string usuario, string negocio)
        {
            List<NAB_LINEAS_PORTADAS> lineasResult = new List<NAB_LINEAS_PORTADAS>();

            try
            {

                DataTable data = LineaPortadaRepository.RetornarLineasPortadas(usuario, negocio, "Resumen");

                if (data.Rows.Count > 0)
                {
                    lineasResult = data.AsEnumerable().Select(m => new NAB_LINEAS_PORTADAS()
                    {
                        Negocio = m.Field<string>("ID_EB"),
                        //Celular = m.Field<string>("CELULAR"),
                        Operador = m.Field<string>("OPERADOR"),
                        //PlanOrigen = m.Field<string>("PLAN_ORIGEN"),
                        //PlanDestino = m.Field<string>("PLAN_DESTINA"),
                        Traspaso = m.Field<bool?>("TRASPASO"),
                        TipoIdentOrigen = m.Field<string>("TIPO_IDENT_ORIGEN"),
                        NumIdentOrigen = m.Field<string>("NUM_IDENT_ORIGEN"),
                        NombreClienteOrigen = m.Field<string>("NOMBRE_CLIENTE_ORIGEN"),
                        ApellidoClienteOrigen = m.Field<string>("APELLIDO_CLIENTE_ORIGEN"),
                        CantLineas = m.Field<int>("CANT_LINEAS").ToString()
                        ,CodPlan = m.Field<string>("COD_PLAN")
                        ,RefEquipo = m.Field<string>("REF_EQUIPO")
                    }).ToList();
                }

                return lineasResult.ToList();
            }
            catch (Exception)
            {
                return lineasResult.ToList();
            }
        }


        /// <summary>
        /// Obtiene la informacion de lineas portadas
        /// </summary>
        /// <param name="usuario"></param>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static IEnumerable<NAB_LINEAS_PORTADAS> ObtenerLineasPortadasDetalle(string usuario, string negocio)
        {
            List<NAB_LINEAS_PORTADAS> lineasResult = new List<NAB_LINEAS_PORTADAS>();

            try
            {
                DataTable data = LineaPortadaRepository.RetornarLineasPortadas(usuario, negocio, "Detalle");

                if (data.Rows.Count > 0)
                {
                    lineasResult = data.AsEnumerable().Select(m => new NAB_LINEAS_PORTADAS()
                    {
                        Negocio = m.Field<string>("ID_EB")
                        ,
                        Celular = m.Field<Int64>("CELULAR").ToString()
                        ,
                        Operador = m.Field<string>("OPERADOR")
                        ,
                        PlanOrigen = m.Field<string>("PLAN_ORIGEN")
                        ,
                        PlanDestino = m.Field<string>("PLAN_DESTINO")
                        ,
                        Traspaso = m.Field<bool?>("TRASPASO")
                        ,
                        TipoIdentOrigen = m.Field<string>("TIPO_IDENT_ORIGEN")
                        ,
                        NumIdentOrigen = m.Field<string>("NUM_IDENT_ORIGEN")
                        ,
                        NombreClienteOrigen = m.Field<string>("NOMBRE_CLIENTE_ORIGEN")
                        ,
                        ApellidoClienteOrigen = m.Field<string>("APELLIDO_CLIENTE_ORIGEN")
                        ,
                        CodPlan = m.Field<string>("COD_PLAN")
                        ,
                        RefEquipo = m.Field<string>("REF_EQUIPO")
                    }).ToList();
                }

                return lineasResult.ToList();
            }
            catch (Exception)
            {
                return lineasResult.ToList();
            }
        }

        /// <summary>
        /// Obtiene la informacion de lineas portadas
        /// </summary>
        /// <param name="usuario"></param>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static IEnumerable<NAB_LINEAS_PORTADAS> ObtenerLineasPortadasDetalle(string usuario, string negocio, string identidadOrigen)
        {
            List<NAB_LINEAS_PORTADAS> lineasResult = new List<NAB_LINEAS_PORTADAS>();

            try
            {

                DataTable data = LineaPortadaRepository.RetornarLineasPortadas(usuario, negocio, "Agrupado", identidadOrigen);

                if (data.Rows.Count > 0)
                {
                    lineasResult = data.AsEnumerable().Select(m => new NAB_LINEAS_PORTADAS()
                    {
                        Negocio = m.Field<string>("ID_EB")
                        ,Celular = m.Field<Int64>("CELULAR").ToString()
                        ,Operador = m.Field<string>("OPERADOR")
                        ,PlanOrigen = m.Field<string>("PLAN_ORIGEN")
                        ,PlanDestino = m.Field<string>("PLAN_DESTINO")
                        ,Traspaso = m.Field<bool?>("TRASPASO")
                        ,TipoIdentOrigen = m.Field<string>("TIPO_IDENT_ORIGEN")
                        ,NumIdentOrigen = m.Field<string>("NUM_IDENT_ORIGEN")
                        ,NombreClienteOrigen = m.Field<string>("NOMBRE_CLIENTE_ORIGEN")
                        ,ApellidoClienteOrigen = m.Field<string>("APELLIDO_CLIENTE_ORIGEN")
                        ,CodPlan = m.Field<string>("COD_PLAN")
                        ,RefEquipo = m.Field<string>("REF_EQUIPO")
                    }).ToList();
                }

                return lineasResult.ToList();
            }
            catch (Exception)
            {
                return lineasResult.ToList();
            }
        }

        public static string ObtenerRegionalNegocio(string negocio)
        {
            try
            {
                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect regional = new Conect(currentLine);
                regional.commandQuery = String.Format("SELECT MesaRegional AS REGIONAL FROM CCC.dbo.BC_MesaControl WHERE MesaConsPref='{0}'", negocio);
                regional.execQuery(false);
                return regional.getColumnValue("REGIONAL");
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static int ObtenerTipoContrato(string id_eb)
        {
            string NombreTipoContrato = string.Empty;
            int TipoContrato = 0;
            if (!string.IsNullOrWhiteSpace(id_eb))
            {
                Conect transac = new Conect(0);
                transac.commandQuery = "Nab_SP_Comercial_GetList";
                transac.addParameters("user", HttpContext.Current.User.Identity.Name);
                transac.addParameters("vista", "TipoContrato_X_Negocio");
                transac.addParameters("parametros", id_eb);
                transac.execTransac(true);
                if (transac.numRows > 0)
                {
                    TipoContrato = int.Parse(transac.getColumnValue("TIPO"));
                    NombreTipoContrato = transac.getColumnValue("NOMBRE_CONTRATO");
                    return TipoContrato;
                }
                else
                {
                    return 0;
                }
            }
            return 0;
        }

        public static int ObtenerCantidadDeLineasNegocio(string IdEb, string Producto)
        {
            try
            {
                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect lineas = new Conect(currentLine);
                lineas.commandQuery = "Nab_SP_Negocios_Lineas_QX_Producto";
                lineas.addParameters("id_eb", IdEb);
                lineas.addParameters("producto", Producto);
                lineas.execQuery(true);
                if (lineas.getColumnValue("CANTIDAD") != null)
                {
                    return Convert.ToInt32(lineas.getColumnValue("CANTIDAD"));
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception)
            {
                return 0;
            }
        }

        public static string ObtenerCiudad(string codDistrito, string userId)
        {
            string ciudad = string.Empty;
            try
            {
                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect lista = new Conect(currentLine);
                //lista.commandQuery = "Nab_EB_Comercial_GetList";
                //lista.addParameters("vista", "distritosEstrVenta");                
                lista.commandQuery = "Nab_SP_Comercial_GetList";
                lista.addParameters("user", userId);
                lista.addParameters("vista", "CiudadXId"); 
                lista.addParameters("parametros", codDistrito);
                lista.execQuery(true);
                List<ListItem> ciudades = lista.getListItems().ToList();
                ciudad = ciudades.Where(ciu => ciu.Value == codDistrito).Select(t => t.Text).FirstOrDefault();
            }
            catch
            {
                ciudad = string.Empty;
            }
            return ciudad;
        }
        #endregion
    }
}
