﻿using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    public class UsuariosRepository
    {
        public static string GetRol(string nh)
        {
            try
            {
                //string rol = ctx.Nab_Obtener_Rol(userId).FirstOrDefault();
                //return rol;
                try
                {
                    Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                    userConection.addParameters("nh", nh);
                    userConection.commandQuery = "Nab_Obtener_Rol";
                    userConection.execQuery(true);
                    string result = userConection.getColumnValue("ROLES");
                    return result.Replace(",", "");
                }
                catch (Exception)
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static List<USERS_PROCESOS> GetUsuariosProcesos()
        {
            try
            {
                //List<USERS_PROCESOS> usuariosProcesos = ctx.USERS_PROCESOS.ToList();
                //return usuariosProcesos;
                List<USERS_PROCESOS> usuariosProcesos = null;
                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                userConection.commandQuery = "Nab_Obtener_Procesos_Usuario";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    usuariosProcesos = data.AsEnumerable().Select(m => new USERS_PROCESOS()
                    {
                        ID_PROCESO = m.Field<int>("ID_PROCESO"),
                        PROCESO = m.Field<string>("PROCESO"),
                    }).ToList();
                    return usuariosProcesos;
                }
                else return null;

            }
            catch (Exception)
            {
                return null;
            }
        }

        public static List<NAB_GLOBAL_USER_PROCESOS_MODULOS> GetProcesoModulo(int modulo)
        {
            try
            {
                //List<NAB_GLOBAL_USER_PROCESOS_MODULOS> procesos = ctx.NAB_GLOBAL_USER_PROCESOS_MODULOS.Where(x => x.ID_MODULO == modulo).ToList();
                //return procesos;
                List<NAB_GLOBAL_USER_PROCESOS_MODULOS> procesos = null;
                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                userConection.addParameters("modulo", modulo);
                userConection.commandQuery = "Nab_Obtener_Procesos_Modulos_Usuario";
                DataTable data = userConection.getDataTable(true);

                if (data.Rows.Count > 0)
                {
                    procesos = data.AsEnumerable().Select(m => new NAB_GLOBAL_USER_PROCESOS_MODULOS()
                    {
                        ID_MODULO = m.Field<int>("ID_MODULO"),
                        ID_PROCESO = m.Field<int>("ID_PROCESO"),
                    }).ToList();
                    return procesos;
                }
                else return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static void InsertarUsuario(USERS usuario)
        {
            try
            {
                //NABISEntities ctx = new NABISEntities();
                //ctx.Nab_Usuario_Insertar(
                //      usuario.USR_ID  ,
                //    usuario.CC,
                //    usuario.USR_LOGIN,
                //    usuario.USR_NOMBRE,
                //    usuario.USR_PASSW,
                //    usuario.USR_MAIL,
                //    usuario.ID_REGIONAL,
                //    usuario.ID_AREA,
                //    usuario.ID_GRUPO,
                //    usuario.ID_PROCESO,
                //    usuario.ID_TIPO,
                //    usuario.USR_EQUIPO,
                //    usuario.USR_IP,
                //    usuario.USR_CELULAR.ToString(),
                //    usuario.USR_EXT.ToString(),
                //    usuario.ID_PERFIL,
                //    usuario.COD_VEND,
                //    usuario.ID_CANAL,
                //    usuario.COD_AGENTE
                //    );

                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());

                userConection.commandQuery = "Nab_Usuario_Insertar";
                userConection.addParameters("nh", usuario.USR_ID);
                userConection.addParameters("cc", usuario.CC);
                userConection.addParameters("login", usuario.USR_LOGIN);
                userConection.addParameters("nombre", usuario.USR_NOMBRE);
                userConection.addParameters("pass", usuario.USR_PASSW);
                userConection.addParameters("mail", usuario.USR_MAIL);
                userConection.addParameters("reg", usuario.ID_REGIONAL);
                userConection.addParameters("area", usuario.ID_AREA);
                userConection.addParameters("grupo", usuario.ID_GRUPO);
                userConection.addParameters("proceso", usuario.ID_PROCESO);
                userConection.addParameters("tipo", usuario.ID_TIPO);
                userConection.addParameters("equipo", usuario.USR_EQUIPO);
                userConection.addParameters("ip", usuario.USR_IP);
                userConection.addParameters("cel", usuario.USR_CELULAR.ToString());
                userConection.addParameters("ext", usuario.USR_EXT.ToString());
                userConection.addParameters("perfil", usuario.ID_PERFIL);
                userConection.addParameters("cod", usuario.COD_VEND);
                userConection.addParameters("canal", usuario.ID_CANAL);
                userConection.addParameters("agente", usuario.COD_AGENTE);
                userConection.execQuery(true);

            }
            catch (Exception)
            {
                throw;
            }
        }

        public static string ObtenerModulo(string nh)
        {
            try
            {
                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                userConection.addParameters("nh", nh);
                userConection.commandQuery = "Nab_Obtener_Modulo";
                userConection.execQuery(true);
                return userConection.getColumnValue("MODULO");
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static void DesbloqueLogin(string nh, string pass)
        {
            Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
            userConection.addParameters("nh", nh);
            userConection.addParameters("pass", pass);
            userConection.commandQuery = "Nab_Usuario_DesbloqueoLogin";
            userConection.execQuery(true);
        }

        public static void CambiarEstado(string nh, Nullable<int> estado)
        {
            Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
            userConection.addParameters("nh", nh);
            userConection.addParameters("estado", estado);
            userConection.commandQuery = "Nab_Usuario_Estado";
            userConection.execQuery(true);
        }

        public static bool ActualizarUsuario(string nh, string mail, Nullable<int> perfil)
        {
            try
            {
                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                userConection.addParameters("nh", nh);
                userConection.addParameters("mail", mail);
                userConection.addParameters("perfil", perfil);
                userConection.commandQuery = "Nab_Usuario_UpdateEmail";
                userConection.execQuery(true);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static bool ActualizarContrasena(string nh, string pass, string passnew)
        {
            try
            {
                Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
                userConection.addParameters("user", nh);
                userConection.addParameters("current_pass", pass);
                userConection.addParameters("new_pass", passnew);
                userConection.commandQuery = "Nab_SP_Users_Password_Update";
                userConection.execTransac(true);
                return userConection.numRows > 0;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public static NAB_AGENTES ObtenerNombreAgente(int codigo, string canal, string usrLogin)
        {
            NAB_AGENTES agente = new NAB_AGENTES();
            Conect userConection = new Conect(new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber());
            userConection.addParameters("cod_vend", codigo);
            userConection.addParameters("canal", canal);
            userConection.addParameters("usrLogin", usrLogin);
            userConection.commandQuery = "Nab_Consulta_Vendedor";
            userConection.execQuery(true);
            if (userConection.numRows > 0)
            {
                agente.NombreAgente = userConection.getColumnValue("AGENTE");
                agente.NombreVendedor = userConection.getColumnValue("NOMBRE_VENDEDOR");
                return agente;
            }
            else
            {
                return null;
            }



        }
    }
}