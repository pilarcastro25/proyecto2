﻿using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    /// <summary>
    /// Repositorio de vendedor.
    /// </summary>
    public class NabGlobalVendedoresRepository
    {
        /// <summary>
        /// Procedimiento almacenado para visualizar la informacion asociada a un vendedor.
        /// </summary>
        private const string NAB_GLOBAL_OBTENER_INFORMACION_VENDEDOR = "Nab_Global_Obtener_Informacion_Vendedor";

        /// <summary>
        /// Obtener informacion almacenada de vendedor
        /// </summary>
        /// <param name="codigoVendedor">Codigo Vendedor</param>
        /// <returns></returns>
        protected DataTable ObtenerVendedor(string codigoVendedor)
        {
            var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect vendedor = new Conect(currentLine);
            vendedor.commandQuery = NAB_GLOBAL_OBTENER_INFORMACION_VENDEDOR;
            vendedor.addParameters("COD_VENDEDOR", codigoVendedor);
            return vendedor.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion de vendedor
        /// </summary>
        /// <param name="codigoVendedor">Codigo Vendedor</param>
        /// <returns></returns>
        public NAB_GLOBAL_VENDEDORES ObtenerVendedorInfo(string codigoVendedor)
        {
            NAB_GLOBAL_VENDEDORES vendedor = new NAB_GLOBAL_VENDEDORES();
            try
            {
                var entities = this.ObtenerVendedor(codigoVendedor);
                if (entities == null)
                {
                    throw new Exception();
                }
                else if (entities.Rows.Count > 0)
                {
                    DataRow dr = entities.Rows[0];
                    vendedor = new NAB_GLOBAL_VENDEDORES(dr);
                }
            }
            catch (Exception exc)
            {
                vendedor = new NAB_GLOBAL_VENDEDORES(); ;
            }
            return vendedor;
        }
    }
}