﻿using Nabis_ET.Activaciones;
using Nabis.App_GlobalCode;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace Nabis.Repository
{
    public class BeneficiosRepository
    {
        #region Constantes
        /// <summary>
        /// Nombre SP de la bandeja del analista
        /// </summary>
        private const string BANDEJA_ANALISTA = "Nab_SP_Activaciones_Beneficios_Bandeja_Analista";

        /// <summary>
        /// Nombre SP de consulta de beneficios
        /// </summary>
        private const string CONSULTA_BENEFICIOS = "Nab_SP_Activaciones_Beneficios_Consulta";

        /// <summary>
        /// Nombre SP de consulta de conceptos
        /// </summary>
        private const string CONSULTA_CONCEPTOS = "Nab_SP_Activaciones_Beneficios_Concepto";

        /// <summary>
        /// Nombre SP de insertar nuevos beneficios
        /// </summary>
        private const string INSERTAR_BENEFICIOS = "Nab_SP_Activaciones_Beneficios_Insertar";

        /// <summary>
        /// Nombre SP de insertar nuevos beneficios
        /// </summary>
        private const string ACTUALIZAR_BENEFICIOS = "Nab_SP_Activaciones_Beneficios_Actualizar";

        /// <summary>
        /// Nombre SP de elmiinar beneficios
        /// </summary>
        private const string ELIMINAR_BENEFICIOS = "Nab_SP_Activaciones_Beneficios_Eliminar";
        #endregion
        #region Métodos públicos
        /// <summary>
        /// Bandeja del analista
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static DataTable ObtenerNegociosUsuario(string usuario)
        {
            DataTable negocios = new DataTable();
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = BANDEJA_ANALISTA;
                conexion.addParameters("id_user", usuario);
                negocios = conexion.getDataTable(true);
                return negocios;
            }
            catch (Exception)
            {
                return negocios;
            }
        }
        /// <summary>
        /// Obtener beneficios
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<Beneficio> ObtenerBeneficios()
        {
            DataTable beneficiosTabla = new DataTable();
            IEnumerable<Beneficio> beneficios = new List<Beneficio>();
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = CONSULTA_BENEFICIOS;
                beneficiosTabla = conexion.getDataTable(true);
                if (beneficiosTabla.Rows.Count > 0)
                {
                    beneficios = beneficiosTabla.AsEnumerable().Select(x => new Beneficio
                    {
                        CODIGO = x.Field<string>("CODIGO"),
                        LATENCIA = x.Field<int>("LATENCIA"),
                        CONCEPTO = x.Field<string>("CONCEPTO"),
                        DESCRIPCION = x.Field<string>("DESCRIPCION")
                    }).ToList();
                }
                return beneficios;
            }
            catch (Exception)
            {
                return beneficios;
            }

        }
        /// <summary>
        /// Obtener conceptos de los beneficios
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<ListItem> ObtenerConceptos()
        {
            IEnumerable<ListItem> conceptos = new List<ListItem>();
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = CONSULTA_CONCEPTOS;
                DataTable datos = conexion.getDataTable(true);
                if (datos.Rows.Count > 0)
                {
                    conceptos = datos.AsEnumerable().Select(x => new ListItem
                    {
                        Value = (x.Field<int>("ID_RELACION")).ToString(),
                        Text = x.Field<string>("RELACION")
                    });
                }
                return conceptos;
            }
            catch (Exception)
            {
                return conceptos;
            }
        }
        /// <summary>
        /// Insertar nuevo beneficio
        /// </summary>
        /// <param name="beneficios"></param>
        /// <returns></returns>
        public static bool InsertarBeneficio(string usuarioLogin, Beneficio beneficios)
        {
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = INSERTAR_BENEFICIOS;
                conexion.addParameters("user_login", usuarioLogin);
                conexion.addParameters("cod_beneficios", beneficios.CODIGO);
                conexion.addParameters("descripcion", beneficios.DESCRIPCION);
                conexion.addParameters("latencia", beneficios.LATENCIA);
                conexion.addParameters("id_concepto", beneficios.CONCEPTO);
                conexion.execQuery(true);
                return true;
            }
            catch (Exception)
            {
                return false;
            }


        }
        /// <summary>
        /// Actualizar Beneficio
        /// </summary>
        /// <param name="usuario"></param>
        /// <param name="beneficio"></param>
        /// <returns></returns>
        public static bool ActualizarBeneficio(string usuario, Beneficio beneficio)
        {
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = ACTUALIZAR_BENEFICIOS;
                conexion.addParameters("user_login", usuario);
                conexion.addParameters("cod_beneficios", beneficio.CODIGO);
                conexion.addParameters("descripcion", beneficio.DESCRIPCION);
                conexion.addParameters("latencia", beneficio.LATENCIA);
                conexion.addParameters("id_concepto", beneficio.CONCEPTO);
                conexion.execQuery(true);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// Eliminar Beneficio
        /// </summary>
        /// <param name="usuario"></param>
        /// <param name="beneficio"></param>
        /// <returns></returns>
        public static bool EliminarBeneficio(string usuario, string beneficio)
        {
            try
            {
                Conect conexion = new Conect(0);
                conexion.commandQuery = ELIMINAR_BENEFICIOS;
                conexion.addParameters("user_login", usuario);
                conexion.addParameters("cod_beneficio", beneficio);
                conexion.execQuery(true);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        #endregion
    }
}
