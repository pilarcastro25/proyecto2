﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.Models.Entities;
using Nabis.App_GlobalCode;
using System.Data;
using Nabis_ET.Comercial;

namespace Nabis.Repository
{
    public class TraspasoRepository
    {
        public static Boolean InsertarTraspaso(NAB_CREDITO_TRASPASO traspasoInsert)
        {
            try
            {
                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect userConection = new Conect(currentLine);
                userConection.commandQuery = "Nab_Eb_Insertar_Traspaso";
                userConection.addParameters("idEb", traspasoInsert.IdEb);
                userConection.addParameters("celular", traspasoInsert.Celular);
                userConection.addParameters("imei", traspasoInsert.Imei);
                userConection.addParameters("idPlan", traspasoInsert.IdPlan);
                userConection.addParameters("idProducto", traspasoInsert.IdProducto);
                userConection.addParameters("marcaEquipo", traspasoInsert.MarcaEquipo);
                userConection.addParameters("usuarioRegistro", traspasoInsert.UsuarioRegistro);
                userConection.addParameters("idTipoIdentidadOrigen", traspasoInsert.IdTipoIdentidadOrigen);
                userConection.addParameters("cedOrigen", traspasoInsert.CedOrigen);
                userConection.addParameters("nombreOrigen", traspasoInsert.NombreOrigen);
                userConection.addParameters("celularOrigen", traspasoInsert.CelularOrigen);
                userConection.addParameters("idTipoIdentidadDestino", traspasoInsert.IdTipoIdentidadDestino);
                userConection.addParameters("cedDestino", traspasoInsert.CedDestino);
                userConection.addParameters("nombreDestino", traspasoInsert.NombreDestino);
                userConection.addParameters("celularDestino", traspasoInsert.CelularDestino);
                userConection.addParameters("nit", traspasoInsert.Nit);
                userConection.addParameters("correo", traspasoInsert.CorreoNotificaciones);
                userConection.addParameters("clausulas", traspasoInsert.ClausulasACargoDePersonaOrigen);
                userConection.addParameters("saldosEnContra", traspasoInsert.SaldosACargoDePersonaOrigen);
                userConection.addParameters("adjunto1", traspasoInsert.Adjunto1);
                userConection.addParameters("adjunto2", traspasoInsert.Adjunto2);
                userConection.addParameters("adjunto3", traspasoInsert.Adjunto3);
                userConection.addParameters("adjunto4", traspasoInsert.Adjunto4);

                userConection.execQuery(true);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static PersonaJuridicaObj ObtenerPersonaJuridica(string negocio)
        {
            try
            {
                PersonaJuridicaObj persona = new PersonaJuridicaObj();
                Nab_Negocio_SP result = MappingRepository.GetNegocio(negocio);
                persona.NombreCompleto = String.Format("{0} {1} {2}", result.REP_LEGAL_NOMBRE, result.REP_LEGAL_SUP_APELLIDO1, result.REP_LEGAL_SUP_APELLIDO2);
                persona.CelContactoReferenciaComercial1 = result.REP_LEGAL_CELULAR.ToString();
                persona.NumeroIdentificacionRepresentanteLegal = result.REP_LEGAL_IDENTIDAD.ToString();
                persona.NumeroIdentificacion = result.IDENTIDAD;
                return persona;
            }
            catch (Exception)
            {
                return null;
            }
        }
        public static NAB_CREDITO_TRASPASO ObtenerTraspaso(string imei = null, string celular = null)
        {
            try
            {
                //NAB_CREDITO_TRASPASO traspasoResult = ctx.NAB_CREDITO_TRASPASO.FirstOrDefault(x => x.Celular == celular);
                //return traspasoResult;

                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                NAB_CREDITO_TRASPASO traspasoResult = null;
                Conect userConection = new Conect(currentLine);
                userConection.commandQuery = "Nab_Obtener_Traspaso_Imei_Celular";
                userConection.addParameters("imei", imei);
                userConection.addParameters("celular", celular);
                userConection.execQuery(true);

                if (userConection.numRows > 0)
                {
                    traspasoResult = new NAB_CREDITO_TRASPASO();
                    traspasoResult.IdTraspaso = Convert.ToInt32(userConection.getColumnValue("IdTraspaso"));
                    traspasoResult.IdEb = userConection.getColumnValue("IdEb").ToString();
                    traspasoResult.IdPlan = userConection.getColumnValue("IdPlan").ToString();
                    return traspasoResult;
                }
                else return null;

            }
            catch (Exception)
            {
                return null;
            }
        }
        public static Boolean ValidarImeis(List<string> imeis)
        {
            try
            {
                bool bandera = true;
                long result;
                imeis.ForEach(x =>
                {
                    if (x.Length != 15 || !Int64.TryParse(x, out result))
                    {
                        bandera = false;
                    }
                });
                return bandera;
            }
            catch (Exception)
            {
                throw new Exception("Error en la validación de IMEIS");
            }

        }
        public static Boolean ValidarCelulares(List<string> celulares)
        {
            try
            {
                bool bandera = true;
                long result;
                celulares.ForEach(x =>
                {
                    if (x.Length != 10 || !Int64.TryParse(x, out result))
                    {
                        bandera = false;
                    }
                });
                return bandera;
            }
            catch (Exception)
            {
                throw new Exception("Error en la validación de IMEIS");
            }

        }
    }
}