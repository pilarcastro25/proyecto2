﻿// ===================================================================================================
// Desarrollado Por		    :   Harold Caicedo.
// Fecha de Creación		:   2016/09/05.
// ===================================================================================================
// Versión	        Descripción
// 1.0.0.0	        Clase fachada que permite la conexion a la base de datos para la entidad
//                  que almacena negocios.
//             
// ===================================================================================================
// HISTORIAL DE CAMBIOS:
// ===================================================================================================
// Ver.	 Fecha		    Autor					Descripción
// ---	 -------------	----------------------	------------------------------------------------------
// XX	 yyyy/MM/dd	    [Nombre Completo]	    [Razón del cambio realizado] 
// ===================================================================================================

using Nabi.Common.Utils;
using Nabis.App_GlobalCode;
using Nabis.Models;
using Nabis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSComercial;
using Nabis_BS.BComercial;
using Nabis_ET.Comercial;
using System.Web;
//using Nabis_ET.Comercial;
namespace Nabis.Repository
{
    /// <summary>
    /// Clase fachada que permite la conexion a la base de datos para la entidad
    /// que almacena negocios.
    /// </summary>
    public class RadicacionNegocioRepository
    {
        #region Constantes
        /// <summary>
        /// Nombre de procedimiento almancenado para obtener los negocios erradicados en el sistema
        /// </summary>
        private const string NAB_EB_COMERCIALCONSULTA_NEGOCIOS = "Nab_SP_Comercial_Consulta_Negocios";
        /// <summary>
        /// Nombre de procedimiento almacenado para crear consecutivo de negocios en la base de datos de
        /// NABIS.
        /// </summary>
        private const string NAB_CONSECUTIVO_NEGOCIO = "Nab_SP_Comercial_Crear_Consecutivo_Negocios";
        /// <summary>
        /// Nombre de procedimiento consulta negocios atados en
        /// NABIS.
        /// </summary>
        private const string NAB_NEGOCIOS_ATADOS = "Nab_SP_Comercial_Obtener_Negocios_Atados";
        /// <summary>
        /// Nombre de procedimiento almacenado para lamacenar negocios en la base de datos de
        /// NABIS.
        /// </summary>
        //private const string NAB_EB_RAD_NEGOCIO = "Nab_Eb_radNegocio_Pymes";
        private const string NAB_EB_RAD_NEGOCIO = "Nab_SP_Comercial_Radicar_Negocio_Pymes";
        /// <summary>
        /// Nombre de procedimiento almacenado para almacenar los planes adquiridos asociados a un negocio
        /// </summary>
        private const string NAB_VENTA_PLAN_ADQUIRIDOS = "Nab_SP_Comercial_Negocios_PlanesAdquiridos";
        /// <summary>
        /// Nombre de procedimiento almancenado para almacenar los planes adquiridos asociados un negocio.
        /// </summary>
        private const string NAB_VENTA_ELIMINAR_PLAN_ADQUIRIDOS = "Nab_SP_Negocio_Plan_Adquirido_Eliminar";
        /// <summary>
        /// Nombre de procedimiento almancenado para obtener los usuarios autorizados por codigo de contrato.
        /// </summary>
        //private const string NAB_VENTA_OBTENER_USUARIO_AUTORIZADOS = "Nab_Venta_Obtener_Usuario_Autorizados";
        private const string NAB_VENTA_OBTENER_USUARIO_AUTORIZADOS = "Nab_SP_Comercial_Obtener_Usuario_Autorizados";
        /// <summary>
        /// Nombre de procedimiento almacenado para almacenar los usuarios autorizados a un negocio.
        /// </summary>
        //private const string NAB_VENTAS_USUARIO_AUTORIZADO_PERFIL = "Nab_Ventas_Usuario_Autorizados";
        private const string NAB_VENTAS_USUARIO_AUTORIZADO_PERFIL = "Nab_SP_Comercial_Usuario_Autorizados_Insert";
        /// <summary>
        /// Nombre de procedimiento almacenado para obtener la informacion adicional de un negocio.
        /// </summary>
        //private const string NAB_VENTA_OBTENER_INFORMACION_ADICIONAL = "Nab_Venta_Obtener_Informacion_Adicional";
        private const string NAB_VENTA_OBTENER_INFORMACION_ADICIONAL = "Nab_SP_Comercial_Obtener_Informacion_Adicional";
        /// <summary>
        /// Procedimiento almacenado para guardar la informacion adicional asociado a un negocio.
        /// </summary>
        private const string NAB_VENTAS_RADICACION_INFORMACION_ADICIONAL = "Nab_SP_Comercial_Informacion_Adicional_Insertar";
        /// <summary>
        /// Procedimiento almacenado que devuelve la coleccion de planes adquiridos para un negocio.
        /// </summary>
        private const string NAB_VENTA_OBTENER_PLANES_ADQUIRIDOS = "Nab_SP_Comercial_PlanesAdquiridos_Consulta";
        /// <summary>
        /// Procedimiento almacenado para guardar la informacion adicional asociado a un negocio.
        /// </summary>
        private const string NAB_VENTAS_RADICACION_VENTA_A_CUOTAS_ADICIONAL = "Nab_SP_Negocio_VentaCuotas_Insert";
        /// <summary>
        /// Obtener informacion de venta a cuotas.
        /// </summary>
        private const string NAB_VENTA_OBTENER_VENTA_A_CUOTAS = "Nab_SP_Comercial_Venta_a_Cuotas_Obtener";
        /// <summary>
        /// Obtener informacion de empresa en linea.
        /// </summary>
        private const string NAB_EMPRESA_LINEA_CONSULTA = "Nab_SP_Negocio_Empresa_Linea_Consulta";
        /// <summary>
        /// Obtener informacion de cobro revertido.
        /// </summary>
        private const string NAB_VENTA_COBRO_REVERTIDO = "Nab_SP_Comercial_Cargar_Cobro_Revertido_Asociado";
        /// <summary>
        /// Procedimiento almacanado para guardar informacion de adicional de condiciones uniformes.
        /// </summary>
        //private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL = "Nab_Ventas_Condiciones_Uniformes_Informacion_Adicional";
        private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL = "Nab_SP_Negocio_Condiciones_Uniformes_Informacion_Adicional_Insert";
        /// <summary>
        /// Procedimiento almacenado para obtener la informacion adicional de un negocio de condiciones uniformes.
        /// </summary>
        //private const string NAB_VENTA_OBTENER_CONDICIONES_UNIFORMES_INFO_ADICIONAL = "Nab_Venta_Obtener_Condiciones_Uniformes_Info_Adicional";
        private const string NAB_VENTA_OBTENER_CONDICIONES_UNIFORMES_INFO_ADICIONAL = "Nab_SP_Negocios_Condiciones_Uniformes_Info_Adicional_Obtener";

        /// <summary>
        /// Procedimiento almacenado para insertar la información adicional del anexo del contrato de condiciones uniformes
        /// </summary>
        //private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL_ANEXO = "Nab_Ventas_Condiciones_Uniformes_Informacion_Adicional_Anexo";
        private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL_ANEXO = "Nab_SP_Comercial_Condiciones_Uniformes_Informacion_Adicional_Anexo_Insert";
        /// <summary>
        /// Consulta de anexo en el contrato de condiciones uniformes
        /// </summary>
        private const string NAB_OBTENER_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL_ANEXO = "Nab_SP_Comercial_Negocio_CU_Informacion_Adicional_Anexo";
        /// <summary>
        /// Procedimiento almacenado para obtener las activaciones robot de un negocio
        /// </summary>
        //private const string NAB_OBTENER_ACTIVACION_ROBOT = "Nab_Obtener_Activacion_Robot";
        private const string NAB_OBTENER_ACTIVACION_ROBOT = "Nab_SP_Comercial_Activacion_Lineas_Obtener";
        /// <summary>
        /// Procedimiento almacenado para insertar la informacion de condiciones uniformes de direccion de facturacion.
        /// </summary>
        //private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_DIRECCION_FACTURACION = "Nab_Ventas_Condiciones_Uniformes_Informacion_Direccion_Facturacion";
        private const string NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_DIRECCION_FACTURACION = "Nab_SP_Comercial_Condiciones_Uniformes_Informacion_Direccion_Facturacion_Insert";
        /// <summary>
        /// Procedimiento almacenado para obtener la informacion de condiciones uniformes de direccion de facturacion.
        /// </summary>
        //private const string NAB_VENTA_OBTENER_CONDICIONES_UNIFORMES_INFO_DIRECCION = "Nab_Venta_Obtener_Condiciones_Uniformes_Info_Direccion";
        private const string NAB_VENTA_OBTENER_CONDICIONES_UNIFORMES_INFO_DIRECCION = "Nab_SP_Negocios_Condiciones_Uniformes_Info_Direccion_Obtener";
        /// <summary>
        /// Procedimiento almacenado para obtener la informacion de anexo otro si de condiciones uniformes.
        /// </summary>
        //private const string NAB_VENTA_OBTENER_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES = "Nab_Venta_Obtener_Anexo_Otros_Si_Condiciones_Uniformes";
        private const string NAB_VENTA_OBTENER_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES = "Nab_SP_Comercial_Anexo_Otros_Si_Condiciones_Uniformes_Obtener";
        /// <summary>
        /// Procedimiento almacenado para almacenar la informacion de anexo otro si de condiciones uniformes.
        /// </summary>
        //private const string NAB_VENTAS_AGREGAR_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES = "Nab_Ventas_Agregar_Anexo_Otros_Si_Condiciones_Uniformes";
        private const string NAB_VENTAS_AGREGAR_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES = "Nab_SP_Comercial_Anexo_Otros_Si_Condiciones_Uniformes_Agregar";
        #endregion Constantes

        #region Propiedades
        /// <summary>
        /// Linea actual sobre la cual se realiza el proceso.
        /// </summary>
        private int CurrentLine { get; set; }
        #endregion Propiedades

        /// <summary>
        /// Crear consecutivo de negocio en base de datos en NABIS
        /// </summary>
        /// <param name="regionalVendedor"></param>
        /// <param name="consecutivo"></param>
        /// <returns>"Consecutivo"</returns>
        public bool ConsecutivoNegocio_NAB(string regionalVendedor, ref string consecutivo)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect consNegocio = new Conect(this.CurrentLine);
            consNegocio.commandQuery = NAB_CONSECUTIVO_NEGOCIO;
            consNegocio.addParameters("Regional_Vendedor", regionalVendedor);
            consNegocio.addParametersOutPut("Consecutivo", "", SqlDbType.VarChar, 50);
            consNegocio.execTransac(true);
            consecutivo = (string)consNegocio.getValueParameterOut("Consecutivo");
            return (consNegocio.numRows > 0);
        }
        /// <summary>
        /// consultar si tiene negocios atados
        /// </summary>
        /// <param name="ideb_referencia"></param>
        /// <param name="identificacion"></param>
        /// <returns>"Consecutivo"</returns>
        public bool ValidarNegocioAtado(string ideb_referencia, string identificacion)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect consNegocio = new Conect(this.CurrentLine);
            consNegocio.commandQuery = NAB_NEGOCIOS_ATADOS;
            consNegocio.addParameters("ideb", ideb_referencia);
            consNegocio.addParameters("identidad", identificacion);
            consNegocio.execTransac(true);
            return (consNegocio.numRows > 0);
        }

        /// <summary>
        /// Crear registro de negocio en base de datos en NABIS
        /// </summary>
        /// <param name="consecutivoNegocio"></param>
        /// <param name="codigoVendedor"></param>
        /// <param name="canalVendedor"></param>
        /// <param name="canalVenta"></param>
        /// <param name="cantidadLineas"></param>
        /// <param name="portabilidad"></param>
        /// <param name="pedidoLogistica"></param>
        /// <param name="fechaCambio"></param>
        /// <param name="tipoSolicitud"></param>
        /// <param name="tipoIdentificacionCliente"></param>
        /// <param name="identificacionCliente"></param>
        /// <param name="nombreCliente"></param>
        /// <param name="ciudadCliente"></param>
        /// <param name="tipoCalleCliente"></param>
        /// <param name="direccionCliente"></param>
        /// <param name="barrioCliente"></param>
        /// <param name="indicativoFijoCliente"></param>
        /// <param name="numeroFijoCliente"></param>
        /// <param name="numeroIdentificacionRepresentanteLegal"></param>
        /// <param name="nombreRepresentanteLegal"></param>
        /// <param name="apellido1RepresentanteLegal"></param>
        /// <param name="apellido2RepresentanteLegal"></param>
        /// <param name="celularRepresentanteLegal"></param>
        /// <param name="fechaConstitucionRepresentanteLegal"></param>
        /// <param name="idCanalVenta"></param>
        /// <param name="idTipoContrato"></param>
        /// <param name="idTipoCliente"></param>
        /// <param name="idTipoSolicitud"></param>
        /// <param name="idMarcacionEspecial"></param>
        /// <param name="idContrato"></param>
        /// <param name="idTipoCambioPlan"></param>
        /// <param name="idUsuario"></param>
        /// <param name="nombreUsuarioAplicacion"></param>
        /// <param name="nombreUsuario"></param>
        /// <returns></returns>
        public bool RadicacionNegocio_NAB(string consecutivoNegocio, string codigoVendedor, int? canalVendedor, string canalVenta, string cantidadLineas,
            string portabilidad, string pedidoLogistica, string fechaCambio, string idOperador, string tipoSolicitud, string tipoIdentificacionCliente,
            string identificacionCliente, string nombreCliente, string ciudadCliente, string tipoCalleCliente, string direccionCliente,
            string barrioCliente, string indicativoFijoCliente, string numeroFijoCliente, int idIdentificacionRepresentanteLegal, string numeroIdentificacionRepresentanteLegal,
            string nombreRepresentanteLegal, string apellido1RepresentanteLegal, string apellido2RepresentanteLegal, string celularRepresentanteLegal,
            string fechaConstitucionRepresentanteLegal, string emailRepresentanteLegal, string idCanalVenta, string idTipoContrato, string idTipoCliente, string idTipoSolicitud,
            string idMarcacionEspecial, string idContrato, string idTipoCambioPlan, string idUsuario, string nombreUsuarioAplicacion, string nombreUsuario,
            string telefono_cliente, string observaciones, ref string mensajeError, string emailCliente, bool esNeg_Atado, string tipoNegocioAtado, string negocioReferencia,
            ref int resultado)
        {
            mensajeError = string.Empty;
            int Cantidad_registros = -1;
            int cod_vend;
            int.TryParse(codigoVendedor, out cod_vend);
            //string canal_vend = canalVendedor;
            string nombre_grupo = canalVenta;
            int cant_lineas;
            int? idOperadorPortado;
            int.TryParse(cantidadLineas, out cant_lineas);
            bool portado = (portabilidad == "Si");
            bool pedido = (pedidoLogistica == "Si");
            DateTime fec_ingreso = DateTime.Now;
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect radNegocio = new Conect(this.CurrentLine);
            radNegocio.commandQuery = NAB_EB_RAD_NEGOCIO;
            radNegocio.addParameters("id_eb", consecutivoNegocio);
            radNegocio.addParameters("fec_ingreso", fec_ingreso);
            radNegocio.addParameters("cod_vend", cod_vend);
            radNegocio.addParameters("canal_vend", canalVendedor);
            radNegocio.addParameters("nombre_grupo", nombre_grupo);
            radNegocio.addParameters("user", idUsuario);
            radNegocio.addParameters("cant_lineas", cant_lineas);
            radNegocio.addParameters("portado", portado);
            radNegocio.addParameters("fec_ventana", (string.IsNullOrEmpty(fechaCambio)) ? (string.Empty) : (fechaCambio));
            idOperadorPortado = (portado) ? Convert.ToInt32(idOperador) : (int?)null;
            radNegocio.addParameters("Operador", idOperadorPortado);
            radNegocio.addParameters("pedido", pedido);
            radNegocio.addParameters("tipo_solicitud", tipoSolicitud);
            //InfoCliente
            radNegocio.addParameters("id_identidad", tipoIdentificacionCliente);
            radNegocio.addParameters("identidad", identificacionCliente);
            radNegocio.addParameters("nomCliente", nombreCliente);
            radNegocio.addParameters("cod_distrito", ciudadCliente);
            radNegocio.addParameters("cod_tipo_calle", tipoCalleCliente);
            radNegocio.addParameters("direccion", direccionCliente);
            radNegocio.addParameters("complemento", barrioCliente);
            radNegocio.addParameters("emailCliente", emailCliente);
            int numFijo = Convert.ToInt32(indicativoFijoCliente + numeroFijoCliente);
            //Rep. Legal
            radNegocio.addParameters("RepLegalTipoIdent", idIdentificacionRepresentanteLegal);
            radNegocio.addParameters("RepLegalIdent", Convert.ToInt32(numeroIdentificacionRepresentanteLegal));
            radNegocio.addParameters("RepLegalNom", nombreRepresentanteLegal);
            radNegocio.addParameters("RepLegalAp1", apellido1RepresentanteLegal);
            radNegocio.addParameters("RepLegalAp2", apellido2RepresentanteLegal);
            radNegocio.addParameters("RepLegalFijo", numFijo);
            radNegocio.addParameters("RepLegalCelular", Convert.ToInt64(celularRepresentanteLegal, CultureInfo.InvariantCulture));
            radNegocio.addParameters("RepLegalFecNac", fechaConstitucionRepresentanteLegal);
            radNegocio.addParameters("RepLegalCorreo", emailRepresentanteLegal);
            //información de solicitud
            radNegocio.addParameters("id_grupo", idCanalVenta);
            radNegocio.addParameters("id_tipo_contrato", idTipoContrato);
            radNegocio.addParameters("id_tipo_cliente", idTipoCliente);
            radNegocio.addParameters("id_tipo_servicio", 2); //2 = Móvil
            radNegocio.addParameters("id_tipo_solicitud", idTipoSolicitud);
            radNegocio.addParameters("id_convenio", idMarcacionEspecial);
            long IdContratoMarco = (string.IsNullOrEmpty(idContrato)) ? (-1) : (Convert.ToInt64(idContrato, CultureInfo.InvariantCulture));
            radNegocio.addParameters("id_contratoMarco", IdContratoMarco);
            radNegocio.addParameters("id_tipo_cambio_plan", idTipoCambioPlan);
            radNegocio.addParameters("esPyme", true);
            radNegocio.addParameters("telefono_cliente", telefono_cliente);
            radNegocio.addParameters("observaciones", observaciones);
            if (esNeg_Atado)
            {
                radNegocio.addParameters("esAtado", 1);
                radNegocio.addParameters("tipo_atado", tipoNegocioAtado);
                radNegocio.addParameters("negocio_referencia", negocioReferencia);
            }
            else
            {
                radNegocio.addParameters("esAtado", 0);
            }
            radNegocio.addParametersOutPut("resultado", "", SqlDbType.Int);
            radNegocio.execTransac(true);
            Cantidad_registros = (int)radNegocio.getValueParameterOut("resultado");
            //mensajeError = radNegocio.getColumnValue("MensajeError");
            //return (radNegocio.numRows > 0);
            return (Cantidad_registros > 0);
        }

        /// <summary>
        /// Permite almacenar la informacion asociada a la estructura de venta de los planes adquiridos.
        /// </summary>
        /// <param name="id_descripcion_plan"></param>
        /// <param name="id_plan_tarifario"></param>
        /// <param name="cantidad_lineas"></param>
        /// <param name="valor_movistar_voz"></param>
        /// <param name="valor_fijo_voz"></param>
        /// <param name="valor_otros_voz"></param>
        /// <param name="valor_movistar_adicional_voz"></param>
        /// <param name="valor_fijo_adicional_voz"></param>
        /// <param name="valor_otros_adicional_voz"></param>
        /// <param name="id_plan_servicio_adicional_1"></param>
        /// <param name="servicio_adicional_1_valor_movistar_voz"></param>
        /// <param name="renta_mes_plan_datos_servicio_adicional_1"></param>
        /// <param name="kb_incluido_plan_datos_servicio_adicional_1"></param>
        /// <param name="kb_adicional_plan_datos_servicio_adicional_1"></param>
        /// <param name="id_plan_servicio_adicional_2"></param>
        /// <param name="servicio_adicional_2_valor_movistar_voz"></param>
        /// <param name="renta_mes_plan_datos_servicio_adicional_2"></param>
        /// <param name="kb_incluido_plan_datos_servicio_adicional_2"></param>
        /// <param name="kb_adicional_plan_datos_servicio_adicional_2"></param>
        /// <param name="id_plan_servicio_adicional_3"></param>
        /// <param name="servicio_adicional_3_valor_movistar_voz"></param>
        /// <param name="renta_mes_plan_datos_servicio_adicional_3"></param>
        /// <param name="kb_incluido_plan_datos_servicio_adicional_3"></param>
        /// <param name="kb_adicional_plan_datos_servicio_adicional_3"></param>
        /// <param name="id_plan_plan_adicional_1"></param>
        /// <param name="plan_adicional_1_valor_movistar_voz"></param>
        /// <param name="renta_mes_plan_datos_plan_adicional_1"></param>
        /// <param name="kb_incluido_plan_datos_plan_adicional_1"></param>
        /// <param name="kb_adicional_plan_datos_plan_adicional_1"></param>
        /// <param name="id_plan_plan_adicional_2"></param>
        /// <param name="plan_adicional_2_valor_movistar_voz"></param>
        /// <param name="renta_mes_plan_datos_plan_adicional_2"></param>
        /// <param name="kb_incluido_plan_datos_plan_adicional_2"></param>
        /// <param name="kb_adicional_plan_datos_plan_adicional_2"></param>
        /// <param name="plan_datos_renta_mes"></param>
        /// <param name="plan_datos_kb_incluido"></param>
        /// <param name="plan_datos_kb_adicional"></param>
        /// <param name="id_codigo_negocio"></param>
        /// <returns></returns>
        public bool GuardarEstructuraVentaPlanAdquiridos(string id_plan_tarifario, string cantidad_lineas, string valor_movistar_voz,
            string valor_fijo_voz, string valor_otros_voz, string valor_movistar_adicional_voz, string valor_fijo_adicional_voz,
            string valor_otros_adicional_voz, string id_plan_servicio_adicional_1, string servicio_adicional_1_valor_movistar_voz,
            string renta_mes_plan_datos_servicio_adicional_1, string kb_incluido_plan_datos_servicio_adicional_1,
            string kb_adicional_plan_datos_servicio_adicional_1, string id_plan_servicio_adicional_2, string servicio_adicional_2_valor_movistar_voz,
            string renta_mes_plan_datos_servicio_adicional_2, string kb_incluido_plan_datos_servicio_adicional_2,
            string kb_adicional_plan_datos_servicio_adicional_2, string id_plan_servicio_adicional_3, string servicio_adicional_3_valor_movistar_voz,
            string renta_mes_plan_datos_servicio_adicional_3, string kb_incluido_plan_datos_servicio_adicional_3,
            string kb_adicional_plan_datos_servicio_adicional_3, string id_plan_plan_adicional_1, string plan_adicional_1_valor_movistar_voz,
            string renta_mes_plan_datos_plan_adicional_1, string kb_incluido_plan_datos_plan_adicional_1, string kb_adicional_plan_datos_plan_adicional_1,
            string id_plan_plan_adicional_2, string plan_adicional_2_valor_movistar_voz, string renta_mes_plan_datos_plan_adicional_2,
            string kb_incluido_plan_datos_plan_adicional_2, string kb_adicional_plan_datos_plan_adicional_2, string plan_datos_renta_mes,
            string plan_datos_kb_incluido, string plan_datos_kb_adicional, string id_codigo_negocio, string plan_renta_mes, string minutos_incluidos, string valor_g_voz, string valor_g_adicional_voz)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect planAdquirido = new Conect(this.CurrentLine);
            planAdquirido.commandQuery = NAB_VENTA_PLAN_ADQUIRIDOS;
            planAdquirido.addParameters("ID_PLAN_TARIFARIO", id_plan_tarifario);
            planAdquirido.addParameters("CANTIDAD_LINEAS", cantidad_lineas);
            planAdquirido.addParameters("VALOR_MOVISTAR_VOZ", valor_movistar_voz);
            planAdquirido.addParameters("VALOR_FIJO_VOZ", valor_fijo_voz);
            planAdquirido.addParameters("VALOR_OTROS_VOZ", valor_otros_voz);
            planAdquirido.addParameters("VALOR_MOVISTAR_ADICIONAL_VOZ", valor_movistar_adicional_voz);
            planAdquirido.addParameters("VALOR_FIJO_ADICIONAL_VOZ", valor_fijo_adicional_voz);
            planAdquirido.addParameters("VALOR_OTROS_ADICIONAL_VOZ", valor_otros_adicional_voz);
            planAdquirido.addParameters("ID_PLAN_SERVICIO_ADICIONAL_1", id_plan_servicio_adicional_1);
            planAdquirido.addParameters("SERVICIO_ADICIONAL_1_VALOR_MOVISTAR_VOZ", servicio_adicional_1_valor_movistar_voz);
            planAdquirido.addParameters("RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_1", renta_mes_plan_datos_servicio_adicional_1);
            planAdquirido.addParameters("KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_1", kb_incluido_plan_datos_servicio_adicional_1);
            planAdquirido.addParameters("KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_1", kb_adicional_plan_datos_servicio_adicional_1);
            planAdquirido.addParameters("ID_PLAN_SERVICIO_ADICIONAL_2", id_plan_servicio_adicional_2);
            planAdquirido.addParameters("SERVICIO_ADICIONAL_2_VALOR_MOVISTAR_VOZ", servicio_adicional_2_valor_movistar_voz);
            planAdquirido.addParameters("RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_2", renta_mes_plan_datos_servicio_adicional_2);
            planAdquirido.addParameters("KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_2", kb_incluido_plan_datos_servicio_adicional_2);
            planAdquirido.addParameters("KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_2", kb_adicional_plan_datos_servicio_adicional_2);
            planAdquirido.addParameters("ID_PLAN_SERVICIO_ADICIONAL_3", id_plan_servicio_adicional_3);
            planAdquirido.addParameters("SERVICIO_ADICIONAL_3_VALOR_MOVISTAR_VOZ", servicio_adicional_3_valor_movistar_voz);
            planAdquirido.addParameters("RENTA_MES_PLAN_DATOS_SERVICIO_ADICIONAL_3", renta_mes_plan_datos_servicio_adicional_3);
            planAdquirido.addParameters("KB_INCLUIDO_PLAN_DATOS_SERVICIO_ADICIONAL_3", kb_incluido_plan_datos_servicio_adicional_3);
            planAdquirido.addParameters("KB_ADICIONAL_PLAN_DATOS_SERVICIO_ADICIONAL_3", kb_adicional_plan_datos_servicio_adicional_3);
            planAdquirido.addParameters("ID_PLAN_PLAN_ADICIONAL_1", id_plan_plan_adicional_1);
            planAdquirido.addParameters("PLAN_ADICIONAL_1_VALOR_MOVISTAR_VOZ", plan_adicional_1_valor_movistar_voz);
            planAdquirido.addParameters("RENTA_MES_PLAN_DATOS_PLAN_ADICIONAL_1", renta_mes_plan_datos_plan_adicional_1);
            planAdquirido.addParameters("KB_INCLUIDO_PLAN_DATOS_PLAN_ADICIONAL_1", kb_incluido_plan_datos_plan_adicional_1);
            planAdquirido.addParameters("KB_ADICIONAL_PLAN_DATOS_PLAN_ADICIONAL_1", kb_adicional_plan_datos_plan_adicional_1);
            planAdquirido.addParameters("ID_PLAN_PLAN_ADICIONAL_2", id_plan_plan_adicional_2);
            planAdquirido.addParameters("PLAN_ADICIONAL_2_VALOR_MOVISTAR_VOZ", plan_adicional_2_valor_movistar_voz);
            planAdquirido.addParameters("RENTA_MES_PLAN_DATOS_PLAN_ADICIONAL_2", renta_mes_plan_datos_plan_adicional_2);
            planAdquirido.addParameters("KB_INCLUIDO_PLAN_DATOS_PLAN_ADICIONAL_2", kb_incluido_plan_datos_plan_adicional_2);
            planAdquirido.addParameters("KB_ADICIONAL_PLAN_DATOS_PLAN_ADICIONAL_2", kb_adicional_plan_datos_plan_adicional_2);
            planAdquirido.addParameters("PLAN_DATOS_RENTA_MES", plan_datos_renta_mes);
            planAdquirido.addParameters("PLAN_DATOS_KB_INCLUIDO", plan_datos_kb_incluido);
            planAdquirido.addParameters("PLAN_DATOS_KB_ADICIONAL", plan_datos_kb_adicional);
            planAdquirido.addParameters("ID_CODIGO_NEGOCIO", id_codigo_negocio);
            planAdquirido.addParameters("CARGO_BASICO", plan_renta_mes);
            planAdquirido.addParameters("MINUTOS_INCLUIDOS", minutos_incluidos);
            planAdquirido.addParameters("VALOR_OTROS_G", valor_g_voz);
            planAdquirido.addParameters("VALOR_G_ADICIONAL_VOZ", valor_g_adicional_voz);
            planAdquirido.execTransac(true);
            return (planAdquirido.numRows > 0);
        }

        /// <summary>
        /// Permite almacenar la informacion asociada a los perfiles de usuario 
        /// autorizados a un negocio
        /// </summary>
        /// <param name="consecutivoNegocio"></param>
        /// <param name="contacto1Nombre"></param>
        /// <param name="contacto1Movil"></param>
        /// <param name="contact1Email"></param>
        /// <param name="contacto1Cedula"></param>
        /// <param name="contacto1PerfilAsignado"></param>
        /// <param name="contacto2Nombre"></param>
        /// <param name="contacto2Movil"></param>
        /// <param name="contacto2Email"></param>
        /// <param name="contacto2Cedula"></param>
        /// <param name="contacto2PerfilAsignado"></param>
        /// <param name="contacto3Nombre"></param>
        /// <param name="contacto3Movil"></param>
        /// <param name="contacto3Email"></param>
        /// <param name="contacto3Cedula"></param>
        /// <param name="contacto3PerfilAsignado"></param>
        /// <param name="contacto4Nombre"></param>
        /// <param name="contacto4Movil"></param>
        /// <param name="contacto4Email"></param>
        /// <param name="contacto4Cedula"></param>
        /// <param name="contacto4PerfilAsignado"></param>
        /// <returns></returns>
        public bool GuardarPerfilesUsuariosAutorizados(string consecutivoNegocio, string contacto1Nombre, string contacto1Movil, string contact1Email, string contacto1Cedula, string contacto1PerfilAsignado,
            string contacto2Nombre, string contacto2Movil, string contacto2Email, string contacto2Cedula, string contacto2PerfilAsignado,
            string contacto3Nombre, string contacto3Movil, string contacto3Email, string contacto3Cedula, string contacto3PerfilAsignado,
            string contacto4Nombre, string contacto4Movil, string contacto4Email, string contacto4Cedula, string contacto4PerfilAsignado)
        {

            string contact1 = contacto1PerfilAsignado == "AD" ? "1" : contacto1PerfilAsignado == "C" ? "2" : contacto1PerfilAsignado == "CD" ? "3" : "0";
            string contact2 = contacto2PerfilAsignado == "AD" ? "1" : contacto2PerfilAsignado == "C" ? "2" : contacto2PerfilAsignado == "CD" ? "3" : "0";
            string contact3 = contacto3PerfilAsignado == "AD" ? "1" : contacto3PerfilAsignado == "C" ? "2" : contacto3PerfilAsignado == "CD" ? "3" : "0";
            string contact4 = contacto4PerfilAsignado == "AD" ? "1" : contacto4PerfilAsignado == "C" ? "2" : contacto4PerfilAsignado == "CD" ? "3" : "0";


            List<ContactoAutorizadoET> ListContactosAut = new List<ContactoAutorizadoET>();
            ListContactosAut.Add(new ContactoAutorizadoET(contacto1Nombre, contacto1Movil, contact1Email, contacto1Cedula, contact1, consecutivoNegocio, string.Empty));
            ListContactosAut.Add(new ContactoAutorizadoET(contacto2Nombre, contacto2Movil, contacto2Email, contacto2Cedula, contact2, consecutivoNegocio, string.Empty));
            ListContactosAut.Add(new ContactoAutorizadoET(contacto3Nombre, contacto3Movil, contacto3Email, contacto3Cedula, contact3, consecutivoNegocio, string.Empty));
            ListContactosAut.Add(new ContactoAutorizadoET(contacto4Nombre, contacto4Movil, contacto4Email, contacto4Cedula, contact4, consecutivoNegocio, string.Empty));

            //Armado del XML para enviar todos los contactos
            StringBuilder ContactosAutorizadosXml = new StringBuilder();
            ContactosAutorizadosXml.AppendLine("<body>");
            foreach (ContactoAutorizadoET Cont in ListContactosAut)
            {
                ContactosAutorizadosXml.Append("<row ");
                ContactosAutorizadosXml.Append(string.Format("A=\"{0}\" ", Cont.NombreCompleto));
                ContactosAutorizadosXml.Append(string.Format("B=\"{0}\" ", Cont.MovilContacto));
                ContactosAutorizadosXml.Append(string.Format("EMAIL_CONTACTO=\"{0}\" ", Cont.EmailContacto));
                ContactosAutorizadosXml.Append(string.Format("ID_PERFIL_AUTORIZADO=\"{0}\" ", Cont.IdPerfilAutorizado));
                ContactosAutorizadosXml.Append(string.Format("CEDULA_CONTACTO=\"{0}\" ", Cont.CedulaContacto));
                ContactosAutorizadosXml.Append(string.Format("ID_CODIGO_NEGOCIO=\"{0}\" ", Cont.CodigoNegocio));
                ContactosAutorizadosXml.Append(string.Format("IVR=\"{0}\" ", 4));
                ContactosAutorizadosXml.Append("></row>");
            }
            ContactosAutorizadosXml.Append("</body>");


            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect negocio = new Conect(this.CurrentLine);
            negocio.commandQuery = NAB_VENTAS_USUARIO_AUTORIZADO_PERFIL;
            negocio.addParameters("CONTACTO_1_NOMBRE", contacto1Nombre);
            negocio.addParameters("CONTACTO_1_MOVIL", contacto1Movil);
            negocio.addParameters("CONTACTO_1_EMAIL", contact1Email);
            negocio.addParameters("CONTACTO_1_PERFIL_AUTORIZADO ", contacto1PerfilAsignado);
            negocio.addParameters("CONTACTO_1_CEDULA", contacto1Cedula);
            negocio.addParameters("CONTACTO_2_NOMBRE", contacto2Nombre);
            negocio.addParameters("CONTACTO_2_MOVIL", contacto2Movil);
            negocio.addParameters("CONTACTO_2_EMAIL", contacto2Email);
            negocio.addParameters("CONTACTO_2_PERFIL_AUTORIZADO", contacto2PerfilAsignado);
            negocio.addParameters("CONTACTO_2_CEDULA", contacto2Cedula);
            negocio.addParameters("CONTACTO_3_NOMBRE", contacto3Nombre);
            negocio.addParameters("CONTACTO_3_MOVIL", contacto3Movil);
            negocio.addParameters("CONTACTO_3_EMAIL", contacto3Email);
            negocio.addParameters("CONTACTO_3_PERFIL_AUTORIZADO", contacto3PerfilAsignado);
            negocio.addParameters("CONTACTO_3_CEDULA", contacto3Cedula);
            negocio.addParameters("CONTACTO_4_NOMBRE", contacto4Nombre);
            negocio.addParameters("CONTACTO_4_MOVIL", contacto4Movil);
            negocio.addParameters("CONTACTO_4_EMAIL", contacto4Email);
            negocio.addParameters("CONTACTO_4_PERFIL_AUTORIZADO ", contacto4PerfilAsignado);
            negocio.addParameters("CONTACTO_4_CEDULA", contacto4Cedula);
            negocio.addParameters("ID_CODIGO_NEGOCIO", consecutivoNegocio);
            negocio.addParameters("CONTACTOS_XML", ContactosAutorizadosXml.ToString());
            negocio.execTransac(true);
            return (negocio.numRows > 0);
        }

        /// <summary>
        /// Guardar la informacion adicional de un negocio en especifico.
        /// </summary>
        /// <param name="consecutivoNegocio"></param>
        /// <param name="idKoral"></param>
        /// <param name="idPricing"></param>
        /// <param name="enviarPorCorreoElectronico"></param>
        /// <param name="correoElectronico"></param>
        /// <param name="nombreClienteAsociado"></param>
        /// <param name="codigoClienteAsociado"></param>
        /// <param name="nitClienteAsociado"></param>
        /// <param name="duracionServicios"></param>
        /// <returns></returns>
        public bool GuardarInformacionAdicionalNegocio(string consecutivoNegocio, string idKoral, string idPricing, bool enviarPorCorreoElectronico, string correoElectronico,
            string nombreClienteAsociado, string codigoClienteAsociado, string nitClienteAsociado, string duracionServicios, string beneficiosServicios,
            string nombreClienteAsociado2, string codigoClienteAsociado2, string nitClienteAsociado2, string nombreClienteAsociado3,
            string codigoClienteAsociado3, string nitClienteAsociado3, string nombreRef1, string telRef1, string institucionRef1, string nombreRef2, string telRef2, string institucionRe2,
            string profesionalCia, string jefeZona, string gerenteRegional, bool perfilSaliente, int? ciudadOpcional, string direccionOpcional,
            string observaciones, string movilcontacto_referencia_1 = "", string movilcontacto_referencia_2 = "", bool? autorizacion_envio_email = null,
            bool? autorizacion_numero_celular = null)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect negocio = new Conect(this.CurrentLine);
            negocio.commandQuery = NAB_VENTAS_RADICACION_INFORMACION_ADICIONAL;
            negocio.addParameters("ID_KORAL", idKoral);
            negocio.addParameters("ID_PRICING", idPricing);
            negocio.addParameters("ENVIO_CORREO_ELECTRONICO", enviarPorCorreoElectronico);
            negocio.addParameters("CORREO_ELECTRONICO", correoElectronico);
            negocio.addParameters("NOMBRE_CLIENTE_SOCIO1", nombreClienteAsociado);
            negocio.addParameters("CODIGO_CLIENTE_SOCIO1", codigoClienteAsociado);
            negocio.addParameters("NIT_CLIENTE_SOCIO1", nitClienteAsociado);
            negocio.addParameters("ID_CODIGO_NEGOCIO", consecutivoNegocio);
            negocio.addParameters("DURACION_SERVICIOS", Convert.ToInt32(duracionServicios));
            //Codigo adicional MTF

            negocio.addParameters("NOMBRE_CLIENTE_SOCIO2", nombreClienteAsociado2);
            negocio.addParameters("CODIGO_CLIENTE_SOCIO2", codigoClienteAsociado2);
            negocio.addParameters("NIT_CLIENTE_SOCIO2", nitClienteAsociado2);
            negocio.addParameters("NOMBRE_CLIENTE_SOCIO3", nombreClienteAsociado3);
            negocio.addParameters("CODIGO_CLIENTE_SOCIO3", codigoClienteAsociado3);
            negocio.addParameters("NIT_CLIENTE_SOCIO3", nitClienteAsociado3);
            negocio.addParameters("RENOVACION_REPOSICION", "NO");
            negocio.addParameters("BENEFICIOS", beneficiosServicios);
            negocio.addParameters("NOMBRE_REFERENCIA_1", nombreRef1);
            negocio.addParameters("TELCONTACTO_REFERENCIA_1", telRef1);
            negocio.addParameters("INSTITUCION_REFERENCIA_1", institucionRef1);
            negocio.addParameters("NOMBRE_REFERENCIA_2", nombreRef2);
            negocio.addParameters("TELCONTACTO_REFERENCIA_2", telRef2);
            negocio.addParameters("INSTITUCION_REFERENCIA_2", institucionRe2);
            negocio.addParameters("PROFESIONAL_CIA", profesionalCia);
            negocio.addParameters("JEFE_ZONA", jefeZona);
            negocio.addParameters("GERENTE_REGIONAL", gerenteRegional);
            negocio.addParameters("PERFIL_SALIENTE", perfilSaliente);
            negocio.addParameters("CIUDAD_OPCIONAL", ciudadOpcional.ToString());
            negocio.addParameters("DIRECCION_OPCIONAL", direccionOpcional);
            negocio.addParameters("OBSERVACIONES", observaciones);
            negocio.addParameters("MOVILCONTACTO_REFERENCIA_1", movilcontacto_referencia_1);
            negocio.addParameters("MOVILCONTACTO_REFERENCIA_2", movilcontacto_referencia_2);
            negocio.addParameters("AUTORIZACION_ENVIO_EMAIL", autorizacion_envio_email);
            negocio.addParameters("AUTORIZACION_NUMERO_CELULAR", autorizacion_numero_celular);
            negocio.execTransac(true);
            return (negocio.numRows > 0);
        }

        /// <summary>
        /// Guardar informacion de venta a cuotas asociada a un negocio seleccionado.
        /// </summary>
        /// <param name="fecha_de_celebracion_del_contrato"></param>
        /// <param name="nombre_comprador"></param>
        /// <param name="identificacion_comprador"></param>
        /// <param name="correo_electronico_comprador"></param>
        /// <param name="telefono_comprador"></param>
        /// <param name="valor_total_equipo"></param>
        /// <param name="cuota_inicial"></param>
        /// <param name="numero_cuotas"></param>
        /// <param name="cuota_mensual"></param>
        /// <param name="valor_total"></param>
        /// <param name="id_codigo_negocio"></param>
        /// <returns></returns>
        public bool GuardarInformacionVentaACuotas(int numero_lineas, DateTime? fecha_de_celebracion_del_contrato,
            string lugar_de_celebracion_del_contrato, string nombre_comprador, string identificacion_comprador, string correo_electronico_comprador,
            string telefono_comprador, string ciudad_comprador, string direccion_comprador, string nombre_representante_legal, string identificacion_representante_legal,
            string forma_de_pago, int? valor_total_equipo, int? cuota_inicial, int? numero_cuotas, int? cuota_mensual, int? valor_total,
            string id_codigo_negocio)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect negocio = new Conect(this.CurrentLine);
            negocio.commandQuery = NAB_VENTAS_RADICACION_VENTA_A_CUOTAS_ADICIONAL;
            negocio.addParameters("NUMERO_LINEAS", numero_lineas);
            negocio.addParameters("FECHA_DE_CELEBRACION_DEL_CONTRATO", fecha_de_celebracion_del_contrato);
            negocio.addParameters("LUGAR_DE_CELEBRACION_DEL_CONTRATO", lugar_de_celebracion_del_contrato);
            negocio.addParameters("NOMBRE_COMPRADOR", nombre_comprador);
            negocio.addParameters("IDENTIFICACION_COMPRADOR", identificacion_comprador);
            negocio.addParameters("CORREO_ELECTRONICO_COMPRADOR", correo_electronico_comprador);
            negocio.addParameters("TELEFONO_COMPRADOR", telefono_comprador);
            negocio.addParameters("CIUDAD_COMPRADOR", ciudad_comprador);
            negocio.addParameters("DIRECCION_COMPRADOR", direccion_comprador);
            negocio.addParameters("NOMBRE_REPRESENTANTE_LEGAL", nombre_representante_legal);
            negocio.addParameters("IDENTIFICACION_REPRESENTANTE_LEGAL", identificacion_representante_legal);
            negocio.addParameters("FORMA_DE_PAGO", forma_de_pago);
            negocio.addParameters("VALOR_TOTAL_EQUIPO", valor_total_equipo);
            negocio.addParameters("CUOTA_INICIAL", cuota_inicial);
            negocio.addParameters("NUMERO_CUOTAS", numero_cuotas);
            negocio.addParameters("CUOTA_MENSUAL", cuota_mensual);
            negocio.addParameters("VALOR_TOTAL", valor_total);
            negocio.addParameters("ID_CODIGO_NEGOCIO", id_codigo_negocio);
            negocio.execTransac(true);
            return (negocio.numRows > 0);
        }

        /// <summary>
        /// Guardar informacion adicional de contrato de condiciones uniformes.
        /// </summary>
        /// <param name="genero_persona_natural">Genero persona natural</param>
        /// <param name="tipo_trabajo">Tipo de trabajo.</param>
        /// <param name="tipo_contrato">Tipo de contrato</param>
        /// <param name="empresa_donde_labora">Empresa en donde labora</param>
        /// <param name="asignacion_salarial">Asignacion salarial</param>
        /// <param name="tarjeta_credito">Tarjeta de credito</param>
        /// <param name="tarjeta_credito_otro">Tarjeta de credito otro</param>
        /// <param name="tarjerta_credito_numero">Numero de tarjeta de credito</param>
        /// <param name="tarjeta_credito_fecha_vencimiento">Fecha de vencimiento tarjeta de credito</param>
        /// <param name="nombre_usuario_autorizado">Nombre de usuario autorizado</param>
        /// <param name="tipo_documento_usuario_autorizado">Tipo de documento usuario autorizado</param>
        /// <param name="numero_identificacion_usuario_autorizado">Numero identificacion usuario autorizado</param>
        /// <param name="referencia_personal_nombre_1">Nombre referencia personal</param>
        /// <param name="referencia_personal_telefono_1">Telefono referencia personal</param>
        /// <param name="referencia_personal_nombre_2">Nombre referencia personal 2</param>
        /// <param name="referencia_personal_empresa_2">Empresa referencia personal 2</param>
        /// <param name="referencia_personal_telefono_2">Telefono referencia personal 2</param>
        /// <param name="id_pricing_id_koral">Id pricing o Id de Koral.</param>
        /// <param name="cod_negocio">Codigo del Negocio.</param>
        /// <returns></returns>
        public bool GuardarInformacionAdicionalCondicionesUniformes(string genero_persona_natural, string tipo_trabajo, string tipo_contrato, string empresa_donde_labora, string asignacion_salarial, string tarjeta_credito,
            string tarjeta_credito_otro, string tarjerta_credito_numero, string tarjeta_credito_fecha_vencimiento, string nombre_usuario_autorizado,
            string tipo_documento_usuario_autorizado, string numero_identificacion_usuario_autorizado,
            string referencia_personal_nombre_1, string referencia_personal_telefono_1, string referencia_personal_nombre_2, string referencia_personal_empresa_2,
            string referencia_personal_telefono_2, string cod_negocio)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect negocio = new Conect(this.CurrentLine);
            negocio.commandQuery = NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL;
            negocio.addParameters("GENERO_PERSONA_NATURAL", genero_persona_natural);
            negocio.addParameters("TIPO_TRABAJO", tipo_trabajo);
            negocio.addParameters("TIPO_CONTRATO", tipo_contrato);
            negocio.addParameters("EMPRESA_DONDE_LABORA", empresa_donde_labora);
            negocio.addParameters("ASIGNACION_SALARIAL", asignacion_salarial);
            negocio.addParameters("TARJETA_CREDITO", tarjeta_credito);
            negocio.addParameters("TARJETA_CREDITO_OTRO", tarjeta_credito_otro);
            negocio.addParameters("TARJERTA_CREDITO_NUMERO", tarjerta_credito_numero);
            negocio.addParameters("TARJETA_CREDITO_FECHA_VENCIMIENTO", tarjeta_credito_fecha_vencimiento);
            negocio.addParameters("NOMBRE_USUARIO_AUTORIZADO", nombre_usuario_autorizado);
            negocio.addParameters("TIPO_DOCUMENTO_USUARIO_AUTORIZADO", tipo_documento_usuario_autorizado);
            negocio.addParameters("NUMERO_IDENTIFICACION_USUARIO_AUTORIZADO", numero_identificacion_usuario_autorizado);
            negocio.addParameters("REFERENCIA_PERSONAL_NOMBRE_1", referencia_personal_nombre_1);
            negocio.addParameters("REFERENCIA_PERSONAL_TELEFONO_1", referencia_personal_telefono_1);
            negocio.addParameters("REFERENCIA_PERSONAL_NOMBRE_2", referencia_personal_nombre_2);
            negocio.addParameters("REFERENCIA_PERSONAL_EMPRESA_2", referencia_personal_empresa_2);
            negocio.addParameters("REFERENCIA_PERSONAL_TELEFONO_2", referencia_personal_telefono_2);
            negocio.addParameters("COD_NEGOCIO", cod_negocio);
            negocio.execTransac(true);
            return (negocio.numRows > 0);
        }

        /// <summary>
        /// Eliminar planes adquiridos de un negocio.
        /// </summary>
        /// <param name="codNegocio"></param>
        /// <returns></returns>
        public void EliminarEstructuraVentaPlanAdquiridos(string IdEb)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect planAdquirido = new Conect(this.CurrentLine);
            planAdquirido.commandQuery = NAB_VENTA_ELIMINAR_PLAN_ADQUIRIDOS;
            planAdquirido.addParameters("id_eb ", IdEb);
            planAdquirido.execTransac(true);
        }

        /// <summary>
        /// Obtener informacion de los usuarios autorizados por contrato.
        /// </summary>
        /// <param name="codigoContrato">Codigo del contrato</param>
        /// <returns></returns>
        protected DataTable ObtenerUsuariosAutorizados(string codigoContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_USUARIO_AUTORIZADOS;
            documentos.addParameters("ID_CODIGO_NEGOCIO", codigoContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion de los usuarios autorizados
        /// </summary>
        /// <param name="codigoContrato"></param>
        /// <returns></returns>
        public ContratoUsuarioAutorizado ObtenerUsuariosAutorizadosPorContrato(string codigoContrato)
        {
            ContratoUsuarioAutorizado usuariosAutorizados = null;
            try
            {
                var entities = this.ObtenerUsuariosAutorizados(codigoContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                else if (entities.Rows.Count > 0)
                {
                    DataRow dr = entities.Rows[0];
                    usuariosAutorizados = new ContratoUsuarioAutorizado(dr);
                }
            }
            catch (Exception exc)
            {
                usuariosAutorizados = null;
            }
            return usuariosAutorizados;
        }

        /// <summary>
        /// Obtener informacion de los usuarios autorizados por contrato.
        /// </summary>
        /// <param name="codigoContrato">Codigo del contrato</param>
        /// <returns></returns>
        protected DataTable ObtenerInformacionAdicional(string codigoContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_INFORMACION_ADICIONAL;
            documentos.addParameters("ID_CODIGO_NEGOCIO", codigoContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion adicional del negocio.
        /// </summary>
        /// <param name="codigoContrato"></param>
        /// <returns></returns>
        public InformacionAdicionalNegocio ObtenerInformacionAdicionalNegocio(string codigoContrato)
        {
            InformacionAdicionalNegocio informacionAdicional = new InformacionAdicionalNegocio();
            try
            {
                var entities = this.ObtenerInformacionAdicional(codigoContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                else if (entities.Rows.Count > 0)
                {
                    DataRow dr = entities.Rows[0];
                    informacionAdicional = new InformacionAdicionalNegocio(dr);
                }
            }
            catch (Exception exc)
            {
                informacionAdicional = null;
            }
            return informacionAdicional;
        }

        /// <summary>
        /// Obtener informacion adicioneal de condiciones uniformes del negocio.
        /// </summary>
        /// <param name="codigoContrato">Codigo del contrato</param>
        /// <returns></returns>
        protected DataTable ObtenerInformacionAdicionalCondicionesUniformes(string codigoContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_CONDICIONES_UNIFORMES_INFO_ADICIONAL;
            documentos.addParameters("ID_CODIGO_NEGOCIO", codigoContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion adicional de condiciones uniformes del negocio.
        /// </summary>
        /// <param name="codigoContrato"></param>
        /// <returns></returns>
        public CondicionesUniformesInfoAdicional ObtenerInformacionAdicionalCondicionesUniformesNegocio(string codigoContrato)
        {
            CondicionesUniformesInfoAdicional informacionAdicional = new CondicionesUniformesInfoAdicional();
            try
            {
                var entities = this.ObtenerInformacionAdicionalCondicionesUniformes(codigoContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                else if (entities.Rows.Count > 0)
                {
                    DataRow dr = entities.Rows[0];
                    informacionAdicional = new CondicionesUniformesInfoAdicional(dr);
                }
            }
            catch (Exception exc)
            {
                informacionAdicional = null;
            }
            return informacionAdicional;
        }

        /// <summary>
        /// Obtener datos de la lista de documentos de asociados a un contrato.
        /// </summary>
        /// <param name="idContrato">Id de Contrato</param>
        /// <returns></returns>
        protected DataTable ObtenerPlanesAdquiridosInfo(string idContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_PLANES_ADQUIRIDOS;
            documentos.addParameters("id_eb", idContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener informacion de documentos asociados un contrato.
        /// </summary>
        /// <param name="idContrato">Id de Contrato.</param>
        /// <returns></returns>
        public IEnumerable<PlanAdquiridoNegocio> ObtenerPlanesAdquiridosNegocio(string idContrato)
        {
            List<PlanAdquiridoNegocio> planes = new List<PlanAdquiridoNegocio>();
            try
            {
                var entities = this.ObtenerPlanesAdquiridosInfo(idContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new PlanAdquiridoNegocio(dr);
                    planes.Add(item);
                }
            }
            catch (Exception exc)
            {
                planes = new List<PlanAdquiridoNegocio>();
            }
            return planes;
        }

        /// <summary>
        /// Obtener informacion de venta a cuotas de un negocio seleccionado.
        /// </summary>
        /// <param name="idContrato"></param>
        /// <returns></returns>
        public DataTable ObtenerVentaACoutasInfo(string idContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_VENTA_A_CUOTAS;
            documentos.addParameters("ID_CODIGO_NEGOCIO", idContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion de venta a cuotas de un negocio seleccionado.
        /// </summary>
        /// <param name="idContrato"></param>
        /// <returns></returns>
        public IEnumerable<NAB_VENTAS_VENTA_A_CUOTAS> ObtenerVentaACoutas(string idContrato)
        {
            List<NAB_VENTAS_VENTA_A_CUOTAS> planes = new List<NAB_VENTAS_VENTA_A_CUOTAS>();
            try
            {
                var entities = this.ObtenerVentaACoutasInfo(idContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new NAB_VENTAS_VENTA_A_CUOTAS(dr);
                    planes.Add(item);
                }
            }
            catch (Exception exc)
            {
                planes = new List<NAB_VENTAS_VENTA_A_CUOTAS>();
            }
            return planes;
        }

        public DataTable ObtenerCobroRevertidoInfo(string idContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect cobroRevertido = new Conect(this.CurrentLine);
            cobroRevertido.commandQuery = NAB_VENTA_COBRO_REVERTIDO;
            cobroRevertido.addParameters("Cod_negocio", idContrato);
            return cobroRevertido.getDataTable(true);
        }


        /// <summary>
        /// Obtener informacion de venta a cuotas de un negocio seleccionado.
        /// </summary>
        /// <param name="idContrato"></param>
        /// <returns></returns>
        public DataTable ObtenerEmpresaLineaInfo(string IdEb)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_EMPRESA_LINEA_CONSULTA;
            documentos.addParameters("id_eb", IdEb);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener la informacion de venta a cuotas de un negocio seleccionado.
        /// </summary>
        /// <param name="idContrato"></param>
        /// <returns></returns>
        public IEnumerable<nab_Empresa_linea> ObtenerEmpresaLinea(string idContrato)
        {
            List<nab_Empresa_linea> empresaLinea = new List<nab_Empresa_linea>();
            try
            {
                var entities = this.ObtenerEmpresaLineaInfo(idContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new nab_Empresa_linea(dr);
                    empresaLinea.Add(item);
                }
            }
            catch (Exception exc)
            {
                empresaLinea = new List<nab_Empresa_linea>();
            }
            return empresaLinea;
        }

        /// <summary>
        /// Obtener radicaciones de negocio existentes en el sistema.
        /// </summary>
        /// <param name="idUsuario">Id Usuario</param>
        /// <param name="numeroContrato">Numero de contrato</param>
        /// <param name="numeroIdentificacion">Numero de identificacion</param>
        /// <param name="vista">Vista</param>
        /// <returns></returns>
        public IEnumerable<RadicacionNegocio> ObtenerRadicacioneNegocio(string idUsuario, string numeroContrato = "", string numeroIdentificacion = "", string vista = "Recientes")
        {
            var radicaciones = this.GetAll(idUsuario, vista);
            radicaciones = this.SearchInfo(radicaciones, numeroContrato, numeroIdentificacion);
            return radicaciones;
        }

        public IEnumerable<RadicacionNegocio> GetAll(string idUsuario, string vista)
        {
            List<RadicacionNegocio> radicaciones = new List<RadicacionNegocio>();
            try
            {
                var entities = this.GetData(idUsuario, vista);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new RadicacionNegocio(dr);
                    radicaciones.Add(item);
                }
            }
            catch (Exception exc)
            {
                radicaciones = new List<RadicacionNegocio>();
            }
            return radicaciones;
        }

        /// <summary>
        /// Obtener datos de la base de datos.
        /// </summary>
        /// <param name="idUsuario"></param>
        /// <param name="numeroContrato"></param>
        /// <param name="numeroIdentificacion"></param>
        /// <param name="vista"></param>
        /// <returns></returns>
        protected DataTable GetData(string idUsuario, string vista)
        {
            CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect recientesList = new Conect(CurrentLine);
            recientesList.commandQuery = NAB_EB_COMERCIALCONSULTA_NEGOCIOS;
            recientesList.addParameters("user", idUsuario);
            recientesList.addParameters("id_eb", "");
            recientesList.addParameters("numIdent", "");
            recientesList.addParameters("vista", vista);
            return recientesList.getDataTable(true);
        }

        private IEnumerable<RadicacionNegocio> SearchInfo(IEnumerable<RadicacionNegocio> entities, string numeroContrato, string numeroIdentificacion)
        {
            var dataSource = entities;
            IEnumerable<RadicacionNegocio> searchResult = null;
            Func<RadicacionNegocio, bool> filterCriteria = p => true;
            var filterHelper = new FilterHelper<RadicacionNegocio>();
            //Radicado de negocio
            if (!string.IsNullOrEmpty(numeroContrato))
            {
                filterCriteria = filterHelper.AddFilterExpression(filterCriteria, p => p.RADICADO.ToUpper(CultureInfo.InvariantCulture)
                    .Contains(numeroContrato.ToUpper(CultureInfo.InvariantCulture)));
            }
            //Numero de identificacion
            if (!string.IsNullOrEmpty(numeroIdentificacion))
            {
                filterCriteria = filterHelper.AddFilterExpression(filterCriteria, p => p.COD_VENDEDOR.ToUpper(CultureInfo.InvariantCulture)
                    .Contains(numeroIdentificacion.ToUpper(CultureInfo.InvariantCulture)));
            }
            if (filterCriteria != null)
            {
                searchResult = dataSource.Where(filterCriteria);
                return searchResult;
            }
            return dataSource;
        }

        public void RadicarDocumentos(string negocio, string idDocumento)
        {
            try
            {
                int currentLines = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect userConection = new Conect(currentLines);
                //userConection.commandQuery = "Nab_Eb_Insertar_Documento_Negocio";
                userConection.commandQuery = "Nab_SP_Comercial_Insertar_Documento";
                userConection.addParameters("IdEb", negocio);
                userConection.addParameters("IdDocumento", idDocumento);
                userConection.execQuery(true);
            }
            catch (Exception)
            {
                throw new Exception("Error guardando documentos");
            }
        }

        public void RadicarDocumentos(string negocio, Documentos documento)
        {
            this.RadicarDocumentos(negocio, ((int)documento).ToString());

        }

        public static IEnumerable<CREDITO_ESTRUCTURA_VENTA> ObtenerEstructuraVentaEquipos(string idEB)
        {
            try
            {
                List<CREDITO_ESTRUCTURA_VENTA> result = new List<CREDITO_ESTRUCTURA_VENTA>();
                int currentLines = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect userConection = new Conect(currentLines);
                //userConection.commandQuery = "Nab_Credito_Estructura_Venta";
                userConection.commandQuery = "Nab_SP_Comercial_Estructura_Venta";
                userConection.addParameters("id_eb", idEB);
                DataTable entities = userConection.getDataTable(true);
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new CREDITO_ESTRUCTURA_VENTA(dr);
                    result.Add(item);
                }
                return result;
            }
            catch (Exception)
            {
                return null;
            }

        }

        /// <summary>
        /// Guardar el anexo del contratod de condiciones uniformes
        /// </summary>
        /// <param name="anexo"></param>
        public bool GuardarAnexoCondicionesUniformes(AnexoCondicionesUniformesContrato anexo)
        {
            try
            {
                this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect anexoCondicionesUniformes = new Conect(this.CurrentLine);
                anexoCondicionesUniformes.commandQuery = NAB_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL_ANEXO;
                anexoCondicionesUniformes.addParameters("ID_NEGOCIO", anexo.IdEb);
                anexoCondicionesUniformes.addParameters("RENOVACION", anexo.Renovacion);

                anexoCondicionesUniformes.execQuery(true);
                return (anexoCondicionesUniformes.numRows > 0);
            }
            catch (Exception)
            {
                throw new Exception("Error guardando anexo");
            }
        }

        /// <summary>
        /// Consulta del anexo del contrato de condiciones uniformes
        /// </summary>
        /// <param name="idEb"></param>
        /// <returns></returns>
        public AnexoCondicionesUniformesContrato ObtenerAnexoCondicionesUniformes(string idEb)
        {
            try
            {
                AnexoCondicionesUniformesContrato anexoResult = null;
                this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect anexoCondicionesUniformes = new Conect(this.CurrentLine);
                anexoCondicionesUniformes.commandQuery = NAB_OBTENER_VENTAS_CONDICIONES_UNIFORMES_INFORMACION_ADICIONAL_ANEXO;
                anexoCondicionesUniformes.addParameters("ID_NEGOCIO", idEb);
                anexoCondicionesUniformes.execQuery(true);
                if (anexoCondicionesUniformes.numRows > 0)
                {
                    anexoResult = new AnexoCondicionesUniformesContrato();
                    anexoResult.IdEb = idEb;
                    anexoResult.Renovacion = Convert.ToBoolean(anexoCondicionesUniformes.getColumnValue("RENOVACION"));
                }
                return anexoResult;
            }
            catch (Exception)
            {

                throw new Exception("Error en la consulta del anexo de contrato de condiciones uniformes");
            }

        }

        public IEnumerable<ActivacionPlan> ObtenerActivacionRobot(string idEb)
        {
            IEnumerable<ActivacionPlan> result = new List<ActivacionPlan>();
            try
            {
                CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect activacionesResultado = new Conect(CurrentLine);
                activacionesResultado.commandQuery = NAB_OBTENER_ACTIVACION_ROBOT;
                activacionesResultado.addParameters("id_eb", idEb);
                DataTable resultadoConsulta = activacionesResultado.getDataTable(true);
                if (resultadoConsulta.Rows.Count > 0)
                {
                    result = resultadoConsulta.AsEnumerable().Select(x =>

                        new ActivacionPlan()
                        {
                            Contrato = x.Field<string>("CONTRATO"),
                            Simcard = x.Field<string>("SIMCARD"),
                            ProcedenciaImei = x.Field<string>("PROCEDENCIAIMEI"),
                            Imei = x.Field<string>("IMEI"),
                            FechaActivacion = x.Field<DateTime>("FECHAACTIVACION")
                        }
                    );
                }
                return result;
            }
            catch (Exception)
            {
                return result;
            }
        }

        public bool GuardarEmpresaLinea(EmpresaEnLinea empresa)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect conect = new Conect(this.CurrentLine);
            //conect.commandQuery = "Nab_Empresa_Linea_Insertar";
            conect.commandQuery = "Nab_SP_Comercial_Empresa_Linea_Insertar";
            conect.addParameters("ConsecutivoContrato", empresa.IdEb);
            conect.addParameters("cantLicencias", empresa.CantidadLicencias);
            conect.addParameters("valorMensual", empresa.ValorMensual);
            conect.addParameters("ciudadFirma", empresa.CiudadFirma);
            conect.addParameters("email", empresa.Email);
            string comando = conect.GetCommand();
            conect.execTransac(true);
            if (conect.numRows > 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Guardar informacion de anexo otro si para contrato de condiciones uniformes.
        /// </summary>
        /// <param name="anexo">Informacion de anexo otro si.</param>
        /// <returns></returns>
        public bool GuardarAnexosOtrosSiCondicionesUniformes(NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES anexo)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect negocio = new Conect(this.CurrentLine);
            negocio.commandQuery = NAB_VENTAS_AGREGAR_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES;
            negocio.addParameters("NUMERO_LINEA", anexo.NUMERO_LINEA);
            negocio.addParameters("NUMERO_CELULAR", anexo.NUMERO_CELULAR);
            negocio.addParameters("CODIGO_PLAN_CODIGO_PLAN", anexo.CODIGO_PLAN_CODIGO_PLAN);
            negocio.addParameters("CODIGO_PLAN_RENTA_BASICA", anexo.CODIGO_PLAN_RENTA_BASICA);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_VOZ_SI", anexo.CONTROL_CONDICIONES_SERVICIO_VOZ_SI);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_VOZ_NO", anexo.CONTROL_CONDICIONES_SERVICIO_VOZ_NO);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_SMS_SI", anexo.CONTROL_CONDICIONES_SERVICIO_SMS_SI);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_SMS_NO", anexo.CONTROL_CONDICIONES_SERVICIO_SMS_NO);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_DATOSSI", anexo.CONTROL_CONDICIONES_SERVICIO_DATOSSI);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_DATOSNO", anexo.CONTROL_CONDICIONES_SERVICIO_DATOSNO);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_LDISI", anexo.CONTROL_CONDICIONES_SERVICIO_LDISI);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_LDINO", anexo.CONTROL_CONDICIONES_SERVICIO_LDINO);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_PREMIUMSI", anexo.CONTROL_CONDICIONES_SERVICIO_PREMIUMSI);
            negocio.addParameters("CONTROL_CONDICIONES_SERVICIO_PREMIUMNO", anexo.CONTROL_CONDICIONES_SERVICIO_PREMIUMNO);
            negocio.addParameters("VALOR_MINUTO_INCLUIDO_VOZ_M", anexo.VALOR_MINUTO_INCLUIDO_VOZ_M);
            negocio.addParameters("VALOR_MINUTO_INCLUIDO_VOZ_F", anexo.VALOR_MINUTO_INCLUIDO_VOZ_F);
            negocio.addParameters("VALOR_MINUTO_INCLUIDO_VOZ_G", anexo.VALOR_MINUTO_INCLUIDO_VOZ_G);
            negocio.addParameters("VALOR_MINUTO_INCLUIDO_VOZ_O", anexo.VALOR_MINUTO_INCLUIDO_VOZ_O);
            negocio.addParameters("VALOR_MINUTO_ADICIONAL_VOZ_M", anexo.VALOR_MINUTO_ADICIONAL_VOZ_M);
            negocio.addParameters("VALOR_MINUTO_ADICIONAL_VOZ_F", anexo.VALOR_MINUTO_ADICIONAL_VOZ_F);
            negocio.addParameters("VALOR_MINUTO_ADICIONAL_VOZ_G", anexo.VALOR_MINUTO_ADICIONAL_VOZ_G);
            negocio.addParameters("VALOR_MINUTO_ADICIONAL_VOZ_O", anexo.VALOR_MINUTO_ADICIONAL_VOZ_O);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_INCLUIDO_M", anexo.VALOR_MENSAJE_TEXTO_INCLUIDO_M);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_INCLUIDO_G", anexo.VALOR_MENSAJE_TEXTO_INCLUIDO_G);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_INCLUIDO_O", anexo.VALOR_MENSAJE_TEXTO_INCLUIDO_O);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_ADICIONAL_M", anexo.VALOR_MENSAJE_TEXTO_ADICIONAL_M);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_ADICIONAL_G", anexo.VALOR_MENSAJE_TEXTO_ADICIONAL_G);
            negocio.addParameters("VALOR_MENSAJE_TEXTO_ADICIONAL_O", anexo.VALOR_MENSAJE_TEXTO_ADICIONAL_O);
            negocio.addParameters("PLAN_DE_DATOS_CODIGO_SERVICIO", anexo.PLAN_DE_DATOS_CODIGO_SERVICIO);
            negocio.addParameters("PLAN_DE_DATOS_RENTA_MENSUAL", anexo.PLAN_DE_DATOS_RENTA_MENSUAL);
            negocio.addParameters("PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN", anexo.PLAN_DE_DATOS_CAPACIDAD_DEL_PLAN);
            negocio.addParameters("PLAN_DE_DATOSKBADICIONAL", anexo.PLAN_DE_DATOSKBADICIONAL);
            negocio.addParameters("EQUIPO_TRAIDO", anexo.EQUIPO_TRAIDO);
            negocio.addParameters("EQUIPO_VENDIDO", anexo.EQUIPO_VENDIDO);
            negocio.addParameters("EQUIPO_MARCA_EQUIPO", anexo.EQUIPO_MARCA_EQUIPO);
            negocio.addParameters("EQUIPO_REF_MODELO", anexo.EQUIPO_REF_MODELO);
            negocio.addParameters("EQUIPO_NOSERIAL_IMEI", anexo.EQUIPO_NOSERIAL_IMEI);
            negocio.addParameters("BANDA_EQUIPO_AWS", anexo.BANDA_EQUIPO_AWS);
            negocio.addParameters("BANDA_EQUIPO_AWS_2500MHZ", anexo.BANDA_EQUIPO_AWS_2500MHZ);
            negocio.addParameters("BANDA_EQUIPO_OTRA", anexo.BANDA_EQUIPO_OTRA);
            negocio.addParameters("EQUIPO_VENTA_CUOTAS_SI", anexo.EQUIPO_VENTA_CUOTAS_SI);
            negocio.addParameters("EQUIPO_VENTA_CUOTAS_NO", anexo.EQUIPO_VENTA_CUOTAS_NO);
            negocio.addParameters("CUOTA_INICIAL", anexo.CUOTA_INICIAL);
            negocio.addParameters("VALOR_A_DIFERIR_EN_CUOTAS", anexo.VALOR_A_DIFERIR_EN_CUOTAS);
            negocio.addParameters("NO_DE_CUOTAS_A_DIFERIR", anexo.NO_DE_CUOTAS_A_DIFERIR);
            negocio.addParameters("NO_SIMCARD89", anexo.NO_SIMCARD89);
            negocio.addParameters("ID_CODIGO_NEGOCIO", anexo.ID_CODIGO_NEGOCIO);
            negocio.execTransac(true);
            return (negocio.numRows > 0);
        }

        /// <summary>
        /// Obtener informacion de anexos otros si para condiciones uniformes.
        /// </summary>
        /// <param name="codigoContrato">Codigo del contrato</param>
        /// <returns></returns>
        protected DataTable ObtenerAnexoOtrosSiCondicionesUniformesInfo(string codigoContrato)
        {
            this.CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.CurrentLine);
            documentos.commandQuery = NAB_VENTA_OBTENER_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES;
            documentos.addParameters("id_eb", codigoContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener informacion de anexos otros si para condiciones uniformes.
        /// </summary>
        /// <param name="codigoContrato">codigo del contrato</param>
        /// <returns></returns>
        public IEnumerable<NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES> ObtenerAnexoOtrosSiCondicionesUniformes(string codigoContrato)
        {
            List<NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES> infoNegocio = new List<NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES>();
            try
            {
                var entities = BNegocio.GetOtroSi(HttpContext.Current.User.Identity.Name, codigoContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow item in entities.Rows)
                {
                    var info = new NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES(item);
                    infoNegocio.Add(info);
                }
            }
            catch
            {
                infoNegocio = new List<NAB_VENTAS_ANEXO_OTROS_SI_CONDICIONES_UNIFORMES>();
            }
            return infoNegocio;
        }
    }
}