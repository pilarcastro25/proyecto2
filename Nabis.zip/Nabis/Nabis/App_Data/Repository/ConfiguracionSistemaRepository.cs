﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Nabis.Models.Entities;
using System.Diagnostics;
using Nabis.App_GlobalCode;
using System.Data;


namespace Nabis.Repository
{
    /// <summary>
    /// Repositorio encargado de traer la informacion de la configuracion.
    /// </summary>
    public static class ConfiguracionSistemaRepository
    {
        private static string NAB_CONFIGURACION_OBTENER_CADENA_CONEXION_EXCHANGE = "Nab_Configuracion_Obtener_Cadena_Conexion_Exchange";

        public static NAB_GLOBAL_P_CONFIGURACION_SISTEMA EncontrarPorAlias(string alias)
        {
            try
            {
                NAB_GLOBAL_P_CONFIGURACION_SISTEMA result = ObtenerTodos()
                    .FirstOrDefault(x => x.ALIAS.Equals(alias, StringComparison.InvariantCultureIgnoreCase));
                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Obtener cadena de conexion para el servidor de exchange.
        /// </summary>
        /// <returns></returns>
        public static string ObtenerCadenaConexionExchange()
        {
            string cadenaConexion = string.Empty;
            var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect configuracion = new Conect(currentLine);
            configuracion.commandQuery = NAB_CONFIGURACION_OBTENER_CADENA_CONEXION_EXCHANGE;
            configuracion.execQuery(true);
            cadenaConexion = configuracion.getColumnValue("CadenaConexion");
            return cadenaConexion;
        }

        /// <summary>
        /// Obtener todos los parametros del sistema 
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<NAB_GLOBAL_P_CONFIGURACION_SISTEMA> ObtenerTodos()
        {
            List<NAB_GLOBAL_P_CONFIGURACION_SISTEMA> items = new List<NAB_GLOBAL_P_CONFIGURACION_SISTEMA>();
            try
            {
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect configuracion = new Conect(currentLine);
                configuracion.commandQuery = string.Format("SELECT ID_CONFIGURACION, NOMBRE, ALIAS, VALOR, DESCRIPCION FROM NAB_GLOBAL_P_CONFIGURACION_SISTEMA");
                var data = configuracion.getDataTable(false);
                if (data == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in data.Rows)
                {
                    var item = new NAB_GLOBAL_P_CONFIGURACION_SISTEMA(dr);
                    items.Add(item);
                }
            }
            catch (Exception ex)
            {
                items = new List<NAB_GLOBAL_P_CONFIGURACION_SISTEMA>();
            }
            return items;
        }
    }
}