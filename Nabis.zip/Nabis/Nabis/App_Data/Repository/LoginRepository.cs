﻿using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    public class LoginRepository
    {
        private int currentLine;

        public LoginRepository(int currentLine)
        {
            this.currentLine = currentLine;

        }
        public Nab_Usuario_Consulta_Result Nab_Usuario_Consulta(string nh = null, string user = null, string nom = null, string reg = null, string area = null, string cc = null)
        {
            try
            {
                Nab_Usuario_Consulta_Result usuario = null;
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("nh", nh);
                userConection.addParameters("user", user);
                userConection.addParameters("nom", nom);
                userConection.addParameters("reg", reg);
                userConection.addParameters("area", area);
                userConection.addParameters("cc", cc);
                userConection.commandQuery = "Nab_Usuario_Consulta";
                userConection.execQuery(true);
                if (userConection.numRows > 0)
                {
                    usuario = new Nab_Usuario_Consulta_Result();
                    usuario.AREA = userConection.getColumnValue("AREA");
                    usuario.CLAVE = userConection.getColumnValue("CLAVE");
                    usuario.CONTADOR = (int?)Convert.ToInt32(userConection.getColumnValue("CONTADOR"));
                    usuario.ESTADO = userConection.getColumnValue("ESTADO");
                    usuario.GRUPO = userConection.getColumnValue("GRUPO");
                    usuario.PERFIL = userConection.getColumnValue("PERFIL");
                    usuario.PROCESO = userConection.getColumnValue("PROCESO");
                    usuario.REGIONAL = userConection.getColumnValue("REGIONAL");
                    usuario.TIPO = userConection.getColumnValue("TIPO");
                    usuario.USR_CELULAR = (decimal?)Convert.ToDecimal(userConection.getColumnValue("USR_CELULAR"));
                    usuario.USR_ID = userConection.getColumnValue("USR_ID");
                    usuario.USR_LOGIN = userConection.getColumnValue("USR_LOGIN");
                    usuario.USR_MAIL = userConection.getColumnValue("USR_MAIL");
                    usuario.USR_NOMBRE = userConection.getColumnValue("USR_NOMBRE");
                    usuario.CC = !String.IsNullOrEmpty(userConection.getColumnValue("CC")) ? Convert.ToInt64(userConection.getColumnValue("CC")) : (long?)null;
                    usuario.COD_VENDEDOR = !String.IsNullOrEmpty(userConection.getColumnValue("COD_VENDEDOR")) ? Convert.ToInt32(userConection.getColumnValue("COD_VENDEDOR")) : (int?)null;
                    usuario.COD_AGENTE = !String.IsNullOrEmpty(userConection.getColumnValue("COD_AGENTE")) ? Convert.ToInt32(userConection.getColumnValue("COD_AGENTE")) : (int?)null;
                    usuario.ID_CANAL_VENDEDOR = !String.IsNullOrEmpty(userConection.getColumnValue("ID_CANAL_VENDEDOR")) ? Convert.ToInt32(userConection.getColumnValue("ID_CANAL_VENDEDOR ")) : (int?)null;
                    usuario.CANAL_VENDEDOR = userConection.getColumnValue("CANAL_VENDEDOR");
                }

                return usuario;

            }
            catch (Exception)
            {
                throw new Exception("Falla en la conexión de red");
            }

        }
        public void Nab_Usuario_DesbloqueoLogin(string nh, string pass)
        {
            try
            {
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("nh", nh);
                userConection.addParameters("pass", pass);
                userConection.commandQuery = "Nab_Usuario_DesbloqueoLogin";
                userConection.execQuery(true);
            }
            catch (Exception)
            {

                throw new Exception("Error mientras se desbloqueaba el usuario");
            }


        }
        public string Nab_Obtener_Modulo(string nh)
        {
            try
            {
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("nh", nh);
                userConection.commandQuery = "Nab_Obtener_Modulo";
                userConection.execQuery(true);
                return userConection.numRows > 0 ? userConection.getColumnValue("MODULO") : null;
            }
            catch (Exception)
            {
                return null;
            }

        }
        public int Nab_Usuario_Bloquear(string user)
        {
            try
            {
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("user", user);
                userConection.commandQuery = "Nab_Usuario_Bloquear";
                userConection.execQuery(true);
                return Convert.ToInt32(userConection.getColumnValue("CONTADOR"));
            }
            catch (Exception)
            {

                throw;
            }
        }
        public NAB_GLOBAL_CORREO_DESBLOQUEO CorreoDesbloqueo()
        {
            try
            {
                NAB_GLOBAL_CORREO_DESBLOQUEO correo = null;
                Conect userConection = new Conect(currentLine);
                userConection.commandQuery = "Nab_Correo_Desbloqueo";
                userConection.execQuery(true);
                if (userConection.numRows > 0)
                {
                    correo = new NAB_GLOBAL_CORREO_DESBLOQUEO();
                    correo.IdCorreo = Convert.ToInt32(userConection.getColumnValue("IdCorreo"));
                    correo.Correo = userConection.getColumnValue("Correo");
                }
                return correo;
            }
            catch (Exception)
            {
                return null;
            }

        }
    }
}