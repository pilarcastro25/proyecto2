﻿using Nabis.App_GlobalCode;
using Nabis.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    /// <summary>
    /// Repositorio de lineas de portabilidad.
    /// </summary>
    public class LineaPortadaRepository
    {

        //private const string NAB_EB_RADNEGOCIOS_INFOLINEASPORTADAS = "Nab_Eb_radNegocios_infoLineasPortadas";
        private const string NAB_EB_RADNEGOCIOS_INFOLINEASPORTADAS = "Nab_SP_Comercial_Lineas_Portadas_info";
        /// <summary>
        /// Obtener datos lineas portadas.
        /// </summary>
        /// <param name="usuarionh"></param>
        /// <param name="numeroContrato"></param>
        /// <returns></returns>
        protected DataTable ObtenerLineasPortadasInfo(string usuarionh, string numeroContrato)
        {
            var CurrentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(CurrentLine);
            documentos.commandQuery = NAB_EB_RADNEGOCIOS_INFOLINEASPORTADAS;
            documentos.addParameters("user", usuarionh);
            documentos.addParameters("id_eb", numeroContrato);
            documentos.addParameters("vista", "Detalle");
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener informacion de documentos asociados un contrato.
        /// </summary>
        /// <param name="idContrato">Id de Contrato.</param>
        /// <returns></returns>
        public IEnumerable<LineaPortada> ObtenerLineasPortadas(string usuarionh, string numeroContrato)
        {
            List<LineaPortada> lineas = new List<LineaPortada>();
            try
            {
                var entities = this.ObtenerLineasPortadasInfo(usuarionh, numeroContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new LineaPortada(dr);
                    lineas.Add(item);
                }
            }
            catch (Exception exc)
            {
                lineas = new List<LineaPortada>();
            }
            return lineas;
        }


       /// <summary>
       /// Obtener informacion de lineas Portadas.
       /// </summary>
       /// <param name="CodNegocio"></param>
       /// <param name="IdUsuario"></param>
       /// <param name="vista"></param>
       /// <returns></returns>
        public static DataTable RetornarLineasPortadas(string IdUsuario,string CodNegocio,string vista, string identidadOrigen = null)
        {
            DataTable Dt = new DataTable();
            int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect transac = new Conect(currentLine);
            //transac.commandQuery = "Nab_Eb_radNegocios_infoLineasPortadas";
            transac.commandQuery = "Nab_SP_Comercial_Informacion_Lineas_Portadas";
            transac.addParameters("user", IdUsuario);
            transac.addParameters("id_eb", CodNegocio);
            transac.addParameters("vista", vista);
            transac.addParameters("identidad_origen", identidadOrigen);
            Dt = transac.getDataTable(true);
            return Dt;
        }
    }
}