﻿using Nabis.App_GlobalCode;
using Nabis.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    public enum Documentos
    {
        FUN = 1,
        SMP,
        PAGARE,
        A_PORTABILIDAD,
        A_MODIFICATORIO = 6,
        CEDULA,
        FUS,
        VAC,
        CH,
        CC,
        CM,
        CRL,
        SI,
        OTROS_SI,
        HR,
        A_SERVICIO_MOVIL,
        TRASPASO,
        CEL,
        A_MULTIDESTINO,
        M2M,
        M_LIBRE,
        FVI,
        Portabilidad,
        COBRO_REVERTIDO,
        MEPE,
        A_PRO,
        A_ILIMITADO,
        CUSM
    }
    public class DocumentoTipoContratoRepository
    {
        /// <summary>
        /// Nombre de procedimiento almancenado para obtener los negocios erradicados en el sistema
        /// </summary>
        private const string NAB_EB_DOCUMENTOS_NEGOCIO = "Nab_SP_Comercial_Negocio_Documentos_GetList";
        /// <summary>
        /// Nombre de procedimieno almacenado para obtener los documentos asociados a un negocio a 
        /// erradicar en el sistema
        /// </summary>
        //private const string NAB_EB_DOCUMENTOS_NEGOCIO_VISTA_PREVIA = "Nab_SP_Documentos_Negocio_Vista_Previa";
        private const string NAB_EB_DOCUMENTOS_NEGOCIO_VISTA_PREVIA = "Nab_SP_Comercial_Documentos_Vista_Previa";

        /// <summary>
        /// Linea actual sobre la cual se realiza el proceso.
        /// </summary>
        private int currentLine { get; set; }

        /// <summary>
        /// Obtener datos de la lista de documentos de asociados a un contrato.
        /// </summary>
        /// <param name="idTipoContrato">Id Tipo de contrato</param>
        /// <param name="idTipoSolicitud">Id Tipo de solicitud</param>
        /// <param name="idConvenio">Id de Marcacion especial</param>
        /// <param name="esPortabilidad">Es portabilidad</param>
        /// <returns></returns>
        protected DataTable GetData(int idTipoContrato, int idTipoSolicitud, int idConvenio, bool esPortabilidad)
        {
            this.currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.currentLine);
            documentos.commandQuery = NAB_EB_DOCUMENTOS_NEGOCIO_VISTA_PREVIA;
            documentos.addParameters("id_tipo_contrato", idTipoContrato);
            documentos.addParameters("id_tipo_solicitud", idTipoSolicitud);
            documentos.addParameters("id_convenio", idConvenio);
            documentos.addParameters("es_portabilidad", esPortabilidad);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener datos de la lista de documentos de asociados a un contrato.
        /// </summary>
        /// <param name="idContrato">Id de Contrato</param>
        /// <returns></returns>
        protected DataTable GetData(string idContrato)
        {
            this.currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect documentos = new Conect(this.currentLine);
            documentos.commandQuery = NAB_EB_DOCUMENTOS_NEGOCIO;
            documentos.addParameters("id_contrato", idContrato);
            return documentos.getDataTable(true);
        }

        /// <summary>
        /// Obtener informacion de documentos asociados un contrato.
        /// </summary>
        /// <param name="idContrato">Id de Contrato.</param>
        /// <returns></returns>
        public IEnumerable<DocumentoTipoContrato> ObtenerDocumentos(string idContrato)
        {
            List<DocumentoTipoContrato> documentos = new List<DocumentoTipoContrato>();
            try
            {
                var entities = this.GetData(idContrato);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new DocumentoTipoContrato(dr);
                    documentos.Add(item);
                }
            }
            catch (Exception exc)
            {
                documentos = new List<DocumentoTipoContrato>();
            }
            return documentos;
        }

        /// <summary>
        /// Obtener informacion de los documentos obligatorios para un contrato
        /// </summary>
        /// <param name="idTipoContrato">Id Tipo de contrato</param>
        /// <param name="idTipoSolicitud">Id Tipo de solicitud</param>
        /// <param name="idConvenio">Id de Marcacion especial</param>
        /// <param name="esPortabilidad">Es portabilidad</param>
        /// <returns></returns>
        public IEnumerable<DocumentoTipoContrato> ObtenerDocumentos(int idTipoContrato, int idTipoSolicitud, int idConvenio, bool esPortabilidad)
        {
            List<DocumentoTipoContrato> documentos = new List<DocumentoTipoContrato>();
            try
            {
                var entities = this.GetData(idTipoContrato, idTipoSolicitud, idConvenio, esPortabilidad);
                if (entities == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in entities.Rows)
                {
                    var item = new DocumentoTipoContrato(dr);
                    documentos.Add(item);
                }
            }
            catch (Exception exc)
            {
                documentos = new List<DocumentoTipoContrato>();
            }
            return documentos;
        }
    }
}