﻿using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;

namespace Nabis.Repository
{
    /// <summary>
    /// Repositorio que se conecta con la informacion de codigos de cliente de e-bussiness.
    /// </summary>
    public class BCRobSCLClientesRepository
    {
        /// <summary>
        /// Cadena de conexion a e-bussiness.
        /// </summary>
        private const string CONEXION_EB = "EB";

        public static IEnumerable<BC_RobSCL_Clientes> ObtenerCodigosCliente(string numeroIdentificacion)
        {
            List<BC_RobSCL_Clientes> items = new List<BC_RobSCL_Clientes>();
            try
            {
                StringBuilder stbQuery = new StringBuilder();
                var currentLine = new StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect configuracion = new Conect(currentLine, CONEXION_EB);
                stbQuery.Append("SELECT CU.*, CL.Cod_Cliente ");
                stbQuery.Append("FROM CCC.dbo.BC_RobSCL_Clientes CL ");
                stbQuery.Append("JOIN CCC.dbo.BC_RobSCL_Cuentas CU ON CL.Cod_Cuenta = CU.Cod_Cuenta ");
                stbQuery.Append(string.Format("WHERE RTRIM(LTRIM(CU.Num_Ident)) = RTRIM(LTRIM('{0}'))", numeroIdentificacion));
                configuracion.commandQuery = stbQuery.ToString();
                var data = configuracion.getDataTable(false);
                if (data == null)
                {
                    throw new Exception();
                }
                foreach (DataRow dr in data.Rows)
                {
                    var item = new BC_RobSCL_Clientes(dr);
                    items.Add(item);
                }
            }
            catch (Exception ex)
            {
                items = new List<BC_RobSCL_Clientes>();
            }
            return items;
        }
    }
}