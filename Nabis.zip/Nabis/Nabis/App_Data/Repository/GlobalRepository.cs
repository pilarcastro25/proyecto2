﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    public class GlobalRepository
    {
        public bool InsertarModuloNegocio() {
            throw new Exception("En etapa de desarrollo");
        }
    }
}