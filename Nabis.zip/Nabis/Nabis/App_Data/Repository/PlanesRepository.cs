﻿using Nabis.App_GlobalCode;
using Nabis.Models.Entities;
using Nabis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nabis.Repository
{
    public class PlanesRepository
    {
        public static string EliminarPlan(string codigo)
        {
            try
            {
                //ctx.Nab_Eliminar_Plan(codigo);
                //return "Plan eliminado";
                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("cod", codigo);
                userConection.commandQuery = "Nab_Eliminar_Plan";
                userConection.execQuery(true);

                return "Plan eliminado";
            }
            catch (Exception)
            {
                return "Error mientras se desbloqueaba el usuario";
            }
        }
        public static string IngresarPlan(string codigo, string descripcion, int tipo)
        {
            try
            {
                //ctx.Nab_Insertar_Plan(codigo, descripcion, tipo);

                int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
                Conect userConection = new Conect(currentLine);
                userConection.addParameters("cod", codigo);
                userConection.addParameters("descripcion", descripcion);
                userConection.addParameters("idTipo", tipo);
                userConection.commandQuery = "Nab_Insertar_Plan";
                userConection.execQuery(true);

                return "Plan ingresado con éxito";

            }
            catch (Exception)
            {

                return "Error ingresando nuevo plan";
            }
        }
        public static void EditarPlan(GridPlanes plan, string tipo)
        {
            //ctx.Nab_Modificar_Plan(plan.IdPlan, plan.CodPlan, plan.Descripcion, Convert.ToInt32(tipo));

            int currentLine = new System.Diagnostics.StackTrace(true).GetFrame(0).GetFileLineNumber();
            Conect userConection = new Conect(currentLine);
            userConection.addParameters("id", plan.IdPlan);
            userConection.addParameters("cod", plan.CodPlan);
            userConection.addParameters("descripcion", plan.Descripcion);
            userConection.addParameters("tipo", Convert.ToInt32(tipo));
            userConection.commandQuery = "Nab_Modificar_Plan";
            userConection.execQuery(true);

        }
    }
}