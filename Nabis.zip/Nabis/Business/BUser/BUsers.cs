﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSUsers;
using System.Data;


namespace Nabis_BS.BUser
{
    public class BUsersAccounts
    {
        public static User GetUserInfo(string userLogin)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                User usuario = userCliente.GetUserInfo(userLogin);
                return usuario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public User GetUser(string user, int IdCanal)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                User usuario = userCliente.GetUser(user, IdCanal.ToString());
                return usuario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static UserLogin Login(string user, string password)
        {
            try {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                UserLogin usuario = userCliente.Login(user, password);
                return usuario; 
            }catch(Exception ex){
                throw ex;
            }
        }

        public bool RegistrarUsuario(string userLogin, User userNew, int[] roles, ref string msg)
        {
            try{
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.Insert(userLogin, userNew, roles.ToList(), ref msg);
            }
            catch (Exception ex){
                throw ex;
            }
        }

        public bool ActualizarUsuario(string userLogin, User userUpdate)
        {
            try{
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.Update(userLogin, userUpdate);
            }
            catch (Exception ex){
                throw ex;
            }
        }

        public static string[] GetRolesForUser(string userLogin)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.GetUserRolesForUser(userLogin).ToArray();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool UserInRole(string userLogin, string RolName)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.UserInRole(userLogin, RolName);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool InsertRoles(string userLogin, string idUser, int[] roles, ref string msg)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.InsertRoles(userLogin, idUser, roles.ToList() , ref msg);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool DeleteRoles(string userLogin, string idUser, int[] roles, ref string msg)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                return userCliente.DeleteRoles(userLogin, idUser, roles.ToList(), ref msg);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<GenericOption> GetUsersInRol(string rolesNamesList)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                List<GenericOption> usersList = userCliente.GetUsersInRol(rolesNamesList);
                return usersList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<GenericOption> GetListRolesInUser(string idUser)
        {
            try
            {
                NabWSUsers.UsersClient userCliente = new NabWSUsers.UsersClient();
                List<GenericOption> usersList = userCliente.GetRolesForUser(idUser);
                return usersList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
