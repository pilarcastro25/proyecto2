﻿using Nabis_BS.NabWSAtlantida;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.Activaciones
{
    public static class AtlantidaBL
    {
        /// <summary>
        /// Método de inserción individual de aprovisionamientos
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool Insertaraprovisionamiento(AprovisionamientoAtlantida datos)
        {
            AtlantidaClient aprovisionamientoClient = new AtlantidaClient();
            bool result = aprovisionamientoClient.InsertarAprovisionamiento(datos);
            return result;
        }
        /// <summary>
        /// Método de inserción masiva de aprovisionamientos
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertaraprovisionamientoMasivo(List<AprovisionamientoAtlantida> datos)
        {
            AtlantidaClient aprovisionamientoClient = new AtlantidaClient();
            bool result = aprovisionamientoClient.InsertarAprovisionamientoMasivo(datos);
            return result;
        }
    }
}
