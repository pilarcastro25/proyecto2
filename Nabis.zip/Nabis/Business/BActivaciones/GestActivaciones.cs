﻿using Nabis_BS.NabWSActivaciones;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls;

//using System.Web.UI.WebControls;
namespace Nabis_BS.BActivaciones
{
	public class GestActivaciones
	{
		#region CONSTANTES

		/// <summary>
		/// Nombre SP que carga los registros en la bandeja del analista
		/// </summary>
		private const string BANDEJA_ANALISTA = "Nab_SP_Activaciones_Cargar_Bandeja";

		#endregion CONSTANTES

		#region METODOS

		/// <summary>
		/// Actualiza el codigo de cliente del negocio
		/// </summary>
		/// <param name="Negocio"></param>
		/// <param name="usuario"></param>
		/// <param name="cod_cliente"></param>
		/// <returns></returns>
		public static bool Actualizar_CodCliente(string Negocio, string Usuario, string Cod_Cliente)
		{
			return ActualizarInformacionPreadi(Negocio, Usuario, Cod_Cliente, 0, null, null, null, 0);
		}

		/// <summary>
		/// Actualización del código de vendedor del negocio
		/// </summary>
		/// <param name="Negocio"></param>
		/// <param name="Usuario"></param>
		/// <param name="Cod_Vendedor"></param>
		/// <returns></returns>
		public static bool Actualizar_CodVendedor(string Negocio, string Usuario, string Cod_Vendedor)
		{
			return ActualizarInformacionPreadi(Negocio, Usuario, null, 0, null, Cod_Vendedor, null, 0);
		}

		/// <summary>
		/// Actualización de la fecha de programación
		/// </summary>
		/// <param name="Negocio"></param>
		/// <param name="Usuario"></param>
		/// <param name="fec_prog"></param>
		/// <returns></returns>
		public static bool Actualizar_FecProgramada(string Negocio, string Usuario, int id_estructura, DateTime fec_prog)
		{
			return ActualizarInformacionPreadi(Negocio, Usuario, null, id_estructura, fec_prog, null, null, 0);
		}

		/// <summary>
		/// Actualización del Perfil de Contacto Autorizado
		/// </summary>
		/// <param name="Negocio"></param>
		/// <param name="Usuario"></param>
		/// <param name="Id_Perfil"></param>
		/// <param name="id_contacto_autorizado"></param>
		/// <returns></returns>
		public static bool Actualizar_PerfilContacto(string Negocio, string Usuario, string Id_Perfil, int id_contacto_autorizado)
		{
			return ActualizarInformacionPreadi(Negocio, Usuario, null, 0, null, null, Id_Perfil, id_contacto_autorizado);
		}

		/// <summary>
		/// que permite actualizar informacion a preauditor
		/// </summary>
		/// <param name="Negocio"></param>
		/// <param name="usuario_lg"></param>
		/// <param name="cod_cliente"></param>
		/// <param name="fec_prog"></param>
		/// <param name="cod_vend"></param>
		/// <param name="perfil_aut"></param>
		/// <returns></returns>
		public static bool ActualizarInformacionPreadi(string Negocio, string usuario_lg, string cod_cliente, int id_estructura, DateTime? fec_prog, string cod_vend, string perfil_aut, int id_contacto_autorizado)
		{
			ActivacionesClient actiserv = new ActivacionesClient();
			bool val = actiserv.ActualizarInformacion(Negocio, usuario_lg, cod_cliente, id_estructura, fec_prog, cod_vend, perfil_aut, id_contacto_autorizado);
			return val;
		}

		/// <summary>
		/// Activacion manual de negocios, envía directo a Logistica
		/// </summary>
		/// <param name="Negocios"></param>
		/// <param name="Observacion"></param>
		/// <returns></returns>
		public static bool AsignaManual(string Negocios, int Estructura, string Observacion)
		{
			ActivacionesClient activaciones = new ActivacionesClient();
			return activaciones.Manual(Negocios, Estructura, Observacion);
		}

		/// <summary>
		/// Asignacion de Negocios Masiva a robot
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static bool AsignaMasivoRobot(string Negocios, int Estructura, string Observacion)
		{
			ActivacionesClient activacionesServicio = new ActivacionesClient();
			return activacionesServicio.AsignacionRobotMasivo(Negocios, Estructura, Observacion);
		}

		/// <summary>
		/// Metodo para insertar novedades
		/// </summary>
		/// <param name="user_log"></param>
		/// <param name="Negocio"></param>
		/// <param name="user_log"></param>
		/// <param name="Negocio"></param>
		/// <param name="user_log"></param>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static bool IngresarNovedades(string CodNovedad, DateTime? FechaInicio, string CodNegocio, int IdCausal, int IdEstado, string Observaciones, string XmlNovedades)
		{
			ActivacionesClient actserv = new ActivacionesClient();
			bool val = actserv.Insertar_Novedades(CodNovedad, FechaInicio, CodNegocio, IdCausal, IdEstado, Observaciones, XmlNovedades);
			return val;
		}

		/// <summary>
		/// Método para la Obtener la informacion de Contactos Autorizados
		/// </summary>
		/// <param name="negocio"></param>
		/// <returns></returns>
		public static IEnumerable<ContactoAutorizadoET> ObtenerContactosAutorizados(string negocio)
		{
			try
			{
				ActivacionesClient activacionesServicio = new ActivacionesClient();
				IEnumerable<ContactoAutorizadoET> result = activacionesServicio.CargarContactosAutorizados(negocio);
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception("Error Cargando los Contactos Aut");
			}
		}

		/// <summary>
		/// Metodo que carga la Informacion de la Estructura de Venta
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerEstructuraVenta(string Negocio)
		{
			try
			{
				ActivacionesClient actiserv = new ActivacionesClient();
				DataTable result = actiserv.CargarEstructuraVenta(Negocio);
				return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Metodo que carga la Informacion de la Estructura de Venta
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerEstructuraVentaDetalle(string Negocio, int id_str_venta)
		{
			try
			{
				ActivacionesClient actiserv = new ActivacionesClient();
				DataTable result = actiserv.CargarEstructuraVentaDetalle(Negocio, id_str_venta);
				return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Metodo que carga la Informacion de los Contactos Autorizados asociados al Negocio
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static IEnumerable<ContactoAutorizadoET> ObtenerInfoAconta_Aut(string Negocio)
		{
			ActivacionesClient actiserv = new ActivacionesClient();
			IEnumerable<ContactoAutorizadoET> conta = actiserv.CargarContactosAutorizados(Negocio);
			return conta;
		}

		/// <summary>
		/// Método para la Obtencion de la informacion del Negocio Seleccionado
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static IEnumerable<InformacionNegocio> ObtenerInformacionNegocio(string Negocio)
		{
			try
			{
				ActivacionesClient servicioActi = new ActivacionesClient();
				IEnumerable<InformacionNegocio> Info = servicioActi.ObtenerInformacionNegocio(Negocio);
				return Info;
			}
			catch (Exception)
			{
				throw new Exception("Error cargando la informacion del Negocio");
			}
		}

		/// <summary>
		/// Metodo que carga la Informacion de los Contactos Autorizados asociados al Negocio
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerLineasNegocio(string Negocio)
		{
			ActivacionesClient actserv = new ActivacionesClient();
			DataTable dt = actserv.CargarLineasNegocio(Negocio);
			return dt;
		}

		/// <summary>
		/// Método para la Obtencion de negocios asociados al analista de Activaciones-Preauditoria
		/// </summary>
		/// <param name="usuario"></param>
		/// <returns></returns>
		public static DataTable ObtenerNegociosUsuarioActivaciones(string usuario, int TipoBandeja)
		{
			try
			{
				ActivacionesClient activacionesServicio = new ActivacionesClient();
				DataTable result = activacionesServicio.ObtenerNegocios(usuario, TipoBandeja);
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception("Error obteniendo negocios de activaciones en EB");
			}
		}

		/// <summary>
		/// Metodo que carga la Informacion de los Contactos Autorizados asociados al Negocio
		/// </summary>
		/// <param name="user_log"></param>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerNovedades(string user_log, string Negocio)
		{
			ActivacionesClient actserv = new ActivacionesClient();
			DataTable dt = actserv.CargarNovedades(user_log, Negocio);
			return dt;
		}

		/// <summary>
		/// Método para la Obtener los perfiles del autorizado
		/// </summary>
		/// <param name="negocio"></param>
		/// <returns></returns>
		public static ListItem[] ObtenerPerfilesAutorizados(string vista)
		{
			try
			{
				ActivacionesClient activacionesServicio = new ActivacionesClient();
				List<ListItem> list = activacionesServicio.GetGenericList("", vista, "").Select(x => new ListItem { Value = x.Id, Text = x.Value }).ToList();
				list.Insert(0, new ListItem { Text = "Seleccione", Value = "", Selected = true });
				return list.ToArray();
				//return result;
			}
			catch (Exception ex)
			{
				throw new Exception("Error Cargando los Contactos Aut");
			}
		}

        public static DataTable ListaReciclaje(string ideb)
        {
            ActivacionesClient actserv = new ActivacionesClient();
            DataTable dt = null;
            dt = actserv.ListaAbonadoReciclaje(ideb);
            return dt;
        }

		#endregion METODOS
	}
}