﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Nabis.Utilities;
using Nabis_BS.NabWSBeneficios;

namespace Business.Activaciones
{
    public static class BeneficiosBL
    {
        #region Métodos estáticos
        /// <summary>
        /// Insertar beneficios a lineas
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertarBeneficiosLineas(List<BeneficioLinea> datos)
        {
            try
            {
                BeneficiosClient beneficiosLineas = new BeneficiosClient();
                bool resultado = beneficiosLineas.InsertarBeneficiosLinea(datos);
                return resultado;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para la extracción de negocios asociados al analista
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<BandejaBeneficios> ObtenerNegociosUsuario(string usuario)
        {
            try
            {
                BeneficiosClient beneficiosServicio = new BeneficiosClient();
                IEnumerable<BandejaBeneficios> result = beneficiosServicio.ObtenerBandejaUsuario(usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para realizar el update de los registros de las líneas y su SD
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool ActualizarLineasMasivas(List<BeneficioLinea> datos)
        {
            try
            {
                BeneficiosClient beneficiosLineas = new BeneficiosClient();
                bool resultado = beneficiosLineas.ActualizarBeneficioLineasMasivo(datos);
                return resultado;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para realizar consulta de beneficios por negocio
        /// </summary>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static IEnumerable<BeneficioLinea> ConsultarBeneficios(string negocio)
        {
            try
            {
                BeneficiosClient beneficiosNegocio = new BeneficiosClient();
                IEnumerable<BeneficioLinea> beneficios = beneficiosNegocio.ConsultarBeneficiosNegocio(negocio);
                return beneficios;
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Trama para generar el excel
        /// </summary>
        /// <returns></returns>
        public static void GenerarExcelBeneficios(string ruta)
        {
            DateTime fecha = DateTime.Now;
            BeneficiosClient beneficiosExcel = new BeneficiosClient();
            IEnumerable<ExcelBeneficios> excel = beneficiosExcel.TramaBeneficios();
            if (excel.Count() > 0)
            {
                int i = 0;  
                DataTable datos = new DataTable();
                datos.Columns.Add("CONSECUTIVO", typeof(string));
                datos.Columns.Add("NIT", typeof(string));
                datos.Columns.Add("CELULAR", typeof(long));
                datos.Columns.Add("BENEFICIO", typeof(string));
                datos.Columns.Add("TRAMA", typeof(string));
                excel.ToList().ForEach(x =>
                {
                    i++;
                    datos.Rows.Add(x.IdEb, x.Identificacion, x.Celular, x.CodBeneficio, String.Format("{0}|{1}|L|{2}", x.Celular, x.CodBeneficio, x.Latencia));
                });

                GestionarArchivos.CrearExcel(String.Format("{0}/Beneficios_corporativos_{1}_SD", ruta, fecha.ToString("yyyyMMdd")), datos);
                GestionarArchivos.ExtraerArchivo(String.Format("{0}/", ruta), String.Format("Beneficios_corporativos_{0}_SD.xlsx", fecha.ToString("yyyyMMdd")), "xlsx");
            }

        } 
        #endregion
    }
}
