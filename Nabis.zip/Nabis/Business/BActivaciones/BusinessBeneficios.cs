﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Nabis_BS.NabWSBeneficios;

namespace Nabis_BS.Activaciones
{
    public static class BusinessBeneficios
    {
        /// <summary>
        /// Insertar beneficios a lineas
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertarBeneficiosLineas(List<BeneficioLinea> datos)
        {
            try
            {
                BeneficiosClient beneficiosLineas = new BeneficiosClient();
                bool resultado = false; //beneficiosLineas.InsertarBeneficiosLinea(datos);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para la extracción de negocios asociados al analista
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<BandejaBeneficios> ObtenerNegociosUsuario(string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                NabWSBeneficios.BeneficiosClient beneficiosServicio = new NabWSBeneficios.BeneficiosClient();
                IEnumerable<BandejaBeneficios> result = (List<BandejaBeneficios>)beneficiosServicio.ObtenerBandejaUsuario(usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para realizar el update de los registros de las líneas y su SD
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool ActualizarLineasMasivas(List<BeneficioLinea> datos)
        {
            try
            {
                NabWSBeneficios.BeneficiosClient beneficiosLineas = new NabWSBeneficios.BeneficiosClient();
                bool resultado = false;//beneficiosLineas.ActualizarBeneficioLineasMasivo(datos);
                return resultado;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }
        /// <summary>
        /// Método para realizar consulta de beneficios por negocio
        /// </summary>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static IEnumerable<BeneficioLinea> ConsultarBeneficios(string negocio)
        {
            try
            {
                NabWSBeneficios.BeneficiosClient beneficiosNegocio = new NabWSBeneficios.BeneficiosClient();
                IEnumerable<BeneficioLinea> beneficios = null;// (List<BeneficioLinea>)beneficiosNegocio.ConsultarBeneficiosNegocio(negocio);
                return beneficios;
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Trama para generar el excel
        /// </summary>
        /// <returns></returns>
        public static void GenerarExcelBeneficios()
        {
            NabWSBeneficios.BeneficiosClient beneficiosExcel = new NabWSBeneficios.BeneficiosClient();
            IEnumerable<ExcelBeneficios> excel = (IEnumerable<ExcelBeneficios>)beneficiosExcel.TramaBeneficios();

            //List<LineaInfo> lineas = this.RetornarListadeLineasDeBD();
            //if (lineas.Count > 0)
            //{
            //    int i = 0;
            //    DataTable datos = new DataTable();
            //    datos.Columns.Add("NUMERO LINEA", typeof(string));
            //    datos.Columns.Add("NUMERO CELULAR", typeof(string));
            //    datos.Columns.Add("CODIGO PLAN CODIGO PLAN", typeof(string));
            //    datos.Columns.Add("CODIGO PLAN RENTA BASICA", typeof(string));


            //    lineas.ForEach(x =>
            //    {
            //        i++;
            //        datos.Rows.Add(x.NumeroLinea, x.NumeroCelular, x.CodigoPlanCodigodeplan, x.CodigoPlanRentaBasica, x.ControlCondicionesServicioVozSi, x.ControlCondicionesServicioVozNo, x.ControlCondicionesServicioSMSSi
            //                        , x.ControlCondicionesServicioSMSNo, x.ControlCondicionesServicioDatosSi, x.ControlCondicionesServicioDatosNo, x.ControlCondicionesServicioLDISi, x.ControlCondicionesServicioLDINo, x.ControlCondicionesServicioPremiumSi
            //                        , x.ControlCondicionesServicioPremiumNo, x.ValorMinutoIncluidoVoz_M, x.ValorMinutoIncluidoVoz_F, x.ValorMinutoIncluidoVoz_G, x.ValorMinutoIncluidoVoz_O, x.ValorMinutoAdicionalVoz_M, x.ValorMinutoAdicionalVoz_F
            //                        , x.ValorMinutoAdicionalVoz_G, x.ValorMinutoAdicionalVoz_O, x.ValorMensajedeTextoIncluido_M, x.ValorMensajedeTextoIncluido_G, x.ValorMensajedeTextoIncluido_O, x.ValorMensajedeTextoAdicional_M, x.ValorMensajedeTextoAdicional_G
            //                        , x.ValorMensajedeTextoAdicional_O, x.PlanDeDatosCodigoServicio, x.PlanDeDatosRentaMensual, x.PlanDeDatosCapacidaddelPlan, x.PlanDeDatosKBAdicional, x.EquipoTraido, x.EquipoVendido, x.EquipoMarcaEquipo, x.EquipoRefModelo, x.EquipoNoSerialIMEI
            //                        , x.BandaEquipoAWS, x.BandaEquipoAWS_2500MHZ, x.BandaEquipoOTRA, x.EquipoVentaCuotas_SI, x.EquipoVentaCuotas_NO, x.CuotaInicial, x.ValoraDiferirenCuotas, x.NodeCuotasaDiferir, x.NoSIMCARD89, x.CodigoNegocio);
            //    });
            //    GestionarArchivos.CrearExcel(String.Format("{0}/{1}/OtroSi-{2}", this.RutaTemporales, this.CodigoNegocio, this.CodigoNegocio), datos);
            //}
        }
    }
}
