﻿using Nabis_BS.NabWSVerticales;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Business.Activaciones
{
    public static class VerticalesBL
    {
        #region Métodos estáticos
        /// <summary>
        /// Método para el ingreso de aprovisionamientos verticales por negocio
        /// </summary>
        /// <param name="aprovisionamiento"></param>
        /// <returns></returns>
        public static bool IngresarAprovisionamiento(AprovisionamientoVertical aprovisionamiento)
        {
            VerticalesClient verticalesService = new VerticalesClient();
            return verticalesService.IngresarAprovisionamiento(aprovisionamiento);
        }
        /// <summary>
        /// Método de consulta de aprovisionamientos verticales
        /// </summary>
        /// <param name="negocio"></param>
        /// <returns></returns>
        public static AprovisionamientoVertical ConsultarAprovisionamiento(string negocio)
        {
            VerticalesClient verticalesService = new VerticalesClient();
            return verticalesService.ConsultarAprovisionamiento(negocio);
        } 
	#endregion
    }
}
