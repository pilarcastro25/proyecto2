﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Nabis_BS.NabWSActivaciones;


//namespace Nabis_BS.BActivaciones
namespace Business.Activaciones
{
    public class BandejaActivacionesBL
    {
        #region Metodos

        /// <summary>
        /// Método para la Obtencion de negocios asociados al analista de Activaciones-Preauditoria
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static DataTable ObtenerNegociosUsuarioActivaciones(string usuario, int tipoBandeja)
        {
            try
            {
                ActivacionesClient activacionesServicio = new ActivacionesClient();
                DataTable result = activacionesServicio.ObtenerNegocios(usuario,tipoBandeja);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion
    }
}
