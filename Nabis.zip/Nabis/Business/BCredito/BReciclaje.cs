﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSCredito;

namespace Nabis_BS.BCredito
{
    public class BReciclaje
    {
        public bool RadicarLineasReciclaje(Reciclaje_ET recicla, ref string mensaje)
        {
            bool resultadoFinal = true;
            int isError=-1;
            try
            {
                CreditoClient credito = new CreditoClient();
                resultadoFinal = credito.LlenarReciclajes(recicla, ref isError);
                if (resultadoFinal)
                {
                    mensaje = "Se insertaron las lineas de reciclaje";
                }
                else
                {
                    mensaje = "Error al insertar las lineas de reciclaje. Comuniquese con la mesa de ayuda.";
                }
                return resultadoFinal;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
