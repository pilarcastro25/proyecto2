﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSCredito;

namespace Nabis_BS.BCredito
{
    public class BPortabilidad
    {
        /// <summary>
        /// Alias de portabilidad de lineas pendientes.
        /// </summary>
        private const string PORTABILIDAD_ALIAS_PENDIENTE = "T";
        /// <summary>
        /// Alias de portabilidad de lineas en proceso.
        /// </summary>
        private const string PORTABILIDAD_ALIAS_EN_PROCESO = "P";
        /// <summary>
        /// Alias de portabilidad de lineas rechazadas.
        /// </summary>
        private const string PORTABILIDAD_ALIAS_RECHAZADO = "R";

        [Obsolete]
        public static IEnumerable<LineasPortabilidad> ConsultarLineasPortabilidad(string user)
        {
            CreditoClient credito = new CreditoClient();
            try
            {
                List<LineasPortabilidad> lineas = new List<LineasPortabilidad>();

                LineasPortabilidad linea1 = new LineasPortabilidad
                {
                    IdEb = "BOG32017-166",
                    IdOperadorOrigen = 4,
                    Operador = null,
                    Celular = Convert.ToInt64("3134232353"),
                    IdTipoPlanOrigen = 1,
                    PlanOrigen = null,
                    IdTipoPlanDestino = 2,
                    PlanDestino = null,
                    Traspaso = false,
                    IdTipoIdentOrigen = (int?)null,
                    TipoIdentificacion = null,
                    NumIdentOrigen = null,
                    NombreClienteOrigen = null,
                    ApellidoClienteOrigen = null,
                    //FecIngreso = Convert.ToDateTime("2017-03-24"),
                    IdWeb = "0",
                    FechaVentana = Convert.ToDateTime("2017-03-31"),
                    IdLinea = (int?)null
                };
                LineasPortabilidad linea2 = new LineasPortabilidad
                {
                    IdEb = "BOG32017-129",
                    IdOperadorOrigen = 2,
                    Operador = null,
                    Celular = Convert.ToInt64("3134256789"),
                    IdTipoPlanOrigen = 2,
                    PlanOrigen = null,
                    IdTipoPlanDestino = 3,
                    PlanDestino = null,
                    Traspaso = true,
                    IdTipoIdentOrigen = 1,
                    TipoIdentificacion = "CC",
                    NumIdentOrigen = "12233322",
                    NombreClienteOrigen = "oscar",
                    ApellidoClienteOrigen = "cardoso",
                    //FecIngreso = Convert.ToDateTime("2017-03-23"),
                    IdWeb = "12345",
                    FechaVentana = Convert.ToDateTime("2017-03-31"),
                    IdLinea = (int?)null
                };
                LineasPortabilidad linea3 = new LineasPortabilidad
                {
                    IdEb = "BOG32017-98",
                    IdOperadorOrigen = 1,
                    Operador = null,
                    Celular = Convert.ToInt64("3121234567"),
                    IdTipoPlanOrigen = 2,
                    PlanOrigen = null,
                    IdTipoPlanDestino = 1,
                    PlanDestino = null,
                    Traspaso = false,
                    IdTipoIdentOrigen = (int?)null,
                    TipoIdentificacion = null,
                    NumIdentOrigen = null,
                    NombreClienteOrigen = null,
                    ApellidoClienteOrigen = null,
                    //FecIngreso = Convert.ToDateTime("2017-03-20"),
                    IdWeb = "1111",
                    FechaVentana = Convert.ToDateTime("2017-03-29"),
                    IdLinea = (int?)null
                };

                lineas.Add(linea1);
                lineas.Add(linea2);
                lineas.Add(linea3);
                return lineas;
            }
            catch (Exception exc)
            {

                throw exc;
            }
        }

        public static IEnumerable<LineasPortabilidad> ConsultaLineasPortabilidadTotal(string user, string idEB, Int32 estado)
        {
            CreditoClient credito = new CreditoClient();
            try
            {
                IEnumerable<LineasPortabilidad> lineas = credito.DetallePortabilidad(user, idEB, estado);
                return lineas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<LineasPortabilidad> ConsultaLineasPortabilidadProcesadas(string user, string idEB, Int32 estado)
        {
            CreditoClient credito = new CreditoClient();
            try
            {
                IEnumerable<LineasPortabilidad> lineas = credito.ObtenerLineasPortabilidadEnProceso(user, idEB);
                return lineas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<LineasPortabilidad> ConsultaLineasPortabilidadDevueltas(string user, string idEB, Int32 estado)
        {
            CreditoClient credito = new CreditoClient();
            try
            {
                IEnumerable<LineasPortabilidad> lineas = credito.DetallePortabilidad(user, idEB, estado);
                return lineas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Consulta de lineas de portabilidad pendientes
        /// </summary>
        /// <param name="user">usuario</param>
        /// <param name="idEb">codigo del negocio</param>
        /// <returns></returns>
        public static IEnumerable<LineaPortabilidadPendiente> ObtenerLineasPortabilidadPendientes(string user, string idEb)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<LineaPortabilidadPendiente> lineas = credito.ObtenerLineasPortabilidadPendientes(user, idEb);
                return lineas;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Consulta de lineas de portabilidad en proceso
        /// </summary>
        /// <param name="user">usuario</param>
        /// <param name="idEb">codigo del negocio</param>
        /// <returns></returns>
        public static IEnumerable<LineaPortabilidadEnProceso> ObtenerLineasPortabilidadEnProceso(string user, string idEb)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<LineaPortabilidadEnProceso> lineas = credito.ObtenerLineasPortabilidadEnProceso(user, idEb);
                return lineas;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Consulta de lineas de portabilidad rechazadas
        /// </summary>
        /// <param name="user">usuario</param>
        /// <param name="idEb">codigo del negocio</param>
        /// <returns></returns>
        public static IEnumerable<LineaPortabilidadRechazada> ObtenerLineasPortabilidadRechazadas(string user, string idEb)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<LineaPortabilidadRechazada> lineas = credito.ObtenerLineasPortabilidadRechazadas(user, idEb);
                return lineas;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Enviar lineas a la tabla de portabilidad
        /// </summary>
        /// <param name="LineasEnviar"></param>
        /// <returns>True o False</returns>
        public static bool GuardarLineasPortabilidad(GestionLineasABD LineasEnviar)
        {
            bool resultado;
            try
            {
                CreditoClient credito = new CreditoClient();
                resultado = credito.InsertarPortabilidad(LineasEnviar);
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool ActualizarEstadoPortabilidad(GestionLineasABD LineasEnviar)
        {
            bool resultado;
            try
            {
                CreditoClient credito = new CreditoClient();
                resultado = credito.ActualizarPortabilidad(LineasEnviar);
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region Documental Consulta

        /// <summary>
        /// Obtener estructuras de campos
        /// </summary>
        /// <param name="id_eb">codigo del negocio</param>
        /// <param name="id_etapa">id de estapa</param>
        /// <returns></returns>
        public static IEnumerable<EstructuraCampos> ObtenerEstructuraCampos(string id_eb, decimal id_etapa)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<EstructuraCampos> estructuraCampos = credito.ObtenerEstructuraCampos(id_eb, id_etapa);
                return estructuraCampos;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Obtener estructuras de formularios de gestion
        /// </summary>
        /// <param name="id_eb">Codigo del negocio</param>
        /// <param name="id_etapa">Id de estapa</param>
        /// <param name="id_estado">Id de estado</param>
        /// <returns></returns>
        public static IEnumerable<EstructuraFormularioGestion> ObtenerEstructuraFormularioGestion(string id_eb, decimal id_etapa, int id_estado)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<EstructuraFormularioGestion> estructuraCampos = credito.ObtenerEstructuraFormularioGestion(id_eb, id_etapa, id_estado);
                return estructuraCampos;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        /// <summary>
        /// Obtener estructura de notas
        /// </summary>
        /// <param name="id_eb">codigo del negocio</param>
        /// <param name="id_etapa">id de etapa</param>
        /// <returns></returns>
        public static IEnumerable<EstructuraNotas> ObtenerEstructuraNotas(string id_eb, decimal id_etapa)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<EstructuraNotas> estructuraNota = credito.ObtenerEstructuraNotas(id_eb, id_etapa);
                return estructuraNota;
            }
            catch (Exception exc)
            {
                throw exc;
            }
        }

        #endregion Documental Consulta

    }
}
