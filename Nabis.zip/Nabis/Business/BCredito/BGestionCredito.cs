﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSCredito;
using Nabis_BS.NabWSUsers;
using Nabis_BS.NabWSSCL;

namespace Nabis_BS.BCredito
{
    public class BGestionCredito
    {
        /// </summary>
        private const int DIAS_VALIDAR = 8;
        private const int ESTADO_ASIGNADO = 5;
        private const int ESTADO_PENDIENTE = 6;
        private const int ESTADO_PORTABILIDAD = 27;
        private const int ESTADO_ABD_RECHAZADO = 28;
        private const int ESTADO_ABD_APROBADO = 29;
        private static string[] pathControlsEtapasTramite = new string[] { "12" //Etapa 1
                                                    , "13" //Etapa 2
                                                    , "14" //Etapa 3
                                                    , "15" //Etapa 4
            };
        private static string[] estadosAprobadosABD = new string[] { "ACTIVA" 
                                                    , "PREACTIVA"  
            };

        public static IEnumerable<BandejaCredito> ListaBandejaAsignacion(string user_id)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<BandejaCredito> listaBandeja = credito.InfoBandeja(user_id, ESTADO_ASIGNADO);
                return listaBandeja;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<BandejaCredito> ListaBandejaPendiente(string user_id)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<BandejaCredito> listaBandeja = credito.InfoBandeja(user_id, ESTADO_PENDIENTE);
                return listaBandeja;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static  IEnumerable<BandejaCredito> ListaBandejaPortabilidad(string user_id)
        {
            try
            {
                CreditoClient credito = new CreditoClient();
                IEnumerable<BandejaCredito> listaBandeja = credito.InfoBandeja(user_id, ESTADO_PORTABILIDAD);
                return listaBandeja;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<BandejaCredito> ListaBandejaDevoluciones(string user_id)
        {
            int idproceso=-1;

            try
            {
                CreditoClient credito = new CreditoClient();
                UsersClient userCliente = new UsersClient();
                List<GenericOption> roles = userCliente.GetRolesForUser(user_id);
                foreach (GenericOption rol in roles)
                {
                    if (pathControlsEtapasTramite.Any(p => p.Equals(rol.Id)))
                    {
                        idproceso = Convert.ToInt32(rol.Id);
                    }
                }

                IEnumerable<BandejaCredito> listaBandeja = credito.InfoBandejaDevolucion(user_id, idproceso);
                return listaBandeja;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int EvaluarInsumos(string userId, string item, string parametros)
        {
            int respuesta;
            try
            {
                CreditoClient credito = new CreditoClient();
                respuesta = credito.EvaluarInsumosNegocios(userId, item, parametros);
                return respuesta;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static bool ListaLineasProcesarABD(string user_id)
        {
            bool respuesta = false;
            string nidcorto;
            string registros = string.Empty;
            StringBuilder lineas = new StringBuilder();
            try
            {
                CreditoClient credito = new CreditoClient();
                List<ResultadosPortabilidad> listaPortados = null;
                GestionLineasABD lineasGestionar = null;
                IEnumerable<LineasProcesoABD> lineasProcesar = credito.LineasProcesarABD(user_id, ESTADO_PORTABILIDAD, DIAS_VALIDAR);
                foreach (LineasProcesoABD linea in lineasProcesar)
                {
                    nidcorto = linea.Identidad.Remove(linea.Identidad.IndexOf("-") - 1, linea.Identidad.Length);
                    listaPortados = Portados(linea.Celular.ToString(), linea.Identidad, nidcorto);
                    foreach (ResultadosPortabilidad resultado in listaPortados)
                    {
                        if (estadosAprobadosABD.Any(p => p.Equals(resultado.Estado)))
                        {
                            linea.IdEstado = 29;
                        }
                        else
                        {
                            if (resultado.Estado == "RECHAZO")
                            {
                                linea.IdEstado = 28;
                            }
                            else
                            {
                                linea.IdEstado = 27;
                            }
                        }
                        lineas.Clear();
                        lineasGestionar.UserId = user_id;
                        lineasGestionar.IdEb = linea.IdEb;
                        lineas.Append(linea.IdLinea + ",");
                        lineasGestionar.XmlLineas = lineas.ToString().Trim(',');
                        lineasGestionar.Estado = linea.IdEstado;
                        lineasGestionar.FechaVentana = null;
                        lineasGestionar.IdWeb = resultado.CodigoSolicitud;
                        respuesta = CambiarEstadoLineasABD(lineasGestionar);
                    }
                }

                return respuesta;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<ResultadosPortabilidad> Portados(string Celular, string numIdent, string numIdenCorto)
        {
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<ResultadosPortabilidad> Portado = scl.ResultadoABD(Celular, numIdent, numIdenCorto);
                
                return Portado.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool CambiarEstadoLineasABD(GestionLineasABD LineaActualizar)
        {
            bool respuesta;
            try
            {
                CreditoClient credito = new CreditoClient();
                respuesta = credito.ActualizarPortabilidad(LineaActualizar);
                return respuesta;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
