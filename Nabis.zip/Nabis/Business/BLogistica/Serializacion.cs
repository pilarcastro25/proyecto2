﻿namespace Nabis_BS.BLogistica
{
	using NabWSLogistica;
	using System;
	using System.Collections.Generic;

	public class Serializacion
	{
		public static int Logistica_Enviar_Activaciones(Serializar Serie, ref string Resultado)
		{
			try
			{
				using (LogisticaClient LogisticaClient = new LogisticaClient())
					return LogisticaClient.Logistica_Enviar_Activaciones(Serie, ref Resultado);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Listado de Pedidos y Negocios pendientes por serializar
		/// </summary>
		/// <param name="tipoConsulta"></param>
		/// <param name="usuario"></param>
		/// <returns></returns>
		public static IEnumerable<PendientesAsignarL> PdtsSerializar(string tipoConsulta, string usuario)
		{
			try
			{
				using (LogisticaClient LogisticaClient = new LogisticaClient())
					return LogisticaClient.PdtsSerializar(tipoConsulta, usuario);
			}
			catch (Exception ex)
			{
				throw new Exception();
			}
		}
	}
}