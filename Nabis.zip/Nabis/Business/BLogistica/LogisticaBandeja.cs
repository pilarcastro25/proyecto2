﻿using Nabis_BS.NabWSLogistica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;




namespace Nabis_BS.BLogistica
{
    public class LogisticaBandeja
    {
        public string AsignarAnalistaLogistica(string IdEb, string IdUser, ref string Resultado)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.AsignarAnalistaLogistica(IdEb, IdUser, ref Resultado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PendientesAsignarL> Consultar_Pedidos_Pendientes_Asignar()
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Consultar_Pedidos_Pendientes_Asignar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PendientesAsignarL> Logistica_Consultar_Pedidos_Asignados(string IdUser)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos_Asignados(IdUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pedidos(string Id_Eb)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos(Id_Eb);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pedidos_Subpedido(string Id_Eb)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos_Subpedido(Id_Eb);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pedidos_X_IdPedido(string Idpedido)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos_X_IdPedido(Idpedido);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string Logistica_Serializar(Serializar Serie, ref string Resultado)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Serializar(Serie, ref Resultado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string Logistica_Despachar(Despachar Despacho, ref string Resultado)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Despachar(Despacho, ref Resultado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<PendientesAsignarL> Consultar_Pedidos_Pendientespor_Despachar()
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Consultar_Pedidos_Pendientespor_Despachar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pedidos_Serializar(string Idpedido)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos_Serializar(Idpedido);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<ArticulosCantidad> Logistica_Detalles_Serializar(string Idpedido)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Detalles_Serializar(Idpedido);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pendientes_Despachar(string Id_Eb)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pendientes_Despachar(Id_Eb);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Pedido> Logistica_Consultar_Pedidos_Subpedido_X_Nit(string Nit)
        {
            try
            {
                using (NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient())
                    return LogisticaClient.Logistica_Consultar_Pedidos_Subpedido_X_Nit(Nit);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}