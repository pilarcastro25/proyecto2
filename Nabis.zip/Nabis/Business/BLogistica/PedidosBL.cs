﻿using Nabis_BS.NabWSLogistica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Nabis_BS.BLogistica
{
    public class PedidosBL
    {

        public int Pedido_Insertar(Pedido_Insertar Pedido, ref string Resultado)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Pedido_Insertar(Pedido, ref Resultado);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int Insertar_Detalle_pedido(string Id_User, int IdPedido, List<PedidoLinea> Detalles, ref string Resultado)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Insertar_Detalle_pedido(Id_User, IdPedido, Detalles, ref Resultado);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<DetallePedido> Consultar_Detalle_Pedido(string IdPedido)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Consultar_Detalle_Pedido(IdPedido);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public List<Pedido> Comercial_Consultar_Pedido(string Id_User)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Comercial_Consultar_Pedido(Id_User);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Pedido> Comercial_Consultar_Pedido_x_IdEB(string IdEB)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Comercial_Consultar_Pedido_x_IdEB(IdEB);

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Pedido> Comercial_Consulta_Pedido_x_IdPedido(string IdPedido)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Comercial_Consulta_Pedido_x_IdPedido(IdPedido);

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<PendientesAsignarL> Consultar_Pedidos_Pendientes_Asignar()
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Consultar_Pedidos_Pendientes_Asignar();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public int RollBackPedido(int Id_Pedido)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.RollBackPedido(Id_Pedido);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        /// <summary>
        /// metodo para actualizar la informacion del pedido
        /// </summary>
        /// <param name="Pedido"></param>
        /// <param name="User"></param>
        /// <param name="Resultado"></param>
        /// <returns></returns>
        public string Comercial_Actualizacion_Pedido_InformacionGeneral(Pedido Pedido, string User, ref string Resultado)
        {
            try
            {
                NabWSLogistica.LogisticaClient LogisticaClient = new NabWSLogistica.LogisticaClient();
                return LogisticaClient.Comercial_Actualizacion_Pedido_InformacionGeneral(Pedido, User, ref  Resultado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int SerializarArticulo(Serializar Serie, ref string Resultado)
        {
            try
            {
                using (LogisticaClient LogisticaClient = new LogisticaClient())
                    return LogisticaClient.Pedido_SerializarArticulo(Serie, ref Resultado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
