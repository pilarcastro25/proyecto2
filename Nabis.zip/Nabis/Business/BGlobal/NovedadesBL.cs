﻿namespace Nabis_BS.BGlobal
{
    using Nabis_BS.NabWSGlobal;
	using System;
	using System.Data;
    using System.Linq;
    using System.Collections.Generic;
    using Nabis_BS.NabWSRobotActivaciones;

	public class NovedadesBL
    {
        #region CONSTANTES
        /// <summary>
        /// Constante rol robot
        /// </summary>
        private const int ROL_ROBOT = 29;
        #endregion

        /// <summary>
		/// Editar novedades
		/// </summary>
		/// <param name="Cod_Novedad"></param>
		/// <param name="Fec_Inicio"></param>
		/// <param name="Cod_Negocio"></param>
		/// <param name="Id_Causal"></param>
		/// <param name="Id_Estado"></param>
		/// <param name="Observaciones"></param>
		/// <param name="sMsg"></param>
		/// <returns></returns>
		public static bool EditarNovedades(string Cod_Novedad, DateTime? Fec_Inicio, string Cod_Negocio, int Id_Causal, int Id_Estado, string Observaciones, ref string sMsg)
		{
			bool val = IngresarNovedades(Cod_Novedad, Fec_Inicio, Cod_Negocio, Id_Causal, Id_Estado, Observaciones, string.Empty, ref sMsg);
			return val;
		}

		/// <summary>
		/// Metodo para insercion de novedades una a una o masivo
		/// </summary>
		/// <param name="novedad"></param>
		/// <returns></returns>
		public static bool EliminaNovedadTmp(string Negocio, int Novedad)
		{
			GlobalClient globalServicio = new GlobalClient();
			bool val = globalServicio.BorrarNovedadesTemporales(Negocio, Novedad);
			return val;
		}

		/// <summary>
		/// Metodo para insercion de novedades una a una o masivo
		/// </summary>
		/// <param name="CodNovedad"></param>
		/// <param name="FechaInicio"></param>
		/// <param name="CodNegocio"></param>
		/// <param name="IdCausal"></param>
		/// <param name="IdEstado"></param>
		/// <param name="Observaciones"></param>
		/// <param name="XmlNovedades"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static bool IngresarNovedades(string CodNovedad, DateTime? FechaInicio, string CodNegocio, int IdCausal, int IdEstado, string Observaciones, string XmlNovedades, ref string msg)
		{
			GlobalClient globalServicio = new GlobalClient();
			bool val = globalServicio.Insertar_Novedades(CodNovedad, FechaInicio, CodNegocio, IdCausal, IdEstado, Observaciones, XmlNovedades, ref msg);
			return val;
		}

		/// <summary>
		/// Metodo para insercion de novedades una a una o masivo en la tabla temporal
		/// </summary>
		/// <param name="novedad"></param>
		/// <returns></returns>
		public static bool IngresarNovedadesTmp(string CodNovedad, DateTime? FechaInicio, string CodNegocio, int IdCausal, int IdEstado, string Observaciones, string XmlNovedades, ref string msg)
		{
			GlobalClient globalServicio = new GlobalClient();
			bool val = globalServicio.Insertar_Novedades_Temp(CodNovedad, FechaInicio, CodNegocio, IdCausal, IdEstado, Observaciones, XmlNovedades, ref msg);
			return val;
		}

		/// <summary>
		/// Metodo que carga el detalle de la novedad seleccionada
		/// </summary>
		/// <param name="novedad"></param>
		/// <returns></returns>
		public static DataTable ObtenerDetalleNovedad(int novedad)
		{
			GlobalClient globalServicio = new GlobalClient();
			DataTable dtNovedades = globalServicio.CargarDetalleNovedad(novedad);
			return dtNovedades;
		}

		/// <summary>
		/// Metodo que carga las novedads Temporales
		/// </summary>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerNovedadesTmp(string Negocio)
		{
			GlobalClient globalServicio = new GlobalClient();
			DataTable dtNovedades = globalServicio.CargarNovedadesTMP(Negocio);
			return dtNovedades;
		}

		/// <summary>
		/// Metodo que carga las novedads por proceso y usuario
		/// </summary>
		/// <param name="UserLogin"></param>
		/// <param name="Negocio"></param>
		/// <returns></returns>
		public static DataTable ObtenerNovedadesUsuarioProceso(string UserLogin, int proceso_actual, string Negocio)
		{
			GlobalClient globalServicio = new GlobalClient();
			DataTable dtNovedades = globalServicio.CargarNovedades(UserLogin, proceso_actual, Negocio);
			return dtNovedades;
		}

        public static int GetCodigoCausal(Causal_ET procesos)
        {
            GlobalClient global = new GlobalClient();
            try
            {
                int codCausal = global.ObtenerCausal(procesos);
                return codCausal;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<BandejaRobot> ListaBandejaRobot(string user_id)
        {
            try
            {
                GlobalClient global = new GlobalClient();
                IEnumerable<BandejaRobot> listaRobot = global.InfoBandejaRobot(user_id, ROL_ROBOT);
                return listaRobot;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool RestaurarEstadoLineasRobot(string id_eb, int id_estructura, int id_estado)
        {
            try
            {
                GlobalClient global = new GlobalClient();
                RestaurarEstado LineasCambiar = new RestaurarEstado();
                LineasCambiar.IdEb = id_eb;
                LineasCambiar.IdEstructura = id_estructura;
                LineasCambiar.IdEstado = id_estado;
                bool resulta = global.ActualizarEstadoLineasRobot(LineasCambiar);
                return resulta;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<Nabis_BS.NabWSRobotActivaciones.Linea> ConsultarLineas(string user, string estado)
        {
            try
            {
                RobotActivacionesClient RobotClient = new RobotActivacionesClient();
                IEnumerable<Nabis_BS.NabWSRobotActivaciones.Linea> lstLineas = RobotClient.ConsultarLineas(user, estado);
                return lstLineas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static RutasPlantillas ConsultarRuta(string user, string descripcion)
        {
            RobotActivacionesClient RobotClient = new RobotActivacionesClient();
            IEnumerable<RutasPlantillas> ruta = null;
            RutasPlantillas oRuta = null;
            try
            {
                ruta = RobotClient.ConsultarRutasPlantillas(user, descripcion);
                foreach (RutasPlantillas item in ruta)
                {
                    oRuta = new RutasPlantillas();
                    oRuta.RutaPlantilla = item.RutaPlantilla;
                    oRuta.NombreArchivo = item.NombreArchivo;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return oRuta;
        }

        private static void ExportarPlantilla(IEnumerable<Nabis_BS.NabWSGlobal.TramaActivaciones> plantillaCuentas, string descripcion, RutasPlantillas oRuta, string IdEb)
        {
            try
            {                
                string sRuta = oRuta.RutaPlantilla + "\\" + Convert.ToString(DateTime.Now.Year) + "\\" + Convert.ToString(DateTime.Now.Month) + "\\" + Convert.ToString(DateTime.Now.Day) + "\\";
                Nabis.Utilities.GestionarArchivos.CrearCarpeta(sRuta);
                if (descripcion == "POSTPAGO NO PORTADOS")
                {
                    if (plantillaCuentas.Count() > 10)
                    {
                        double cantRegistros = plantillaCuentas.Count();
                        List<string> oAux = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}", x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        List<string> obj = null;
                        int contador = 0;
                        foreach (string item in oAux)
                        {
                            obj.Add(item);
                            contador++;
                            if (contador == 10 && cantRegistros > 10)
                            {
                                cantRegistros = cantRegistros - 10;
                                string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                                sRuta = sRuta + sNombreArchivo;
                                Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                                contador = 0;
                                obj.Clear();
                            }
                            else if (cantRegistros < 10)
                            {
                                string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                                sRuta = sRuta + sNombreArchivo;
                                Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                                contador = 0;
                                obj.Clear();
                            }
                        }
                    }
                    else
                    {
                        string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                        sRuta = sRuta + sNombreArchivo;
                        List<string> obj = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}", x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                    }
                }
                else
                {
                    if (plantillaCuentas.Count() > 0)
                    {
                        string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                        sRuta = sRuta + sNombreArchivo;
                        List<string> obj = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}", x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public static bool GenerarPlantilla(string user, string id_eb, int id_estructura, string estado_estructura)
        {
            bool result = false;
            GlobalClient Global = new GlobalClient();
            RobotActivacionesClient RobotClient = new RobotActivacionesClient();
            try
            {
                IEnumerable<Nabis_BS.NabWSGlobal.TramaActivaciones> plantillaCuentas = null;
                RutasPlantillas oRuta = new RutasPlantillas();
                string descripcion = Global.TipoPlantilla(user,id_eb,id_estructura);
                oRuta = ConsultarRuta(user, descripcion);  
                if (descripcion == "PRECHEQUEO")
                {
                    plantillaCuentas = Global.ConsultaPrechequeo(user, id_eb, id_estructura, estado_estructura);
                    ExportarPlantilla(plantillaCuentas, descripcion, oRuta, id_eb);
                }
                else if (descripcion == "PREPAGO NO PORTADOS")
                {
                    plantillaCuentas = Global.ConsultarPrepagoNoPortados(user, id_eb, id_estructura, estado_estructura);
                    ExportarPlantilla(plantillaCuentas, descripcion, oRuta, id_eb);
                }
                else if (descripcion == "PREPAGO PORTADOS")
                {
                    plantillaCuentas = Global.ConsultarPrepagoPortados(user, id_eb, id_estructura, estado_estructura);
                    ExportarPlantilla(plantillaCuentas, descripcion, oRuta, id_eb);
                }
                else if (descripcion == "POSTPAGO NO PORTADOS")
                {
                    plantillaCuentas = Global.ConsultarPostpagoNoPortados(user, id_eb, id_estructura, estado_estructura);

                            List<Nabis_BS.NabWSGlobal.TramaActivaciones> postPagoCerrado = null;
                            List<Nabis_BS.NabWSGlobal.TramaActivaciones> postPagoAbierto = null;
                            postPagoCerrado = plantillaCuentas.Where(e => e.TipoPlan.Contains("CUENTA")).ToList();
                            ExportarPlantilla(postPagoCerrado, descripcion, oRuta, id_eb);
                            postPagoAbierto = plantillaCuentas.Where(e => e.TipoPlan.Contains("POSTPAGO")).ToList();
                            ExportarPlantilla(postPagoAbierto, descripcion, oRuta, id_eb);
                }
                else if (descripcion == "POSTPAGO PORTADOS")
                {
                    plantillaCuentas = Global.ConsultarPostpagoPortados(user, id_eb, id_estructura, estado_estructura);
                    ExportarPlantilla(plantillaCuentas, descripcion, oRuta, id_eb);
                }
                result = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
	}
}