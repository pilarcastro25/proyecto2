﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Text;
using Utilities.Utilities;
using System.Data;
using Nabis_BS.NabWSSCL;

namespace Nabis_BS.Global
{
    public class SCL_B
    {
        private Nabis_WS.SCL servicesSCL;

		private Nabis_WS.SCL ServicesSCL
		{
			get
			{
				if (servicesSCL == null)
				{
					servicesSCL = new Nabis_WS.SCL();
				}
				return servicesSCL;
			}
		}

		private SqlConnection transac = Nabis_WS.SCL.Get_Conexion();

		public static string PerfilCliente(string numIdent)
		{
			SCLClient scl = new SCLClient();
			//string PerfilCliente = scl.PerfilCliente(numIdent);
			string PerfilCliente = "";
			return PerfilCliente;
		}

		public static IEnumerable<CuentasCliente> CuentaCliente(string numIdent)
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<CuentasCliente> cuenta = scl.CuentasCliente(numIdent);
				return cuenta;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static IEnumerable<SubcuentasCliente> SubcuentaCliente(string numIdent)
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<SubcuentasCliente> subcuenta = scl.SubcuentasCliente(numIdent);
				return subcuenta;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		//public static IEnumerable<BeneficiosAplicados> BeneficioAplicadoLinea(string codAbonado, string numMovil)
		//{
		//    try
		//    {
		//        SCLClient scl = new SCLClient();
		//        IEnumerable<BeneficiosAplicados> BeneficiosAplicados = scl.BeneficiosAplicadosLinea(codAbonado, numMovil);
		//        return BeneficiosAplicados;
		//    }
		//    catch (Exception ex)
		//    {
		//        throw ex;
		//    }
		//}

		public static IEnumerable<PlanesTarifarios> PlanTarifario()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<PlanesTarifarios> plan = scl.PlanesTarifas();
				return plan;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        /*public static bool SeriesPrecios()
        {
            SqlConnection conection = Nabis_WS.SCL.Get_Conexion();
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<SeriesPrecio> SeriesPrecio = new List<SeriesPrecio>();
                Nabis_WS.SCL.SeriesPrecios(ref SeriesPrecio);

                //inicia transferencia
                using (SqlBulkCopy sqlBulk = new SqlBulkCopy(conection))
                {
                    conection.Open();
                    //Give your Destination table name
                    sqlBulk.DestinationTableName = "DBO.NAB_GLOBAL_I_SERIES_PRECIOS_TMP";
                    try
                    {
                        // Write from the source to the destination.
                        sqlBulk.WriteToServer(SeriesPrecio.ToDataTable());
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        conection.Close();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/

        //public static IEnumerable<SeriesBodegas> SerieBodega()
        //{
        //    try
        //    {
        //        SCLClient scl = new SCLClient();
        //        IEnumerable<SeriesBodegas> SeriesBodega = scl.SeriesBodegas();
        //        return SeriesBodega;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public bool SerieBodega()
        {
            SqlConnection conection = Nabis_WS.SCL.Get_Conexion();
            try
            {
                SCLClient scl = new SCLClient();
                DataTable SeriesBodega = new DataTable();  // Nabis_WS.SCL.SeriesBodegasDT();
                ServicesSCL.SeriesBodegas(ref SeriesBodega);
                //inicia transferencia
                using (SqlBulkCopy sqlBulk = new SqlBulkCopy(conection))
                {
                    conection.Open();
                    //Give your Destination table name
                    try
                    {
                        //tabla destino  series_bodegas
                        sqlBulk.DestinationTableName = "DBO.NAB_GLOBAL_I_SERIES_BODEGAS_TMP";
                        //mapeado de campos desde datatable enviada por el servicio a tabla destino
                        sqlBulk.ColumnMappings.Add("NUMERO_SERIE", "NUMERO_SERIE");
                        sqlBulk.ColumnMappings.Add("NUMERO_SERIE", "NUMERO_SERIE");
                        sqlBulk.ColumnMappings.Add("CODIGO_ARTICULO", "CODIGO_ARTICULO");
                        sqlBulk.ColumnMappings.Add("TIPO_STOCK", "TIPO_STOCK");
                        //sqlBulk.ColumnMappings.Add( , "ESTADO" );
                        sqlBulk.ColumnMappings.Add("ID_TIPO_USO", "ID_TIPO_USO");
                        sqlBulk.ColumnMappings.Add("CODIGO_CENTRAL", "CODIGO_CENTRAL");
                        sqlBulk.ColumnMappings.Add("CODIGO_HLR", "CODIGO_HLR");
                        sqlBulk.ColumnMappings.Add("HLR_DEFINITIVO", "HLR_DEFINITIVO");
                        sqlBulk.ColumnMappings.Add("UMERO_TELEFONO", "UMERO_TELEFONO");
                        // Write from the source to the destination.
                        sqlBulk.WriteToServer(SeriesBodega);

                        //se corre el sp que llena las tablas adicionales de los insumos para la tabla de series bodegas
                        Nabis_WS.Global asd = new Nabis_WS.Global();
                        asd.InsertarAdicionlesInsumos(1);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        conection.Close();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*public static bool PlanServicio()
        {
            SqlConnection conection = Nabis_WS.SCL.Get_Conexion();
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<PlanesServicios> PlanesServicios = new List<PlanesServicios>();
                Nabis_WS.SCL.PlanesServicios(ref PlanesServicios);

                //inicia transferencia
                using (SqlBulkCopy sqlBulk = new SqlBulkCopy(conection))
                {
                    conection.Open();
                    //Give your Destination table name
                    sqlBulk.DestinationTableName = "DBO.NAB_GLOBAL_I_PLANES_SERVICIOS_TMP";
                    try
                    {
                        sqlBulk.ColumnMappings.Add(1, 1);
                        sqlBulk.ColumnMappings.Add(2, 2);
                        sqlBulk.ColumnMappings.Add(3, 5);
                        sqlBulk.ColumnMappings.Add(4, 7);
                        sqlBulk.ColumnMappings.Add(5, 8);
                        sqlBulk.ColumnMappings.Add(7, 11);
                        sqlBulk.ColumnMappings.Add(8, 12);
                        sqlBulk.ColumnMappings.Add(10, 14);
                        // Write from the source to the destination.
                        sqlBulk.WriteToServer(PlanesServicios.ToDataTable());
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    finally
                    {
                        conection.Close();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<PlanesAdicionales> PlanConceptoAdicional()
        {
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<PlanesAdicionales> conceptosadicionales = scl.PlanesConceptosAdicionales();
                return conceptosadicionales;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }*/

        public static IEnumerable<SeriesDesbloqueadas> SerieDesbloqueada()
        {
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<SeriesDesbloqueadas> seriesDesbloqueadas = scl.SeriesDesbloqueadas();
                return seriesDesbloqueadas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		public static IEnumerable<Simcards> SimcardTotal()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<Simcards> simcards = scl.SimcardTotales();
				return simcards;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static IEnumerable<SeriesNegativas> SerieNegativa()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<SeriesNegativas> series = scl.SeriesNegativas();
				return series;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static IEnumerable<Articulos> Articulo()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<Articulos> Articulos = scl.Articulos();
				return Articulos;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static IEnumerable<UsuariosAreas> UsuarioArea()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<UsuariosAreas> Users = scl.UsuariosAreas();
				return Users;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		public static IEnumerable<Excepcionados> ExcepcionadosFecha()
		{
			try
			{
				SCLClient scl = new SCLClient();
				IEnumerable<Excepcionados> ExcepcionadoFecha = scl.Excepcionados();
				return ExcepcionadoFecha;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

        public static IEnumerable<Reciclaje> Reciclaje(string numIdent)
        {
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<Reciclaje> reciclaje = null;
                IEnumerable<Reciclaje> reciclajeFiltrado = null;
                reciclaje = scl.Reciclajes();
                if (reciclaje.Count() > 0)
                {
                    var ReciclajeFiltrado = from lisReciclaje in reciclaje
                                            where (lisReciclaje.Identificacion == numIdent)
                                            select lisReciclaje;
                    if (ReciclajeFiltrado != null)
                    {
                        reciclajeFiltrado = ReciclajeFiltrado.ToList();
                    }
                }
                return reciclajeFiltrado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static IEnumerable<ResultadosPortabilidad> Portados(string Ideb, string numIdent, string numIdenCorto)
        {
            try
            {
                SCLClient scl = new SCLClient();
                IEnumerable<ResultadosPortabilidad> Portado = scl.ResultadoABD(Ideb, numIdent, numIdenCorto);
                return Portado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}