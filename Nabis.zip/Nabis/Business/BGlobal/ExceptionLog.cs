﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Web;
using Nabis_BS.NabWSGlobal;

namespace Nabis_BS.Global
{
    public class ExceptionLog
    {
        public static bool Register(List<ExceptionContext> ExceptionList)
        {
            try {
                NabWSGlobal.GlobalClient Log = new NabWSGlobal.GlobalClient();
                return Log.ExceptionLog(ExceptionList);
            }
            catch (Exception ex) {
                throw ex;
            }
        }
    }
}
