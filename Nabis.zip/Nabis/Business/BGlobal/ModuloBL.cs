﻿namespace Nabis_BS.BGlobal
{
	using System;
	using System.Collections.Generic;
	using BComercial;
	using NabWSComercial;

	public class ModuloBL
	{
		/// <summary>
		/// Método para  Obtener los posibles estados para nvedades
		/// </summary>
		/// <returns></returns>
		public static IEnumerable<GenericOption> ObtenerModulos(string userLogin, string vista, string parametros = null)
		{
			try
			{
				return ComercialBL.GetGenericList(userLogin, vista, parametros);
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}