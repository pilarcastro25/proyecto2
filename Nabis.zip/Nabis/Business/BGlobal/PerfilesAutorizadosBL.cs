﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSGlobal;
using Nabis_BS.BComercial;
using Nabis_BS.NabWSComercial;

namespace Nabis_BS.BGlobal
{
    public class PerfilesAutorizadosBL
    {
        /// <summary>
        /// Método para  Obtener los perfiles del contacto autorizado
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<Nabis_BS.NabWSComercial.GenericOption> ObtenerPerfilesAutorizados(string userLogin, string vista, string parametros = null)
        {
            try
            {
                ComercialClient comerc = new ComercialClient();
                return comerc.GetGenericList(userLogin, vista, parametros);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
