﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_WS;

namespace Nabis_BS.BGlobal
{
    public class SMS
    {
        public static bool Send(long NumeroCelular, string Mensaje)
        {
            NabWSGlobal.GlobalClient sms = new NabWSGlobal.GlobalClient();
            sms.SMS_Send(NumeroCelular, Mensaje);
            return true;
        }
    }
}
