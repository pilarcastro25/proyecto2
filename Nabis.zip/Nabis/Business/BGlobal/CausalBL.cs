﻿using System;
using System.Collections.Generic;
using Nabis_BS.NabWSGlobal;

namespace Nabis_BS.BGlobal
{
	public class CausalBL
	{
		/// <summary>
		/// Método para la Obtener las causales asociadas al proceso en que se encuentre actualmente el usuario
		/// </summary>
		/// <param name="proceso"></param>
		/// <returns></returns>
		public static IEnumerable<CausalET> ObtenerCausales(int proceso, int? idProcesoDestino, int? idModulo)
		{
			try
			{
				GlobalClient globalServicio = new GlobalClient();
				IEnumerable<CausalET> result = globalServicio.CargarCausalesUsuario(proceso, idProcesoDestino, idModulo);
				return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Método para  Obtener los posibles estados para nvedades
		/// </summary>
		/// <returns></returns>
		public static IEnumerable<EstadosNovedadesET> ObtenerEstadosNovedades()
		{
			try
			{
				GlobalClient globalServicio = new GlobalClient();
				IEnumerable<EstadosNovedadesET> result = globalServicio.CargarEstadosNovedades();
				return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}