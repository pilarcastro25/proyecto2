﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nabis_BS.BGlobal
{
    public class GlobalData
    {
        public string Regionales(string IdRegion)
        {
            return "pol";
        }
    }
}
