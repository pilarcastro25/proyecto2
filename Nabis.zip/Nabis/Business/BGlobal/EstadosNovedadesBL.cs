﻿using Nabis_BS.NabWSGlobal;
using System;
using System.Collections.Generic;

namespace Nabis_BS.BGlobal
{
	public class EstadosNovedadesBL
	{
		public static IEnumerable<EstadosNovedadesET> ObtenerEstadosNovedades()
		{
			IEnumerable<EstadosNovedadesET> EstadosNov = new List<EstadosNovedadesET>();
			try
			{
				GlobalClient serGlobal = new GlobalClient();
				EstadosNov = serGlobal.CargarEstadosNovedades();
				return EstadosNov;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
	}
}