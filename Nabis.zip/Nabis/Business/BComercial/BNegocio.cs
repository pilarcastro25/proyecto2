﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSComercial;
using System.Data;

namespace Nabis_BS.BComercial
{
    public class BNegocio
    {
        public bool crearConsecutivo(string regional, ref string consecutivo)
        {
            bool resultado;
            try
            {
                ComercialClient comercial = new ComercialClient();
                resultado = comercial.ConsecutivoNegocio(regional, ref consecutivo);
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool RadicarNegocio(string consecutivoNegocio, int codigoVendedor, int? canalVendedor, int idRegional, int cantidadLineas,
            int portabilidad, int pedidoLogistica, string fechaCambio, int? idOperador, int? tipoIdentificacionCliente,
            string identificacionCliente, string nombreCliente, int? ciudadCliente, string tipoCalleCliente, string direccionCliente,
            string barrioCliente, string indicativoFijoCliente, string numeroFijoCliente, int? idIdentificacionRepresentanteLegal, int? numeroIdentificacionRepresentanteLegal,
            string nombreRepresentanteLegal, string apellido1RepresentanteLegal, string apellido2RepresentanteLegal, long? celularRepresentanteLegal,
            string fechaConstitucionRepresentanteLegal, string emailRepresentanteLegal, int? idCanalVenta, int? idTipoContrato, int? idTipoCliente, int? idTipoSolicitud,
            int? idMarcacionEspecial, long? idContrato, int? idTipoCambioPlan, string idUsuario, string nombreUsuarioAplicacion, string nombreUsuario,
            string telefono_cliente, string observaciones, ref string mensajeError, string emailCliente, bool esNeg_Atado, string tipoNegocioAtado, string negocioReferencia)
        { 
            Negocio negocio = new Negocio();
            bool portado = (portabilidad == 1);
            bool resultado;
            DateTime fec_ingreso = DateTime.Now;
            try
            {
                int numFijo = Convert.ToInt32(indicativoFijoCliente + numeroFijoCliente);

                negocio.IdEb = consecutivoNegocio;
                negocio.FecIngreso = fec_ingreso;
                negocio.CodVendedor = codigoVendedor;
                negocio.CanalVendedor = canalVendedor.ToString();
                negocio.IdRegionalNegocio = idRegional;
                negocio.UserIngreso = idUsuario;
                negocio.CantLineas = cantidadLineas;
                negocio.Portado = portabilidad;
                negocio.FecVentana = (portado) ? Convert.ToDateTime(fechaCambio) : (DateTime?)null;
                negocio.IdOperador = (portado) ? idOperador : (int?)null;
                negocio.Pedido = pedidoLogistica;
                negocio.IdTipoSolicitud = idTipoSolicitud;
                negocio.IdIdentidad = tipoIdentificacionCliente;
                negocio.Identidad = identificacionCliente;
                negocio.NombreCliente = nombreCliente;
                negocio.CodDistrito = ciudadCliente;
                negocio.CodTipoCalle = tipoCalleCliente;
                negocio.Direccion = direccionCliente;
                negocio.Complemento = barrioCliente;
                negocio.EmailCliente = emailCliente;
                negocio.IdIdentidadRepLegal = idIdentificacionRepresentanteLegal;
                negocio.RepLegalIdentidad = numeroIdentificacionRepresentanteLegal;
                negocio.RepLegalNombre = nombreRepresentanteLegal;
                negocio.RepLegalApellido1 = apellido1RepresentanteLegal;
                negocio.RepLegalApellido2 = apellido2RepresentanteLegal;
                negocio.RepLegalFijo = numFijo;
                negocio.RepLegalCelular = celularRepresentanteLegal;
                negocio.RepLegalFecnacimiento = (string.IsNullOrEmpty(fechaConstitucionRepresentanteLegal)) ? (DateTime?)null : Convert.ToDateTime(fechaConstitucionRepresentanteLegal);
                negocio.RepLegalEmail = emailCliente;
                negocio.IdGrupo = idCanalVenta;
                negocio.IdTipoContrato = idTipoContrato;
                negocio.IdTipoCliente = idTipoCliente;
                negocio.IdTipoServicio = 2; //2 = Móvil
                negocio.IdConvenio = idMarcacionEspecial;
                negocio.IdContratoMarco = idContrato;
                negocio.IdTipoCambioPlan = idTipoCambioPlan;
                negocio.EsPymes = 1;
                negocio.TelefonoCliente = telefono_cliente;
                negocio.Observaciones = observaciones;
                if (esNeg_Atado)
                {
                    negocio.EsAtado = 1;
                    negocio.TipoNegocioAtado = Convert.ToChar(tipoNegocioAtado);
                    negocio.NegocioReferencia = negocioReferencia;
                }
                else
                {
                    negocio.EsAtado = 0;
                    negocio.TipoNegocioAtado = null;
                    negocio.NegocioReferencia = null;
                }

                ComercialClient comercial = new ComercialClient();
                resultado = comercial.RadNegocio(negocio);
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool TieneNegociosAtados(string IdEbReferencia, string NumeroIdCliente)
        {
            ComercialClient comercial = new ComercialClient();
            bool resultado;
            resultado = comercial.ValidarNegocioAtado(IdEbReferencia, NumeroIdCliente);
            return resultado;
        }

		/// <summary>
		/// Consultar Datos de Negocio
		/// </summary>
		/// <param name="user"></param>
		/// <param name="idEB"></param>
		/// <param name="idEstado"></param>
		/// <returns></returns>
        public static DatosNegocio ConsultarDatosNegocio(string user, string idEB, string idEstado)
        {
            try
            {
                ComercialClient comercial = new ComercialClient();
                IEnumerable<DatosNegocio> negocio = comercial.DatosNegocio(user, idEB, idEstado);                
                return negocio.ToList()[0];                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

		public bool RadicarCuentas(Cuentas_Subcuentas cuentas, ref string mensaje)
        {
            bool resultadoFinal;
            try
            {
                int? idCiclo = (cuentas.IdCiclo == -1) ? (int?)(null) : cuentas.IdCiclo;
                int? estrato = (cuentas.Estrato == -1) ? (int?)(null) : cuentas.Estrato;
                int? idPerfilAutorizado = (cuentas.IdPerfilAutorizado == -1) ? (int?)(null) : cuentas.IdPerfilAutorizado;
                int? codigoDpto = (cuentas.Departamento == -1) ? (int?)(null) : cuentas.Departamento;
                int? codigoCiudad = (cuentas.Ciudad == -1) ? (int?)(null) : cuentas.Ciudad;

                cuentas.Departamento = codigoDpto;
                cuentas.Ciudad = codigoCiudad;
                cuentas.Localidad = codigoCiudad;
                cuentas.IdCiclo = idCiclo;
                cuentas.Estrato = estrato;
                cuentas.IdPerfilAutorizado = idPerfilAutorizado;
                ComercialClient comercial = new ComercialClient();
                resultadoFinal = comercial.IngresarCuentas(cuentas, ref mensaje);
                return resultadoFinal;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool RadicarEstructuraVenta(Estructura_Venta_Completa estructuraVenta, int portabilidad, ref int resultado, ref string mensaje)
        {
            //Estructura_Venta_Completa estructuraVenta = new Estructura_Venta_Completa();
            bool portado = (portabilidad == 1);
            bool resultadoFinal;
            int? codigoCategoriaTributaria = (estructuraVenta.SubCatImpos == -1) ? (int?)(null) : estructuraVenta.SubCatImpos;
            int? roaming = (estructuraVenta.Roaming == -1) ? (int?)(null) : estructuraVenta.Roaming;
            int? codigoSimcard = (estructuraVenta.CodSclSimcard == -1) ? (int?)(null) : estructuraVenta.CodSclSimcard;
            int? codigoImei = (estructuraVenta.CodSclImei == -1) ? (int?)(null) : estructuraVenta.CodSclImei;

            try
            {
                estructuraVenta.SubCatImpos = codigoCategoriaTributaria;
                estructuraVenta.Roaming = roaming;
                estructuraVenta.CodSclImei = codigoImei;
                //estructuraVenta.CambioUso = (int?)null;
                
                ComercialClient comercial = new ComercialClient();
                resultadoFinal = comercial.IngresarEstructuraVentas(estructuraVenta, ref resultado, ref mensaje);
                return resultadoFinal;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<GenericOption> NumeracionesEval(List<string> series, string TipoNumeracion, string procedencia)
        {
            ComercialClient comercial = new ComercialClient();
			List<GenericOption> seriesErradas = comercial.NumeracionesEval(series, TipoNumeracion, procedencia);
            return seriesErradas;
        }

        public static NegocioInformacionAdicional GetInfoAdicional(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            NegocioInformacionAdicional infoAdicional = comercial.Negocio_GetInformacionAdicional(UserLogin, IdEb);
            return infoAdicional;
        }

        public static NegocioContactosAutorizados GetContactosAutorizados(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            NegocioContactosAutorizados contactos = comercial.Negocio_GetContactosAutorizados(UserLogin, IdEb);
            return contactos;
        }

        public static List<NegocioPlanesAdquiridos> GetPlanesAdquiridos(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            List<NegocioPlanesAdquiridos> planes = comercial.Negocio_GetPlanesAdquiridos(UserLogin, IdEb);
            return planes;
        }

        public bool RadicarEmpresaLinea(Empresa_Linea empresaLinea, ref int resultado)
        {
            bool resultadoFinal;
            try
            {
                int? cantLicencias = (empresaLinea.CantLicencias == -1) ? (int?)null : empresaLinea.CantLicencias;
                long? vlrMensual = (empresaLinea.ValorMensual == -1) ? (long?)null : empresaLinea.ValorMensual;
                empresaLinea.CantLicencias = cantLicencias;
                empresaLinea.ValorMensual = vlrMensual;
                ComercialClient comercial = new ComercialClient();
                resultadoFinal = comercial.IngresarEmpresaLinea(empresaLinea, ref resultado);
                return (resultado > 0) ? true : false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<NegocioModalidadesVenta> GetModalidadesVenta(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            List<NegocioModalidadesVenta> modalidades = comercial.Negocio_GetModalidadesVenta(UserLogin, IdEb);
            return modalidades;
        }

		/// <summary>
		/// Obtener los paquetes relacionados con la vista de parametro
		/// </summary>
		/// <param name="UserLogin"></param>
		/// <param name="IdEb"></param>
		/// <param name="Vista">'Pendientes', 'Editados'</param>
		/// <returns></returns>
		public static List<NegocioPaquetes> Consulta_Negocio_GetPaquetes(string UserLogin, string IdEb, string Vista)
		{
			ComercialClient comercial = new ComercialClient();
			List<NegocioPaquetes> paquetes = comercial.Consulta_Negocio_GetPaquetes(UserLogin, IdEb, Vista);
			return paquetes;
		}

		/// <summary>
		/// Actualizar los paquetes relacionados según accion determinada
		/// </summary>
		/// <param name="UserLogin"></param>
		/// <param name="IdEb"></param>
		/// <param name="Accion">'Reiniciar', 'Nuevo', 'Agregar', 'Cerrar'</param>
		/// <param name="Xml"></param>
		/// <returns></returns>
		public static int Update_Negocio_Paquetes(string UserLogin, string IdEb, string Accion, string Xml)
		{
			ComercialClient comercial = new ComercialClient();
			int numrows = comercial.Update_Negocio_Paquetes(UserLogin, IdEb, Accion, Xml);
			return numrows;
		}

		public static int Update_Negocio_Estado(string UserLogin, string IdEb, int IdEstado)
		{
			ComercialClient comercial = new ComercialClient();
			int numrows = comercial.Update_Negocio_Estado(UserLogin, IdEb, IdEstado);
			return numrows;
		}

        public static List<GenericOption> GetDocumentos(string UserLogin, string IdEb, string Alias)
        {
            ComercialClient comercial = new ComercialClient();
            List<GenericOption> documentos = comercial.Negocio_GetDocumentos(UserLogin, IdEb, Alias);
            return documentos;
        }

        public static DataTable GetOtroSi(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            return comercial.Negocio_GetOtroSi(UserLogin, IdEb);
        }

        public static bool IsExceptionPlanSimCardsEval(string UserLogin, string CodPlan, string App, string modulo, bool Exception)
        {
            ComercialClient comercial = new ComercialClient();
            return comercial.IsExceptionPlanSimCardsEval(UserLogin, CodPlan, App, modulo, Exception);
        }

        public static List<NegocioTraspaso> GetTraspasos(string UserLogin, string IdEb, string Vista, string NumIdentOrigen = null)
        {
            ComercialClient comercial = new ComercialClient();
            List<NegocioTraspaso> traspasos = comercial.Negocio_GetTraspasos(UserLogin, IdEb, Vista, NumIdentOrigen = null);
            return traspasos;
        }
        
        public static bool DocumentosEntrega(string UserLogin, string IdEb, string destinatarios, ref string RutaZip)
        {
            ComercialClient comercial = new ComercialClient();
            bool IsSuccess = comercial.Negocio_DocumentosEntrega(UserLogin, IdEb, destinatarios, ref RutaZip);
            return IsSuccess;
        }

        public static List<NegocioCobroRevertidoMepe> GetCobroRevertidoMepe(string UserLogin, string IdEb)
        {
            ComercialClient comercial = new ComercialClient();
            List<NegocioCobroRevertidoMepe> CobroRevertidoMepeList = comercial.Negocio_GetCobroRevertidoMepe(UserLogin, IdEb);
            return CobroRevertidoMepeList;
        }

        /// <summary>
        /// Método que retorna las propiedades de un plan pasado como parámetro
        /// </summary>
        /// <param name="codigoPlan"></param>
        /// <returns></returns>
        public static List<PlanTarifarioOfertador> PlanTarifarioDetalles(string codigoPlan)
        {
            ComercialClient comercial = new ComercialClient();
            List<PlanTarifarioOfertador> planesMoviles = comercial.PlanTarifarioDetalles(codigoPlan);
            return planesMoviles;
        }

        /// <summary>
        /// Obtener informacion adicional de condiciones uniformes para persona natural.
        /// </summary>
        /// <param name="IdEb"></param>
        /// <param name="userLogin"></param>
        /// <returns></returns>
        public static NegocioInformacionAdicionalPersonaNatural ObtenerInformacionAdicionalCondicionesUniformesPersonaNatural(string IdEb, string userLogin)
        {
            NegocioInformacionAdicionalPersonaNatural informacionNegocio = new NegocioInformacionAdicionalPersonaNatural();
            ComercialClient comercial = new ComercialClient();
            informacionNegocio = comercial.Negocio_ObtenerInformacionAdicionalCondicionesUniformesPersonaNatural(IdEb, userLogin);
            return informacionNegocio;
        }

        /// <summary>
        /// Obtener informacion de cuenta asociada a un negocio.
        /// </summary>
        /// <param name="id_eb"></param>
        /// <param name="nombreUsuario"></param>
        /// <returns></returns>
        public static NegocioInformacionCuentas ObtenerInformacionCuentasNegocio(string id_eb, string nombreUsuario)
        {
            NegocioInformacionCuentas informacionNegocio = new NegocioInformacionCuentas();
            ComercialClient comercial = new ComercialClient();
            informacionNegocio = comercial.ObtenerInformacionCuentasNegocio(id_eb, nombreUsuario);
            return informacionNegocio;
        }

        /// <summary>
        /// Método que retorna las estructuras de venta
        /// </summary>
        /// <param name=" idEb"></param>
        /// <returns></returns>
        public static List<EstructurasVentaComercial> EstructurasVentaNegocio(string idEb)
        {
            ComercialClient comercial = new ComercialClient();
            List<EstructurasVentaComercial> estructuras = comercial.ListadoEstructuraVentasComercial(idEb);
            return estructuras;
        }

        /// <summary>
        /// Método que retorna las propiedades de un plan pasado como parámetro
        /// </summary>
        /// <param name="idEb"></param>
        /// <param name="idestructura"></param>
        /// <returns></returns>
        public static List<LineasNegocio> LineasNegocio(string idEb, int? idestructura = null)
        {
            ComercialClient comercial = new ComercialClient();
            List<LineasNegocio> lineas = comercial.ListadoLineasNegocio(idEb, idestructura);
            return lineas;
        }

        /// <summary>
        /// Método que elimina las estructuras de venta
        /// </summary>
        /// <param name="user"></param>
        /// <param name="idEb"></param>
        /// <param name="idestructura"></param>
        /// <returns></returns>
        public static bool EliminarEstructuraVenta(string user, string idEb, int? idestructura = null)
        {
            ComercialClient comercial = new ComercialClient();
            return comercial.EliminarEstructurasVentaNegocio(user, idEb, idestructura); 
        }

        /// <summary>
        /// Método que elimina las estructuras de venta
        /// </summary>
        /// <param name="user"></param>
        /// <param name="idEb"></param>
        /// <param name="idestructura"></param>
        /// <returns></returns>
        public static bool EliminarLineas(string user, string idEb, int linea, int? idestructura = null)
        {
            ComercialClient comercial = new ComercialClient();
            return comercial.EliminarLineasNegocio(user, idEb, linea, idestructura);
        }


        public static string CodCliente_CicloEval(string NumIdent, string CodCliente)
        {
            ComercialClient comercial = new ComercialClient();
            return comercial.CodCliente_CicloEval(NumIdent, CodCliente);
        }
    }
}
