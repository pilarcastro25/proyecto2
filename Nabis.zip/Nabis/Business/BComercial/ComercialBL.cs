﻿using Nabis_BS.NabWSComercial;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Nabis_BS.BComercial
{
	public class ComercialBL
	{
		#region Funciones

		/// <summary>
		/// Método para la Obtencion de las Modalidades de Venta
		/// </summary>
		/// <param name="port"></param>
		/// <returns></returns>
		public static List<GenericOption> ObtenerModalidades(int port, string criterio)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				List<GenericOption> result = comercialServicio.ObtenerModalidades(port, criterio);
				return result;
			}
			catch (Exception ex)
			{
				throw new Exception("Error obteniendo las Modalidades de Venta");
			}
		}

		/// <summary>
		/// Método para la Obtencion de las Modalidades de Venta
		/// </summary>
		/// <param name="port"></param>
		/// <returns></returns>
		public static IEnumerable<GenericOption> GetGenericList(string userLogin, string NameView, string Parametros = null)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				IEnumerable<GenericOption> result = comercialServicio.GetGenericList(userLogin, NameView, Parametros);
				return result;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Método para obtener un vendedor a partir del Código y el IdCanal
		/// </summary>
		/// <param name="port"></param>
		/// <returns></returns>
		public static Vendedor GetVendedor(string userLogin, int CodVendedor, int IdCanal)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				Vendedor vendedor = comercialServicio.GetVendedor(userLogin, CodVendedor, IdCanal);
				return vendedor;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		/// Obtener informacion de los documentos obligatorios para un contrato
		/// </summary>
		/// <param name="idTipoContrato">Id Tipo de contrato</param>
		/// <param name="idTipoSolicitud">Id Tipo de solicitud</param>
		/// <param name="idConvenio">Id de Marcacion especial</param>
		/// <param name="esPortabilidad">Es portabilidad</param>
		/// <returns></returns>
		public static List<Documento> Negocio_GetDocumentosCheckList(int idTipoContrato, int idTipoSolicitud, int idConvenio, bool esPortabilidad)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				List<Documento> documentosList = comercialServicio.Negocio_GetDocumentosCheckList(idTipoContrato, idTipoSolicitud, idConvenio, esPortabilidad);
				return documentosList;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		/// <summary>
		///
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static bool CancelarPedido(long idPedido, string usuario, ref string msg)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				bool resultado = comercialServicio.CancelarPedido(idPedido, usuario, ref msg);
				return resultado;
			}
			catch (Exception ex)
			{
				throw new Exception();
			}
		}

		/// <summary>
		///
		/// </summary>
		/// <param name="obj"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static bool EditarLineasDelPedido(string usuario, string idEb, string idPedido, string idLinea, string accion, ref string msg)
		{
			try
			{
				ComercialClient comercialServicio = new ComercialClient();
				bool resultado = comercialServicio.EditarLineasDelPedido(usuario, idEb, idPedido, idLinea, accion, ref msg);
				return resultado;
			}
			catch (Exception ex)
			{
				throw new Exception();
			}
		}

		#endregion Funciones
	}
}