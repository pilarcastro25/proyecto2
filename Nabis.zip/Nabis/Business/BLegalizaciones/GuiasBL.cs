﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;
using System.Data;

namespace Nabis_BS.BLegalizaciones
{
    public class GuiasBL
    {

        /// <summary>
        /// Desembalar guia
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool DesembalarGuia(long idGuia, int ind,int corp, int opc,int fija, int idCiudadOrigen, string  codigoAgent, string  nota, string  novedades, string  usuario)
        {
            try
            {
                GuiaDetalle obj = new GuiaDetalle
                {
                    idGuia=idGuia,
                    ind=ind,
                    corp=corp,
                    opc=opc,
                    fija=fija,
                    idCiudadOrigen=idCiudadOrigen,
                    codigoAgente=codigoAgent,
                    nota=nota,
                    novedades=novedades,
                    usuario=usuario
                };
                
                
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.DesembalarGuia(obj);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Cambios de valores en las guias.
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool IngresarCambioVentaGuia(string guia,string producto,string operacion,int cantidad,string usuario)
        {
            try
            {

                GuiasCambioVentas obj = new GuiasCambioVentas { 
                    trans=1,
                    numGuia=guia,
                    producto=producto,
                    operacion=operacion,
                    cantidad=cantidad,
                    usuario=usuario
                };
               


                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.IngresarCambioVentaGuia(obj);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar las solicitudes de cambio en las ventas de las guias..
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GuiasCambioVentas> ListarGuiasCambioVentas(int trans, string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GuiasCambioVentas> result = objLegalizacion.ListarGuiasCambioVentas(trans, usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Gestion de Cambios de guia.
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool GestionCambioVentaGuia(int id,int trans,string usuario,string observacion)
        {
            try
            {

                GuiasCambioVentas obj = new GuiasCambioVentas
                {
                    id=id,
                    trans=trans,
                    usuario = usuario,
                    observacion=observacion
                };



                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.GestionCambioVentaGuia(obj);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar las solicitudes de cambio en las ventas de las guias..
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GuiasAuditoria> ListaGuiaAuditoria(string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GuiasAuditoria> result = objLegalizacion.ListaGuiaAuditoria(usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }





        

         /// <summary>
        /// Método para listar los detalles de una guia (lista los pendientes).
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GuiaDetalle> ListaDetalleGuia(GuiaDetalle obj)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GuiaDetalle> result = objLegalizacion.ListaDetalleGuia(obj.idGuia,obj.guia,obj.usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Método para listar Agentes
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GenericOption> ListarAgentes()
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GenericOption> result = objLegalizacion.AgentesListar();
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar Ciudades
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GenericOption> ListarCiudades()
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GenericOption> result = objLegalizacion.CiudadesListar();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

     
    }
}
