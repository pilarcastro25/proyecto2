﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class CajasBL
    {


        /// <summary>
        /// Inserta nueva caja
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertarCaja(Caja caja,ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.InsertarCaja(caja,ref msg);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Cerrar la caja
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool CerrarCaja(Caja caja)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CerrarCaja(caja);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Cambiar contenido de la caja
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool CambiarContenidoCaja(Caja caja)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CambiarContenidoCaja(caja);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Iniciar punteo de la caja
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InicioPunteoCaja(Caja caja)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.InicioPunteoCaja(caja);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Cierra punteo de la caja
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool CierrePunteoCaja(Caja caja)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CierrePunteoCaja(caja);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Despacho de cajas
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool DespachoDeCaja(Caja caja)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.DespachoDeCaja(caja);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Método para listar las solicitudes de cambio en las ventas de las guias..
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<Caja> ListarCajas(Caja caja)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Caja> result = objLegalizacion.CajasListar(caja);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// LISTAR EL TIPO DE CONTENIDO DE LAS CAJAS.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<CajasContenidos> CajasContenidoListar(CajasContenidos objContenido)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<CajasContenidos> result = objLegalizacion.CajasContenidoListar(objContenido);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Despacho de cajas
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool CajasContenidoIngresar(CajasContenidos objContenido)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CajaContenidoIngresar(objContenido);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// EDITAR TABLA TIPO DE CONTENIDO DE LAS CAJAS.
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool CajasContenidoEditar(CajasContenidos objContenido)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CajaContenidoIngresar(objContenido);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

    }
}
