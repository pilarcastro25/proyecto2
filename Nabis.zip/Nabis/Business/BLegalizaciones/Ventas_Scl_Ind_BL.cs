﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class Ventas_Scl_Ind_BL
    {


        /// <summary>
        /// Método para buscar una venta por alguno de estos filtros
        /// </summary>
        /// <param name="usuario">
        /// string celular,     celuar del cliente (Opcional)
        /// string imei,        imei asignado (Opcional)
        /// string idCliente,   Número de identificacion de cliente (Opcional)
        /// string simcard,     simcard del cliente (Opcional)
        /// string codAbonado,  codigo de abonado (Opcional)
        /// string usuario      usuario que realiza consulta (obligatorio)
        /// /// </param>
        /// <returns></returns>
        public static IEnumerable<Ventas_Scl_Ind> ListarVentasSclInd(Ventas_Scl_Ind objVentas)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Ventas_Scl_Ind> result = objLegalizacion.ListarVentasSclInd(objVentas);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// gestionar una venta_scl_ind
        /// </summary>
        /// <param name="datos">
        ///  string guia="123";             // obligatorio  -  string
        ///  int codAbonado = 78925884;     // obligatorio -    int
        ///  int saldo_scl = 0;             // obligatorio - int
        ///  bool muestra = false;          // por defecto es 0=false 1=verdadero
        ///  bool novedad = false;          // por defecto es 0=false 1=verdadero
        ///  string notas = null;           // porque se da la novedad  -  stgring admite null
        ///  string causales = null;        // causales de novedad  -  string admite null (1,2,3,4,5,6,)
        ///  string usuario = "NH004645";   // obligatorio. usuario en la plataforma
        /// 
        /// </param>
        /// <returns></returns>
        public static bool GestionVentasSclInd(Ventas_Scl_Ind_Gestion obj, ref string msg)
        {
            try
            {
               
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.VentasSclIndGestion(obj,ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


     
    }
}


