﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class OpcBL
    {


        /// <summary>
        /// INSERTAR FORMATO OPC
        /// </summary>
        /// <param>
        /// string user = "NH004645";           //User
        /// string guia = "123";                //Guia
        /// long formato = 12345678;            //NumFormato
        /// string nit = "12345-6";             //Nit
        /// int cant_opc = 23;                  //CantOpc
        /// bool novedad = false;               //Novedad
        /// string notas = "NOVEDAD 28";        //Notas             Observacion de novedad
        /// string causales = "11,22,33";       //Causales          Concatenado de id de causales novedad.
        /// string canal = "FISICO";            //Canal
        /// int cod_vend = 0001;                //CodVend
        /// string nom_vend = "PRUEBAS";        //NomVend
        /// string nom_grupo = "PRUEBAS_1";     //NomGrupo
        /// string cod_comis = "COD0001";       //CodComis
        /// string tipo_comis = "PROPIO";       //TipoComis
        /// string cod_agente = "A01BC02";      //CodAgente
        /// string nom_agente = "VENDEDOR";     //NomAgente
        /// </param>
        /// <returns></returns>
        public static bool InsertarFormato(Opc_Formato formato,ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.OpcInsertarFormato(formato, ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// ACTUALIZAR FORMATO OPC
        /// </summary>
        /// <param>
        /// string = "NH004645";    // User:        Usuario que gestiona.
        /// long idformato=1;       // IdFormato:   Pk formato a actualizar.
        /// int cant=-3;            // CantTotal:   Cantidad entera (+ / -) ejemplo cant=-2;  cant=5
        /// </param>
        /// <returns></returns>
        public static bool ActualizarFormato(Opc_Formato formato, ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.OpcActualizarFormato(formato, ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// CERRAR FORMATO OPC
        /// </summary>
        /// <param >
        /// string user = "NH004645";   // User:        usuario que gestiona
        /// long formato = 1234567;     // IdFormato:   id formulario pk
        ///</param>
        /// <returns></returns>
        public static bool CerrarFormato(Opc_Formato formato, ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.OpcCerrarFormato(formato, ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// ELIMINAR FORMATO OPC --  siempre y cuando no tenga OPC´s asociadas a el
        /// </summary>
        /// <param >
        /// string user = "NH004645";   // User:        usuario que gestiona
        /// long idFormato = 1;         // IdFormato:   Id formato (PK)
        /// string guia = "123";        // Guia:        número de guía.
        /// </param>
        /// <returns></returns>
        public static bool EliminarFormato(Opc_Formato formato, ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.OpcEliminaFormato(formato,ref msg);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// LISTAR FORMATO - el UserIngreso es la vista Analista sólo verá los formatos crados por él y en estado abierto
        ///                  Admin tendrá acceso a los formatos cerrados con novedad.
        /// </summary>
        /// <param >
        /// long formato = 12345678;            //Num_Formato.
        /// string nit = "12345-6";             //Nit.
        /// string userIngreso = "Analista";    //UserIngreso:  Analista/Admin
        /// string usuario = "NH004645";        //User:         Usuario que gestiona.
        /// </param>
        /// <returns></returns>
        public static IEnumerable<Opc_Formato> ListarFormato(Opc_Formato objformato)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Opc_Formato> result = objLegalizacion.OpcListarFormato(objformato);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        //----- CONSULTA DE LA TABLA OPC_TMP -----//

        /// <summary>
        /// LISTAR OPC_TMP RESULTADO BÁSICO
        /// </summary>
        /// <param>
        /// long ooss = 0;                  //Ooss:     --- 0  opcional
        /// long celular = 0;               //Celular:  --- 0  opcional
        /// string nit = "900470318-7";     //Nit:       REQUERIDO
        /// string usuario = "NH004645";    //User:      REQUERIDO
        /// </param>
        /// <returns></returns>
        public static IEnumerable<Opc> OpcListarIngresoTransaccion(Opc objOpc)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Opc> result = objLegalizacion.OpcListarIngresoTransaccion(objOpc);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// LISTAR OPC_TMP RESULTADO DETALLADO
        /// </summary>
        /// <param>
        /// long id = 23;                   //Id:   ID TABLA OPC_TMP
        /// string usuario = "NH004645";    //User: USUARIO QUE REALIZA CONSULTA.
        /// </param>
        /// <returns></returns>
        public static IEnumerable<Opc> OpcListarIngresoTransaccionDetalle(Opc objOpc)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Opc> result = objLegalizacion.OpcListarIngresoTransaccionDetalle(objOpc);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// INSERTAR OPC AL FORMATO.
        /// </summary>
        /// <param>
        ///  long idformato = 123;          //IdFormato:    Id del formato (pk)
        ///  string idOpcTmp = "1,2,3,4";   //IdOpcTmp:     id de la tabla OPC_TMP a ingresar.
        ///  string usuario = "NH004645";   //User:         usuario que realiza la gestión
        /// </param>
        /// <returns></returns>
        public static bool OpcTransaccionIngresoAlFormato(Opc objformato, ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.OpcTransaccionIngresoAlFormato(objformato, ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

    }
}
