﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;


namespace Nabis_BS.BLegalizaciones
{
    public class PaquetesBL
    {

        #region Métodos estáticos
        /// <summary>
        /// Insertar beneficios a lineas
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertarPaquete(String usuario)
        {
            try
            {
                PaqueteGuias paquete = new PaqueteGuias();
                paquete.IdPaquete=-1;
                paquete.UserIngreso=usuario;
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.IngresarPaquete(paquete);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar los paquetes creados.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<PaqueteGuias> ListarPaquetes(string vista, int estado,string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<PaqueteGuias> result = objLegalizacion.ObtenerPaqueteGuias(vista, estado, usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Insertar guias al paquete seleccionado.
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool InsertarGuiasPaquete(int trans, string guias, int idPaquete, string usuario)
        {
            try
            {
                Guia guia = new Guia();
                guia.trans=trans;
                guia.guias=guias;
                guia.idPaquete=idPaquete;
                guia.user=usuario;

                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.IngresarGuiasPaquete(guia);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar los usuarios.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<Usuario> ListarUsuarios(string vista, string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Usuario> result = objLegalizacion.ListarUsuarios(vista,usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



        /// <summary>
        /// Asignar paquete guias.
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool AsignarGuiasPaquete(int trans, int idPaquete, string usuario,string usuarioAsignado,string guias)
        {
            try
            {

                Guia guia = new Guia();
                guia.trans = trans;
                guia.idPaquete = idPaquete;
                guia.user = usuario;
                guia.userAsignado = usuarioAsignado;
                guia.guias = guias;

                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.AsignarGuiasPaquete(guia);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar las guias de un paquete.
        /// ya sea por id paquete o por usuario.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GuiaDetalle> ListarGuiasDelPaquete(string vista, string userAsignado, string user)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GuiaDetalle> result = objLegalizacion.ListarGuias(vista,userAsignado,user);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Método para listar las guias de un paquete.
        /// ya sea por id paquete o por usuario.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GuiaDetalle> ListarGuiasSinAsignar(string user)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GuiaDetalle> result = objLegalizacion.ListarGuiasSinAsignar(user);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        #endregion
    }
}
