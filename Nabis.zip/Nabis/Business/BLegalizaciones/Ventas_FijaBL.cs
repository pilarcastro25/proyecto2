﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class Ventas_FijaBL
    {

        /// <summary>
        /// Método para buscar una venta por alguno de estos filtros
        /// </summary>
        /// <param name="usuario">
        /// string celular,     celuar del cliente (Opcional)
        /// string imei,        imei asignado (Opcional)
        /// string idCliente,   Número de identificacion de cliente (Opcional)
        /// string simcard,     simcard del cliente (Opcional)
        /// string codAbonado,  codigo de abonado (Opcional)
        /// string usuario      usuario que realiza consulta (obligatorio)
        /// /// </param>
        /// <returns></returns>
        public static IEnumerable<Fija> Buscar_Fija(Fija objFija)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Fija> result = objLegalizacion.FijaBusar(objFija);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// gestionar una venta_scl_ind
        /// </summary>
        /// <param name="datos"></param>
        /// <returns></returns>
        public static bool Fija_insertar(Fija_Insertar fija, ref string msg)
        {
            try
            {

                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.Fija_Insertar(fija, ref msg);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



    }
}
