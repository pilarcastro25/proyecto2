﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class ReportesBL 
    {


        /// <summary>
        /// metodo para cambiar el estado de una alerta
        /// </summary>
        /// <param name="datos">
        /// IdCondicion     --> PK de la condicion de la alerta
        /// Estado          --> Estado al cual se desea pasar. 1: Activo  0: Inactivo.
        /// </param>
        /// <returns></returns>
        public static bool GenerarReporte(Reportes objReporte)
        {
            try
            {
                /// segun el nombre del reporte a generar obtenemos el id de transacción.
                for (int i = 0; i < MatrizTransaccion.GetLength(0); i++)
                {

                    if (MatrizTransaccion[i,0].Equals(objReporte.NomArchivo))
                    {
                        objReporte.trans = Convert.ToInt32(MatrizTransaccion[i, 1]);
                        break;
                    }
                }



                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.GenerarReporte(objReporte);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }




                                                               //{ "nom archivo", "id trans" }
        static string[,] MatrizTransaccion = new string[6, 2] {  { "Novedades_Ventas_Fijas",                "1" }
                                                                ,{ "Estatus_Captura_SoloDatos_Mensual",     "2" }
                                                                ,{ "Novedades_Ventas_Individuales",         "3" }
                                                                ,{ "Ventas_Pdtes_Por_Legalizar",            "4" }
                                                                ,{ "Ventas_Corporativas_Bandeja_Vs_Pdtes",  "5" }
                                                                ,{ "Estatus_Ventas_Cero_Papel",             "6" }
                                                              };


    }
}
