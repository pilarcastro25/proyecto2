﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;


namespace Nabis_BS.BLegalizaciones
{
    public class InsumosBL
    {

        /// <summary>
        /// Lista el histórico diario del cargue de los insumos 
        /// </summary>
        /// <param name="obj"> // se requiere enviar el usuario que consulta.</param>
        /// <returns></returns>
        public static IEnumerable<Insumos> ListaHistoricoInsumos(Insumos obj)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Insumos> result = objLegalizacion.ListaHistoricoInsumos(obj);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

      
        public static bool CargarInsumo(Insumos obj, ref string msg)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = false;

                if (obj.NombreInsumo.Equals("AtisDwh"))
                { resultado = objLegalizacion.CargarInsumoAtisDwh(obj.Usuario, ref msg); }

                else if (obj.NombreInsumo.Equals("CeroPapel"))
                { resultado = objLegalizacion.CargarInsumoCeroPapel(obj.Usuario, ref msg); }

                else if (obj.NombreInsumo.Equals("Llamadas"))
                { resultado = objLegalizacion.CargarInsumoLlamadas(obj.Usuario, ref msg); }

                else if (obj.NombreInsumo.Equals("MovilLeg"))
                { resultado = objLegalizacion.CargarInsumoMovilLeg(obj.Usuario, ref msg); }

                else if (obj.NombreInsumo.Equals("MovilPendLeg"))
                { resultado = objLegalizacion.CargarInsumoMovilPendLeg(obj.Usuario, ref msg); }

                else if (obj.NombreInsumo.Equals("CeroPapelAgentes"))
                { resultado = objLegalizacion.CargarInsumoCeroPapelAgentes(obj.Usuario, ref msg); }
                
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        public static void TratamientoInsumos(string insumo)
        {
            try
            {

                Legalizacion objLegalizacion = new LegalizacionClient();
                objLegalizacion.TratarInsumoMovilPendLeg(insumo);
                //if (insumo.Equals("MovilPendLeg"))
                //{ objLegalizacion.TratarInsumoMovilPendLeg(); }

                //else if (insumo.Equals("AtisDwh"))
                //{ string valor = "prueba"; }

                //else if (insumo.Equals("CeroPapel"))
                //{ string valor = "prueba"; }

                //else if (insumo.Equals("Llamadas"))
                //{ string valor = "prueba"; }

                //else if (insumo.Equals("MovilLeg"))
                //{ string valor = "prueba"; }



            }
            catch (Exception e)
            { throw new Exception(); }
        }
                    

    }
}
