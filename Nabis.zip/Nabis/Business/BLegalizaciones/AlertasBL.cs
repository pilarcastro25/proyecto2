﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSLegalizacion;

namespace Nabis_BS.BLegalizaciones
{
    public class AlertasBL
    {



        /// <summary>
        /// Método para listar Causales de Novedad
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GenericOption> CausalesNovedadListar(int tipoProducto)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GenericOption> result = objLegalizacion.CausalesNovedadListar(tipoProducto);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Método para listar Causales de Novedad
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<GenericOption> TiposProductoListar()
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GenericOption> result = objLegalizacion.ListarTipoProducto();
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// Insertar alerta
        /// </summary>
        /// <param>
        /// IdProducto      --> Tipo de producto al que aplica la alerta
        /// MsgAlerta       --> Mensaje que mostrará la alerta.
        /// Usuario         --> Usuario que parametriza la alerta
        /// Usuario         --> Usuario que realiza el cambio.
        /// </param>
        /// <returns></returns>
        public static bool InsertarAlerta(Alertas objAlerta)
        {
            try
            {

                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.InsertarAlerta(objAlerta);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// Método para listar alertas parametrizadas..
        /// </summary>
        /// <param>
        /// Usuario     --> Usuario que Visualiza todas las alertas activas o inactivas.
        /// </param>
        /// <returns></returns>
        public static IEnumerable<Alertas> ListarAleras(Alertas objAlerta)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<Alertas> result = objLegalizacion.ListarAlertas(objAlerta);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// metodo para cambiar el estado de una alerta
        /// </summary>
        /// <param>
        /// IdAlerta    --> Pk de la tabla, id al cual se va a cambiar el estado.
        /// Estado      --> Estado al que cambiará la alerta.
        /// Usuario     --> Usuario que realiza la gestión.
        /// </param>
        /// <returns></returns>
        public static bool CambiarEstadoAlerta(Alertas objAlerta)
        {
            try
            {

                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CambiarEstadoAlerta(objAlerta);
                return resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Método para listar los campos segun el id de la alerta y el tipo.
        /// IdAlerta    --> PK de la alerta a la que se le pone la condición.
        /// Usuario     --> Usuario en gestion
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        public static IEnumerable<AlertaCondiciones> ListarCampos(AlertaCondiciones obj)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<AlertaCondiciones> result = objLegalizacion.ListarCampos(obj);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        /// <summary>
        /// Método para listar los valores del campo selecionado.
        /// ESTE MÉTODO YA NO SE VA A UTLIZAR, SE DEJA QUE LO PUEDAN DIGITAR 
        /// PARA PODER CREAR UNA ALERTA ANTES DE QUE EXISTAN VALORES EN EL CAMPO.
        /// </summary>
        /// <param name="usuario"></param>
        /// <returns></returns>
        /*
        public static IEnumerable<AlertaCondiciones> ListarValores(int trans, int idAlerta, string campo, string usuario)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<AlertaCondiciones> result = objLegalizacion.ListarValores(trans, idAlerta, campo, usuario);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        */

        /// <summary>
        /// Insertar Condicion alerta
        /// </summary>
        /// <param >
        /// Campo       --> Campo seleccionado de la tabla den el ddl (tipo string)
        /// Operador    --> Accion a ejecutar (string)
        /// Valor       --> Dato digitado por el usuario el cual debe ser comparado con la venta.
        /// IdAlerta    --> PK id de la alerta a la cual corresponde la condición.
        /// Usuario     --> Usuario en gestion.
        /// </param>
        /// <returns></returns>
        public static bool InsertarAlertaCondicion(AlertaCondiciones obj)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.InsertarAlertaCondicion(obj);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        
        /// <summary>
        /// Método para listar condiciones de la alerta parametrizada.
        /// </summary>
        /// <param name="usuario">
        /// IdAlerta        --> Pk id de alerta 
        /// Usuario         --> Usuario en gestión.
        /// </param>
        /// <returns></returns>
        public static IEnumerable<AlertaCondiciones> ListarCondicionesAlerta(AlertaCondiciones obj)
        {
            try
            {
                //Nabis_BS.NabWSBeneficios.BandejaBeneficios
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<AlertaCondiciones> result = objLegalizacion.ListarCondicionesAlerta(obj);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }


        /// <summary>
        /// metodo para cambiar el estado de una alerta
        /// </summary>
        /// <param name="datos">
        /// IdCondicion     --> PK de la condicion de la alerta
        /// Estado          --> Estado al cual se desea pasar. 1: Activo  0: Inactivo.
        /// </param>
        /// <returns></returns>
        public static bool CambiarEstadoCondicion(AlertaCondiciones obj)
        {
            try
            {
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                bool resultado = objLegalizacion.CambiarEstadoCondicion(obj);
                return true;//resultado;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }




        public static IEnumerable<GenericOption> ListaMsgAlerta(long pkVenta, int tipoProdcuto)
        {
            try
            {
                
                LegalizacionClient objLegalizacion = new LegalizacionClient();
                IEnumerable<GenericOption> result = objLegalizacion.ListaMsgAlerta(pkVenta,tipoProdcuto);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }



    }
}
