﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Nabis_BS.NabWSRobotActivaciones;
using Nabis_BS.NabWSSCL;
using Nabis.Utilities;

namespace Nabis_BS.BRobot
{
    public class ActivacionesRobotBL
    {
        #region Métodos estáticos

        public IEnumerable<Linea> ConsultarLineas(string user, string estado)
        {
            try
            {
                RobotActivacionesClient RobotClient = new RobotActivacionesClient();
                IEnumerable<Linea> lstLineas = RobotClient.ConsultarLineas(user, estado);
                return lstLineas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GenerarPlantilla(IEnumerable<Linea> lstLineas, string user, string descripcion)
        {
            try
            {
                IEnumerable<TramaActivaciones> plantillaCuentas = null;
                RutasPlantillas oRuta = new RutasPlantillas();
                oRuta = ConsultarRuta(user, descripcion);
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                if (lstLineas.Count() > 0)
                {
                    var negocios = lstLineas.GroupBy(p => p.IdEb).Select(y => y.First()).Distinct();
                    foreach (var item in negocios)
                    {

                        RobotActivacionesClient RobotClient = new RobotActivacionesClient();
                        if (descripcion == "CUENTAS POSPAGO")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarCuentasPostpago(user, item.IdEb);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "CUENTAS PREPAGO")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarCuentasPrepago(user, item.IdEb);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "CONTACTOS AUTORIZADOS")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarContactosAutorizados(user, item.IdEb);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "CAMBIO USO")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultaCambioUso(user, item.IdEb);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "PRECHEQUEO")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultaPrechequeo(user, item.IdEb);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "PREPAGO NO PORTADOS")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarPrepagoNoPortados(user, item.IdEb);
                            ActualizarEstadoLinea(plantillaCuentas, lstLineas, user);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "PREPAGO PORTADOS")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarPrepagoPortados(user, item.IdEb);
                            ActualizarEstadoLinea(plantillaCuentas, lstLineas, user);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                        else if (descripcion == "POSTPAGO NO PORTADOS")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarPostpagoNoPortados(user, item.IdEb);
                            //ActualizarEstadoLinea(plantillaCuentas, lstLineas, user);

                            List<TramaActivaciones> postPagoCerrado = null;
                            List<TramaActivaciones> postPagoAbierto = null;
                            postPagoCerrado = plantillaCuentas.Where(e => e.TipoPlan.Contains("CUENTA")).ToList();
                            ExportarPlantilla(postPagoCerrado, descripcion, oRuta, item.IdEb);
                            postPagoAbierto = plantillaCuentas.Where(e => e.TipoPlan.Contains("POSTPAGO")).ToList();
                            ExportarPlantilla(postPagoAbierto, descripcion, oRuta, item.IdEb);                            
                        }
                        else if (descripcion == "POSTPAGO PORTADOS")
                        {
                            Console.WriteLine("Generando Plantilla " + descripcion + " Del Negocio: " + item.IdEb);
                            plantillaCuentas = RobotClient.ConsultarPostpagoPortados(user, item.IdEb);
                            ActualizarEstadoLinea(plantillaCuentas, lstLineas, user);
                            ExportarPlantilla(plantillaCuentas, descripcion, oRuta, item.IdEb);
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private void ExportarPlantilla(IEnumerable<TramaActivaciones> plantillaCuentas, string descripcion, RutasPlantillas oRuta, string IdEb)
        {
            try
            {
                Console.WriteLine("Crear Directorio");
                string sRuta = oRuta.RutaPlantilla + "\\" + Convert.ToString(DateTime.Now.Year) + "\\" + Convert.ToString(DateTime.Now.Month) + "\\" + Convert.ToString(DateTime.Now.Day) + "\\";
                Nabis.Utilities.GestionarArchivos.CrearCarpeta(sRuta);
                Console.WriteLine("Exportando Plantilla " + descripcion + " Del Negocio: " + IdEb);
                if (descripcion == "POSTPAGO NO PORTADOS")
                {
                    if (plantillaCuentas.Count() > 10)
                    {
                        double cantRegistros = plantillaCuentas.Count();
                        List<string> oAux = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}{4}", x.TipoPlan, x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        List<string> obj = null;
                        int contador = 0;
                        foreach (string item in oAux)
                        {
                           obj.Add(item);
                           contador++;
                           if (contador == 10 && cantRegistros > 10)
                           {
                                cantRegistros = cantRegistros - 10;
                                string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                                sRuta = sRuta + sNombreArchivo;
                                Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                                contador = 0;
                                obj.Clear();
                           }
                           else if (cantRegistros < 10)
                           {
                               string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                               sRuta = sRuta + sNombreArchivo;
                               Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                               contador = 0;
                               obj.Clear();
                           }
                        }
                    }
                    else
                    {                        
                        string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                        sRuta = sRuta + sNombreArchivo;
                        List<string> obj = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}{4}", x.TipoPlan, x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                    }
                }
                else
                {
                    if (plantillaCuentas.Count() > 0)
                    {
                        string sNombreArchivo = oRuta.NombreArchivo + Convert.ToString(DateTime.Now.Year) + Convert.ToString(DateTime.Now.Month) + Convert.ToString(DateTime.Now.Day) + Convert.ToString(DateTime.Now.Minute) + Convert.ToString(DateTime.Now.Second);
                        sRuta = sRuta + sNombreArchivo;
                        List<string> obj = plantillaCuentas.Select(x => string.Format("{0}{1}{2}{3}", x.Trama0, x.Trama1, x.Trama2, x.Trama3)).ToList();
                        Nabis.Utilities.GestionarArchivos.GenerarPlantillaRobot(sRuta, obj);
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        
        private void ActualizarEstadoLinea(IEnumerable<TramaActivaciones> plantillaCuentas, IEnumerable<Linea> lstLineas, string user)
        {
            try
            {
                RobotActivacionesClient RobotClient = new RobotActivacionesClient();
                int resultado = 0;
                foreach (TramaActivaciones item in plantillaCuentas)
                {
                    var linea = lstLineas.Where(e => e.Id == item.Id);
                    foreach (var l in linea)
	                {
		                l.IdEstado = 33;
                        l.UsuarioDescarga = user;
                        resultado = RobotClient.ActualizarEstadoLineaRobot(l);
	                }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

      

        private RutasPlantillas ConsultarRuta(string user, string descripcion)
        {
            RobotActivacionesClient RobotClient = new RobotActivacionesClient();
            IEnumerable<RutasPlantillas> ruta = null;
            RutasPlantillas oRuta = null;
            try
            {
                ruta = RobotClient.ConsultarRutasPlantillas(user, descripcion);
                foreach (RutasPlantillas item in ruta)
                {
                    oRuta = new RutasPlantillas();
                    oRuta.RutaPlantilla = item.RutaPlantilla;
                    oRuta.NombreArchivo = item.NombreArchivo;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return oRuta;
        }

        public void ValidarActivacionLinea(Linea linea, string user)
        {
            RobotActivacionesClient RobotClient = new RobotActivacionesClient();
            SCLClient oSCLClient = new SCLClient();
            IEnumerable<LineasAAA> lineaAAA = null;
            int resultado = 0;
            try
            {
                lineaAAA = oSCLClient.LineaAAA(linea.Imei, linea.SimCard);
                if (lineaAAA.Count() > 0)
                {
                    foreach (LineasAAA item in lineaAAA)
                    {                       
                        linea.UsuarioDescarga = user;
                        if (item.COD_SITUACION != "BAA")
                        {                            
                            //Cambiar estado de la linea a activada por robot  Activado por Robot
                            linea.IdEstado = 34;
                            resultado = RobotClient.ActualizarEstadoLineaRobot(linea);
                        }
                        else
                        {
                            if (linea.Reproceso >= 3)
                            {
                                //Cambiar estado de la linea a Proceso Fallido en Robot
                                linea.IdEstado = 35;
                                resultado = RobotClient.ActualizarEstadoLineaRobot(linea);
                            }
                        }
                    }
                }
                else
                {
                    //Cambiar estado de la linea a Proceso Fallido en Robot
                    if (linea.Reproceso >= 3)
                    {
                        //Cambiar estado de la linea a Proceso Fallido en Robot
                        linea.IdEstado = 35;
                        resultado = RobotClient.ActualizarEstadoLineaRobot(linea);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        
    }
}
